#ifndef _included_GridFunctionOps3_h
#define _included_GridFunctionOps3_h

/*
*************************************************************************
*                                                                       *
* GridFunctionOps3.h                                                    *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/************************************************************************************/
/* Fill */
/************************************************************************************/
template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_Fill(DAGH_GFType const &val, 
                                    int const time, int const level,
                                    int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) (gdb[t][l][i]->griddata(ident)).fill(val);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_Fill(DAGH_GFType const &val, 
                                    int const time, int const level,
                                    int const mgl, int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) (gdb[t][l][i]->griddata(mgl,ident)).fill(val);
  }

/************************************************************************************/

/************************************************************************************/
/* Copy */
/************************************************************************************/
template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_Copy(int const t1, int const l1, 
                                    GridFunction(3)<DAGH_GFType> const &rhs,
                	            int const t2, int const l2, 
                                    BBox const &where,
                                    int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int time1 = dagh_timeindex(t1,l1);
   register int time2 = rhs.dagh_timeindex(t2,l2);
   for (register int i=0; i<length; i++)
     if (gdb[time1][l1][i] && rhs.gdb[time2][l2][i]) 
	(gdb[time1][l1][i]->griddata(ident)).copy(
           rhs.gdb[time2][l2][i]->griddata(ident),alignedwhere);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_Copy(int const t1, int const l1, 
                                    GridFunction(3)<DAGH_GFType> const &rhs,
                	            int const t2, int const l2, 
                                    int const ident)
  {
   register int time1 = dagh_timeindex(t1,l1);
   register int time2 = rhs.dagh_timeindex(t2,l2);
   for (register int i=0; i<length; i++)
     if (gdb[time1][l1][i] && rhs.gdb[time2][l2][i]) 
	(gdb[time1][l1][i]->griddata(ident)).copy(rhs.gdb[time2][l2][i]->griddata(ident));
  }
/************************************************************************************/

/************************************************************************************/
/* Equals */
/************************************************************************************/
template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_equals(int const time, int const level, 
                                             BBox const &where, 
                                             DAGH_GFType const &val,
                                             int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
     (gdb[t][l][i]->griddata(ident)).equals(val,alignedwhere);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_equals(int const time, int const level, 
                                             DAGH_GFType const &val,
                                             int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) (gdb[t][l][i]->griddata(ident)).equals(val);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_equals(int const t1, int const l1, 
                                             GridFunction(3)<DAGH_GFType> const &rhs,
                	                     int const t2, int const l2, 
                                             BBox const &where,
                                             int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int time1 = dagh_timeindex(t1,l1);
   register int time2 = rhs.dagh_timeindex(t2,l2);
   for (register int i=0; i<length; i++)
     if (gdb[time1][l1][i] && rhs.gdb[time2][l2][i]) 
       (gdb[time1][l1][i]->griddata(ident)).equals(
         rhs.gdb[time2][l2][i]->griddata(ident),alignedwhere);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_equals(int const t1, int const l1, 
                                             GridFunction(3)<DAGH_GFType> const &rhs,
                	                     int const t2, int const l2, 
                                             int const ident)
  { 
   register int time1 = dagh_timeindex(t1,l1);
   register int time2 = rhs.dagh_timeindex(t2,l2);
   for (register int i=0; i<length; i++)
     if (gdb[time1][l1][i] && rhs.gdb[time2][l2][i]) 
	(gdb[time1][l1][i]->griddata(ident)).equals(rhs.gdb[time2][l2][i]->griddata(ident));
  }
/************************************************************************************/

/************************************************************************************/
/* Plus */
/************************************************************************************/
template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_plus(int const time, int const level, 
                                           BBox const &where,
                                           DAGH_GFType const &val,
                                           int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) (gdb[t][l][i]->griddata(ident)).plus(val,alignedwhere);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_plus(int const time, int const level, 
                                           DAGH_GFType const &val,
                                           int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) (gdb[t][l][i]->griddata(ident)).plus(val);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_plus(int const t1, int const l1, 
                                           GridFunction(3)<DAGH_GFType> const &rhs,
                	                   int const t2, int const l2, 
                                           BBox const &where,
                                           int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int time1 = dagh_timeindex(t1,l1);
   register int time2 = rhs.dagh_timeindex(t2,l2);
   for (register int i=0; i<length; i++)
     if (gdb[time1][l1][i] && rhs.gdb[time2][l2][i]) 
       (gdb[time1][l1][i]->griddata(ident)).plus(
         rhs.gdb[time2][l2][i]->griddata(ident),alignedwhere);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_plus(int const t1, int const l1, 
                                           GridFunction(3)<DAGH_GFType> const &rhs,
                	                   int const t2, int const l2, 
                                           int const ident)
  { 
   register int time1 = dagh_timeindex(t1,l1);
   register int time2 = rhs.dagh_timeindex(t2,l2);
   for (register int i=0; i<length; i++)
     if (gdb[time1][l1][i] && rhs.gdb[time2][l2][i]) 
	(gdb[time1][l1][i]->griddata(ident)).plus(rhs.gdb[time2][l2][i]->griddata(ident));
  }
/************************************************************************************/

/************************************************************************************/
/* Minus */
/************************************************************************************/
template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_minus(int const time, int const level, 
                                           BBox const &where,
                                           DAGH_GFType const &val,
                                           int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
     (gdb[t][l][i]->griddata(ident)).minus(val,alignedwhere);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_minus(int const time, int const level, 
                                           DAGH_GFType const &val,
                                           int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) (gdb[t][l][i]->griddata(ident)).minus(val);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_minus(int const t1, int const l1, 
                                           GridFunction(3)<DAGH_GFType> const &rhs,
                	                   int const t2, int const l2, 
                                           BBox const &where,
                                           int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int time1 = dagh_timeindex(t1,l1);
   register int time2 = rhs.dagh_timeindex(t2,l2);
   for (register int i=0; i<length; i++)
     if (gdb[time1][l1][i] && rhs.gdb[time2][l2][i]) 
       (gdb[time1][l1][i]->griddata(ident)).minus(
         rhs.gdb[time2][l2][i]->griddata(ident),alignedwhere);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_minus(int const t1, int const l1, 
                                           GridFunction(3)<DAGH_GFType> const &rhs,
                	                   int const t2, int const l2, 
                                           int const ident)
  { 
   register int time1 = dagh_timeindex(t1,l1);
   register int time2 = rhs.dagh_timeindex(t2,l2);
   for (register int i=0; i<length; i++)
     if (gdb[time1][l1][i] && rhs.gdb[time2][l2][i]) 
	(gdb[time1][l1][i]->griddata(ident)).minus(rhs.gdb[time2][l2][i]->griddata(ident));
  }
/************************************************************************************/

/************************************************************************************/
/* Multiply */
/************************************************************************************/
template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_multiply(int const time, int const level, 
                                           BBox const &where,
                                           DAGH_GFType const &val,
                                           int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
     (gdb[t][l][i]->griddata(ident)).multiply(val,alignedwhere);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_multiply(int const time, int const level, 
                                           DAGH_GFType const &val,
                                           int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) (gdb[t][l][i]->griddata(ident)).multiply(val);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_multiply(int const t1, int const l1, 
                                           GridFunction(3)<DAGH_GFType> const &rhs,
                	                   int const t2, int const l2, 
                                           BBox const &where,
                                           int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int time1 = dagh_timeindex(t1,l1);
   register int time2 = rhs.dagh_timeindex(t2,l2);
   for (register int i=0; i<length; i++)
     if (gdb[time1][l1][i] && rhs.gdb[time2][l2][i]) 
       (gdb[time1][l1][i]->griddata(ident)).multiply(
         rhs.gdb[time2][l2][i]->griddata(ident),alignedwhere);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_multiply(int const t1, int const l1, 
                                           GridFunction(3)<DAGH_GFType> const &rhs,
                	                   int const t2, int const l2, 
                                           int const ident)
  { 
   register int time1 = dagh_timeindex(t1,l1);
   register int time2 = rhs.dagh_timeindex(t2,l2);
   for (register int i=0; i<length; i++)
     if (gdb[time1][l1][i] && rhs.gdb[time2][l2][i]) 
	(gdb[time1][l1][i]->griddata(ident)).multiply(rhs.gdb[time2][l2][i]->griddata(ident));
  }
/************************************************************************************/

/************************************************************************************/
/* Divide */
/************************************************************************************/
template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_divide(int const time, int const level, 
                                           BBox const &where,
                                           DAGH_GFType const &val,
                                           int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
     (gdb[t][l][i]->griddata(ident)).divide(val,alignedwhere);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_divide(int const time, int const level, 
                                           DAGH_GFType const &val,
                                           int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) (gdb[t][l][i]->griddata(ident)).divide(val);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_divide(int const t1, int const l1, 
                                           GridFunction(3)<DAGH_GFType> const &rhs,
                	                   int const t2, int const l2, 
                                           BBox const &where,
                                           int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int time1 = dagh_timeindex(t1,l1);
   register int time2 = rhs.dagh_timeindex(t2,l2);
   for (register int i=0; i<length; i++)
     if (gdb[time1][l1][i] && rhs.gdb[time2][l2][i]) 
       (gdb[time1][l1][i]->griddata(ident)).divide(
         rhs.gdb[time2][l2][i]->griddata(ident),alignedwhere);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_divide(int const t1, int const l1, 
                                           GridFunction(3)<DAGH_GFType> const &rhs,
                	                   int const t2, int const l2, 
                                           int const ident)
  { 
   register int time1 = dagh_timeindex(t1,l1);
   register int time2 = rhs.dagh_timeindex(t2,l2);
   for (register int i=0; i<length; i++)
     if (gdb[time1][l1][i] && rhs.gdb[time2][l2][i]) 
	(gdb[time1][l1][i]->griddata(ident)).divide(rhs.gdb[time2][l2][i]->griddata(ident));
  }
/************************************************************************************/

#endif
