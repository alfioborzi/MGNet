#include "defnc.pre"
#include "defnc.v2"

#define DEBUG_KUGENA    0
#define DEBUG_KUGENR    0

/**********************************************************************/

REAL kusoln(x, y) REAL x, y; {

  static REAL pi = 3.141592653589793;

  return (REAL)(exp((double)x) * sin((double)(pi * x)) 
                               * sin((double)(pi * y)));
  }

/**********************************************************************/

ksgena(k, nn, levinf) 
        INT k, *nn;
        struct  stlevinf **levinf;
  {

  INT  i, *ijap, j, kk, lena, n, n1, n2;
  REAL h1, h2, *pa, *px;
#if DEBUG_KUGENA
  REAL *pb;
#endif

  /* set size and matrix type */
  n1 = *nn;
  n2 = *(nn + 1);
  n = n1 * n2;
  NACOLS(k) = n;
  NAROWS(k) = n;
  ATYPE(k)  = 0;

  /* allocate space */
  if ((ijap = PTRIJA(k) = (INT *)malloc(3 * n * sizeof(INT))) == NULL)
    return;
  if ((pa = PTRA(k) = (REAL *)malloc(3 * n * sizeof(REAL))) == NULL) {
    free(PTRIJA(k));
    PTRIJA(k) = NULL;
    return;
    }
  if ((px = PTRX(k) = (REAL *)malloc(n * sizeof(REAL))) == NULL) {
    free(PTRA(k));
    free(PTRIJA(k));
    PTRIJA(k) = NULL;
    PTRA(k) = NULL;
    return;
    }
  if ((PTRB(k) = (REAL *)malloc(n * sizeof(REAL))) == NULL) {
    free(PTRX(k));
    free(PTRA(k));
    free(PTRIJA(k));
    PTRIJA(k) = NULL;
    PTRA(k) = NULL;
    PTRX(k) = NULL;
    return;
    }

  /* get the solution and setup the main diagonal of a */
  h1 = 1. / (n1 + 1);
  h2 = 1. / (n2 + 1);
  for (j = 1; j <= n2; j++)
    for (i = 1; i <= n1; i++) {
      *px++ = kusoln((REAL)i*h1,(REAL)j*h2);
      *pa++ = 4.;
      }
  *pa++ = 0.;

  /* generate upper part of a */
  kk = 1;
  lena = n + 2;
  ijap = PTRIJA(k) - 1;
  pa = PTRA(k) - 1;
  for (j = 0; j < n2; j++)
    for (i = 0; i < n1; i++) {
      *(ijap+kk) = lena;
      if (j) {
        *(ijap+lena) = kk - n1;
        *(pa+lena++) = -1.;
        }
      if (i) {
        *(ijap+lena) = kk - 1;
        *(pa+lena++) = -1.;
        }
      kk++;
      }
  *(ijap+n+1) = lena;
  lena--;

  /* generate rhs b */
  j = 0;
  klax(&j, &n, &n, PTRIJA(k), PTRA(k), PTRX(k), PTRB(k), &ATYPE(k), &i);
  
#if DEBUG_KUGENA
  pa = PTRA(k);
  pb = PTRB(k);
  px = PTRX(k);
  ijap = PTRIJA(k);
  printf("===== gena =====\n");
  printf("n,lena,atype,flag = %d,%d,%d,%d\n", n, lena, 0,  i);
  printf("     i  ija             a             x             b\n");
  for (i = 0; i < n; i++)
    printf(" %5d%5d %13.5e %13.5e %13.5e\n", i+1, *(ijap+i),
                                          *(pa+i), *(px+i), *(pb+i));
  for (i = n; i < lena; i++)
    printf(" %5d%5d %13.5e\n", i+1, *(ijap+i), *(pa+i));
#endif

  }

/**********************************************************************/

ksgenr(k, cols, rows, nnf, nnc, levinf)
        INT  cols, *nnc, *nnf, rows;
        struct  stlevinf **levinf;
  {

  INT  i, *ijrp, j, kk, l, l2, n;
  static REAL desc3[ ] = { 0.,
                           .25, .5, .25, .5, 1., .5, .25, .5, .25,
                           0.
                         };
  static REAL desc4[ ] = { .25, 0., 0., 0., 0., .5, 0., 0., 0., 0., 1., 0.,
                           0., 0.
                         };
  REAL *dp, *rp;

  /* set size and matrix type */
  NRCOLS(k) = cols;
  NRROWS(k) = rows;
  RTYPE(k)  = 4;
  n = *nnc;

  /* allocate space */
  if ((ijrp = PTRIJR(k) = (INT *)malloc((n * n + 30) * sizeof(INT)))
        == NULL)
    return;
  if ((rp = PTRR(k) = (REAL *)malloc(30 * sizeof(REAL))) == NULL) {
    free(PTRIJR(k));
    PTRIJR(k) = NULL;
    return;
    }

  /* store r matrix */
  *rp = 0.;
  switch (RTYPE(k)) {
    case 3:     /* simple stencil */
      dp = desc3;
      l = 11;
      break;
    case 4:     /* complex stencil */
      dp = desc4;
      l = 14;
      break;
    }
  for (i = 1 ; i <= l; i++) {
    *(rp+ i)  = *dp;
    *(rp+l+i) = *dp++;
    }

  /* store simple stencil part of ijr */
  switch (RTYPE(k)) {
    case 3:     /* simple stencil */
      *ijrp      = 23;
      *(ijrp+ 1) = 9;
      *(ijrp+ 2) = 0;
      *(ijrp+ 3) = 1;
      *(ijrp+ 4) = 2;
      *(ijrp+ 5) = *nnf;
      *(ijrp+ 6) = *nnf + 1;
      *(ijrp+ 7) = *nnf + 2;
      *(ijrp+ 8) = 2 * *nnf;
      *(ijrp+ 9) = 2 * *nnf + 1;
      *(ijrp+10) = 2 * *nnf + 2;
      l2 = 13;
      break;
    case 4:     /* complex stencil */
      *ijrp      = 29;
      *(ijrp+ 1) = 4;
      *(ijrp+ 2) = 0;
      *(ijrp+ 3) = 2;
      *(ijrp+ 4) = 2 * *nnf;
      *(ijrp+ 5) = 2 * *nnf + 2;
      *(ijrp+ 6) = 4;
      *(ijrp+ 7) = 1;
      *(ijrp+ 8) = *nnf;
      *(ijrp+ 9) = *nnf + 2;
      *(ijrp+10) = 2 * *nnf + 1;
      *(ijrp+11) = 1;
      *(ijrp+12) = *nnf + 1;
      *(ijrp+13) = 0;
      l2 = 16;
      break;
    }
  for (j = 1; j <= l; j++)
    *(ijrp+l+j) = *(ijrp+j);
  *(ijrp+l)     = 2;
  *(ijrp+(2*l)) = *nnf + 3;

  /* store pointers to correct simple stencil */
  kk = *ijrp;
  for (j = 0; j < n; j++)
    for (i = 0; i < n; i++)
      *(ijrp+kk++) = (i < n-1) ? 2 : l2;

#if DEBUG_KUGENR
  printf("\n ===== genr =====");
  printf(" cols,rows,lenr,lenijr,rtype,n = %d,%d,%d,%d,%d,%d\n", 
         cols, rows, *ijrp, *ijrp + 1 + n*n, 3, n);
  printf("     i   ijr             r\n");
  for (j = 0; j < *ijrp; j++)
    printf("%6d%6d%14.5e\n", j+1, *(ijrp+j), *(rp+j));
  for (j = *ijrp; j < *ijrp + n*n; j++)
    printf("%6d%6d\n", j+1, *(ijrp+j));
#endif

  }

/**********************************************************************/

ksgennir(k, cols, rows, nnf, nnc, levinf)
        INT  cols, *nnc, *nnf, rows;
        struct  stlevinf **levinf;
  {
  return;
  }


/**********************************************************************/

kun(nn, nodims) INT *nn, *nodims; {

  *nn++   = 15;
  *nn     = 15;
  *nodims = 2;
  }

/**********************************************************************/

kunewn(nnf, nnc, nodims) INT *nnc, *nnf, nodims; {

  int  j;

  for (j = 0; j < nodims; j++)
    *nnc++ = (*nnf++ - 1) / 2;
  }
