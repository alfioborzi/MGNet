#ifndef _included_IndexGridData2_h
#define _included_IndexGridData2_h

/*
*************************************************************************
*									*
* IndexGridData2.h							*
*									*
* Provide macros for array looping and indexing.			*
*									*
* Adaptation  from LPARX developed by  				*
* Scott Kohn (skohn-at-cs.ucsd.edu)                       		*
*                                                                       *
*************************************************************************
*/

#include <generic.h>

/*
*************************************************************************
*									*
* Define some looping constructs for GridData.  Note that these will	*
* take either an array or a region as the second argument.		*
*									*
* Copy the region extents into a local constant integer to aid the	*
* compiler in doing some loop optimizations.				*
*									*
*************************************************************************
*/

#ifndef for_2
#define for_2(i, j, r, s) {						\
   const int name2(j,_L) = (((r).lower(1)+s(1)-1)/s(1))*s(1);           \
   const int name2(j,_U) = (r).upper(1);	                        \
   const int name2(i,_L) = (((r).lower(0)+s(0)-1)/s(0))*s(0);           \
   const int name2(i,_U) = (r).upper(0);	                        \
   const int name2(sj,_S) = (s(1));					\
   const int name2(si,_S) = (s(0));					\
   for (int j = name2(j,_L); j <= name2(j,_U); j+=name2(sj,_S))		\
   for (int i = name2(i,_L); i <= name2(i,_U); i+=name2(si,_S)) {
#endif

#ifndef end_for
#define end_for } }
#endif

/*
*************************************************************************
*									*
* These macros provide simple access to ``fast indexing'' from C++.	*
* Current C++ compilers do not do a good job of optimizing C++ loops	*
* with array access.  Using these macros should speed up loops by a	*
* factor of about three.  Note that we still use the Fortran indexing	*
* convention.								*
*									*
* These macros should be used as follows:				*
*									*
*	BeginFastIndex2(a, double);					*
*	for_2(i, j, a)							*
*	   FastIndex2(a, i, j) = 0.0;					*
*	end_for								*
*	EndFastIndex2(a);						*
*									*
*************************************************************************
*/

#ifndef BeginFastIndex2
#define BeginFastIndex2(a, b, d, type) {				\
const int   name2(a,_B)  = b.bottom();					\
type *const name2(a,_D)  = d;						\
const int   name2(a,_e0) = b.extents(0);				\
const int   name2(a,_s0) = b.stepsize(0);                               \
const int   name2(a,_s1) = b.stepsize(1)
#define FastIndex2(a, i, j)						\
name2(a,_D)[name2(a,_B)+((i)/name2(a,_s0))+name2(a,_e0)*((j)/name2(a,_s1))]
#define EndFastIndex2(a) }
#endif

#endif
