#ifndef _included_BucketType_c
#define _included_BucketType_c

/*
*************************************************************************
* BucketType.c                           				*
*                              						*
*************************************************************************
*/

template <class Type>
Type *Bucket<Type>::remove(void)
 { 
  if (cur == recordNULL) return ( (Type *) NULL );
  union record *r = prevrec(cur); 
  removerec(cur); cur = r;
  return ( (cur != recordNULL && !cur->isempty()) ? \
           (Type *) cur->rec.data : (Type *) NULL );
 }

template <class Type>
Type *Bucket<Type>::prev(void)
 { 
  if (cur == recordNULL) return ( last() );
  cur = prevrec(cur);
  return ( (cur != recordNULL && !cur->isempty()) ? \
           (Type *) cur->rec.data : (Type *) NULL );
}

template <class Type>
Type *Bucket<Type>::next(void)
 { 
  if (cur == recordNULL) return ( first() );
  cur = nextrec(cur);
  return ( (cur != recordNULL && !cur->isempty()) ? \
           (Type *) cur->rec.data : (Type *) NULL );
 }

#endif
