#ifndef _included_GridDataOpsRed_1_h
#define _included_GridDataOpsRed_1_h

/*
*************************************************************************
*                                                                       *
* GridDataOpsRed1.h                                                     *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/****************************** maxval ***************************************/

template <class Type>
Type GridData(1)<Type>::maxval (BBox const &where)

  {
    Type max_val = (Type) DAGHSmall;  
    short flag = DAGHTrue;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(1)<Type> &dst = *this;

       BeginFastIndex1(dst, dst._bbox, dst._data, Type);

       for_1(i, intersection, max_step)
         if (flag == DAGHTrue) 
           { max_val = FastIndex1(dst,i); flag = DAGHFalse; }
         else if (FastIndex1(dst,i) > max_val)
           max_val = FastIndex1(dst,i);
       end_for

       EndFastIndex1(dst);

      }
    return (max_val);
  }

/************************************************************************/

/****************************** minval ***************************************/

template <class Type>
Type GridData(1)<Type>::minval (BBox const &where)

  {
    Type min_val = MAXLIM(Type);
    short flag = DAGHTrue;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(1)<Type> &dst = *this;

       BeginFastIndex1(dst, dst._bbox, dst._data, Type);

       for_1(i, intersection, max_step)
         if (flag == DAGHTrue) 
           { min_val = FastIndex1(dst,i); flag = DAGHFalse; }
         else if (FastIndex1(dst,i) < min_val) 
	   min_val = FastIndex1(dst,i);
       end_for

       EndFastIndex1(dst);

      }
    return (min_val);
  }

/************************************************************************/

/****************************** sum ***************************************/

template <class Type>
Type GridData(1)<Type>::sum (BBox const &where)

  {
    Type sum_val = (Type) 0;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(1)<Type> &dst = *this;

       BeginFastIndex1(dst, dst._bbox, dst._data, Type);

       for_1(i, intersection, max_step)
         sum_val += FastIndex1(dst,i);
       end_for

       EndFastIndex1(dst);

      }
    return (sum_val);
  }

/************************************************************************/

/****************************** product ***************************************/

template <class Type>
Type GridData(1)<Type>::product (BBox const &where)

  {
    Type prod_val = (Type) 1;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(1)<Type> &dst = *this;

       BeginFastIndex1(dst, dst._bbox, dst._data, Type);

       for_1(i, intersection, max_step)
         prod_val *= FastIndex1(dst,i);
       end_for

       EndFastIndex1(dst);

      }
    return (prod_val);
  }

/************************************************************************/

/****************************** moment1 ***************************************/
template <class Type>
Type GridData(1)<Type>::moment1 (int const axis, BBox const &where)

  {
    Type m1 = (Type) 0;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(1)<Type> &dst = *this;

       BeginFastIndex1(dst, dst._bbox, dst._data, Type);

       if (axis == DAGH_X) {
         for_1(i, intersection, max_step)
           m1 += FastIndex1(dst,i) * i;
         end_for
       }

       EndFastIndex1(dst);
      }
    return (m1);
  }
/************************************************************************/

/****************************** sumsqrd ***************************************/

template <class Type>
void GridData(1)<Type>::sumsqrd (BBox const &where, Type &s, int &c)

  {
    s = (Type) 0;
    c = 0;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(1)<Type> &dst = *this;

       BeginFastIndex1(dst, dst._bbox, dst._data, Type);

       for_1(i, intersection, max_step)
         s += FastIndex1(dst,i) * FastIndex1(dst,i);
	 c++;
       end_for

       EndFastIndex1(dst);

      }
  }

/************************************************************************/


#endif
