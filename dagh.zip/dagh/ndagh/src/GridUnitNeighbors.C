/*
*************************************************************************
*                                                                       *
* GridUnitNeighbors.C                                                   *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"

#include "GridUnit.h"
#include "GridDataParams.h"

#ifdef DEBUG_PRINT
#include "CommServer.h"
#endif

/*
*************************************************************************
*                                                                       *
* Member function guGetNeighbors returns an array of baseindices of 	*
* the neighboring GridUnits.						*
*                                                                       *
* Note that this routine assumes that the neighbors have the same 	*
* extent as the GridUnit itself.					*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

void GridUnit::guGetNeighbors(dMapIndex** &neighbors, const int lev) const
  {
   register unsigned h = baseindex.GetDimCardinality(lev);
   register unsigned hmax = baseindex.GetDimMax(lev);
   register unsigned ext = extent-(finelev-lev);

   unsigned *clb = new unsigned[dim]; 
   guLCoords(clb,lev);
   unsigned *cub = new unsigned[dim]; 
   guUCoords(cub,lev);

   register int i;
   for (i=0;i<dim;i++) {
     int max = cub[i] > clb[i] ? cub[i] : clb[i];
     int min = cub[i] < clb[i] ? cub[i] : clb[i];
     cub[i] = max; clb[i] = min;
   }
     
   //if (neighbors) {
   //  for (register int i=0;i<2*dim;i++)
   //     if (neighbors[i]) delete neighbors[i];
   //  delete [] neighbors;
   //}
   assert (!neighbors);
   neighbors = new dMapIndex *[2*dim];

   for (i=0;i<dim;i++) {

     if (clb[i] >= h) {
       clb[i] -= h;
       neighbors[2*i] = new dMapIndex(baseindex);
       neighbors[2*i]->Map((unsigned *)clb);
       neighbors[2*i]->ResetBase(lev,ext);
       clb[i]+=h;
     }
     else 
      neighbors[2*i] = (dMapIndex *)NULL;


     if (cub[i] <= hmax-h) {
       cub[i] += h;
       neighbors[2*i+1] = new dMapIndex(baseindex);
       neighbors[2*i+1]->Map((unsigned *)cub);
       neighbors[2*i+1]->ResetBase(lev,ext);
       cub[i]-=h;
     }
     else 
      neighbors[2*i+1] = (dMapIndex *)NULL;

   }
   if (cub) delete [] cub;
   if (clb) delete [] clb;
  }


void GridUnit::guGetNeighbors(dMapIndex** &neighbors, int &cnt, const int lev, 
				int const dir, int const next) const
  {
   unsigned h = baseindex.GetDimCardinality(lev);
   unsigned hmax = baseindex.GetDimMax(lev);
   unsigned ext = extent-(finelev-lev);
   unsigned num = baseindex.GetCardinality(1,next);
   unsigned extratio = baseindex.GetCardinality(1,ext-next);

#ifdef DEBUG_PRINT_NEIGH
            ( comm_service::log() << "GridUnit::guGetNeighbors"  << " "
                         << baseindex << " "
                         << "dir: " << dir << " "
                         << "h: " << h << " "
                         << "hmax: " << hmax << " "
                         << "num: " << num << " "
                         << "ext: " << ext << " "
                         << "extratio: " << extratio << " "
                         << endl ).flush();
#endif

   unsigned *clb = new unsigned[dim]; 
   guLCoords(clb,lev);
   unsigned *cub = new unsigned[dim]; 
   guUCoords(cub,lev);

   for (register int ii=0;ii<dim;ii++) {
     int max = cub[ii] > clb[ii] ? cub[ii] : clb[ii];
     int min = cub[ii] < clb[ii] ? cub[ii] : clb[ii];
     cub[ii] = max; clb[ii] = min;
   }
     
   //if (neighbors) delete [] neighbors;
   assert (!neighbors);

   cnt = 0;
   int r0 = dir/2;
   int r1 = 0, r2 = 0;
   switch (dim) {
     case 1:
       if (dir%2 == 0) {
         if (clb[r0] >= h) {
           cnt = 1;
           neighbors = new dMapIndex *[cnt];
           clb[r0] -= h;
           neighbors[0] = new dMapIndex(baseindex);
           neighbors[0]->Map((unsigned *)clb);
           neighbors[0]->ResetBase(lev,ext-next);
           clb[r0]+=h;
         } else 
           neighbors = (dMapIndex **)NULL;
       } else {
         if (cub[r0] <= hmax-h) {
           cnt = 1;
           neighbors = new dMapIndex *[cnt];
           cub[r0] += h;
           neighbors[0] = new dMapIndex(baseindex);
           neighbors[0]->Map((unsigned *)cub);
           neighbors[0]->ResetBase(lev,ext-next);
           cub[r0]-=h;
         } else 
           neighbors = (dMapIndex **)NULL;
       }
       break;

     case 2:
       r1 = (r0+1)%dim;
       if (dir%2 == 0) {
         if (clb[r0] >= h) {
           cnt = num;
           neighbors = new dMapIndex *[cnt];
	   register unsigned hsmall = h*extratio;
           clb[r0] -= h; 
           for (int i=0;i<num;i++) {
	     clb[r1] += hsmall*i;
             neighbors[i] = new dMapIndex(baseindex);
             neighbors[i]->Map((unsigned *)clb);
             neighbors[i]->ResetBase(lev,ext-next);
             clb[r1] -= hsmall*i;
           }
           clb[r0] += h;
         } else 
           neighbors = (dMapIndex **)NULL;
       } else {
         if (cub[r0] <= hmax-h) {
           cnt = num;
           neighbors = new dMapIndex *[cnt];
	   register unsigned hsmall = h*extratio;
           cub[r0] += h;
           for (int i=0;i<num;i++) {
	     cub[r1] -= hsmall*i;
             neighbors[i] = new dMapIndex(baseindex);
             neighbors[i]->Map((unsigned *)cub);
             neighbors[i]->ResetBase(lev,ext-next);
             cub[r1] += hsmall*i;
           }
           cub[r0] -= h;
         } else 
           neighbors = (dMapIndex **)NULL;
       }
       break;

     case 3:
       r1 = (r0+1)%dim;
       r2 = (r0+2)%dim;
       if (dir%2 == 0) {
         if (clb[r0] >= h) {
           cnt = num*num; 
           neighbors = new dMapIndex *[cnt];
	   register unsigned hsmall = h*extratio;
           clb[r0] -= h;
           for (int i=0;i<num;i++) {
	     clb[r1] += hsmall*i;
             for (int j=0;j<num;j++) {
	       clb[r2] += hsmall*j;
               neighbors[i*num+j] = new dMapIndex(baseindex);
               neighbors[i*num+j]->Map((unsigned *)clb);
               neighbors[i*num+j]->ResetBase(lev,ext-next);
               clb[r2] -= hsmall*j;
             }
	     clb[r1] -= hsmall*i;
           }
           clb[r0] += h; 
         } else 
           neighbors = (dMapIndex **)NULL;
       } else {
         if (cub[r0] <= hmax-h) {
           cnt = num*num; 
           neighbors = new dMapIndex *[cnt];
	   register unsigned hsmall = h*extratio;
           cub[r0] += h;
           for (int i=0;i<num;i++) {
	     cub[r1] -= hsmall*i;
             for (int j=0;j<num;j++) {
	       cub[r2] -= hsmall*j;
               neighbors[i*num+j] = new dMapIndex(baseindex);
               neighbors[i*num+j]->Map((unsigned *)cub);
               neighbors[i*num+j]->ResetBase(lev,ext-next);
               cub[r2] += hsmall*j;
             }
	     cub[r1] += hsmall*i;
           }
	   cub[r0] -= h;
         } else 
           neighbors = (dMapIndex **)NULL;
       }
       break;
     default:
       assert(dim <= 3);
       break;
     }
   if (cub) delete [] cub;
   if (clb) delete [] clb;
  }

void GridUnit::guGetNeighbors(dMapIndex** &neighbors, int &cnt, int const lev, int const dir, 
			dMapIndex const &hisindex, int const hisext, int const next) const
  {
   unsigned h = baseindex.GetDimCardinality(lev);
   unsigned hmax = baseindex.GetDimMax(lev);
   unsigned ext = extent-(finelev-lev);
   unsigned num = baseindex.GetCardinality(1,next);
   unsigned extratio = baseindex.GetCardinality(1,hisext-next);

#ifdef DEBUG_PRINT_NEIGH
            ( comm_service::log() << "GridUnit::guGetNeighbors"  << " "
                         << baseindex << " "
                         << "dir: " << dir << " "
                         << "h: " << h << " "
                         << "hmax: " << hmax << " "
                         << "num: " << num << " "
                         << "ext: " << ext << " "
                         << "extratio: " << extratio << " "
                         << endl ).flush();
#endif

   unsigned *clb = new unsigned[dim]; 
   hisindex.GetCoords(clb,lev);

   unsigned *cub = new unsigned[dim]; 
   dMapIndex ti = hisindex;
   ti.SetBox(lev,hisext);
   ti.GetCoords(cub,lev);

   for (register int ii=0;ii<dim;ii++) {
     int max = cub[ii] > clb[ii] ? cub[ii] : clb[ii];
     int min = cub[ii] < clb[ii] ? cub[ii] : clb[ii];
     cub[ii] = max; clb[ii] = min;
   }
     
   //if (neighbors) delete [] neighbors;
   assert (!neighbors);

   cnt = 0;
   int r0 = dir/2;
   int r1 = 0, r2 = 0;
   switch (dim) {
     case 1:
       if (dir%2 == 0) {
         cnt = 1;
         neighbors = new dMapIndex *[cnt];
         neighbors[0] = new dMapIndex(baseindex);
         neighbors[0]->Map((unsigned *)cub);
         neighbors[0]->ResetBase(lev,hisext-next);
       } else {
         cnt = 1;
         neighbors = new dMapIndex *[cnt];
         neighbors[0] = new dMapIndex(baseindex);
         neighbors[0]->Map((unsigned *)clb);
         neighbors[0]->ResetBase(lev,hisext-next);
       }
       break;

     case 2:
       r1 = (r0+1)%dim;
       if (dir%2 == 0) {
         cnt = num;
         neighbors = new dMapIndex *[cnt];
	 register unsigned hsmall = h*extratio;
	 int i;
         for (i=0;i<num;i++) {
	   cub[r1] -= hsmall*i;
           neighbors[i] = new dMapIndex(baseindex);
           neighbors[i]->Map((unsigned *)cub);
           neighbors[i]->ResetBase(lev,hisext-next);
           cub[r1] += hsmall*i;
         }
       } else {
         cnt = num;
         neighbors = new dMapIndex *[cnt];
	 register unsigned hsmall = h*extratio;
         for (int i=0;i<num;i++) {
	   clb[r1] += hsmall*i;
           neighbors[i] = new dMapIndex(baseindex);
           neighbors[i]->Map((unsigned *)clb);
           neighbors[i]->ResetBase(lev,hisext-next);
           clb[r1] -= hsmall*i;
         }
       }
       break;

     case 3:
       r1 = (r0+1)%dim;
       r2 = (r0+2)%dim;
       if (dir%2 == 0) {
         cnt = num*num; 
         neighbors = new dMapIndex *[cnt];
	 register unsigned hsmall = h*extratio;
	 int i;
         for (i=0;i<num;i++) {
	   cub[r1] -= hsmall*i;
           for (int j=0;j<num;j++) {
	     cub[r2] -= hsmall*j;
             neighbors[i*num+j] = new dMapIndex(baseindex);
             neighbors[i*num+j]->Map((unsigned *)cub);
             neighbors[i*num+j]->ResetBase(lev,hisext-next);
             cub[r2] += hsmall*j;
           }
	   cub[r1] += hsmall*i;
         }
       } else {
         cnt = num*num; 
         neighbors = new dMapIndex *[cnt];
	 register unsigned hsmall = h*extratio;
         for (int i=0;i<num;i++) {
	   clb[r1] += hsmall*i;
           for (int j=0;j<num;j++) {
	     clb[r2] += hsmall*j;
             neighbors[i*num+j] = new dMapIndex(baseindex);
             neighbors[i*num+j]->Map((unsigned *)clb);
             neighbors[i*num+j]->ResetBase(lev,hisext-next);
             clb[r2] -= hsmall*j;
           }
	   clb[r1] -= hsmall*i;
         }
       }
       break;
     default:
       assert(dim <= 3);
       break;
     }
   if (cub) delete [] cub;
   if (clb) delete [] clb;
  }

/*
*************************************************************************
*                                                                       *
* void GridUnit::guGetCorners(dMapIndex** &corners,int const lev) const	*
*                                                                       *
* Member function guGetCorners returns an array of baseindices of 	*
* the cornering GridUnits.						*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/* dirs := backward == 0 and forward == 1 */
static int IncrementCoords(unsigned *c, unsigned const *clb, unsigned const *cub, 
                           int const dim, unsigned const h, unsigned const hmax, 
                           int const dir)
  {
    if (dir == 0 && clb[dim] >= h) {
       c[dim] = clb[dim] - h;
       return 1;
    }
    else if (dir == 1 && cub[dim] <= hmax-h) {
       c[dim] = cub[dim] + h;
       return 1;
    }
    else {
       return 0;
    }
  }

static dMapIndex *GetCornerIndex(dMapIndex const &bi, unsigned *c, 
                                 int const lev, int const ext, int const next=0)
  {
    dMapIndex *ci = new dMapIndex(bi);
    ci->Map(c);
    ci->ResetBase(lev,ext-next);
    return ci;
  }

void GridUnit::guGetCorners(dMapIndex** &corners, int const lev) const
  {
   assert (dim <= 3);
   assert (!corners);

   if (dim == 1) return; /* No corners in a 1-D case */

   register unsigned h = baseindex.GetDimCardinality(lev);
   register unsigned hmax = baseindex.GetDimMax(lev);
   register unsigned ext = extent-(finelev-lev);
   register unsigned num = baseindex.GetCardinality(1,dim);

   unsigned *clb = new unsigned[dim]; 
   guLCoords(clb,lev);
   unsigned *cub = new unsigned[dim]; 
   guUCoords(cub,lev);

   for (register int ii=0;ii<dim;ii++) {
     int max = cub[ii] > clb[ii] ? cub[ii] : clb[ii];
     int min = cub[ii] < clb[ii] ? cub[ii] : clb[ii];
     cub[ii] = max; clb[ii] = min;
   }
     
   corners = new dMapIndex *[num];
   for (register int cii=0;cii<num;cii++)
     corners[cii] = (dMapIndex *) NULL;

   switch (dim) {
   case 3:
     { 
     unsigned *c = new unsigned[dim]; 
     for (register int i=0;i<2;i++)
     if (IncrementCoords(c,clb,cub,0,h,hmax,i)) {

       for (register int j=0;j<2;j++) 
       if (IncrementCoords(c,clb,cub,1,h,hmax,j)) {

         for (register int k=0;k<2;k++)
         if (IncrementCoords(c,clb,cub,2,h,hmax,k)) {
           int index = (i*4+j*2+k);
           corners[index] = GetCornerIndex(baseindex,c,lev,ext);
         }

       }

     }
     if (c) delete [] c;
     }
     break;
     
   case 2:
     {
     unsigned *c = new unsigned[dim]; 
     for (register int i=0;i<2;i++)
     if (IncrementCoords(c,clb,cub,0,h,hmax,i)) {

       for (register int j=0;j<2;j++) 
       if (IncrementCoords(c,clb,cub,1,h,hmax,j)) {

         int index = (i*2+j);
         corners[index] = GetCornerIndex(baseindex,c,lev,ext);

       }

     }
     if (c) delete [] c;
     }
     break;

   default:
     assert(dim <= 3);
     break;
   }
   if (cub) delete [] cub;
   if (clb) delete [] clb;
  }

void GridUnit::guGetCorners(dMapIndex** &corners, int &cnt, const int lev, 
				int const dir, int const next) const
  {
   assert (dim <= 3);
   assert (!corners);

   if (dim == 1) { /* No corners in a 1-D case */
     cnt = 0;
     return;
   }

   unsigned h = baseindex.GetDimCardinality(lev);
   unsigned hmax = baseindex.GetDimMax(lev);
   unsigned ext = extent-(finelev-lev);
   unsigned num = baseindex.GetCardinality(1,next);
   unsigned extratio = baseindex.GetCardinality(1,ext-next);

#ifdef DEBUG_PRINT_CORNERS
            ( comm_service::log() << "GridUnit::guGetCorners"  << " "
                         << baseindex << " "
                         << "dir: " << dir << " "
                         << "h: " << h << " "
                         << "hmax: " << hmax << " "
                         << "num: " << num << " "
                         << "ext: " << ext << " "
                         << "extratio: " << extratio << " "
                         << endl ).flush();
#endif

   unsigned *clb = new unsigned[dim]; 
   guLCoords(clb,lev);
   unsigned *cub = new unsigned[dim]; 
   guUCoords(cub,lev);

   for (register int i=0;i<dim;i++) {
     int max = cub[i] > clb[i] ? cub[i] : clb[i];
     int min = cub[i] < clb[i] ? cub[i] : clb[i];
     cub[i] = max; clb[i] = min;
   }
     
   int ndir = dir - CORNERS;
   cnt = 0;
   switch (dim) {
     case 2:
     {
       unsigned *c = new unsigned[dim];
       if (IncrementCoords(c,clb,cub,0,h,hmax,(ndir/4)%2)) {
         if (IncrementCoords(c,clb,cub,1,h,hmax,(ndir/2)%2)) {
           cnt = 1;
           corners = new dMapIndex *[cnt];
           corners[0] = GetCornerIndex(baseindex,c,lev,ext,next);
         }
       }
       if (c) delete [] c;
     }
       break;

     case 3:
     {
       unsigned *c = new unsigned[dim];
       if (IncrementCoords(c,clb,cub,0,h,hmax,(ndir/4)%2)) {
         if (IncrementCoords(c,clb,cub,1,h,hmax,(ndir/2)%2)) {
           if (IncrementCoords(c,clb,cub,2,h,hmax,ndir%2)) {
             cnt = 1;
             corners = new dMapIndex *[cnt];
             corners[0] = GetCornerIndex(baseindex,c,lev,ext,next);
           }
         }
       }
       if (c) delete [] c;
     }
       break;

     }
   if (cub) delete [] cub;
   if (clb) delete [] clb;
  }

void GridUnit::guGetCorners(dMapIndex** &corners, int &cnt, int const lev, int const dir, 
			dMapIndex const &hisindex, int const hisext, int const next) const
  {
   assert (dim <= 3);
   assert (!corners);

   if (dim == 1) { /* No corners in a 1-D case */
     cnt = 0;
     return;
   }

   unsigned h = baseindex.GetDimCardinality(lev);
   unsigned hmax = baseindex.GetDimMax(lev);
   unsigned ext = extent-(finelev-lev);
   unsigned num = baseindex.GetCardinality(1,next);
   unsigned extratio = baseindex.GetCardinality(1,hisext-next);

#ifdef DEBUG_PRINT_CORNERS
            ( comm_service::log() << "GridUnit::guGetCorners"  << " "
                         << baseindex << " "
                         << "dir: " << dir << " "
                         << "h: " << h << " "
                         << "hmax: " << hmax << " "
                         << "num: " << num << " "
                         << "ext: " << ext << " "
                         << "extratio: " << extratio << " "
                         << endl ).flush();
#endif

   unsigned *clb = new unsigned[dim]; 
   hisindex.GetCoords(clb,lev);

   unsigned *cub = new unsigned[dim]; 
   dMapIndex ti = hisindex;
   ti.SetBox(lev,hisext);
   ti.GetCoords(cub,lev);

   for (register int i=0;i<dim;i++) {
     int max = cub[i] > clb[i] ? cub[i] : clb[i];
     int min = cub[i] < clb[i] ? cub[i] : clb[i];
     cub[i] = max; clb[i] = min;
   }
     
   cnt = 1;
   unsigned *c = new unsigned[dim];
   switch (dim) { 
   case 2:
   {
     if (dir == WS) {
       c[0] = cub[0]; 
       c[1] = cub[1]; 
     }
     else if (dir == WN) {
       c[0] = cub[0]; 
       c[1] = clb[1]; 
     }
     else if (dir == ES) {
       c[0] = clb[0]; 
       c[1] = cub[1]; 
     }
     else if (dir == EN) {
       c[0] = clb[0]; 
       c[1] = clb[1]; 
     }
   }
     break;

   case 3:
   {
     if (dir == WSF) {
       c[0] = cub[0]; 
       c[1] = cub[1]; 
       c[2] = cub[2]; 
     }
     else if (dir == WSB) {
       c[0] = cub[0]; 
       c[1] = cub[1]; 
       c[2] = clb[2]; 
     }
     else if (dir == WNF) {
       c[0] = cub[0]; 
       c[1] = clb[1]; 
       c[2] = cub[2]; 
     }
     else if (dir == WNB) {
       c[0] = cub[0]; 
       c[1] = clb[1]; 
       c[2] = clb[2]; 
     }
     else if (dir == ESF) {
       c[0] = clb[0]; 
       c[1] = cub[1]; 
       c[2] = cub[2]; 
     }
     else if (dir == ESB) {
       c[0] = clb[0]; 
       c[1] = cub[1]; 
       c[2] = clb[2]; 
     }
     else if (dir == ENF) {
       c[0] = clb[0]; 
       c[1] = clb[1]; 
       c[2] = cub[2]; 
     }
     else if (dir == ENB) {
       c[0] = clb[0]; 
       c[1] = clb[1]; 
       c[2] = clb[2]; 
     }
   }
     break;
   
   default:
     assert (dim > 3);
     break; 
   }

   corners = new dMapIndex *[cnt];
   corners[0] = new dMapIndex(baseindex);
   corners[0]->Map((unsigned *)c);
   corners[0]->ResetBase(lev,hisext-next);

   if (c) delete [] c;
   if (cub) delete [] cub;
   if (clb) delete [] clb;
  }

/*
*************************************************************************
*                                                                       *
* void GridUnit::guGetEdges(dMapIndex** &edges,int const lev) const	*
*                                                                       *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/* dirs := backward == -1 ; same == 0 ; forward == 1 */
static int IncrementCoordsEdges(unsigned *c, unsigned const *clb, unsigned const *cub, 
                           int const dim, 
                           unsigned const h, unsigned const hmax, 
                           int const dir)
  {
    if (dir == -1 && clb[dim] >= h) {
       c[dim] = clb[dim] - h;
       return 1;
    }
    if (dir == 0) {
       c[dim] = clb[dim];
       return 1;
    }
    else if (dir == 1 && cub[dim] <= hmax-h) {
       c[dim] = cub[dim] + h;
       return 1;
    }
    else {
       return 0;
    }
  }

static dMapIndex *GetEdgeIndex(dMapIndex const &bi, unsigned *c, 
                              int const lev, int const ext, int const next=0)
  {
    dMapIndex *ci = new dMapIndex(bi);
    ci->Map(c);
    ci->ResetBase(lev,ext-next);
    return ci;
  }

void GridUnit::guGetEdges(dMapIndex** &edges, int const lev) const
  {
   assert (dim <= 3);
   assert (!edges);

   if (dim == 1 || dim == 2) { /* No edges in a 1-D or 2-D case */
     return;
   }

   register unsigned h = baseindex.GetDimCardinality(lev);
   register unsigned hmax = baseindex.GetDimMax(lev);
   register unsigned ext = extent-(finelev-lev);
   register unsigned num = 12;

   unsigned *clb = new unsigned[dim]; 
   guLCoords(clb,lev);
   unsigned *cub = new unsigned[dim]; 
   guUCoords(cub,lev);

   register int i;
   for (i=0;i<dim;i++) {
     int max = cub[i] > clb[i] ? cub[i] : clb[i];
     int min = cub[i] < clb[i] ? cub[i] : clb[i];
     cub[i] = max; clb[i] = min;
   }
     
   edges = new dMapIndex *[num];
   for (register int eii=0;eii<num;eii++)
     edges[eii] = (dMapIndex *) NULL;

   { /* WSC */
     unsigned *c = new unsigned[dim]; 
     if (IncrementCoordsEdges(c,clb,cub,0,h,hmax,-1)) {
       if (IncrementCoordsEdges(c,clb,cub,1,h,hmax,-1)) {
         if (IncrementCoordsEdges(c,clb,cub,2,h,hmax,0)) {
           int index = WSC-EDGES;
           edges[index] = GetEdgeIndex(baseindex,c,lev,ext);
         }

       }

     }
     if (c) delete [] c;
   } /* WSC */
     

   { /* WNC */
     unsigned *c = new unsigned[dim]; 
     if (IncrementCoordsEdges(c,clb,cub,0,h,hmax,-1)) {
       if (IncrementCoordsEdges(c,clb,cub,1,h,hmax,+1)) {
         if (IncrementCoordsEdges(c,clb,cub,2,h,hmax,0)) {
           int index = WNC-EDGES;
           edges[index] = GetEdgeIndex(baseindex,c,lev,ext);
         }

       }

     }
     if (c) delete [] c;
   } /* WNC */
     
   { /* WCF */
     unsigned *c = new unsigned[dim]; 
     if (IncrementCoordsEdges(c,clb,cub,0,h,hmax,-1)) {
       if (IncrementCoordsEdges(c,clb,cub,1,h,hmax,0)) {
         if (IncrementCoordsEdges(c,clb,cub,2,h,hmax,-1)) {
           int index = WCF-EDGES;
           edges[index] = GetEdgeIndex(baseindex,c,lev,ext);
         }

       }

     }
     if (c) delete [] c;
   } /* WCF */
     
   { /* WCB */
     unsigned *c = new unsigned[dim]; 
     if (IncrementCoordsEdges(c,clb,cub,0,h,hmax,-1)) {
       if (IncrementCoordsEdges(c,clb,cub,1,h,hmax,0)) {
         if (IncrementCoordsEdges(c,clb,cub,2,h,hmax,1)) {
           int index = WCB-EDGES;
           edges[index] = GetEdgeIndex(baseindex,c,lev,ext);
         }

       }

     }
     if (c) delete [] c;
   } /* WCB */

   { /* CSF */
     unsigned *c = new unsigned[dim]; 
     if (IncrementCoordsEdges(c,clb,cub,0,h,hmax,0)) {
       if (IncrementCoordsEdges(c,clb,cub,1,h,hmax,-1)) {
         if (IncrementCoordsEdges(c,clb,cub,2,h,hmax,-1)) {
           int index = CSF-EDGES;
           edges[index] = GetEdgeIndex(baseindex,c,lev,ext);
         }

       }

     }
     if (c) delete [] c;
   } /* CSF */
     

   { /* CSB */
     unsigned *c = new unsigned[dim]; 
     if (IncrementCoordsEdges(c,clb,cub,0,h,hmax,0)) {
       if (IncrementCoordsEdges(c,clb,cub,1,h,hmax,-1)) {
         if (IncrementCoordsEdges(c,clb,cub,2,h,hmax,+1)) {
           int index = CSB-EDGES;
           edges[index] = GetEdgeIndex(baseindex,c,lev,ext);
         }

       }

     }
     if (c) delete [] c;
   } /* CSB */
     
   { /* CNF */
     unsigned *c = new unsigned[dim]; 
     if (IncrementCoordsEdges(c,clb,cub,0,h,hmax,0)) {
       if (IncrementCoordsEdges(c,clb,cub,1,h,hmax,+1)) {
         if (IncrementCoordsEdges(c,clb,cub,2,h,hmax,-1)) {
           int index = CNF-EDGES;
           edges[index] = GetEdgeIndex(baseindex,c,lev,ext);
         }

       }

     }
     if (c) delete [] c;
   } /* CNF */
     
   { /* CNB */
     unsigned *c = new unsigned[dim]; 
     if (IncrementCoordsEdges(c,clb,cub,0,h,hmax,0)) {
       if (IncrementCoordsEdges(c,clb,cub,1,h,hmax,+1)) {
         if (IncrementCoordsEdges(c,clb,cub,2,h,hmax,+1)) {
           int index = CNB-EDGES;
           edges[index] = GetEdgeIndex(baseindex,c,lev,ext);
         }

       }

     }
     if (c) delete [] c;
   } /* CNB */

   { /* ESC */
     unsigned *c = new unsigned[dim]; 
     if (IncrementCoordsEdges(c,clb,cub,0,h,hmax,+1)) {
       if (IncrementCoordsEdges(c,clb,cub,1,h,hmax,-1)) {
         if (IncrementCoordsEdges(c,clb,cub,2,h,hmax,0)) {
           int index = ESC-EDGES;
           edges[index] = GetEdgeIndex(baseindex,c,lev,ext);
         }

       }

     }
     if (c) delete [] c;
   } /* ESC */
     

   { /* ENC */
     unsigned *c = new unsigned[dim]; 
     if (IncrementCoordsEdges(c,clb,cub,0,h,hmax,+1)) {
       if (IncrementCoordsEdges(c,clb,cub,1,h,hmax,+1)) {
         if (IncrementCoordsEdges(c,clb,cub,2,h,hmax,0)) {
           int index = ENC-EDGES;
           edges[index] = GetEdgeIndex(baseindex,c,lev,ext);
         }

       }

     }
     if (c) delete [] c;
   } /* ENC */
     
   { /* ECF */
     unsigned *c = new unsigned[dim]; 
     if (IncrementCoordsEdges(c,clb,cub,0,h,hmax,+1)) {
       if (IncrementCoordsEdges(c,clb,cub,1,h,hmax,0)) {
         if (IncrementCoordsEdges(c,clb,cub,2,h,hmax,-1)) {
           int index = ECF-EDGES;
           edges[index] = GetEdgeIndex(baseindex,c,lev,ext);
         }

       }

     }
     if (c) delete [] c;
   } /* ECF */
     
   { /* ECB */
     unsigned *c = new unsigned[dim]; 
     if (IncrementCoordsEdges(c,clb,cub,0,h,hmax,+1)) {
       if (IncrementCoordsEdges(c,clb,cub,1,h,hmax,0)) {
         if (IncrementCoordsEdges(c,clb,cub,2,h,hmax,+1)) {
           int index = ECB-EDGES;
           edges[index] = GetEdgeIndex(baseindex,c,lev,ext);
         }

       }

     }
     if (c) delete [] c;
   } /* ECB */

   if (cub) delete [] cub;
   if (clb) delete [] clb;

#ifdef DEBUG_PRINT_EDGES
   {
     for (int i=0;i<num;i++) {
            ( comm_service::log() << "GridUnit::guGetEdges"  << " "
                         << baseindex << " "
                         << "dir: " << i << " "
                         << "edge: " << *edges[i] << " "
                         << endl ).flush();
     }
   }
#endif

  }

void GridUnit::guGetEdges(dMapIndex** &edges, int &cnt, int const lev, int const dir, 
			dMapIndex const &hisindex, int const hisext, int const next) const
  {
   assert (dim <= 3);
   assert (!edges);

   if (dim == 1 || dim == 2) { /* No edges in a 1-D or 2-D case */
     cnt = 0;
     return;
   }

   unsigned h = baseindex.GetDimCardinality(lev);
   unsigned hmax = baseindex.GetDimMax(lev);
   unsigned ext = extent-(finelev-lev);
   unsigned num = baseindex.GetCardinality(1,next);
   unsigned extratio = baseindex.GetCardinality(1,hisext-next);

#ifdef DEBUG_PRINT_EDGES
            ( comm_service::log() << "GridUnit::guGetEdges"  << " "
                         << baseindex << " "
                         << "dir: " << dir << " "
                         << "h: " << h << " "
                         << "hmax: " << hmax << " "
                         << "num: " << num << " "
                         << "ext: " << ext << " "
                         << "extratio: " << extratio << " "
                         << endl ).flush();
#endif

   unsigned *clb = new unsigned[dim]; 
   hisindex.GetCoords(clb,lev);

   unsigned *cub = new unsigned[dim]; 
   dMapIndex ti = hisindex;
   ti.SetBox(lev,hisext);
   ti.GetCoords(cub,lev);

   for (register int ii=0;ii<dim;ii++) {
     int max = cub[ii] > clb[ii] ? cub[ii] : clb[ii];
     int min = cub[ii] < clb[ii] ? cub[ii] : clb[ii];
     cub[ii] = max; clb[ii] = min;
   }
     
   cnt = 0;
   int r = 0, d = 0;
   unsigned c[3];
   if (dir == WSC) { 
     r = 2; d = 0;
     c[0] = cub[0]; 
     c[1] = cub[1]; 
     c[2] = cub[2]; 
   }
   else if (dir == WNC) {
     r = 2; d = 0;
     c[0] = cub[0]; 
     c[1] = clb[1]; 
     c[2] = cub[2]; 
   }
   else if (dir == WCF) {
     r = 1; d = 0;
     c[0] = cub[0]; 
     c[1] = cub[1]; 
     c[2] = cub[2]; 
   }
   else if (dir == WCB) {
     r = 1; d = 0;
     c[0] = cub[0]; 
     c[1] = cub[1]; 
     c[2] = clb[2]; 
   }
   else if (dir == CSF) {
     r = 0; d = 0;
     c[0] = cub[0]; 
     c[1] = cub[1]; 
     c[2] = cub[2]; 
   }
   else if (dir == CSB) {
     r = 0; d = 0;
     c[0] = cub[0]; 
     c[1] = cub[1]; 
     c[2] = clb[2]; 
   }
   else if (dir == CNF) {
     r = 0; d = 0;
     c[0] = cub[0]; 
     c[1] = clb[1]; 
     c[2] = cub[2]; 
   }
   else if (dir == CNB) {
     r = 0; d = 0;
     c[0] = cub[0]; 
     c[1] = clb[1]; 
     c[2] = clb[2]; 
   }
   else if (dir == ESC) {
     r = 2; d = 0;
     c[0] = clb[0]; 
     c[1] = cub[1]; 
     c[2] = cub[2]; 
   }
   else if (dir == ENC) {
     r = 2; d = 0;
     c[0] = clb[0]; 
     c[1] = clb[1]; 
     c[2] = cub[2]; 
   }
   else if (dir == ECF) {
     r = 1; d = 0;
     c[0] = clb[0]; 
     c[1] = cub[1]; 
     c[2] = cub[2]; 
   }
   else if (dir == ECB) {
     r = 1; d = 0;
     c[0] = clb[0]; 
     c[1] = cub[1]; 
     c[2] = clb[2]; 
   }

   if (d == 0) {
     cnt = num;
     edges = new dMapIndex *[cnt];
     register unsigned hsmall = h*extratio;
     for (int i=0;i<num;i++) {
       c[r] -= hsmall*i;
       edges[i] = new dMapIndex(baseindex);
       edges[i]->Map((unsigned *)c);
       edges[i]->ResetBase(lev,hisext-next);
       c[r] += hsmall*i;
     }
   }
   else if (d == 1) {
     cnt = num;
     edges = new dMapIndex *[cnt];
     register unsigned hsmall = h*extratio;
     for (int i=0;i<num;i++) {
       c[r] += hsmall*i;
       edges[i] = new dMapIndex(baseindex);
       edges[i]->Map((unsigned *)c);
       edges[i]->ResetBase(lev,hisext-next);
       c[r] -= hsmall*i;
     }
   }
   if (cub) delete [] cub;
   if (clb) delete [] clb;
  }
