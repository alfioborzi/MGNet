There are two codes here:

    CONTROLLA
        controlla.for       Self contained code
        controlla.txt       Documentation

    SANTAFE
        santafe.dat         Input dataset
        santafe.for         Self contained code
        santafe.txt         Documentation

They are contributed by Alfio Borzi, alfio.borzi@uni-graz.at.
