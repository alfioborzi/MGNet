/*
*************************************************************************
*                                                                       *
* class DAGHIOServerRcv                                                 *
* class DAGHIOServerSnd                                                 *
* class DAGHIOServerPing                                                *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "CommIOServer.h"

#include "GridHierarchy.h"

/*************************************************************************/
/* DAGHIOServerRcv */
/*************************************************************************/
DAGHIOServerRcv::DAGHIOServerRcv(unsigned const tag, 
                                 GridHierarchy& gridhierarchy,
                                 DAGHIO_WriteFunc writefunc)
 	: comm_service(DAGHNull,tag), gh(gridhierarchy), Size(0), wf(writefunc),
	  end_cnt(0)
  {

#ifdef DAGH_NO_MPI
#else

#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerRcv::DAGHIOServerRcv " 
			 << comm_service::proc_me() << " "
			 << " MPI_Irecv: "
			 << "Tag: " << Tag << " " 
			 << "Size: " << 1 << " "
			 << endl ).flush();
#endif

    int R = MPI_Irecv(&Size,1,MPI_INT,MPI_ANY_SOURCE,Tag,
                      comm_service::comm_io(),req());

    if ( MPI_SUCCESS != R ) 
      comm_service::error_die("DAGHIOServerRcv::DAGHIOServerRcv","MPI_Irecv",R);

#endif

  }

void DAGHIOServerRcv::callrecv( const MPI_Status & MS )
  {
    if (Size == DAGHNull) {
      if (++end_cnt == comm_service::proc_num()) {
#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerRcv::callrecv " 
			 << comm_service::proc_me() << " "
                         << "EndCnt = " << end_cnt << " "
			 << "Ending ServerRcv"
			 << endl ).flush();
#endif
	return;
      }
      else {
#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerRcv::callrecv " 
			 << comm_service::proc_me() << " "
                         << "EndCnt = " << end_cnt
			 << endl ).flush();
#endif
      }
    }
    else {
      void *Rcv = (void *) new char[Size];
      assert (Rcv != 0);

#ifdef DAGH_NO_MPI
#else

      int from = MS.MPI_SOURCE;

#ifdef DEBUG_PRINT_COMM_IO
      ( comm_service::log() << "DAGHIOServerRcv::callrecv " 
			    << comm_service::proc_me() << " "
			    << " MPI_Recv: "
			    << "Tag: " << (DAGHIOTag|DAGHIOWriteDataTag) << " " 
			    << "Size: " << Size << " "
			    << "From: " << from << " "
			    << endl ).flush();
#endif

      MPI_Status status;
      int R = MPI_Recv(Rcv,Size,MPI_BYTE,from,(DAGHIOTag|DAGHIOWriteDataTag),
		       comm_service::comm_io(),&status);
      if ( MPI_SUCCESS != R ) 
	comm_service::error_die("DAGHIOServerRcv::callrecv","MPI_Recv",R);

#endif

      if (Size > 0) rcv_update(Rcv);
      else {
	if (Rcv) delete [] Rcv;
      }
      Rcv = 0;
    }

#ifdef DAGH_NO_MPI
#else
#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerRcv::callrecv " 
			 << comm_service::proc_me() << " "
			 << " MPI_Irecv: "
			 << "Tag: " << Tag << " " 
			 << "Size: " << 1 << " "
			 << endl ).flush();
#endif

    int R = MPI_Irecv(&Size,1,MPI_INT,MPI_ANY_SOURCE,Tag,
                  comm_service::comm_io(),req());
    if ( MPI_SUCCESS != R )
      comm_service::error_die("DAGHIOServerRcv::callrecv","MPI_Irecv",R);

#endif
  }

void DAGHIOServerRcv::rcv_update(void *Rcv)
  {
   GridDataBucketVoid *rcvbkt = new GridDataBucketVoid(Rcv);

#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "GridTableCommRcv::rcv_update " 
                         << comm_service::proc_me() << " "
			 << "Recieved { " 
			 << *rcvbkt->head() 
			 << " }" 
			 << endl ).flush();
#endif

   const int type = rcvbkt->type();

   if (wf) {
     if (type == DAGHPacked) {
       int num = rcvbkt->num();
       for (int i=0;i<num;i++) {
#ifdef DEBUG_PRINT_COMM_IO
       ( comm_service::log() << "GridTableCommRcv::rcv_update " 
                             << comm_service::proc_me() << " "
			     << "Writing (" << i << "){ " 
			     << *rcvbkt->head(i) 
			     << " }" 
			     << endl ).flush();
#endif
         (wf)(gh, rcvbkt->head(i), rcvbkt->data(i));
       }
     }
     else {
#ifdef DEBUG_PRINT_COMM_IO
       ( comm_service::log() << "GridTableCommRcv::rcv_update " 
                             << comm_service::proc_me() << " "
			     << "Writing { " 
			     << *rcvbkt->head() 
			     << " }" 
			     << endl ).flush();
#endif
       (wf)(gh, rcvbkt->head(),rcvbkt->data());
     }
   }
   else {
     cerr << "DAGHIOServerRcv::rcv_update: WriteFunc not set" << "\n";
   }

   delete rcvbkt;
   rcvbkt = 0;
  }

const char * DAGHIOServerRcv::name( void ) const
  {
   static const char Name[] = "DAGHIOServerRcv" ;
   return Name ;
  }

/*************************************************************************/
/* DAGHIOServerSnd */
/*************************************************************************/
DAGHIOServerSnd::DAGHIOServerSnd(const unsigned tag, 
                                 GridHierarchy& gridhierarchy,
                                 DAGHIO_ReadFunc readfunc)
 	:comm_service(DAGHNull,tag), gh(gridhierarchy), 
	 Size(sizeof(struct gdhdr)), rf(readfunc), end_cnt(0)
  {
#ifdef DAGH_NO_MPI
#else

#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerSnd::DAGHIOServerSnd " 
			 << comm_service::proc_me() << " "
			 << " MPI_Irecv: "
			 << "Tag: " << Tag << " " 
			 << "Size: " << Size << " "
			 << endl ).flush();
#endif

    int R = MPI_Irecv(&Req,sizeof(struct gdhdr),MPI_BYTE,
                      MPI_ANY_SOURCE,Tag,comm_service::comm_io(),req());
    if ( MPI_SUCCESS != R ) 
      comm_service::error_die("DAGHIOServerSnd::DAGHIOServerSnd","MPI_Irecv",R);

#endif

  }

void DAGHIOServerSnd::callrecv( const MPI_Status & MS )
  {
    if (Req.type == DAGHNull) {
      if (++end_cnt == comm_service::proc_num()){
#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerSnd::callrecv " 
			 << comm_service::proc_me() << " "
                         << "EndCnt = " << end_cnt << " "
			 << "Ending ServerSnd"
			 << endl ).flush();
#endif
	 return;
      }
      else {
#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerSnd::callrecv " 
			 << comm_service::proc_me() << " "
                         << "EndCnt = " << end_cnt
			 << endl ).flush();
#endif
      }
    }
    else {
      snd_update( Req );
    } 

#ifdef DAGH_NO_MPI
#else

#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerSnd::callrecv " 
			 << comm_service::proc_me() << " "
			 << " MPI_Irecv: "
			 << "Tag: " << Tag << " " 
			 << "Size: " << Size << " "
			 << endl ).flush();
#endif

    int R = MPI_Irecv(&Req,sizeof(struct gdhdr),MPI_BYTE,
                      MPI_ANY_SOURCE,Tag,comm_service::comm_io(),req());
    if ( MPI_SUCCESS != R ) 
      comm_service::error_die("DAGHIOServerSnd::callrecv","MPI_Irecv",R);

#endif

  }

void DAGHIOServerSnd::snd_update(struct gdhdr& Req)
  {

#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerSnd::snd_update " 
			 << comm_service::proc_me() << " "
			 << "Request("
			 << Req
			 << ")"
			 << endl ).flush();
#endif

   GridDataBucketVoid *bkt = 
                new GridDataBucketVoid(Req,DAGHIO_DataSize(Req.gfdatatype));

   const unsigned T = (DAGHIOTag|DAGHIOReadDataTag|Req.index);

   if (rf) {
     (rf)(gh, bkt->head(),bkt->data());
   }
   else {
     cerr << "DAGHIOServerSnd::snd_update: ReadFunc not set" << "\n";
   }

   const int dest = bkt->owner();
   void *package = 0; unsigned size;
   bkt->pack(package,size);

#ifdef DAGH_NO_MPI
#else

#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerSnd::snd_update" << " " 
                         << comm_service::proc_me() << " "
                         << "MPI_Rsend: " << " "
                         << T << " "
                         << "Size: " << size << " "
                         << "Dest: " << dest << " "
                         << endl ).flush();
#endif

   int R = MPI_Rsend(package, size, MPI_BYTE, dest,
                     T, comm_service::comm_io() );

   if ( MPI_SUCCESS != R )
     comm_service::error_die("DAGHIOServerSnd::snd_update","MPI_Rsend",R);

#endif

   delete bkt;
  }

const char * DAGHIOServerSnd::name( void ) const
  {
   static const char Name[] = "DAGHIOServerSnd" ;
   return Name ;
  }

/*************************************************************************/
/* DAGHIOServerPing */
/*************************************************************************/
DAGHIOServerPing::DAGHIOServerPing(const unsigned tag, 
                                   GridHierarchy& gridhierarchy,
                                   DAGHIO_PingFunc pingfunc)
 	: comm_service(DAGHNull,tag), gh(gridhierarchy), pf(pingfunc),
	  flag(DAGHTrue), end_cnt(0)
  {

#ifdef DAGH_NO_MPI
#else

#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerPing::DAGHIOServerPing " 
			 << comm_service::proc_me() << " "
			 << " MPI_Irecv: "
			 << "Tag: " << Tag << " " 
			 << "Size: " << 0 << " "
			 << endl ).flush();
#endif

    int R = MPI_Irecv(&flag,1,MPI_INT,MPI_ANY_SOURCE,Tag,
                      comm_service::comm_io(),req());
    if ( MPI_SUCCESS != R ) 
      comm_service::error_die("DAGHIOServerPing::DAGHIOServerPing","MPI_Irecv",R);

#endif

  }

void DAGHIOServerPing::callrecv( const MPI_Status & MS )
  {
    if (flag == DAGHFalse) {
      if (++end_cnt == comm_service::proc_num()) {
#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerPing::callrecv " 
			 << comm_service::proc_me() << " "
                         << "EndCnt = " << end_cnt << " "
			 << "Ending ServerPing"
			 << endl ).flush();
#endif
	return;
      }
      else {
#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerPing::callrecv " 
			 << comm_service::proc_me() << " "
                         << "EndCnt = " << end_cnt
			 << endl ).flush();
#endif
      }
    }
    else {
      if (pf) {
	(pf) (gh);
      }
      else {
	cerr << "DAGHIOServerPing::callrecv: PingFunc not set" << "\n";
      }
    }

    if (!comm_service::comminit()) return;

#ifdef DAGH_NO_MPI
#else

#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIOServerPing::callrecv " 
			 << comm_service::proc_me() << " "
			 << " MPI_Irecv: "
			 << "Tag: " << Tag << " " 
			 << "Size: " << 0 << " "
			 << endl ).flush();
#endif

    flag = DAGHTrue;
    int R = MPI_Irecv(&flag,1,MPI_INT,MPI_ANY_SOURCE,Tag,
                      comm_service::comm_io(),req());
    if ( MPI_SUCCESS != R ) 
      comm_service::error_die("DAGHIOServerPing::commrecv","MPI_Irecv",R);

#endif
  }

const char * DAGHIOServerPing::name( void ) const
  {
   static const char Name[] = "DAGHIOServerPing" ;
   return Name ;
  }
