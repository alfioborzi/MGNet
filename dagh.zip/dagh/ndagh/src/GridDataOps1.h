#ifndef _included_GridDataOps_1_h
#define _included_GridDataOps_1_h

/*
*************************************************************************
*                                                                       *
* GridDataOps1.h                                                        *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

template <class Type>
void GridData(1)<Type>::lin_interp (GridData(1)<Type> const &gd1, double const frac1,
                   GridData(1)<Type> const &gd2, double const frac2,
                   BBox const &where)
  {
   BBox intersection = _bbox * gd1._bbox * gd2._bbox * where;
   if (!intersection.empty())
    {
     //Coords max_step = (_step > gd1._step) ? _step : 
     //		(gd1._step > gd2._step) ? gd1._step : gd2._step;

     Coords max_step = max(_step, gd1._step);
     max_step.max(gd2._step);

     GridData(1)<Type> &dst = *this;

     BeginFastIndex1(src1, gd1._bbox, gd1._data, const Type);
     BeginFastIndex1(src2, gd2._bbox, gd2._data, const Type);
     BeginFastIndex1(dst, dst._bbox, dst._data, Type);

     for_1(i, intersection, max_step)
       FastIndex1(dst,i) = (Type) ((FastIndex1(src1,i) * frac1)
			 + (FastIndex1(src2,i) * frac2));
     end_for

     EndFastIndex1(dst);
     EndFastIndex1(src1);
     EndFastIndex1(src2);
   }
  }

/**************************************************************************/

template <class Type>
void GridData(1)<Type>::equals (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(equal)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(1)<Type>::equals (GridData(1)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(equal)(gd, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(1)<Type>::plus (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(plus)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(1)<Type>::plus (GridData(1)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(plus)(gd, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(1)<Type>::minus (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(minus)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(1)<Type>::minus (GridData(1)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(minus)(gd, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(1)<Type>::multiply (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(mult)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(1)<Type>::multiply (GridData(1)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(mult)(gd, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(1)<Type>::divide (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(div)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(1)<Type>::divide (GridData(1)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(div)(gd, newto, newfrom, max_step);
     }
  }

/****************************** = ***************************************/

template <class Type>
void GridData(1)<Type>::gd_OperateRegion(equal) (Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(1)<Type> &dst = *this;

   BeginFastIndex1(dst, dst._bbox, dst._data, Type);

   for_1(i, to, step)
      FastIndex1(dst,i) = val;
   end_for

   EndFastIndex1(dst);
  }

template <class Type>
void GridData(1)<Type>::gd_OperateRegion(equal) (GridData(1)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(1)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);

   BeginFastIndex1(src, src._bbox, src._data, const Type);
   BeginFastIndex1(dst, dst._bbox, dst._data, Type);

   for_1(i, to, step)
      FastIndex1(dst,i) = FastIndex1(src,i+di);
   end_for

   EndFastIndex1(dst);
   EndFastIndex1(src);
  }

/************************************************************************/

/****************************** + ***************************************/

template <class Type>
void GridData(1)<Type>::gd_OperateRegion(plus)(Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(1)<Type> &dst = *this;

   BeginFastIndex1(dst, dst._bbox, dst._data, Type);

   for_1(i, to, step)
      FastIndex1(dst,i) += val;
   end_for

   EndFastIndex1(dst);
  }

template <class Type>
void GridData(1)<Type>::gd_OperateRegion(plus)(GridData(1)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(1)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);

   BeginFastIndex1(src, src._bbox, src._data, const Type);
   BeginFastIndex1(dst, dst._bbox, dst._data, Type);

   for_1(i, to, step)
      FastIndex1(dst,i) += FastIndex1(src,i+di);
   end_for

   EndFastIndex1(dst);
   EndFastIndex1(src);
  }

/************************************************************************/

/****************************** - ***************************************/

template <class Type>
void GridData(1)<Type>::gd_OperateRegion(minus)(Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(1)<Type> &dst = *this;

   BeginFastIndex1(dst, dst._bbox, dst._data, Type);

   for_1(i, to, step)
      FastIndex1(dst,i) -= val;
   end_for

   EndFastIndex1(dst);
  }

template <class Type>
void GridData(1)<Type>::gd_OperateRegion(minus)(GridData(1)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(1)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);

   BeginFastIndex1(src, src._bbox, src._data, const Type);
   BeginFastIndex1(dst, dst._bbox, dst._data, Type);

   for_1(i, to, step)
      FastIndex1(dst,i) -= FastIndex1(src,i+di);
   end_for

   EndFastIndex1(dst);
   EndFastIndex1(src);
  }

/************************************************************************/

/****************************** * ***************************************/

template <class Type>
void GridData(1)<Type>::gd_OperateRegion(mult)(Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(1)<Type> &dst = *this;

   BeginFastIndex1(dst, dst._bbox, dst._data, Type);

   for_1(i, to, step)
      FastIndex1(dst,i) *= val;
   end_for

   EndFastIndex1(dst);
  }

template <class Type>
void GridData(1)<Type>::gd_OperateRegion(mult)(GridData(1)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(1)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);

   BeginFastIndex1(src, src._bbox, src._data, const Type);
   BeginFastIndex1(dst, dst._bbox, dst._data, Type);

   for_1(i, to, step)
      FastIndex1(dst,i) *= FastIndex1(src,i+di);
   end_for

   EndFastIndex1(dst);
   EndFastIndex1(src);
  }

/************************************************************************/

/****************************** / ***************************************/

template <class Type>
void GridData(1)<Type>::gd_OperateRegion(div)(Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   assert (val != (Type)0);
   GridData(1)<Type> &dst = *this;

   BeginFastIndex1(dst, dst._bbox, dst._data, Type);

   for_1(i, to, step)
      FastIndex1(dst,i) /= val;
   end_for

   EndFastIndex1(dst);
  }

template <class Type>
void GridData(1)<Type>::gd_OperateRegion(div)(GridData(1)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(1)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);

   BeginFastIndex1(src, src._bbox, src._data, const Type);
   BeginFastIndex1(dst, dst._bbox, dst._data, Type);

   for_1(i, to, step)
      FastIndex1(dst,i) /= FastIndex1(src,i+di);
   end_for

   EndFastIndex1(dst);
   EndFastIndex1(src);
  }
/************************************************************************/

#endif
