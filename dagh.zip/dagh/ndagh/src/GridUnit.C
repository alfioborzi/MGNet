/*
*************************************************************************
*                                                                       *
* GridUnit.C                                                          	*
*                                                                       *
* Class GridUnit implements a uniform block of the computational Grid.  *
* The unit is identified by is position (baseindex) and it's size (ext- *
* ent) at a particular level. A GridUnit can be refine or coarsened     *
* or can be decomposed into GridUnits of smaller extent.                *
* For a given base, and extent at a level, the size of the GridUnit at  *
* the level is (base)^(dim*extent). Thus the size of the GridUnit is    *
* limited to powers of the base.                                        *
* Note that, a uniform block of a single level of the Grid can also     *
* be represented (as a special case) by GridUnit.                       *
* GridUnit class provides a member function to query the baseindices of *
* neighboring GridUnits at different levels.                            *
*                                                                       *
* The entire computational Grid is maintainted as a combination of      *
* GridUnits.                                                            *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"

#include "GridUnit.h"

#ifdef DEBUG_PRINT
#include "CommServer.h"
#endif

#ifndef __ENABLE_INLINE__
#include "GridUnit.inline"
#endif

/*
*************************************************************************
*                                                                       *
* GridUnit::GridUnit (...... )						*	
*                                                                       *
* Constructor with baseindex specified as coordinates/ph-index. 	*
* Uses the Map/Invert of baseindex to generate the associted sfc 	*
* mapping.								*
* The extent of	GridUnit is specified in terms of levels such that	*
* number of elements = base^(dim*extent). Note that the extent referers	*
* to the topmost level; num is the sum of the elements at all numlev 	*
* levels; and baselev is the base level grid.				*
* An initial refinement of reflev leval can be specified - in which 	*
* case numlev is set to reflev and num and extent are accordingly 	*
* updated.								*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

GridUnit::GridUnit(const int ndim, const int clev, 
	           unsigned const *bcoords, const int ext, const int mlev, 
		   const int lstep, const int reflev)
	: owner(DAGHNoBody), index(DAGHNull), dim(ndim), 
          baselev(clev-ext),
          crslev(clev), finelev(clev+(lstep*reflev)),
          maxlev(mlev), minlev(clev), levstep(lstep), 
          extent(ext+(lstep*reflev)),
          baseindex(ndim,mlev), lowindex(ndim,mlev)
  {
   assert(clev >= ext);
   baseindex.Map(bcoords);
   assert(clev > ext || baseindex.sfcGetIndex() == 0);
   guSetBBox();
  }

GridUnit::GridUnit(const int ndim, const int clev, 
		   unsigned const bindex, const int ext, const int mlev, 
		   const int lstep, const int reflev)
        : owner(DAGHNoBody), index(DAGHNull), dim(ndim),
          baselev(clev-ext),
          crslev(clev), finelev(clev+(lstep*reflev)),
          maxlev(mlev), minlev(clev), levstep(lstep),
          extent(ext+(lstep*reflev)),
          baseindex(ndim,mlev), lowindex(ndim,mlev)
  {
   assert(clev > ext || bindex == 0);
   assert(bindex < baseindex.GetCardinality(crslev));
   baseindex.SetIndex(bindex,crslev);
   guSetBBox();
  }

/*
*************************************************************************
*                                                                       *
* GridUnit const &GridUnit::operator= (GridUnit const &other)		*
*                                                                       *
* Overload the assignment operator for GridUnit                       	*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

GridUnit const &GridUnit::operator= (GridUnit const &other)
  {
   if (this != &other)
     {
      owner = other.owner;
      index = other.index;
      dim = other.dim;
      baselev = other.baselev;
      crslev = other.crslev;
      finelev = other.finelev;
      maxlev = other.maxlev;
      minlev = other.minlev;
      levstep = other.levstep;
      extent = other.extent;
      baseindex = other.baseindex;
      fbb = other.fbb;
      mbb = other.mbb;
     }
   return(*this);
  }

/*
*************************************************************************
*                                                                       *
* QUERY Routines                                                        *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

void GridUnit::guSetBBox()
{
 register int step = baseindex.GetDimCardinality(finelev);
 Coords lc = guLCoords(finelev);
 Coords uc = guUCoords(finelev);
 fbb = BBox (lc.getmin(uc),uc.getmax(lc),step);
}

BBox GridUnit::guBBoxAbs(const int lev, const int olap, 
                                        const int extgh) const
{
 assert(lev >= 0);
 if (!fbb.empty() && lev==finelev) {
   return ( (olap==0 && extgh==0) ? fbb : 
            (extgh==0) ? growupper(fbb,olap) :
                         grow(growupper(fbb,olap),extgh) );
 }
 else if (!fbb.empty() && lev<finelev) {
   BBox tmpbb = coarsen(fbb,baseindex.GetCardinality(1,finelev-lev));
   return ( (olap==0 && extgh==0) ? tmpbb : 
            (extgh==0) ? growupper(tmpbb,olap) :
                         grow(growupper(tmpbb,olap),extgh) );
 }
 else {
   register int step = baseindex.GetDimCardinality(lev);
   Coords lc = guLCoords(lev);
   Coords uc = guUCoords(lev);
   BBox tmpbb (lc.getmin(uc)-(extgh*step),
               uc.getmax(lc)+((olap+extgh)*step), step);
   return (tmpbb);
 }
}

BBox GridUnit::guBBoxAbs(const int lev, const short* olap, 
                                        const int extgh) const
{
 assert(lev >= 0);
 if (!fbb.empty() && lev==finelev) {
   return ( (olap==0 && extgh==0) ? fbb : 
            (extgh==0) ? growupperbydim(fbb,olap) :
                         grow(growupperbydim(fbb,olap),extgh) );
 }
 else if (!fbb.empty() && lev<finelev) {
   BBox tmpbb = coarsen(fbb,baseindex.GetCardinality(1,finelev-lev));
   return ( (olap==0 && extgh==0) ? tmpbb : 
            (extgh==0) ? growupperbydim(tmpbb,olap) :
                         grow(growupperbydim(tmpbb,olap),extgh) );
 }
 else {
   register int step = baseindex.GetDimCardinality(lev);
   Coords lc = guLCoords(lev);
   Coords uc = guUCoords(lev);
   BBox tmpbb (lc.getmin(uc)-(extgh*step),
               uc.getmax(lc)+(extgh*step), step);
   return ( (olap == 0) ? tmpbb : growupperbydim(tmpbb,olap) );
 }
}

BBox GridUnit::guBBox(const int lev, const int olap,
                                     const int extgh) const
{
 if (lev>finelev || lev<crslev) {
   register int step = baseindex.GetDimCardinality(lev);
   BBox bb(dim,step);
   return (bb);
 }
 else if (!fbb.empty() && lev==finelev) {
     return ( (olap==0 && extgh==0) ? fbb : 
            (extgh==0) ? growupper(fbb,olap) :
                         grow(growupper(fbb,olap),extgh) );
 }
 else if (!fbb.empty() && lev<finelev) {
   BBox tmpbb = coarsen(fbb,baseindex.GetCardinality(1,finelev-lev));
   return ( (olap==0 && extgh==0) ? tmpbb : 
            (extgh==0) ? growupper(tmpbb,olap) :
                         grow(growupper(tmpbb,olap),extgh) );
 }
 else {
   register int step = baseindex.GetDimCardinality(lev);
   Coords lc = guLCoords(lev);
   Coords uc = guUCoords(lev);
   BBox tmpbb (lc.getmin(uc)-(extgh*step),
               uc.getmax(lc)+((olap+extgh)*step), step);
   return (tmpbb);
 }
}

BBox GridUnit::guBBox(const int lev, const short* olap,
                                     const int extgh) const
{
 if (lev>finelev || lev<crslev) {
   register int step = baseindex.GetDimCardinality(lev);
   BBox bb(dim,step);
   return (bb);
 }
 else if (!fbb.empty() && lev==finelev) {
     return ( (olap==0 && extgh==0) ? fbb : 
            (extgh==0) ? growupperbydim(fbb,olap) :
                         grow(growupperbydim(fbb,olap),extgh) );
 }
 else if (!fbb.empty() && lev<finelev) {
   BBox tmpbb = coarsen(fbb,baseindex.GetCardinality(1,finelev-lev));
   return ( (olap==0 && extgh==0) ? tmpbb : 
            (extgh==0) ? growupperbydim(tmpbb,olap) :
                         grow(growupperbydim(tmpbb,olap),extgh) );
 }
 else {
   register int step = baseindex.GetDimCardinality(lev);
   Coords lc = guLCoords(lev);
   Coords uc = guUCoords(lev);
   BBox tmpbb (lc.getmin(uc)-(extgh*step),
               uc.getmax(lc)+(extgh*step), step);
   return ( (olap == 0) ? tmpbb : growupperbydim(tmpbb,olap) );
 }
}

BBox GridUnit::guMergedBBox(const int lev, const int olap,
                                           const int extgh) const
{
 if (!mbb.empty() && lev == finelev) {
   return ( (olap==0 && extgh==0) ? mbb : 
            (extgh==0) ? growupper(mbb,olap) :
                         grow(growupper(mbb,olap),extgh) );
 }
 if (!mbb.empty() && lev < finelev) {
   BBox tmpbb = coarsen(mbb,baseindex.GetCardinality(1,finelev-lev));
   return ( (olap==0 && extgh==0) ? tmpbb : 
            (extgh==0) ? growupper(tmpbb,olap) :
                         grow(growupper(tmpbb,olap),extgh) );
 }
 else {
   register int step = baseindex.GetDimCardinality(lev);
   BBox bb(dim,step);
   return (bb);
 }
}

BBox GridUnit::guMergedBBox(const int lev, const short* olap,
                                           const int extgh) const
{
 if (!mbb.empty() && lev == finelev) {
   return ( (olap==0 && extgh==0) ? mbb : 
            (extgh==0) ? growupperbydim(mbb,olap) :
                         grow(growupperbydim(mbb,olap),extgh) );
 }
 if (!mbb.empty() && lev < finelev) {
   BBox tmpbb = coarsen(mbb,baseindex.GetCardinality(1,finelev-lev));
   return ( (olap==0 && extgh==0) ? tmpbb : 
            (extgh==0) ? growupperbydim(tmpbb,olap) :
                         grow(growupperbydim(tmpbb,olap),extgh) );
 }
 else {
   register int step = baseindex.GetDimCardinality(lev);
   BBox bb(dim,step);
   return (bb);
 }
}

BBox GridUnit::guBBox(const int minl, const int maxl, 
		      const short* olap, const int extgh) const
{
 if (minl>finelev || maxl<crslev) {
   register int step = baseindex.GetDimCardinality(maxl);
   BBox bb(dim,step);
   return (bb);
 }
 else if (!fbb.empty() && maxl>=finelev) {
     return ( (olap==0 && extgh==0) ? fbb : 
            (extgh==0) ? growupperbydim(fbb,olap) :
                         grow(growupperbydim(fbb,olap),extgh) );
 }
 else if (!fbb.empty() && maxl<finelev) {
   BBox tmpbb = coarsen(fbb,baseindex.GetCardinality(1,finelev-maxl));
   return ( (olap==0 && extgh==0) ? tmpbb : 
            (extgh==0) ? growupperbydim(tmpbb,olap) :
                         grow(growupperbydim(tmpbb,olap),extgh) );
 }
 else {
   register int step = baseindex.GetDimCardinality(maxl);
   Coords lc = guLCoords(maxl);
   Coords uc = guUCoords(maxl);
   BBox tmpbb (lc.getmin(uc)-(extgh*step),
               uc.getmax(lc)+(extgh*step), step);
   return ( (olap == 0) ? tmpbb : growupperbydim(tmpbb,olap) );
 }
}

BBox GridUnit::guMergedBBox(const int minl, const int maxl, 
			    const short* olap, const int extgh) const
{
 if (!mbb.empty() && (minl>finelev || maxl<crslev)) {
   register int step = baseindex.GetDimCardinality(maxl);
   BBox bb(dim,step);
   return (bb);
 }
 else if (!mbb.empty() && maxl>=finelev) {
   return ( (olap==0 && extgh==0) ? mbb : 
            (extgh==0) ? growupperbydim(mbb,olap) :
                         grow(growupperbydim(mbb,olap),extgh) );
 }
 if (!mbb.empty() && maxl<finelev) {
   BBox tmpbb = coarsen(mbb,baseindex.GetCardinality(1,finelev-maxl));
   return ( (olap==0 && extgh==0) ? tmpbb : 
            (extgh==0) ? growupperbydim(tmpbb,olap) :
                         grow(growupperbydim(tmpbb,olap),extgh) );
 }
 else {
   register int step = baseindex.GetDimCardinality(maxl);
   BBox bb(dim,step);
   return (bb);
 }
}

int GridUnit::guInside(const BBox& bbox, const int lev) const
  {
    if (lev>finelev || lev<crslev) return 0;
    int *cu = new int[dim];
    int *cl = new int[dim];
    baseindex.GetCoords((unsigned *)cl,lev); 
    dMapIndex ti(baseindex); ti.SetBox(lev,extent-(finelev-lev));
    ti.GetCoords((unsigned *)cu,lev);

    if (bbox.inside(cl) && bbox.inside(cu))  {
      if (cu) delete [] cu;
      if (cl) delete [] cl; 
      return 1; 
    }
    else { 
      if (cu) delete [] cu;
      if (cl) delete [] cl; 
      return 0; 
    }
  }

/*
*************************************************************************
*                                                                       *
* void GridUnit::guRefine (const int levs)				*	
*                                                                       *
* Member function guRefine refines the GridUnit by "levs" levels.	*
* The grid extent level is incremented by "levs"; i.e. the GridUnit	*
* contains (Base)^dim*(extlev+levs) points.				*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

void GridUnit::guRefine (const int levs)
  {
   int levels = levs*levstep;
   assert(finelev+levels <= maxlev);

   extent += levels;
   finelev += levels;
   baselev = finelev-extent;
   guSetBBox();
  }

void GridUnit::guRefine (GridUnit &gu, const int levs)
  {
   int levels = levs*levstep;
   assert(finelev+levels <= maxlev);

   gu.owner = owner;
   gu.index = index;
   gu.dim = dim;
   gu.levstep = levstep;
   gu.maxlev = maxlev;
   gu.minlev = minlev;

   gu.crslev = finelev+levstep;
   gu.finelev = finelev+levels;
   gu.extent = extent+levels; 
   gu.baselev = gu.finelev-gu.extent;

   gu.baseindex = baseindex;
   gu.guSetBBox();
  }

/*
*************************************************************************
*                                                                       *
* void GridUnit::guCoarsen (const int levs)				*	
*                                                                       *
* Member function guCoarsen corsens the GridUnit by "levs" levels.	*
* The grid extent level is decremented by "levs"; i.e. the GridUnit	*
* contains (Base)^dim*(extlev-levs) points.				*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

void GridUnit::guCoarsen (const int levs)
  {
   int levels = levs*levstep;
   assert(finelev-levs >= crslev);

   extent -= levels; 
   finelev -= levels;
   baselev = finelev-extent;
   guSetBBox();
  }

void GridUnit::guCoarsen (GridUnit &gu, const int levs)
  {
   int levels = levs*levstep;
   assert(finelev-levs >= crslev);

   gu.owner = owner;
   gu.index = index;
   gu.dim = dim;
   gu.levstep = levstep;
   gu.maxlev = maxlev;
   gu.minlev = minlev;

   gu.crslev = crslev;
   gu.finelev = finelev-levels;
   gu.extent = extent-levels; 
   gu.baselev = gu.finelev-gu.extent;

   gu.baseindex = baseindex;
   gu.guSetBBox();
  }

/*
****************************************************************************
*                                                                          *
* Member function guDecompose decomposes the GridUnit into an array of	   *
* (Base)^dim*lev GridUnits with extent = extent-lev;			   *
* i.e. (Base)^dim*(extlev-lev) points.					   *
*                                                                          *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                        *
*                                                                          *
****************************************************************************
*/

void GridUnit::guDecompose (GridUnit**& gu, int& cnt, const int lev) const
  {
   if (lev == 0) { cnt = 0; return; }
   const int numlev = (finelev-crslev)/levstep + 1;
   assert(lev > 0 && lev <= extent-(numlev-1)*levstep);

   cnt = baseindex.GetCardinality(lev);
   register unsigned newext = extent-lev;
   register unsigned newblev = baselev+lev;

   //if (gu) delete [] gu;
   assert (!gu);
   gu = new GridUnit *[cnt];
 
   for (int i=0;i<cnt;i++) {
     gu[i] = new GridUnit(*this);
     gu[i]->baselev = newblev;
     gu[i]->extent = newext;

     gu[i]->baseindex.SetIndex(i,newblev,lev);
     gu[i]->guSetBBox();
   }
  }

/*
****************************************************************************
*                                                                          *
* Member function guDecomposeReplicate decomposes the GridUnit into an 	   *
* array of (Base)^dim*lev GridUnits with extent = extent-lev;		   *
* i.e. (Base)^dim*(extlev-lev) points.					   *
* If the new extent at any level is less than the "minext", that level    *
* is replicated across the grid units with the first GridUnit as the owner *
*                                                                          *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                        *
*                                                                          *
****************************************************************************
*/

void GridUnit::guDecomposeReplicate (GridUnit**& gu, int& cnt, 
			const int lev, const int minext) const
  {
   if (lev == 0) { cnt = 0; return; }

   const int numlev = (finelev-crslev)/levstep + 1;
   int newcext = (extent-(numlev-1)*levstep) - lev;

   int newclev;
   if (newcext>=minext) newclev = crslev;
   else if ((minext-newcext)%levstep > 0)
     newclev = crslev + ((minext-newcext+levstep)/levstep)*levstep;
   else 
     newclev = crslev + minext-newcext;

   cnt = baseindex.GetCardinality(lev);
   register int newext = extent-lev;
   register int newblev = baselev+lev;

   //if (gu) delete [] gu;
   assert (!gu);
   gu = new GridUnit *[cnt];
 
   for (int i=0;i<cnt;i++) {
     gu[i] = new GridUnit(*this);
     gu[i]->baselev = newblev;
     gu[i]->extent = newext;
     gu[i]->baseindex.SetIndex(i,newblev,lev);
     if (i != 0)  {
       gu[i]->crslev = newclev;
     }
     gu[i]->guSetBBox();
   }
  }

/*
*************************************************************************
*                                                                       *
* GridUnit **GridUnit::guGetLevels(void) const				*
*                                                                       *
* Member function guGetLevels returns the GridUnits's at different 	*
* levels of the composite GridUnit as an array.				*
* The returned array is of dimension maxlev-crslev. The undefined 	*
* levels are (GridUnit *) NULL.						*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

void GridUnit::guGetLevels(GridUnit** &gu) const
  {

   //if (gu) delete [] gu;
   assert (!gu);
   gu = new GridUnit *[(maxlev-minlev)/levstep+1];

   const int numlev = (finelev-crslev)/levstep + 1;
   unsigned ext = extent-(numlev-1)*levstep;

   int offset = (minlev-crslev)/levstep;
   for (int i=0;i<numlev;i++) {
     gu[i+offset] = new GridUnit(*this);
     gu[i+offset]->crslev = (i*levstep)+crslev;
     gu[i+offset]->finelev = (i*levstep)+crslev;
     gu[i+offset]->extent = ext;
     gu[i+offset]->guSetBBox();
     ext += levstep;
   }
  }

void GridUnit::guGetLevels(GridUnit &gu, const int lev) const
  {
   register unsigned ext = extent-(finelev-lev);

   gu.owner = owner;
   gu.index = index;
   gu.dim = dim;
   gu.levstep = levstep;
   gu.maxlev = maxlev;
   gu.minlev = minlev;

   gu.crslev = lev;
   gu.finelev = lev;
   gu.extent = ext;

   gu.baselev = gu.finelev-gu.extent;
   gu.baseindex = baseindex;
   gu.guSetBBox();
  }

ostream&  operator << (ostream& os, const GridUnit& gu)
  {

   if (&gu == (GridUnit *)NULL) return os;

   os << "Owner: " << gu.owner << " ";
   os << "Idx: " << gu.index << " ";
   os << "Dim: " << gu.dim << " ";
   os << "Blev: " << gu.baselev << " ";
   os << "CLev: " << gu.crslev << " ";
   os << "Flev: " << gu.finelev << " ";
   os << "NLev: " << gu.guNumLev() << " ";
   os << "MLev: " << gu.maxlev << " ";
   os << "LStep: " << gu.levstep << " ";
   os << "Num: " << gu.guNum(0) << " ";
   os << "Work: " << gu.guWork(0) << " ";
   os << "Ext: " << gu.extent << " ";

   dMapIndex **neighbors = 0;
   for(int i=gu.crslev;i<=gu.finelev;i+=gu.levstep) {
     os <<  "\n";
     os << "Level " << i << ":";
     os << gu.guBBox(i) << " ";
     os << gu.guMergedBBox(i) << " ";
     os << gu.guBaseIndex() << " ";
     os << gu.guTopIndex(i) << " ";
     os << gu.guMaxIndex(i) << " ";
     os << gu.guExtent(i) << " ";
     os << gu.guNum(i) << " ";
     os << gu.guWork(i) << " ";
     os <<  "\n";
     /***************************/
     //neighbors = gu.guGetNeighbors(i);
     //os << "   Neighbors:" << " ";
     //for(int j=0;j<2*gu.dim;j++) {
     //  if (neighbors && neighbors[j]) {
     //    os << j << "-" << *neighbors[j] << "  ";
     //    delete neighbors[j];
     //  }
     //}
     //if (neighbors) delete [] neighbors;
     /***************************/
   }
   return os;
  }

ofstream&  operator << (ofstream& ofs, const GridUnit& gu)
  {

   if (&gu == (GridUnit *)NULL) return ofs;

   ofs.write((char*)&gu,sizeof(GridUnit));

   return ofs;
  }

ifstream&  operator >> (ifstream& ifs, GridUnit& gu)
  {

   if (&gu == (GridUnit *)NULL) return ifs;

   ifs.read((char*)&gu,sizeof(GridUnit));

   return ifs;
  }
