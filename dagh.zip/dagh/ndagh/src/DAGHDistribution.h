#ifndef _included_DAGHDistribution_h
#define _included_DAGHDistribution_h

/*
*************************************************************************
*                                                                       *
* DAGHDistribution.h							*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"

#include "List.h"
#include "GridUnit.h"
#include "GridUnitList.h"

/************************************************************************/
/* Pluggable Work function prototype */
/************************************************************************/
typedef unsigned long (*WorkFunc) (const unsigned long *numelems, 
                                   const int *level);
/************************************************************************/

class DAGHSpan 
  {
   dMapIndex min;
   dMapIndex max;

public:   
   inline DAGHSpan() {}

   inline DAGHSpan(dMapIndex const &lmin, dMapIndex const &lmax)
	: min(lmin), max(lmax) { }

   inline DAGHSpan(const DAGHSpan& other)
	: min(other.min), max(other.max) { }

   inline int contains(dMapIndex const index) const 
	{ return (index >= min && index <= max); }

   inline const DAGHSpan& operator = (const DAGHSpan& other)
      { min = other.min; max = other.max; return *this; }
  };

class DAGHDistribution
  {
   int type; 	/* Type of distribution */

   //List<DAGHSpan> localspans; /* Local index spans */
   
   BBox* boxes;  /* List of boxes for regular distributions */

   WorkFunc wfunc; /* Pluggable work function */

public:
   inline DAGHDistribution(const int disttype) 
	: type(disttype) , wfunc(0), boxes(0) { }

   DAGHDistribution(const int disttype, BBoxList& bbl);

   inline ~DAGHDistribution() { if (boxes) delete [] boxes; }

   void partition(GridUnitList*& globallist, 
                  GridUnitList*& locallist, 
                  const int np, const int me, 
                  const int minw, const short* olap);

   //int islocal(dMapIndex const &idx);

   inline int dist() const { return type; }

   inline void set_dist(const int disttype)
	{ type = disttype; }

   void set_dist(const int disttype, BBoxList& bbl);

   inline void set_workfunc( void *workfunc )
	{ wfunc = (WorkFunc) workfunc; }

   unsigned long get_load( GridUnitList &list,  const short* olap );

private:
   void partitionComposite(GridUnitList*& globallist, 
                           GridUnitList*& locallist, 
                           const int np, const int me, 
                           const int minw, const short* olap);

   void partitionBlockOne(const int axis,
                          GridUnitList*& globallist, 
                          GridUnitList*& locallist, 
                          const int np, const int me, 
                          const int minw, const short* olap);

   void partitionBlockTwo(const int axis1, const int axis2,
                          GridUnitList*& globallist, 
                          GridUnitList*& locallist, 
                          const int np, const int me, 
                          const int minw, const short* olap);

   void partitionBlockAll(GridUnitList*& globallist, 
                          GridUnitList*& locallist, 
                          const int np, const int me, 
                          const int minw, const short* olap);

   void partitionUserDef(GridUnitList*& globallist, 
                         GridUnitList*& locallist, 
                         const int np, const int me, 
                         const int minw, const short* olap);
  };

#endif
