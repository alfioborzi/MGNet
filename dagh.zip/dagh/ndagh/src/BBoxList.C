/*
************************************************************************* 
*                                                                       *
* class BBoxList							*
*                                                                       *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "BBoxList.h"


/*************************************************************************/
/* overloaded assignment */
/*************************************************************************/
BBoxList&  BBoxList::operator = (const BBoxList& cother)
  {
    BBoxList &other = (BBoxList &) cother;
    union record *tmpcur = other.currec();

    empty();
    BBox *bb = 0;
    for (bb=other.first();bb;bb=other.next()) {
      add(*bb);
    }

    assert(num==other.num);
    other.setcurrec(tmpcur);
    return *this;
  }
   
/*************************************************************************/
/* nest in another list */
/*************************************************************************/
void BBoxList::nest (const BBoxList &crhs)
  {
   BBoxList &rhs = (BBoxList &) crhs;
   union record *tmpcur = rhs.currec();

   register BBox *rhsbb = rhs.first();
   register BBox *bb = first();
   if (num == 0) {
     for (;rhsbb;rhsbb=rhs.next()) 
 	add(*rhsbb);
   }
   else {
     for (;rhsbb;rhsbb=rhs.next())  {
       for (;bb;bb=next()) {
         if (*rhsbb == *bb) break;
         else {
           BBox intersection = *rhsbb * *bb;
           if (!intersection.empty()) {
	     *bb += *rhsbb;
           }
         }
       }
       if (!bb) bb = first();
     }
   }

   rhs.setcurrec(tmpcur);
  }

/*************************************************************************/
/* merge the  boxes */
/*************************************************************************/
void BBoxList::mergeboxes(const short* olap)
  {
   if (num == 0) return;

   const int rank = (first())->rank;

   BBoxList mergebbl(*this);
   BBoxList bbl;

   register int onum = 0;
   register int rstrt = 0;
   register int d = 0;
   while (onum != mergebbl.num) {
     onum = mergebbl.num;

   //for (register int d=rank-1; d>=0 ; d--) {
   for (register int dd=0; dd<rank ; dd++) {
     d = (rstrt + dd)%rank;
     bbl = mergebbl;
     mergebbl.empty();
     for (BBox *bb=bbl.first();bb;bb=bbl.next()) {
       BBox mbb = *bb; 
       for (BBox *withbb=mergebbl.first();withbb;withbb=mergebbl.next()) {
         if (mbb.mergable(*withbb, d, olap[d])) {
           mbb += *withbb;
           mergebbl.remove();
         }
       }
       mergebbl.add(mbb);
       bbl.remove();
     }
     assert(bbl.isempty());
   } }

   empty();
   *this = mergebbl;
   rstrt++;
  }

/*************************************************************************/
/* reduce into a single bounding box */
/*************************************************************************/
BBox BBoxList::reduce()
  {
   if (num == 0) return BBox::_empty_bbox;

   union record *tmpcur = currec();
   
   BBox rbbox;
   register BBox *bb = first();
   rbbox.rank = bb->rank;
   for (;bb;bb=next()) rbbox += *bb;

   setcurrec(tmpcur);
   return rbbox;
  }

/*************************************************************************/
/* combine two lists */
/*************************************************************************/
void BBoxList::combine(const BBoxList &crhs)
  {
   BBoxList &rhs = (BBoxList &) crhs;
   union record *tmpcur = rhs.currec();

   register BBox *rhsbb = rhs.first();
   for (;rhsbb;rhsbb=rhs.next()) add(*rhsbb);

   rhs.setcurrec(tmpcur);
  }

/*************************************************************************/
/* and print it out... */
/*************************************************************************/
ostream&  operator << (ostream& os, const BBoxList& cbbl)
  {
   if (&cbbl == BBoxListNULL) return os;

   BBoxList &bbl = (BBoxList &) cbbl;
   union record *tmpcur = bbl.currec();

   os << "Num:" << bbl.num << " ";
   os <<  "\n";

   if (bbl.num == 0) return os;

   BBox *b = 0;
   os << *bbl.first();
   os << "\n**********************************\n";

   while ( (b=bbl.next()) != BBoxNULL ) {
        os << *b;
        os << "\n**********************************\n";
        os << flush;
   }

   bbl.setcurrec(tmpcur);
   return os;
  }

/*
*************************************************************************
*                                                                       *
* And overload BINARY << for the BBL class....				*
*                                                                       *
*************************************************************************
*/

ofstream&  operator << (ofstream& ofs, const BBoxList& cbbl)
  {
   if (&cbbl == BBoxListNULL) return ofs;

   BBoxList &bbl = (BBoxList &) cbbl;
   union record *tmpcur = bbl.currec();
 
   if (bbl.num == 0) return ofs;
   
   ofs.write((char*)&bbl.num,sizeof(int));

   BBox *b = 0;
   for (b = bbl.first(); b != BBoxNULL; b = bbl.next())
     ofs << *b;

   bbl.setcurrec(tmpcur);

   return ofs;
  }

ifstream&  operator >> (ifstream& ifs, BBoxList& cbbl)
  {
   if (&cbbl == BBoxListNULL) return ifs;

   BBoxList &bbl = (BBoxList &) cbbl;
   union record *tmpcur = bbl.currec();
 
   int numin;
   ifs.read((char*)&numin,sizeof(int));

   if (numin == 0) return ifs;

   BBox bb;
   for (register int n=0; n<numin; n++) {
     ifs >> bb;
     bbl.add(bb);
   }

   bbl.setcurrec(tmpcur);

   return ifs;
  }

