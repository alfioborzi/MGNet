
c---------------------- start of fn1.h ---------------------------------
        integer fn_ini
        FLOAT   alpha, beta, zeta, pi
        common /fn_con/ alpha, beta, zeta, pi, fn_ini
c----------------------- end of fn1.h ----------------------------------
