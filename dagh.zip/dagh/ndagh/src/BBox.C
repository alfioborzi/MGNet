/*
*************************************************************************
*									*
* BBox.C								*
*									*
* Author:  Manish Parashar <parashar@cs.utexas.edu>			*
*									*
*************************************************************************
*/

#include "BBox.h"

#ifndef __ENABLE_INLINE__
#include "BBox.inline"
#endif

#define MATCH(s, c) while ((s).get() != (c))

/*************************************************************************/
/* Static empty bbox */
/*************************************************************************/
class BBox BBox::_empty_bbox;
/*************************************************************************/

/*
*************************************************************************
*									*
* istream& operator >> (istream& s, BBox &bb)				*
*									*
* Operator >> reads in BBox information in the form [lower, upper, step]*
*									*
*************************************************************************
*/

istream& operator >> (istream& s, BBox &bb)
  {
   Coords low(bb.rank,0), high(bb.rank,0);
   Coords step(bb.rank,0);

   MATCH(s, '[');
   s >> low;
   MATCH(s, ',');
   s >> high;
   MATCH(s, ',');
   s >> step;
   MATCH(s, ']');

   BBox newbb(low, high, step);
   bb = newbb;
   return(s);
  }

/*
*************************************************************************
*                                                                       *
* ostream& operator << (ostream& s, BBox const &bb)                     *
*                                                                       *
* Operator << writes the point information in bb as [lower, upper].     *
*                                                                       *
*************************************************************************
*/

ostream& operator << (ostream& s, BBox const &bb)
  {
   if (bb.empty())
      s << "[(),()]";
   else {
      s << '[';
      s << bb.lower();
      s << ',';
      s << bb.upper();
      s << ',';
      s << bb.stepsize();
      s << ']';
   }
   return(s);
  }

/*
*************************************************************************
*									*
* ifstream& operator >> (ifstream& s, BBox& bb)			        *
* ofstream& operator << (ofstream& s, const BBox& bb)                   *
*									*
*************************************************************************
*/

ifstream&  operator >> (ifstream& s, BBox& bb)
  {
   if (&bb == (BBox *)NULL) return s;

   s.read((char*)&bb,sizeof(BBox));

   return s;
  }

ofstream&  operator << (ofstream& s, const BBox& bb)
  {
   if (&bb == (BBox *)NULL) return s;

   s.write((char*)&bb,sizeof(BBox));

   return s;
  }

/*
*************************************************************************
*									*
* BBox &BBox::operator += (BBox cosnt &rhs)				*
* int BBox::operator == (BBox cosnt &rhs) const				*
*									*
*************************************************************************
*/

/*$BBox &BBox::operator += (Coords const &rhs)
  {
   if (empty()) { lb = rhs; ub = rhs; return(*this); }
   lb.min(rhs);
   ub.max(rhs);
   return(*this);
  }

BBox &BBox::operator += (BBox const &rhs)
  {
   if (empty()) return(*this = rhs);
   if (rhs.empty()) return(*this);
   lb.min(rhs.lb);
   ub.max(rhs.ub);
   return(*this);
  }

int BBox::operator == (BBox const &rhs) const
  {
   return(((ub == rhs.ub) && (lb == rhs.lb)) || (empty() && rhs.empty()));
  }$*/

/*
*************************************************************************
*									*
* The mergable functions checks is two bounding boxes are mergable in	*
* a given direction.							*
*									*
*************************************************************************
*/

/*$int BBox::mergable(BBox const &rhs, const short* olap) const
{
  int flag = 0;
  for (int r=rank-1;r>=0;r--)
    flag = (flag || mergable(rhs, r, olap[r]));

  return flag;
}

int BBox::mergable(BBox const &rhs, const int d, const int olap) const
{
  int flag = 0;

  switch (rank)
  {
   case 1:
     assert (d < 1);
     flag =  (abs(lb(d) - rhs.ub(d)) == (1-olap)*step(d)) || 
             (abs(ub(d) - rhs.lb(d)) == (1-olap)*step(d));
     break;
   case 2:
     assert (d < 2);
     flag =  compatible(rhs,(d+1)%2) &&
             ((abs(lb(d) - rhs.ub(d)) == (1-olap)*step(d)) || 
             (abs(ub(d) - rhs.lb(d)) == (1-olap)*step(d)));
     break;
   case 3:
     assert (d < 3);
     flag =  compatible(rhs,(d+1)%3) &&
             compatible(rhs,(d+2)%3) &&
             ((abs(lb(d) - rhs.ub(d)) == (1-olap)*step(d)) || 
             (abs(ub(d) - rhs.lb(d)) == (1-olap)*step(d)));
     break;
  }
  
  return flag;
}$*/

/*
*************************************************************************
*									*
* The accrete() and grow() functions increase the size of a region.	*
* Both accrete() and grow() do the same thing.  The CC compiler had	*
* some trouble inlining them, so we define them here.			*
*									*
*************************************************************************
*/

/*$BBox accrete(BBox const &bbox, Coords const &c)
  {
   if (bbox.empty()) return(bbox);
   return(BBox(bbox.lower()-c*bbox.stepsize(), bbox.upper()+c*bbox.stepsize(),
							bbox.stepsize()));
  }

BBox grow(BBox const &bbox, Coords const &c)
  {
   if (bbox.empty()) return(bbox);
   return(BBox(bbox.lower()-c*bbox.stepsize(), bbox.upper()+c*bbox.stepsize(),
							bbox.stepsize()));
  }

BBox accrete(BBox const &bbox, const int c)
  {
   if (bbox.empty()) return(bbox);
   return(BBox(bbox.lower()-bbox.stepsize()*c, bbox.upper()+bbox.stepsize()*c,
							bbox.stepsize()));
  }

BBox grow(BBox const &bbox, const int c)
  {
   if (bbox.empty()) return(bbox);
   return(BBox(bbox.lower()-bbox.stepsize()*c, bbox.upper()+bbox.stepsize()*c,
							bbox.stepsize()));
  }$*/

BBox* accrete(BBox const *const bbox, const int n, const int c)
  {
   BBox **accreted = new BBox *[n];
   for (register int i = 0; i < n; i++) 
	accreted[i] = new BBox(accrete(bbox[i], c));

   return(*accreted);
  }

BBox* grow(BBox const *const bbox, const int n, const int c)
  {
   BBox **grown = new BBox *[n];
   for (register int i = 0; i < n; i++) 
	grown[i] = new BBox(grow(bbox[i], c));

   return(*grown);
  }

BBox* accrete(BBox const *const bbox, const int n, Coords const &c)
  {
   BBox **accreted = new BBox *[n];
   for (register int i = 0; i < n; i++) 
	accreted[i] = new BBox(accrete(bbox[i], c));

   return(*accreted);
  }

BBox* grow(BBox const *const bbox, const int n, Coords const &c)
  {
   BBox **grown = new BBox *[n];
   for (register int i = 0; i < n; i++) 
	grown[i] = new BBox(grow(bbox[i], c));

   return(*grown);
  }

/*$BBox growupper(BBox const &bbox, const int c)
  {
   if (bbox.empty()) return(bbox);
   return(BBox(bbox.lower(), bbox.upper()+bbox.stepsize()*c, bbox.stepsize()));
  }

BBox growlower(BBox const &bbox, const int c)
  {
   if (bbox.empty()) return(bbox);
   return(BBox(bbox.lower()+bbox.stepsize()*c, bbox.upper(), bbox.stepsize()));
  }

BBox growupper(BBox const &bbox, const int d, const int c)
  {
   if (bbox.empty()) return(bbox);
   Coords u = bbox.upper(); u(d) += c*bbox.stepsize(d);
   return(BBox(bbox.lower(), u, bbox.stepsize()));
  }

BBox growlower(BBox const &bbox, const int d, const int c)
  {
   if (bbox.empty()) return(bbox);
   Coords l = bbox.lower(); l(d) += c*bbox.stepsize(d);
   return(BBox(l, bbox.upper(), bbox.stepsize()));
  }$*/

/*$BBox growbydim (BBox const &bbox, const short *c)
  {
   BBox bb(bbox);
   if (bb.empty()) return(bb);
   for (int i=0;i<bb.rank;i++) {
     bb.lower(i) -= (bb.stepsize(i)*c[2*i]);
     bb.upper(i) += (bb.stepsize(i)*c[2*i+1]);
   }
   return bb;
  }

BBox growupperbydim (BBox const &bbox, const short *c)
  {
   BBox bb(bbox);
   if (bb.empty()) return(bb);
   for (int i=0;i<bb.rank;i++) {
     bb.upper(i) += (bb.stepsize(i)*c[i]);
   }
   return bb;
  }

BBox growlowerbydim (BBox const &bbox, const short *c)
  {
   BBox bb(bbox);
   if (bb.empty()) return(bb);
   for (int i=0;i<bb.rank;i++) {
     bb.lower(i) += (bb.stepsize(i)*c[i]);
   }
   return bb;
  }

BBox shrinkbydim (BBox const &bbox, const short *c)
  {
   BBox bb(bbox);
   if (bb.empty()) return(bb);
   for (int i=0;i<bb.rank;i++) {
     bb.lower(i) += (bb.stepsize(i)*c[2*i]);
     bb.upper(i) -= (bb.stepsize(i)*c[2*i+1]);
   }
   return bb;
  }

BBox shrinkupperbydim (BBox const &bbox, const short *c)
  {
   BBox bb(bbox);
   if (bb.empty()) return(bb);
   for (int i=0;i<bb.rank;i++) {
     bb.upper(i) -= (bb.stepsize(i)*c[i]);
   }
   return bb;
  }

BBox shrinklowerbydim (BBox const &bbox, const short *c)
  {
   BBox bb(bbox);
   if (bb.empty()) return(bb);
   for (int i=0;i<bb.rank;i++) {
     bb.lower(i) -= (bb.stepsize(i)*c[i]);
   }
   return bb;
  }$*/

/* Function shift() shifts the  space of the region */
/*$BBox shiftabs(BBox const &bb, const int c)
  { return(BBox(bb.lower()+c, bb.upper()+c, bb.stepsize())); }
BBox shiftabs(BBox const &bb, Coords const &c)
  { return(BBox(bb.lower()+c, bb.upper()+c, bb.stepsize())); }

BBox shift(BBox const &bb, const int c)
  { return(BBox(bb.lower()+bb.stepsize()*c, bb.upper()+bb.stepsize()*c,
                                                bb.stepsize())); }
BBox shift(BBox const &bb, Coords const &c)
  { return(BBox(bb.lower()+c*bb.stepsize(), bb.upper()+c*bb.stepsize(),
                                                bb.stepsize())); }

BBox shiftabs(BBox const &bbox, const int d, const int c)
  {
   if (bbox.empty()) return(bbox);
   Coords u = bbox.upper(); u(d) += c;
   Coords l = bbox.lower(); l(d) += c;
   return(BBox(l, u, bbox.stepsize()));
  }

BBox shift(BBox const &bbox, const int d, const int c)
  {
   if (bbox.empty()) return(bbox);
   Coords u = bbox.upper(); u(d) += c*bbox.stepsize(d);
   Coords l = bbox.lower(); l(d) += c*bbox.stepsize(d);
   return(BBox(l, u, bbox.stepsize()));
  }$*/

/* Function coarsen() coarsens  the BBox by a given factor */
/*$BBox coarsen(BBox const &bbox, const int by)
  {
   if (bbox.empty()) return(bbox);
   Coords s = bbox.stepsize() * by;
   Coords l = (bbox.lower() / s ) * s; 
   Coords u = (bbox.upper() / s ) * s; 
   return(BBox(l, u, s));
  }

BBox coarsen(BBox const &bbox, Coords const by)
  {
   if (bbox.empty()) return(bbox);
   Coords s = bbox.stepsize() * by;
   Coords l = (bbox.lower() / s ) * s; 
   Coords u = (bbox.upper() / s ) * s; 
   return(BBox(l, u, s));
  }

BBox coarsen(BBox const &bbox, const int d, const int by)
  {
   if (bbox.empty()) return(bbox);
   Coords s = bbox.stepsize(); s(d) *= by;
   Coords l = (bbox.lower() / s ) * s; 
   Coords u = (bbox.upper() / s ) * s; 
   return(BBox(l, u, s));
  }$*/
