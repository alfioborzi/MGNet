
/*
*************************************************************************
* DAGHIO_hdf_ncsa.C							
*                                                                       
* IO Interface to John Shalf / NCSA AMR HDF Files
* More info at http://bach.ncsa.uiuc.edu/IO/
*                                                                       
* Author:  Manish Parashar <parashar@cs.utexas.edu>   
*          Paul Walker <pwalker@ncsa.uiuc.edu>
*                                                                       
*************************************************************************
*/

#include "DAGHIO_hdf_ncsa.h"

#undef DEBUG_IO

void DAGHIO_HDF_NCSA_Write(GridHierarchy& gh, struct gdhdr* hdr, void* data)
  {
#if defined(IO_NCSAIO)||defined(IO_OLDNCSA)
   assert (hdr->gfdatatype == DAGH_Double);

   const BBox &bb = hdr->bbox;
   int rank = bb.rank;
   const double time = (double const) 1.0*hdr->time;

   char* gfname = hdr->gfname;
   int dims[5], origin[5], resolution[5], ub[5];
   

   for (int i=0;i<rank;i++) {
     dims[i] = bb.extents(i);
     origin[i] = bb.lower(i);
     ub[i] = bb.upper(i);
     resolution[i] = bb.stepsize(i);
   }
   if (rank == 1) {
     cerr << "Rank 1 data cannot be placed in an NCSA HDF File easily";
     return;
   }

   const int orank = rank;
   /* Fake up 3D data as a slice for now.  This is clearly a kludge. */
   if (orank == 2) {
     rank          = 3;
     dims[2]       = 1;
     origin[2]     = 0;
     ub[2]         = 1;
     resolution[2] = 1;
   }

   /* Flip dims in 3D */
   if (orank == 3) {
     int tflip = dims[2];
     dims[2] = dims[0];
     dims[0] = tflip;
   }

   char filename[256];
#ifdef DEBUG_IO
   (cout << "Writing a chunk with following:\n" <<
    "T   : " << hdr->time << "  L : " << hdr->level << 
    " NAME : " << gfname << "\n" <<
    "dims: " << dims[0] << " " << dims[1] << " " << dims[2] << "\n").flush();
#endif
#else
   (cerr << "Please recompile dagh with NCSA IO\n").flush();
   return;
#endif


#ifdef IO_NCSAIO
   sprintf(filename,"%s.hdf",gfname);
   SDSsetNT(filename,DFNT_FLOAT64);

   AMRwriteData(filename, gfname,
		(int32)(hdr->level), 
		(int32)(hdr->index), 
		(int32)(hdr->time), 
		(float64)0.0,
		(int32)(rank),
		dims, origin, resolution,
		data);
#endif
#ifdef IO_OLDNCSA
   WriteChunk(gfname,0,(int32)(hdr->level),(int32)(hdr->index),
	      (int32)(hdr->time),(int32)(rank), dims, origin, ub,
	      bb.size(), (double *)data);
#endif
  }

void DAGHIO_HDF_NCSA_Read(GridHierarchy &gh, struct gdhdr* hdr, void* data)
  {
   assert (hdr->gfdatatype == DAGH_Double);

   cerr << "DAGHIO_ncsa_rnpl.C\n" << "Read is defined, but not implemented\n";
  }

void DAGHIO_HDF_NCSA_Finalize() {
#ifdef IO_NCSAIO
  SDScloseAll();
#endif

#ifdef IO_OLDNCSA
  FinalizeIO();
#endif
}
