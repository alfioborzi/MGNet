/***********************************************************************
*
* Subroutine KLRES   Compute r = b - Ax
*
* Key: n  integer     i  input        1  vector
*      r  real        o  output       2  matrix
*      d  real*8      s  scratch
*      c  character
*
*      Argument  Description
*      --------  -----------
* ri1  a         matrix stored in sparse form with n rows
* ni   atype     type of matrix
*                   0  symmetric
*                   1  nonsymmetric
*                  -1  nonsymmetric, solve with a transpose
* ri1  b         right hand side, size n
* no   flag      return code
*                   0  no error
*                  -7  incorrect matrix type for matrix-vector multiply
* ni1  ija       pointers to rows of matrix followed by column indices
*                of matrix
* ni   n         number of rows in matrix
* ro1  res       residual, size n
* ri1  x         solution vector, size n
*
***********************************************************************/

#include "defnc.pre"

klres(n, ija, a, x, b, res, atype, flag)

        INT     *atype, *flag, *ija, *n;
        REAL    *a, *b, *res, *x;
  {

  /*********************************************************************
  *----local variables */
  INT     i;
  /********************************************************************/

  *flag = 0;

  /* form Ax */
  i = 0;
  klax(&i, n, n, ija, a, x, res, atype, flag);

  /* complete residual vector */
  if (*flag == 0)
    for (i = *n; i--; ) {
      *res = *b++ - *res;
      res++;
      }

  }

