/* measure execution time in seconds */
/* Bill Mitchell 10/9/92             */
/*                                   */
/* Use unix routine"times"to measure */
/* user execution time between       */
/* calls to second in seconds.       */
/* Callable from FORTRAN and C.      */
/* Returns double precsion (real*8)  */
/* in FORTRAN and double in C.       */

/* FORTRAN callable version */
static int holdtime,flagtime=1;
double second_()
{
/* just call C version */
   double second();
   return second();
}

/* C callable version */
double second()
{
#include <sys/types.h>
#include <sys/times.h>
#include <sys/param.h>
   clock_t times();
   clock_t t;
   struct tms t1;

/* call "times" */
   t=times(&t1);
   if (flagtime) {
      flagtime=0;
      holdtime=t;
   }
/* user time in 1/HZ seconds is in tms_utime */
/* HZ is in sys/param.h */
   return ((double)t1.tms_utime)/((double)HZ);
}
