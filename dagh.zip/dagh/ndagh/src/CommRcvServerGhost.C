/*
*************************************************************************
*                                                                       *
* GridTableGhostRcv							*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "CommRcvServer.h"

/*************************************************************************/
/* class GridTableGhostRcv */
/*************************************************************************/
GridTableGhostRcv::GridTableGhostRcv(GridTable& GT, const unsigned tag,
                                     const unsigned size, const int src)
 	: Table(GT), Size(size), comm_service(GT.gfid,tag,src), Request(0),
          rcvflag(DAGHFalse)
  {
    if (req() == 0) { 
      setreq(Id, Tag, Src); 
      return; 
    }
    Request = new char[Size];
    assert (Request != 0);

#ifdef DAGH_NO_MPI
#else

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTableGhostRcv::GridTableGhostRcv " 
			 << "(" << comm_service::proc_me() << ") "
			 << "MPI_Irecv: "
			 << "Tag: " << Tag << " " 
			 << "Size: " << Size << " "
			 << "From: " << Src << " "
			 << endl ).flush();
#endif

    int R = MPI_Irecv(Request,Size,MPI_BYTE,
                      Src,Tag,comm_service::comm(Id),req());

    if ( MPI_SUCCESS != R ) 
      comm_service::error_die("GridTableGhostRcv::GridTableGhostRcv","MPI_Irecv",R);

#endif

  }

GridTableGhostRcv::~GridTableGhostRcv(void)
  { if ( Request ) delete [] Request; }

void GridTableGhostRcv::callrecv( const MPI_Status & MS )
  {
   rcvflag = DAGHTrue;
   rcv_update(Request);
   Request = (char *) NULL;
   Request = new char[Size];
   assert (Request != 0);
  }

void GridTableGhostRcv::postrcv(void)
  {
#ifdef DAGH_NO_MPI
#else

   if (!Request) return;
   if (*req() != MPI_REQUEST_NULL) return;

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTableGhostRcv::postrcv " 
                         << "(" << comm_service::proc_me() << ") "
			 << "MPI_Irecv: "
			 << "Tag: " << Tag << " " 
			 << "Size: " << Size << " "
			 << "From: " << Src << " "
			 << endl ).flush();
#endif

    int R = MPI_Irecv(Request,Size,MPI_BYTE,
                      Src,Tag,comm_service::comm(Id),req());

   if ( MPI_SUCCESS != R ) 
     comm_service::error_die("GridTableGhostRcv::postrcv","MPI_Irecv",R);

#endif

   rcvflag = DAGHFalse;
  }

void GridTableGhostRcv::callrecvNpost( const MPI_Status & MS )
  {
   rcvflag = DAGHTrue;
   rcv_update(Request);
   Request = (char *) NULL;
   Request = new char[Size];
   assert (Request != 0);

#ifdef DAGH_NO_MPI
#else

   assert (*req() == MPI_REQUEST_NULL);
#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTableGhostRcv::postrcv " 
                         << "(" << comm_service::proc_me() << ") "
			 << "MPI_Irecv: "
			 << "Tag: " << Tag << " " 
			 << "Size: " << Size << " "
			 << "From: " << Src << " "
			 << endl ).flush();
#endif

    int R = MPI_Irecv(Request,Size,MPI_BYTE,
                      Src,Tag,comm_service::comm(Id),req());

   if ( MPI_SUCCESS != R ) 
     comm_service::error_die("GridTableGhostRcv::callrecv","MPI_Irecv",R);

#endif

   rcvflag = DAGHFalse;
  }

void GridTableGhostRcv::rcv_update(void *Rcv)
  {
   GridDataBucketVoid *rcvbkt = new GridDataBucketVoid(Rcv);

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTableGhostRcv::rcv_update " 
                         << "(" << comm_service::proc_me() << ") "
			 << "Recieved { " 
			 << *rcvbkt->head() 
			 << " }" 
			 << endl ).flush();
#endif

   int type = rcvbkt->type();

   if (type == DAGHPacked) {
     int num = rcvbkt->num();
     for (register int i=0;i<num;i++) {
       struct gdhdr *gdh = rcvbkt->head(i);
       GridTableEntry &tmpgte = *Table.find(gdh->baseindex);
       if (&tmpgte == GridTableEntryNULL) 
         comm_service::error_die("GridTableGhostRcv::rcv_update ",
                                 "No Table Entry",DAGH_FATAL);

       GridDataBucketVoid *&gdbkt = tmpgte(gdh->time,gdh->level,gdh->index);
       tmpgte.dataoffset(gdh->time,gdh->level,gdh->index) = i;
       if (gdbkt != GridDataBucketVoidNULL) {
         GridDataBucketVoid *tmpbkt = gdbkt;
         gdbkt = (GridDataBucketVoid *) rcvbkt->alias();
         tmpbkt->free();
         tmpbkt = 0;
       }
       else {
         gdbkt = (GridDataBucketVoid *) rcvbkt->alias();
       }
#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTableGhostRcv::rcv_update " 
                         << "(" << comm_service::proc_me() << ") "
			 << "Extracted { " 
			 << "(" << i << ")"
			 << *gdh
			 << tmpgte
			 << " }" 
			 << endl ).flush();
#endif
     }
   }
   else {
     struct gdhdr *gdh = rcvbkt->head();
   
     GridTableEntry &tmpgte = *Table.find(gdh->baseindex);
     if (&tmpgte == GridTableEntryNULL) 
       comm_service::error_die("GridTableGhostRcv::rcv_update " , 
                               "No Table Entry" , DAGH_FATAL );

     GridDataBucketVoid *&gdbkt = tmpgte(gdh->time,gdh->level,gdh->index);
     tmpgte.dataoffset(gdh->time,gdh->level,gdh->index) = 0;
     if (gdbkt != GridDataBucketVoidNULL) {
       GridDataBucketVoid *tmpbkt = gdbkt;
       gdbkt = (GridDataBucketVoid *) rcvbkt->alias();
       tmpbkt->free();
       tmpbkt = 0;
     }
     else {
       gdbkt = (GridDataBucketVoid *) rcvbkt->alias();
     }
#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTableGhostRcv::rcv_update " 
                         << "(" << comm_service::proc_me() << ") "
			 << "Extracted { " 
			 << gdh
			 << " }" 
			 << endl ).flush();
#endif
   }
   rcvbkt->free();
  }

const char * GridTableGhostRcv::name( void ) const
  {
   static const char Name[] = "GridTableGhostRcv" ;
   return Name ;
  }
