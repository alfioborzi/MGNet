#ifndef _included_DAGHMemoryTraces_h
#define _included_DAGHMemoryTraces_h

/*
*************************************************************************
* DAGHMemoryTraces.h                                                    *
*                                                                       *
* Maintain memory allocation and deallocation traces 			*
*                                                                       *
*************************************************************************
*/

#include "iostream.h"

class DAGHMemoryTrace
  {
   static unsigned alloc_cnt;
   static unsigned free_cnt;

public:
   inline DAGHMemoryTrace() 
    { cout << "**** DAGHMemoryTrace on ! ****" << endl; }

   inline ~DAGHMemoryTrace()
    {
      cout << endl 
           << "************************************************" << endl
           << "**** Memory Allocated:\t" << alloc_cnt << " ****" << endl
           << "**** Memory Free'd:   \t" << free_cnt << " ****" << endl
           << "************************************************" << endl
           << flush;
    }

   inline static void alloc(const unsigned size) { alloc_cnt += size; }
   inline static void free(const unsigned size)  { free_cnt += size; }
  
  };

#endif
