/*
*************************************************************************
*                                                                       *
* GridFunctionVoid.C				                  *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                                *
*                                                                       *
*************************************************************************
*/

#include "GridFunctionVoid.h"
#include "GridHierarchy.h"

/*****************************************************************************/
/* constructor */
/*****************************************************************************/

GridFunctionVoid::GridFunctionVoid(const int type,
				   const int rank,
				   char const name[],
				   GridHierarchy &gh,
				   const int align,
				   const int bndrywidth,
				   const int extghwidth,
				   const int cflag, 
				   const int sflag,
				   const int bflag,
				   const int adptbflag,
				   const int extghflag)
  : gftype(type), gfrank(rank), gfname(name),
    alignment(align), 
    bwidth(bndrywidth), extghostwidth(extghwidth),
    comm_flag(cflag), shadow_flag(sflag), 
    bndry_flag(bflag), adaptbndry_flag(adptbflag),
    extghost_flag(extghflag), compose_flag(DAGHFalse), 
    template_flag(DAGHNull),
    init_flag(DAGHTrue), update_flag(DAGHTrue), 
    prolong_flag(DAGHTrue), restrict_flag(DAGHTrue), 
    bndry_update_flag(DAGHTrue), 
    adaptbndry_update_flag(DAGHTrue),
    io_flag(DAGHTrue), chkpt_flag(DAGHTrue),
    time_sten_rad(0), space_sten_rad(0), time_alias(0),
    interactions(gh.rank, DAGHGhostInteraction, 1),
    ghost_send_info(0), ghost_recv_info(0), 
    ghost_recv_server(0), data_recv_server(0),
    updatedstep(gh.updatedvaluestep()),
    gt(0), dagh(gh),
    rcvsize(0), shrcvsize(0), slen(0), sndsize(0), sndbbox(0), 
    sndindex(0),rcvindex(0), sndlevel(0), sndcnt(0)
  {

   dagh.DAGH_InitOverlaps(gftype,overlap);

   time_alias = new short[2*time_sten_rad+1];
   time_alias[2*time_sten_rad] = 2*time_sten_rad;

   space_sten_rad = new short[2*gfrank];
   for (register int r=0; r<gfrank; r++) {
     space_sten_rad[2*r] = 0;
     space_sten_rad[2*r+1] = 0;
   }

   curtime[0] = curtime[1] = 0;

   if (cflag >= DAGHTemplateComm) {
     template_flag = cflag - DAGHTemplateComm;
#ifdef DEBUG_PRINT
     assert(dagh.gflist[template_flag]);
#endif
     comm_flag = dagh.gflist[template_flag]->comm_flag;
   }

   for (register int ui=0; ui<DAGHGFVFlagNum; ui++)
     userflags[ui] = 0;
  }

GridFunctionVoid::GridFunctionVoid(const int type,
				   const int rank,
				   char const name[],
				   const int tsten, 
				   const int ssten,
				   GridHierarchy &gh,
				   const int align, 
				   const int bndrywidth,
				   const int extghwidth,
				   const int cflag, 
				   const int sflag,
				   const int bflag,
				   const int adptbflag,
				   const int extghflag)
  : gftype(type), gfrank(rank), gfname(name),
    alignment(align), 
    bwidth(bndrywidth), extghostwidth(extghwidth),
    comm_flag(cflag), shadow_flag(sflag), 
    bndry_flag(bflag), adaptbndry_flag(adptbflag),
    extghost_flag(extghflag), compose_flag(DAGHFalse), 
    template_flag(DAGHNull),
    init_flag(DAGHTrue), update_flag(DAGHTrue), 
    prolong_flag(DAGHTrue), restrict_flag(DAGHTrue), 
    bndry_update_flag(DAGHTrue), 
    adaptbndry_update_flag(DAGHTrue),
    io_flag(DAGHTrue), chkpt_flag(DAGHTrue),
    time_sten_rad(tsten), space_sten_rad(0), time_alias(0),
    interactions(gh.rank, DAGHGhostInteraction, 1),
    ghost_send_info(0), ghost_recv_info(0), 
    ghost_recv_server(0), data_recv_server(0),
    updatedstep(gh.updatedvaluestep()),
    gt(0), dagh(gh),
    rcvsize(0), shrcvsize(0), slen(0), sndsize(0), sndbbox(0), 
    sndindex(0),rcvindex(0), sndlevel(0), sndcnt(0)
  {

   dagh.DAGH_InitOverlaps(gftype,overlap);

   time_alias = new short[2*time_sten_rad+1];
   for (register int i=0;i<time_sten_rad;i++) {
     time_alias[2*i] = 2*i;
     time_alias[2*i+1] = 2*i+1;
   }
   time_alias[2*time_sten_rad] = 2*time_sten_rad;

   space_sten_rad = new short[2*gfrank];
   for (register int r=0; r<gfrank; r++) {
     space_sten_rad[2*r] = ssten;
     space_sten_rad[2*r+1] = ssten;
   }

   curtime[0] = curtime[1] = 0;

   if (cflag >= DAGHTemplateComm) {
     template_flag = cflag - DAGHTemplateComm;
#ifdef DEBUG_PRINT
     assert(dagh.gflist[template_flag]);
#endif
     comm_flag = dagh.gflist[template_flag]->comm_flag;
   }

   for (register int ui=0; ui<DAGHGFVFlagNum; ui++)
     userflags[ui] = 0;
}

GridFunctionVoid::GridFunctionVoid(const int type,
				   const int rank,
				   char const name[],
				   const int tsten, 
				   const int *ssten,
				   GridHierarchy &gh,
				   const int align, 
				   const int bndrywidth,
				   const int extghwidth,
				   const int cflag, 
				   const int sflag, 
				   const int bflag,
				   const int adptbflag,
				   const int extghflag)
  : gftype(type), gfrank(rank), gfname(name),
    alignment(align), 
    bwidth(bndrywidth), extghostwidth(extghwidth),
    comm_flag(cflag), shadow_flag(sflag), 
    bndry_flag(bflag), adaptbndry_flag(adptbflag),
    extghost_flag(extghflag), compose_flag(DAGHFalse), 
    template_flag(DAGHNull),
    init_flag(DAGHTrue), update_flag(DAGHTrue), 
    prolong_flag(DAGHTrue), restrict_flag(DAGHTrue), 
    bndry_update_flag(DAGHTrue), 
    adaptbndry_update_flag(DAGHTrue),
    io_flag(DAGHTrue), chkpt_flag(DAGHTrue),
    time_sten_rad(tsten), space_sten_rad(0), time_alias(0),
    interactions(gh.rank, DAGHGhostInteraction, 1),
    ghost_send_info(0), ghost_recv_info(0), 
    ghost_recv_server(0), data_recv_server(0),
    updatedstep(gh.updatedvaluestep()),
    gt(0), dagh(gh),
    rcvsize(0), shrcvsize(0), slen(0), sndsize(0), sndbbox(0), 
    sndindex(0),rcvindex(0), sndlevel(0), sndcnt(0)
  {

   dagh.DAGH_InitOverlaps(gftype,overlap);

   time_alias = new short[2*time_sten_rad+1];
   for (register int i=0;i<time_sten_rad;i++) {
     time_alias[2*i] = 2*i;
     time_alias[2*i+1] = 2*i+1;
   }
   time_alias[2*time_sten_rad] = 2*time_sten_rad;

   space_sten_rad = new short[2*gfrank];
   for (register int r=0; r<gfrank; r++) {
     space_sten_rad[2*r] = ssten[2*r];
     space_sten_rad[2*r+1] = ssten[2*r+1];
   }

   curtime[0] = curtime[1] = 0;

   if (cflag >= DAGHTemplateComm) {
     template_flag = cflag - DAGHTemplateComm;
#ifdef DEBUG_PRINT
     assert(dagh.gflist[template_flag]);
#endif
     comm_flag = dagh.gflist[template_flag]->comm_flag;
   }

   for (register int ui=0; ui<DAGHGFVFlagNum; ui++)
     userflags[ui] = 0;
  }

GridFunctionVoid::GridFunctionVoid(char const name[],
				   const int rank,
				   const GridFunctionVoid& gfv,
				   const int cflag, 
				   const int sflag, 
				   const int bflag,
				   const int adptbflag,
				   const int extghflag)
  : gftype(gfv.gftype), gfrank(rank), gfname(name),
    alignment(gfv.alignment), 
    bwidth(gfv.bwidth), extghostwidth(gfv.extghostwidth),
    comm_flag(cflag), shadow_flag(sflag), 
    bndry_flag(bflag), adaptbndry_flag(adptbflag),
    extghost_flag(extghflag), compose_flag(DAGHFalse), 
    template_flag(DAGHNull),
    init_flag(DAGHTrue), update_flag(DAGHTrue), 
    prolong_flag(DAGHTrue), restrict_flag(DAGHTrue), 
    bndry_update_flag(DAGHTrue), 
    adaptbndry_update_flag(DAGHTrue),
    io_flag(DAGHTrue), chkpt_flag(DAGHTrue),
    time_sten_rad(gfv.time_sten_rad), space_sten_rad(0),
    time_alias(0), 
    interactions(gfv.dagh.rank, DAGHGhostInteraction, 1),
    ghost_send_info(0), ghost_recv_info(0), 
    ghost_recv_server(0), data_recv_server(0),
    updatedstep(gfv.dagh.updatedvaluestep()),
    gt(0), dagh(gfv.dagh),
    rcvsize(0), shrcvsize(0), slen(0), sndsize(0), sndbbox(0), 
    sndindex(0),rcvindex(0), sndlevel(0), sndcnt(0)
  {

   dagh.DAGH_InitOverlaps(gftype,overlap);

   time_alias = new short[2*time_sten_rad+1];
   for (register int i=0;i<time_sten_rad;i++) {
     time_alias[2*i] = 2*i;
     time_alias[2*i+1] = 2*i+1;
   }
   time_alias[2*time_sten_rad] = 2*time_sten_rad;

   const short* ssten = gfv.space_sten_rad;
   space_sten_rad = new short[2*gfrank];
   for (register int r=0; r<gfrank; r++) {
     space_sten_rad[2*r] = ssten[2*r];
     space_sten_rad[2*r+1] = ssten[2*r+1];
   }

   curtime[0] = curtime[1] = 0;

   if (cflag >= DAGHTemplateComm) {
     template_flag = cflag - DAGHTemplateComm;
#ifdef DEBUG_PRINT
     assert(dagh.gflist[template_flag]);
#endif
     comm_flag = dagh.gflist[template_flag]->comm_flag;
   }

   for (register int ui=0; ui<DAGHGFVFlagNum; ui++)
     userflags[ui] = 0;
  }

/*****************************************************************************/
/* destructor */
/*****************************************************************************/
GridFunctionVoid::~GridFunctionVoid()
   {
     if (curtime[0]) delete [] curtime[0];
     if (curtime[1]) delete [] curtime[1];
     if (time_alias) delete [] time_alias;
     if (space_sten_rad) delete [] space_sten_rad;
   }

/*****************************************************************************/
/* Set GF Type */
/*****************************************************************************/
void GridFunctionVoid::GF_SetGridFunctionType(const int gft)
{ gftype = gft; dagh.DAGH_InitOverlaps(gftype,overlap); }

/*****************************************************************************/
/* set time stencil */
/*****************************************************************************/

void GridFunctionVoid::GF_SetSpaceStencil(const int s_sten)
  {
   for (int r=0; r<gfrank; r++) {
     space_sten_rad[2*r] = s_sten;
     space_sten_rad[2*r+1] = s_sten;
   }
  }

void GridFunctionVoid::GF_SetSpaceStencil(const int *s_sten)
  {
   for (int r=0; r<gfrank; r++) {
     space_sten_rad[2*r] = s_sten[2*r];
     space_sten_rad[2*r+1] = s_sten[2*r+1];
   }
  }

/*****************************************************************************/
/* set time stencil */
/*****************************************************************************/

void GridFunctionVoid::GF_SetTimeStencil(const int t_sten)
  {
   if (time_sten_rad == t_sten) return;

   time_sten_rad = t_sten;
   if (time_alias) delete [] time_alias;
   time_alias = new short[2*time_sten_rad+1];
   for (register int i=0;i<time_sten_rad;i++)
    { time_alias[2*i] = 2*i; time_alias[2*i+1] = 2*i+1; }
   time_alias[2*time_sten_rad] = 2*time_sten_rad;
  }

/*****************************************************************************/
/* virtual methods that will be called by GridHierarchy */
/*****************************************************************************/
void GridFunctionVoid::GF_FreeTmpStorage()
  {
   slen = 0;
   if (rcvsize) delete [] rcvsize; 
   rcvsize = 0;
   if (shrcvsize) delete [] shrcvsize;
   shrcvsize = 0;
   if (sndsize) delete [] sndsize;
   sndsize = 0;
   if (sndbbox) delete [] sndbbox;
   sndbbox = 0;
   if (sndindex) delete [] sndindex;
   sndindex = 0;
   if (rcvindex) delete [] rcvindex;
   rcvindex = 0;
   if (sndlevel) delete [] sndlevel;
   sndlevel = 0;
   if (sndcnt) delete [] sndcnt;
   sndcnt = 0;
  }

/*****************************************************************************/
/* virtual methods for time aliasing */
/*****************************************************************************/
void GridFunctionVoid::GF_DeleteGDBStorage(const int t)
{ cerr << "Dummy GF_DeleteGDBStorage(t) function\n"; }

/*****************************************************************************/
/* virtual methods that will be called by GridHierarchy */
/*****************************************************************************/

void GridFunctionVoid::GF_Compose()
     { cerr << "Dummy compose function\n"; }

void GridFunctionVoid::GF_Recompose(const int omindex, 
				    const GridUnitList& ollist,
                                    GridUnitList& rlist, 
				    GridUnitList& slist,
				    GridUnitList& olist)
     { cerr << "Dummy recompose function\n"; }

void GridFunctionVoid::GF_CheckpointRecompose()
     { cerr << "Dummy recompose function\n"; }

void GridFunctionVoid::GF_Checkpoint(ofstream& ofs)
     { cerr << "Dummy GF_Checkpoint(ofs) function\n"; }

void GridFunctionVoid::GF_CheckpointRestart()
     { cerr << "Dummy GF_Restart(name, gul) function\n"; }

/*****************************************************************************/
/* overloaded stdout */
/*****************************************************************************/

ostream& operator<<(ostream& os, const GridFunctionVoid& gfv)
  { 
   if (&gfv == (GridFunctionVoid *) NULL) return os;

   os << "GridFunction "
      << "[" << gfv.gfid << "] " 
      << "[" << gfv.gftype << "] " 
      << "[" << gfv.gfrank << "] " 
      << "[" << gfv.gfname << "] "
      << "[" << gfv.alignment << "] "
      << endl; 

   os << "[Comm:" << gfv.comm_flag << "] " 
      << "[Shadow:" << gfv.shadow_flag << "] " 
      << "[Bndry:" << gfv.bndry_flag << "] " 
      << "[AdaptBndry:" << gfv.adaptbndry_flag << "] " 
      << "[ExtGhost:" << gfv.extghost_flag << "] " 
      << endl; 
     
   os << "[TSten:" << gfv.time_sten_rad << "] "
      << "[SSten: ";
   
   for (int r=0; r<gfv.gfrank; r++) {
     os << gfv.space_sten_rad[2*r] << " "
        << gfv.space_sten_rad[2*r+1] << " ";
   }
   os << "]" << endl; 
     
   os << gfv.interactions;

   return os; 
  }

ostream& operator<<(ostream& os, const GF_Interaction& gfi)
  {
    if (&gfi == (GF_Interaction *) NULL) return os;

    os << "GF_Interaction[ ";
    os << gfi.cnt << "[";
    for (register int i=0;i<gfi.cnt;i++) os << gfi.size[i] << " ";
    os << "] ";
    os << gfi.tsize;
    os << "]";
    return os;
  }

/*****************************************************************************/
/* binary out for checkpointing */
/*****************************************************************************/
ofstream& operator<<(ofstream& ofs, const GridFunctionVoid& gfv)
  { 
   if (&gfv == (GridFunctionVoid *) NULL) return ofs;

   // does nothing for now.

   return ofs; 
  }


ifstream& operator>>(ifstream& ifs, GridFunctionVoid& gfv)
  { 
   if (&gfv == (GridFunctionVoid *) NULL) return ifs;

   // does nothing for now.

   return ifs; 
  }
