/*
*************************************************************************
* DAGHDistribution.C							*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGHDistribution.h"

#ifdef DEBUG_PRINT
#include "CommServer.h"
#endif

/*************************************************************************/
/* Partitioning functions based on Paul Walker's implementation          */
/*************************************************************************/
void partition_one(const BBox& wholebbox, BBox* boxes, const int np, 
                   const int dim);
void partition_two(const BBox& wholebbox, BBox* boxes, const int np, 
                   const int dim1, const int dim2);
void partition_all(const BBox& wholebbox, BBox* boxes, const int np);
void pwalker_partition(const BBox& wholebbox, BBox* boxes, const int np);
/*************************************************************************/

DAGHDistribution::DAGHDistribution(const int disttype, BBoxList& bbl)
        : type(disttype), wfunc(0), boxes(0)
  {
    boxes = new BBox[bbl.number()];
    register BBox* bb = 0;
    register int cnt = 0;
    for (bb=bbl.first();bb;bb=bbl.next()) {
      boxes[cnt++] = *bb; 
    }
  }

void DAGHDistribution::set_dist(const int disttype, BBoxList& bbl)
  {
    type = disttype;
    if (boxes) delete [] boxes;
    boxes = new BBox[bbl.number()];
    register BBox* bb = 0;
    register int cnt = 0;
    for (bb=bbl.first();bb;bb=bbl.next()) {
      boxes[cnt++] = *bb; 
    }
  }

unsigned long DAGHDistribution::get_load(GridUnitList& ggul, const short* olap)
  {
    if (wfunc) { 
      unsigned long load = 0, n = 0;
      int levels = ggul.levels();
      for (int l=0;l<levels;l++) load += (*wfunc)(&(n=ggul.numelems(l,olap)),&l);
      return load;
    } 
    else return( ggul.load(olap) );
  }

void DAGHDistribution::partition(GridUnitList*& ggul,
                                 GridUnitList*& lgul,
                                 const int np, const int me, 
                                 const int minw, const short* olap)
  {
    if (type == DAGHCompositeDistribution) 
      partitionComposite(ggul, lgul, np, me, minw, olap);

    else if (type == DAGHBlockXDistribution) 
      partitionBlockOne(DAGH_X, ggul, lgul, np, me, minw, olap);
    else if (type == DAGHBlockYDistribution) 
      partitionBlockOne(DAGH_Y, ggul, lgul, np, me, minw, olap);
    else if (type == DAGHBlockZDistribution) 
      partitionBlockOne(DAGH_Z, ggul, lgul, np, me, minw, olap);

    else if (type == DAGHBlockXYDistribution) 
      partitionBlockTwo(DAGH_X, DAGH_Y, ggul, lgul, np, me, minw, olap);
    else if (type == DAGHBlockYZDistribution) 
      partitionBlockTwo(DAGH_Y, DAGH_Z, ggul, lgul, np, me, minw, olap);
    else if (type == DAGHBlockXZDistribution) 
      partitionBlockTwo(DAGH_X, DAGH_Z, ggul, lgul, np, me, minw, olap);

    else if (type == DAGHBlockAllDistribution) 
      partitionBlockAll(ggul, lgul, np, me, minw, olap);

    else if (type == DAGHUserDefDistribution) 
      partitionUserDef(ggul, lgul, np, me, minw, olap);

    else
      assert(0);
  }

void DAGHDistribution::partitionComposite(GridUnitList*& ggul,
                                          GridUnitList*& lgul,
                                          const int np, const int me, 
                                          const int minw, const short* olap)
  {
    /* Cannot partition an empty list */
    assert(ggul->number() > 0);
  
    /* Zero procs... ? */
    assert(np > 0);

    //if (!localspans.isempty()) localspans.empty();

    if (lgul) lgul->empty();
    else {
      lgul = new GridUnitList;
      lgul->settag(me);
    }

    dMapIndex *lmin = 0;
    dMapIndex lmax;

    unsigned long work = get_load(*ggul,olap);

    unsigned long thresh = (unsigned) ((1.0*(work/np))+0.5);
    register unsigned long curthresh = thresh;

    int p = 0, pcnt = 0;
    unsigned tmpw = 0, w = 0;

    register GridUnit *tmpgu = ggul->first();

#ifdef DEBUG_PRINT_DIST
     ( comm_service::log() << "\n{ Composite Distribution: "
                           << np << " " << work << " " << thresh
                           << "} \n"
                           ).flush();
#endif

    for (int cnt=0;tmpgu;cnt++,tmpgu=ggul->next()) {
      w += (tmpw = tmpgu->guWork(olap));

#ifdef DEBUG_PRINT_DIST
     ( comm_service::log() << "\n{ Partitioning: "
                           << cnt << " " << p << " "
                           << curthresh << " " << w << " " << tmpw << " "
                           << tmpgu->guBaseIndex()  << " "
                           << *ggul->currec()
                           << "} \n"
                           ).flush();
#endif

      if (w <= curthresh) {

#ifdef DEBUG_PRINT_DIST
     if (p>=np)
     ( comm_service::log() << "\n************* Current Composite List *************\n"
                           << *ggul
                           << "\n************* ***************** *************\n"
                           << "\n************* Current Bucket *************\n"
                           << *((SimpleBucketVoid *) ggul)
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif
        assert (p<np);
        tmpgu->guSetOwner(p); pcnt++;
        if (p == me)  lgul->add(*tmpgu);
        if (!lmin) lmin = new dMapIndex(tmpgu->guBaseIndex());
        lmax = tmpgu->guBaseIndex();
      }
      else if (w-curthresh < tmpw/4) {

#ifdef DEBUG_PRINT_DIST
     if (p>=np)
     ( comm_service::log() << "\n************* Current Composite List *************\n"
                           << *ggul
                           << "\n************* ***************** *************\n"
                           << "\n************* Current Bucket *************\n"
                           << *((SimpleBucketVoid *) ggul)
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

        assert(p<np);
        tmpgu->guSetOwner(p); pcnt++;
        if (p == me)  lgul->add(*tmpgu);
        lmax = tmpgu->guBaseIndex();
        p++; pcnt = 0;
        curthresh = w + (unsigned) ((1.0*((work-w)/(np-p)))+0.5);
      }
      else if (tmpw > thresh && tmpgu->guExtent(tmpgu->guCrsLev()) > minw) {
        w -= tmpw;
        cnt--;
        int oldwork = work;
        ggul->decompose();
        work = get_load(*ggul,olap);

#ifdef DEBUG_PRINT_DIST
     ( comm_service::log() << "\n************* After Decompose *************\n"
                           << "Cur Proc:" << p << " "
                           << tmpgu->guBaseIndex() << " "
                           << *ggul->current() << "\n"
                           << "Cur GU:" << ggul->current() << "\n"
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

        thresh = (unsigned) ((1.0*(work/np))+0.5);
        curthresh = curthresh+(unsigned)((1.0*((work-oldwork)/(np-p)))+0.5);
      }
      else if (pcnt == 0) {

#ifdef DEBUG_PRINT_DIST
     if (p>=np)
     ( comm_service::log() << "\n************* Current Composite List *************\n"
                           << *ggul
                           << "\n************* ***************** *************\n"
                           << "\n************* Current Bucket *************\n"
                           << *((SimpleBucketVoid *) ggul)
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

        assert(p<np);
        tmpgu->guSetOwner(p); pcnt++;
        if (p == me)  lgul->add(*tmpgu);
        lmax = tmpgu->guBaseIndex();
        p++; pcnt = 0;
        curthresh = w + (unsigned) ((1.0*((work-w)/(np-p)))+0.5);
      }
      else  {
        p++; pcnt = 0;

#ifdef DEBUG_PRINT_DIST
     if (p>=np)
     ( comm_service::log() << "\n************* Current Composite List *************\n"
                           << *ggul
                           << "\n************* ***************** *************\n"
                           << "\n************* Current Bucket *************\n"
                           << *((SimpleBucketVoid *) ggul)
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

        assert(p<np);
        tmpgu->guSetOwner(p);
        if (p == me) lgul->add(*tmpgu);
        if (!lmin) lmin = new dMapIndex(tmpgu->guBaseIndex());
        lmax = tmpgu->guBaseIndex();
        curthresh = (w-tmpw) + (unsigned) ((1.0*((work-(w-tmpw))/(np-p)))+0.5);
        if (w >= curthresh) {
          p++; pcnt = 0;
          if (p < np)
            curthresh = w + (unsigned) ((1.0*((work-w)/(np-p)))+0.5);
        }
      }
    }
    //localspans.add(DAGHSpan(*lmin,lmax));
    if(lmin) delete lmin;
  }

void DAGHDistribution::partitionBlockOne(const int axis,
                                         GridUnitList*& ggul,
                                         GridUnitList*& lgul,
                                         const int np, const int me, 
                                         const int minw, const short* olap)
  {
    /* Cannot partition an empty list */
    assert(ggul->number() > 0);
  
    /* Zero procs... ? */
    assert(np > 0);

    if (boxes) delete [] boxes;
    boxes = new BBox[np];

    const int flev = (ggul->first())->guFineLev();
    BBoxList tmpbbl;
    ggul->bboxlist(tmpbbl, flev, 0, 0);
    BBox wbbox = tmpbbl.reduce();
    partition_one(wbbox, boxes, np, axis);

    GridUnitList tmpgul;
    for (register int p=0;p<np;p++) {
      ggul->intersect(boxes[p], flev, tmpgul, 0);
      GridUnitList tmpgul(*ggul);
      tmpgul *= boxes[p];
      ggul->setowner(tmpgul,p);
      if (p == me) {
        if (lgul) {
          lgul->empty();
          *lgul = tmpgul;
        }
        else {
          lgul = new GridUnitList(tmpgul);
        }
        lgul->settag(me);
        lgul->setowner(me);
      } 
    }
  }

void DAGHDistribution::partitionBlockTwo(const int axis1, const int axis2,
                                         GridUnitList*& ggul,
                                         GridUnitList*& lgul,
                                         const int np, const int me, 
                                         const int minw, const short* olap)
  {
    /* Cannot partition an empty list */
    assert(ggul->number() > 0);
  
    /* Zero procs... ? */
    assert(np > 0);

    if (boxes) delete [] boxes;
    boxes = new BBox[np];

    const int flev = (ggul->first())->guFineLev();
    BBoxList tmpbbl;
    ggul->bboxlist(tmpbbl, flev, 0, 0);
    BBox wbbox = tmpbbl.reduce();
    partition_two(wbbox, boxes, np, axis1, axis2);

    GridUnitList tmpgul;
    for (register int p=0;p<np;p++) {
      ggul->intersect(boxes[p], flev, tmpgul, 0);
      GridUnitList tmpgul(*ggul);
      tmpgul *= boxes[p];
      ggul->setowner(tmpgul,p);
      if (p == me) {
        if (lgul) {
          lgul->empty();
          *lgul = tmpgul;
        }
        else {
          lgul = new GridUnitList(tmpgul);
        }
        lgul->settag(me);
        lgul->setowner(me);
      } 
    }
  }

void DAGHDistribution::partitionBlockAll(GridUnitList*& ggul,
                                         GridUnitList*& lgul,
                                         const int np, const int me, 
                                         const int minw, const short* olap)
  {
    /* Cannot partition an empty list */
    assert(ggul->number() > 0);
  
    /* Zero procs... ? */
    assert(np > 0);

    if (boxes) delete boxes;
    boxes = new BBox[np];

    const int flev = (ggul->first())->guFineLev();
    BBoxList tmpbbl;
    ggul->bboxlist(tmpbbl, flev, 0, 0);
    BBox wbbox = tmpbbl.reduce();
    partition_all(wbbox, boxes, np);

    GridUnitList tmpgul;
    for (register int p=0;p<np;p++) {
      ggul->intersect(boxes[p], flev, tmpgul, 0);
      GridUnitList tmpgul(*ggul);
      tmpgul *= boxes[p];
      ggul->setowner(tmpgul,p);
      if (p == me) {
        if (lgul) {
          lgul->empty();
          *lgul = tmpgul;
        }
        else {
          lgul = new GridUnitList(tmpgul);
        }
        lgul->settag(me);
        lgul->setowner(me);
      } 
    }
  }

void DAGHDistribution::partitionUserDef(GridUnitList*& ggul,
                                        GridUnitList*& lgul,
                                        const int np, const int me, 
                                        const int minw, const short* olap)
  {
    /* The list boxes has to be defined */
    assert(boxes); 

    /* Cannot partition an empty list */
    assert(ggul->number() > 0);
  
    /* Zero procs... ? */
    assert(np > 0);

    const int flev = (ggul->first())->guFineLev();
    BBoxList tmpbbl;
    ggul->bboxlist(tmpbbl, flev, 0, 0);
    BBox wbbox = tmpbbl.reduce();
    partition_all(wbbox, boxes, np);

    GridUnitList tmpgul;
    for (register int p=0;p<np;p++) {
      ggul->intersect(boxes[p], flev, tmpgul, 0);
      GridUnitList tmpgul(*ggul);
      tmpgul *= boxes[p];
      ggul->setowner(tmpgul,p);
      if (p == me) {
        if (lgul) {
          lgul->empty();
          *lgul = tmpgul;
        }
        else {
          lgul = new GridUnitList(tmpgul);
        }
        lgul->settag(me);
        lgul->setowner(me);
      } 
    }
  }

/*$int DAGHDistribution::islocal(dMapIndex const &idx)
  {
    DAGHSpan *span = 0;

    DAGHListLoop(localspans,span,DAGHSpan) 
	if (span->contains(idx)) return 1;
    DAGHEndLoop
    
    return 0;
  }$*/

void partition_one(const BBox& wholebbox, BBox* boxes, const int np, 
                   const int dim)
  {
    const int rank = wholebbox.rank;
    const int glb = wholebbox.lower(dim);
    const int gub = wholebbox.upper(dim);
    const int step = wholebbox.stepsize(dim);
    const int extent = wholebbox.extents(dim);

    assert (extent >= np); // I should have atleast extent points. */

    const int dx = extent/np;
    const int Xtra = extent%np;

    for (register int p=0;p<np;p++) {
      const int dlower = p*dx + min(Xtra,p);
      const int dupper = (np-p-1)*dx + max((Xtra-p-1),0);
      boxes[p] = wholebbox;
      boxes[p].growlower(dim,dlower);
      boxes[p].growupper(dim,-dupper);
    }
  }

/* A modification of pwalker_partition by Paul Walker */
void partition_two(const BBox& wholebbox, BBox* boxes, const int np, 
                   const int dim1, const int dim2)
  {
    /* Great now figure out the decomposition in n1,n2 */
    int n1,n2;
    
    /* Initizialize */
    n1 = np;
    n2 = 1;
    if (n1 % 2 == 0) {
      while (n1 % 2 == 0 && n1 > n2
             && (abs(n1-n2) >= abs(n1/2-n2*2))) {
        n1 /= 2;
        n2 *= 2;
      }
    } else {
      while (n1 % 3 == 0 && n1 > n2
             && (abs(n1-n2) >= abs(n1/3-n2*3))) {
        n1 /= 3;
        n2 *= 3;
      }
    }

    const int rank = wholebbox.rank;
    Coords glb(wholebbox.lower());
    Coords gub(wholebbox.upper());

    /* Set up deltas */
    Coords delt(rank,0); 
    delt(dim1) =  (gub(dim1)-glb(dim1))/n1;
    delt(dim2) =  (gub(dim2)-glb(dim2))/n2;

    /* Initialize the bboxes */
    for (register int p=0;p<np;p++) boxes[p] = wholebbox;

    for (register int ii=0;ii<n1;ii++) {
      for (register int jj=0;jj<n2;jj++) {
        /* We may care about topology here later... */
        int whichp = ii + jj*n1;
        boxes[whichp].growlower(dim1,ii*delt(dim1));
        boxes[whichp].growlower(dim2,jj*delt(dim2));

        boxes[whichp].growupper(dim1,-((n1-ii-1)*delt(dim1)));
        boxes[whichp].growupper(dim2,-((n2-jj-1)*delt(dim2)));
      }
    }
  }

/* A modification of pwalker_partition by Paul Walker */
void partition_all(const BBox& wholebbox, BBox* boxes, const int np)
  {
    /* Great now figure out the decomposition in n1,n2,n3 */
    int n1,n2,n3;
    
    /* Initizialize */
    n1 = np;
    n2 = 1;
    n3 = 1;
    for (register int i=0;i<2;i++) {
      int twof = 0;
      if (n1 % 2 == 0) twof = 1;
      if (twof) {
        while (n1 % 2 == 0 && n1 > n2
               && (abs(n1-n2) >= abs(n1/2-n2*2))) {
          n1 /= 2;
          n2 *= 2;
        }
      } else {
        while (n1 % 3 == 0 && n1 > n2
               && (abs(n1-n2) >= abs(n1/3-n2*3))) {
          n1 /= 3;
          n2 *= 3;
        }
      }
      twof = 0;
      if (n2 % 2 == 0) twof = 1;
      if (twof) {
        while (n2 % 2 == 0 && n2 > n3
               && (abs(n2-n3) >= abs(n2/2-n3*2))) {
          n2 /= 2;
          n3 *= 2;
        }
      } else {
        while (n2 % 3 == 0 && n2 > n3
               && (abs(n2-n3) >= abs(n2/3-n3*3))) {
          n2 /= 3;
          n3 *= 3;
        }
      }
    }
    /* Sort based on global box (later)... */ 
    
    const int rank = wholebbox.rank;
    Coords glb(wholebbox.lower());
    Coords gub(wholebbox.upper());

    /* Set up deltas */
    Coords delt(rank,0);
    delt(0) =  (gub(0)-glb(0))/n1;
    delt(1) =  (gub(1)-glb(1))/n2;
    delt(2) =  (gub(2)-glb(2))/n3;

    /* Initialize the bboxes */
    for (register int p=0;p<np;p++) boxes[p] = wholebbox;

    for (register int ii=0;ii<n1;ii++) {
      for (register int jj=0;jj<n2;jj++) {
        for (register int kk=0;kk<n3;kk++) {
          /* We may care about topology here later... */
          int whichp = ii + jj*n1 + kk*n1*n2;

          boxes[whichp].growlower(0,ii*delt(0));
          boxes[whichp].growlower(1,jj*delt(1));
          boxes[whichp].growlower(2,kk*delt(2));

          boxes[whichp].growupper(0,-((n1-ii-1)*delt(0)));
          boxes[whichp].growupper(1,-((n2-jj-1)*delt(1)));
          boxes[whichp].growupper(2,-((n3-kk-1)*delt(2)));
        }
      }
    }
  }

void pwalker_partition(const BBox& wholebbox, BBox* boxes, const int np)
  {
    Coords glb(wholebbox.lower());
    Coords gub(wholebbox.upper());
    /* Great now figure out the decomposition in nx,ny,nz */
    int nx,ny,nz;
    
    /* Initizialize */
    nx = np;
    ny = 1;
    nz = 1;
    for (int i=0;i<2;i++) {
      int twof = 0;
      if (nx % 2 == 0) twof = 1;
      if (twof) {
        while (nx % 2 == 0 && nx > ny
               && (abs(nx-ny) >= abs(nx/2-ny*2))) {
          nx /= 2;
          ny *= 2;
        }
      } else {
        while (nx % 3 == 0 && nx > ny
               && (abs(nx-ny) >= abs(nx/3-ny*3))) {
          nx /= 3;
          ny *= 3;
        }
      }
      twof = 0;
      if (ny % 2 == 0) twof = 1;
      if (twof) {
        while (ny % 2 == 0 && ny > nz
               && (abs(ny-nz) >= abs(ny/2-nz*2))) {
          ny /= 2;
          nz *= 2;
        }
      } else {
        while (ny % 3 == 0 && ny > nz
               && (abs(ny-nz) >= abs(ny/3-nz*3))) {
          ny /= 3;
          nz *= 3;
        }
      }
    }
    /* Sort based on global box (later)... */ 
    
    /* Now make the coordinates for each box ... */
    BBox mt(3,0);
    for (int p=0;p<np;p++) boxes[p] = mt;
    int ii,jj,kk;
    int *delt = new int[3], *layout = new int[3];

    /* Set up layout and deltas */
    layout[0] = nx; layout[1] = ny; layout[2] = nz;
    for (int mm=0;mm<3;mm++) {
      delt[mm] =  (gub(mm)-glb(mm))/layout[mm];
    }


    Coords mylb(3,0),myub(3,0);
    for (ii=0;ii<nx;ii++)
      for (jj=0;jj<ny;jj++)
        for (kk=0;kk<nz;kk++) {
          /* We may care about topology here later... */
          int whichp = ii + jj*nx + kk*nx*ny;
          mylb(0) = delt[0]*ii;
          mylb(1) = delt[1]*jj;
          mylb(2) = delt[2]*kk;

          myub(0) = 
            (ii != nx-1 ? delt[0]*(ii+1)-1 : gub(0));
          myub(1) = 
            (jj != ny-1 ? delt[1]*(jj+1)-1 : gub(1));
          myub(2) = 
            (kk != nz-1 ? delt[2]*(kk+1)-1 : gub(2));

          boxes[whichp].setlower(mylb);
          boxes[whichp].setupper(myub);
          boxes[whichp].setstepsize(0,1);
          boxes[whichp].setstepsize(1,1);
          boxes[whichp].setstepsize(2,1);
        }
}
