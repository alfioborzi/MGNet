#ifndef _included_GDBStorage2_h
#define _included_GDBStorage2_h

/*
*************************************************************************
*                                                                       *
* GDBStorage2.h								*
*                                                                       *
* One unit of GDB storage						*
*                                                                       *
*************************************************************************
*/

#ifndef GridDataBlockStorage
#define GridDataBlockStorage(dim)	name2(GridDataBlockStorage,dim)
#endif

template <class Type> class GridDataBlock(2);
template <class Type> class GridFunction(2);

template <class Type>
class GridDataBlockStorage(2)
  {
   friend ostream& operator<<(ostream&, const GridDataBlockStorage(2)<Type>&);
   friend class GridDataBlock(2)<Type>;
   friend class GridFunction(2)<Type>;

   BBox bbox;
   BBox ibbox;
   BBox bndrybbox[2*2];
   GridData(2)<Type> data;

   inline GridDataBlockStorage(2)() {}
   inline void allocate() { data.allocate(bbox); }
  };

template <class Type>
ostream& operator<<(ostream& os, const GridDataBlockStorage(2)<Type>& gdbs);

#endif
