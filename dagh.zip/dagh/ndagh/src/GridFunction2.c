#ifndef _included_GridFunction2_c
#define _included_GridFunction2_c

/*
*************************************************************************
*                                                                       *
* GridFunction2.c                                                       *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/*****************************************************************************/
/**** Constructors ****/
/*****************************************************************************/

/*****************************************************************************/
/**** Simple Constructors - the GF is explicitly setup using GF_Set*() ****/
/*****************************************************************************/
template <class DAGH_GFType>
GridFunction(2)<DAGH_GFType>::GridFunction(2)(const char name[], 
                                              GridHierarchy& gh)
	: GridFunctionVoid(gh.dagh_type(),2,name,gh,
			   gh.default_alignment(2),
			   gh.boundarywidth(),
                           gh.externalghostwidth(),
                           DAGHComm,DAGHNoShadow,
			   gh.boundarytype(),
			   gh.adaptboundarytype(),
                           DAGHNoExternalGhost),
          length(0), gdb(0), bvalue(0),
          ifunc(0), ufunc(0), bfunc(0), abfunc(0), pfunc(0), rfunc(0), 
	  iofunc(0)
  { 
   const int pnum = comm_service::proc_num();

   /* set up storage for ghost comm */
   if (comm()) {
     ghost_send_info = new GF_Interaction** [pnum];
     ghost_recv_info = new GF_Interaction** [pnum];
     ghost_recv_server = new GridTableGhostRcv** [pnum];
     for (register int p=0;p<pnum;p++) {
       ghost_send_info[p] = 0;
       ghost_recv_info[p] = 0;
       ghost_recv_server[p] = 0;
     }
   }

   /* setup storage for data comm */
   data_recv_server = new GridTableDataRcv** [pnum];
   for (register int p=0;p<pnum;p++) data_recv_server[p] = 0;

   gfid = gh.DAGH_AddGridFunction((GridFunctionVoid *) this);
  }

/*****************************************************************************/
/*** Constructor for backward compatibility ***/
/*****************************************************************************/
template <class DAGH_GFType>
GridFunction(2)<DAGH_GFType>::GridFunction(2)(const char name[],
					      const int t_sten, 
					      const int s_sten,
					      GridHierarchy& gh,
					      const int cflag, 
					      const int sflag,
					      const int extghflag)
	: GridFunctionVoid(gh.dagh_type(),2,name,t_sten,s_sten,
			   gh,DAGH_All,gh.boundarywidth(),
			   gh.externalghostwidth(),
                           cflag,sflag,gh.boundarytype(),
			   gh.adaptboundarytype(),extghflag), 
          length(0), gdb(0), bvalue(0),
          ifunc(0), ufunc(0), bfunc(0), abfunc(0), pfunc(0), rfunc(0), 
	  iofunc(0)
  { 
   gfid = gh.DAGH_AddGridFunction((GridFunctionVoid *) this);

   const int pnum = comm_service::proc_num();

   /* set up storage for ghost comm */
   if (comm()) {
     ghost_send_info = new GF_Interaction** [pnum];
     ghost_recv_info = new GF_Interaction** [pnum];
     ghost_recv_server = new GridTableGhostRcv** [pnum];
     for (register int p=0;p<pnum;p++) {
       ghost_send_info[p] = 0;
       ghost_recv_info[p] = 0;
       ghost_recv_server[p] = 0;
     }
   }

   /* setup storage for data comm */
   data_recv_server = new GridTableDataRcv** [pnum];
   for (register int p=0;p<pnum;p++) data_recv_server[p] = 0;

   GF_Compose();

   if (dagh.chkpt_restart() && checkpoint()) 
     GF_CheckpointRestart();
  }

/*****************************************************************************/
/*** Constructor to set GF type (Cell/NonCell Centerted). ***/
/*****************************************************************************/
template <class DAGH_GFType>
GridFunction(2)<DAGH_GFType>::GridFunction(2)(const char name[],
					      const int t_sten, 
					      const int s_sten,
					      GridHierarchy& gh, 
					      const int type,
					      const int cflag, 
					      const int sflag, 
					      const int bflag,
					      const int adptbflag,
					      const int extghflag)
	: GridFunctionVoid(((type == DAGHNull) ? gh.dagh_type() : type),
			   2,name,t_sten,s_sten,gh,DAGH_All,
			   gh.boundarywidth(),gh.externalghostwidth(),
                           cflag,sflag,bflag,adptbflag,extghflag),
          length(0), gdb(0), bvalue(0),
          ifunc(0), ufunc(0), bfunc(0), abfunc(0), pfunc(0), rfunc(0),
	  iofunc(0)
  { 
   gfid = gh.DAGH_AddGridFunction((GridFunctionVoid *) this);

   const int pnum = comm_service::proc_num();

   /* set up storage for ghost comm */
   if (comm()) {
     ghost_send_info = new GF_Interaction** [pnum];
     ghost_recv_info = new GF_Interaction** [pnum];
     ghost_recv_server = new GridTableGhostRcv** [pnum];
     for (register int p=0;p<pnum;p++) {
       ghost_send_info[p] = 0;
       ghost_recv_info[p] = 0;
       ghost_recv_server[p] = 0;
     }
   }

   /* setup storage for data comm */
   data_recv_server = new GridTableDataRcv** [pnum];
   for (register int p=0;p<pnum;p++) data_recv_server[p] = 0;

   GF_Compose();

   if (dagh.chkpt_restart() && checkpoint()) 
     GF_CheckpointRestart();
  }

template <class DAGH_GFType>
GridFunction(2)<DAGH_GFType>::GridFunction(2)(const char name[],
					      const int t_sten, 
					      const int* s_sten,
					      GridHierarchy& gh, 
					      const int type,
					      const int cflag, 
					      const int sflag, 
					      const int bflag,
					      const int adptbflag,
					      const int extghflag)
	: GridFunctionVoid(((type == DAGHNull) ? gh.dagh_type() : type),
			   2,name,t_sten,s_sten,gh,DAGH_All,
			   gh.boundarywidth(),gh.externalghostwidth(),
                           cflag,sflag,bflag,adptbflag,extghflag),
          length(0), gdb(0), bvalue(0),
          ifunc(0), ufunc(0), bfunc(0), abfunc(0), pfunc(0), rfunc(0), 
	  iofunc(0)
  { 
   gfid = gh.DAGH_AddGridFunction((GridFunctionVoid *) this);

   const int pnum = comm_service::proc_num();

   /* set up storage for ghost comm */
   if (comm()) {
     ghost_send_info = new GF_Interaction** [pnum];
     ghost_recv_info = new GF_Interaction** [pnum];
     ghost_recv_server = new GridTableGhostRcv** [pnum];
     for (register int p=0;p<pnum;p++) {
       ghost_send_info[p] = 0;
       ghost_recv_info[p] = 0;
       ghost_recv_server[p] = 0;
     }
   }

   /* setup storage for data comm */
   data_recv_server = new GridTableDataRcv** [pnum];
   for (register int p=0;p<pnum;p++) data_recv_server[p] = 0;

   GF_Compose();

   if (dagh.chkpt_restart() && checkpoint()) 
     GF_CheckpointRestart();
  }

/*****************************************************************************/
/*** Constructor for GF's with gfRank < dagh.rank ***/
/*****************************************************************************/
template <class DAGH_GFType>
GridFunction(2)<DAGH_GFType>::GridFunction(2)(const char name[],
					      const int t_sten, 
					      const int s_sten,
					      GridHierarchy& gh, 
					      const int type,
					      const int align,
					      const int cflag, 
					      const int sflag,
					      const int bflag,
					      const int adptbflag,
					      const int extghflag)
	: GridFunctionVoid(((type == DAGHNull) ? gh.dagh_type() : type),
			   2,name,t_sten,s_sten,gh,align,
			   gh.boundarywidth(),gh.externalghostwidth(),
                           cflag,sflag,bflag,adptbflag,extghflag),
          length(0), gdb(0), bvalue(0),
          ifunc(0), ufunc(0), bfunc(0), abfunc(0), pfunc(0), rfunc(0),
	  iofunc(0)
  { 
   gfid = gh.DAGH_AddGridFunction((GridFunctionVoid *) this);

   const int pnum = comm_service::proc_num();

   /* set up storage for ghost comm */
   if (comm()) {
     ghost_send_info = new GF_Interaction** [pnum];
     ghost_recv_info = new GF_Interaction** [pnum];
     ghost_recv_server = new GridTableGhostRcv** [pnum];
     for (register int p=0;p<pnum;p++) {
       ghost_send_info[p] = 0;
       ghost_recv_info[p] = 0;
       ghost_recv_server[p] = 0;
     }
   }

   /* setup storage for data comm */
   data_recv_server = new GridTableDataRcv** [pnum];
   for (register int p=0;p<pnum;p++) data_recv_server[p] = 0;

   GF_Compose();

   if (dagh.chkpt_restart() && checkpoint()) 
     GF_CheckpointRestart();
  }

template <class DAGH_GFType>
GridFunction(2)<DAGH_GFType>::GridFunction(2)(const char name[],
					      const int t_sten, 
					      const int* s_sten,
					      GridHierarchy& gh, 
					      const int type,
					      const int align,
					      const int cflag, 
					      const int sflag, 
					      const int bflag,
					      const int adptbflag,
					      const int extghflag)
	: GridFunctionVoid(((type == DAGHNull) ? gh.dagh_type() : type),
			   2,name,t_sten,s_sten,gh,align,
			   gh.boundarywidth(),gh.externalghostwidth(),
                           cflag,sflag,bflag,adptbflag,extghflag),
          length(0), gdb(0), bvalue(0),
          ifunc(0), ufunc(0), bfunc(0), abfunc(0), pfunc(0), rfunc(0),
	  iofunc(0)
  { 
   gfid = gh.DAGH_AddGridFunction((GridFunctionVoid *) this);

   const int pnum = comm_service::proc_num();

   /* set up storage for ghost comm */
   if (comm()) {
     ghost_send_info = new GF_Interaction** [pnum];
     ghost_recv_info = new GF_Interaction** [pnum];
     ghost_recv_server = new GridTableGhostRcv** [pnum];
     for (register int p=0;p<pnum;p++) {
       ghost_send_info[p] = 0;
       ghost_recv_info[p] = 0;
       ghost_recv_server[p] = 0;
     }
   }

   /* setup storage for data comm */
   data_recv_server = new GridTableDataRcv** [pnum];
   for (register int p=0;p<pnum;p++) data_recv_server[p] = 0;

   GF_Compose();

   if (dagh.chkpt_restart() && checkpoint()) 
     GF_CheckpointRestart();
  }

/*****************************************************************************/
/*** Constructor for GF's at a given time and level ***/
/*****************************************************************************/
template <class DAGH_GFType>
GridFunction(2)<DAGH_GFType>::GridFunction(2)(const char name[],
					      const int t_sten, 
					      const int s_sten,
					      const int time, 
					      const int level,
					      GridHierarchy& gh, 
					      const int type,
					      const int cflag, 
					      const int sflag, 
					      const int bflag,
					      const int adptbflag,
					      const int extghflag)
	: GridFunctionVoid(((type == DAGHNull) ? gh.dagh_type() : type),
			   2,name,t_sten,s_sten,gh,DAGH_All,
			   gh.boundarywidth(),gh.externalghostwidth(),
                           cflag,sflag,bflag,adptbflag,extghflag),
          length(0), gdb(0), bvalue(0),
          ifunc(0), ufunc(0), bfunc(0), abfunc(0), pfunc(0), rfunc(0),
	  iofunc(0)
  { 
   gfid = gh.DAGH_AddGridFunction((GridFunctionVoid *) this);

   const int pnum = comm_service::proc_num();

   /* set up storage for ghost comm */
   if (comm()) {
     ghost_send_info = new GF_Interaction** [pnum];
     ghost_recv_info = new GF_Interaction** [pnum];
     ghost_recv_server = new GridTableGhostRcv** [pnum];
     for (register int p=0;p<pnum;p++) {
       ghost_send_info[p] = 0;
       ghost_recv_info[p] = 0;
       ghost_recv_server[p] = 0;
     }
   }

   /* setup storage for data comm */
   data_recv_server = new GridTableDataRcv** [pnum];
   for (register int p=0;p<pnum;p++) data_recv_server[p] = 0;

   GF_Compose(time,level);

   if (dagh.chkpt_restart() && checkpoint()) 
     GF_CheckpointRestart();
  }

template <class DAGH_GFType>
GridFunction(2)<DAGH_GFType>::GridFunction(2)(const char name[],
					      const int t_sten, 
					      const int* s_sten,
					      const int time, 
					      const int level,
					      GridHierarchy& gh, 
					      const int type,
					      const int cflag, 
					      const int sflag, 
					      const int bflag,
					      const int adptbflag,
					      const int extghflag)
	: GridFunctionVoid(((type == DAGHNull) ? gh.dagh_type() : type),
			   2,name,t_sten,s_sten,gh,DAGH_All,
			   gh.boundarywidth(),gh.externalghostwidth(),
                           cflag,sflag,bflag,adptbflag,extghflag),
          length(0), gdb(0), bvalue(0),
          ifunc(0), ufunc(0), bfunc(0), abfunc(0), pfunc(0), rfunc(0), 
	  iofunc(0)
  { 
   gfid = gh.DAGH_AddGridFunction((GridFunctionVoid *) this);

   const int pnum = comm_service::proc_num();

   /* set up storage for ghost comm */
   if (comm()) {
     ghost_send_info = new GF_Interaction** [pnum];
     ghost_recv_info = new GF_Interaction** [pnum];
     ghost_recv_server = new GridTableGhostRcv** [pnum];
     for (register int p=0;p<pnum;p++) {
       ghost_send_info[p] = 0;
       ghost_recv_info[p] = 0;
       ghost_recv_server[p] = 0;
     }
   }

   /* setup storage for data comm */
   data_recv_server = new GridTableDataRcv** [pnum];
   for (register int p=0;p<pnum;p++) data_recv_server[p] = 0;

   GF_Compose(time,level);

   if (dagh.chkpt_restart() && checkpoint()) 
     GF_CheckpointRestart();
  }

/*****************************************************************************/
/*** Constructor from another GF ***/
/*****************************************************************************/
template <class DAGH_GFType>
GridFunction(2)<DAGH_GFType>::GridFunction(2)(const char name[], 
                         const GridFunction(2)<DAGH_GFType>& gf,
					      const int time, 
					      const int level,
					      const int cflag, 
					      const int sflag, 
					      const int bflag,
					      const int adptbflag,
					      const int extghflag)
	: GridFunctionVoid(name,2,gf,cflag,sflag,bflag,adptbflag,extghflag),
          length(0), gdb(0), bvalue(0),
          ifunc(0), ufunc(0), bfunc(0), abfunc(0), pfunc(0), rfunc(0), 
	  iofunc(0)
  { 
   for (register int i=0;i<time_sten_rad;i++) {
      time_alias[2*i] = gf.time_alias[2*i];
      time_alias[2*i+1] = gf.time_alias[2*i+1];
   }
   time_alias[2*time_sten_rad] = gf.time_alias[2*time_sten_rad];

   gfid = dagh.DAGH_AddGridFunction((GridFunctionVoid *) this);

   const int pnum = comm_service::proc_num();

   /* set up storage for ghost comm */
   if (comm()) {
     ghost_send_info = new GF_Interaction** [pnum];
     ghost_recv_info = new GF_Interaction** [pnum];
     ghost_recv_server = new GridTableGhostRcv** [pnum];
     for (register int p=0;p<pnum;p++) {
       ghost_send_info[p] = 0;
       ghost_recv_info[p] = 0;
       ghost_recv_server[p] = 0;
     }
   }

   /* setup storage for data comm */
   data_recv_server = new GridTableDataRcv** [pnum];
   for (register int p=0;p<pnum;p++) data_recv_server[p] = 0;

   GF_Compose(gf,time,level);

   if (dagh.chkpt_restart() && checkpoint()) 
     GF_CheckpointRestart();
  }

/*****************************************************************************/
/**** Destructor ****/
/*****************************************************************************/
template <class DAGH_GFType>
GridFunction(2)<DAGH_GFType>::~GridFunction(2)()
  {
   GF_DeleteGDBStorage();

   if (comm()) {
     GF_DeleteGhostCommInfo();
     if (ghost_send_info) delete [] ghost_send_info;
     ghost_send_info = 0;
     if (ghost_recv_info) delete [] ghost_recv_info;
     ghost_recv_info = 0;
     if (ghost_recv_server) delete [] ghost_recv_server;
     ghost_recv_server = 0;
   }

   GF_DeleteDataCommInfo();
   if (data_recv_server) delete [] data_recv_server;
   data_recv_server = 0;

   if (gt) delete gt;

   dagh.DAGH_DelGridFunction(gfid);
  }
   
/*****************************************************************************/
/**** DeleteInfo ***/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_DeleteGDBStorage()
   {
     const int levels = dagh.totallevels();
     const int timesteps = 2*time_sten_rad+1;

     if (gdb) {
      for (register int t = 0 ; t < timesteps ; t++) {
       if (gdb[t]) {
         for (register int l = 0 ; l < levels ;l++) {
           if (gdb[t][l]) {
             for (register int i =0 ; i < length ; i++) 
               if (gdb[t][l][i]) 
		 { delete gdb[t][l][i]; gdb[t][l][i] = 0; }
	     delete [] gdb[t][l]; gdb[t][l] = 0;
           }
         }
         delete [] gdb[t]; gdb[t] = 0;
       }
      }
      delete [] gdb; gdb = 0;
     }
   }

template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_DeleteGDBStorage(const int t)
   {
     const int levels = dagh.totallevels();

     if (gdb && gdb[t]) {
       for (register int l = 0 ; l < levels ;l++) {
	 if (gdb[t][l]) {
	   for (register int i =0 ; i < length ; i++) 
	     if (gdb[t][l][i]) 
	       { delete gdb[t][l][i]; gdb[t][l][i] = 0; }
	   delete [] gdb[t][l]; gdb[t][l] = 0;
	 }
       }
       delete [] gdb[t]; gdb[t] = 0;
     }
   }

template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_DeleteGhostCommInfo()
   {
     const int pnum = comm_service::proc_num();

     if (comm()) {
       const int levels = dagh.totallevels();
       const int cnt = DAGHMaxAxis * DAGHMaxDirs * levels;

       for (register int i=pnum-1;i>=0;i--) {
         if (ghost_send_info[i]) {
           for (register int j=cnt-1;j>=0;j--) {
             if (ghost_send_info[i] && ghost_send_info[i][j]) {
               delete ghost_send_info[i][j];
               ghost_send_info[i][j] = 0;
             }
           }
           delete [] ghost_send_info[i];
           ghost_send_info[i] = 0;
         }
         if (ghost_recv_info[i] || ghost_recv_server[i]) {
           for (register int j=cnt-1;j>=0;j--) {
             if (ghost_recv_info[i] && ghost_recv_info[i][j]) {
               delete ghost_recv_info[i][j];
               ghost_recv_info[i][j] = 0;
             }
             if (ghost_recv_server[i] && ghost_recv_server[i][j]) {
               delete ghost_recv_server[i][j];
               ghost_recv_server[i][j] = 0;
             }
           }
           if (ghost_recv_info[i]) delete [] ghost_recv_info[i];
           ghost_recv_info[i] = 0;
           if (ghost_recv_server[i]) delete [] ghost_recv_server[i];
           ghost_recv_server[i] = 0;
         }
       }
     }
   }

template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_DeleteDataCommInfo()
   {
     const int pnum = comm_service::proc_num();

     const int timesteps = 2*time_sten_rad+1;
     for (register int i=pnum-1;i>=0;i--) {
       if (data_recv_server[i]) {
         for (register int j=timesteps-1;j>=0;j--) {
           if (data_recv_server[i][j]) {
             delete data_recv_server[i][j];
             data_recv_server[i][j] = 0;
           }
           delete [] data_recv_server[i];
           data_recv_server[i] = 0;
         }
       }
     }
   }

/*****************************************************************************/
/**** Compose() ****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_Compose()
  {

   if (comm_flag >= DAGHTemplateComm) {
     template_flag = comm_flag - DAGHTemplateComm;
#ifdef DEBUG_PRINT
     assert(dagh.gflist[template_flag]);
#endif
     comm_flag = dagh.gflist[template_flag]->comm_type();
   }

   if (composed()) return;
    /* set up the interactions */
   interactions.compute_interactions(
               (comm_flag != DAGHCommNoFace),
               (comm_flag != DAGHCommFaceOnly && comm_flag != DAGHCommNoCorner),
               (comm_flag != DAGHCommFaceOnly && comm_flag != DAGHCommNoEdge) );

   const int me = comm_service::proc_me();
   const int pnum = comm_service::proc_num();

   const int levels = dagh.totallevels();

   /* set up storage for the current time counter */
   curtime[0] = new int[levels];
   curtime[1] = new int[levels];
   for (register int i=0;i<levels;i++) {
     curtime[0][i] = curtime[1][i] = 0;
   }

   const int tsteps = 2*time_sten_rad+1;

   GridUnitList *cgul = dagh.clist();
   const int mindex = dagh.maxindex()+1;

   gt = new GridTable(gfid,*cgul,mindex,tsteps);

   const List<MergedGridUnit*> &mgulist = dagh.mllist();
   length = mgulist.number();
 

#ifdef DEBUG_PRINT_GF_GT
     ( comm_service::log() << "\n************* Grid Table *************\n"
			   << "------ [" << gfname << "] ------" << "\n"
                           << *gt
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

   /* If memory is already allocated, delete it.... */
   GF_DeleteGDBStorage();

   register int t;
   /* Allocate memory */
   gdb = new GridDataBlock(2)<DAGH_GFType> ***[tsteps];
   for (t=0;t<tsteps;t++) {
     gdb[t] = (GridDataBlock(2)<DAGH_GFType> ***) NULL;
   }
   for (t=0;t<tsteps;t++) {
     if (!gdb[time_alias[t]]) {
       gdb[time_alias[t]] = new GridDataBlock(2)<DAGH_GFType> **[levels];

       for (register int l=0;l<levels;l++) {
         gdb[time_alias[t]][l] = new GridDataBlock(2)<DAGH_GFType> *[length];
         for (register int i=0;i<length;i++) 
           gdb[time_alias[t]][l][i] = (GridDataBlock(2)<DAGH_GFType> *) NULL;
       }
     }
   }
   
   const int has_shadow = shadow();

   GridFunction(2)<DAGH_GFType>* gftemplate = 0;
   if (template_flag != DAGHNull) {
     gftemplate = (GridFunction(2)<DAGH_GFType>*) dagh.gflist[template_flag];
     if (gftemplate && !gftemplate->composed()) gftemplate = 0;
   }
   const GridDataBlock(2)<DAGH_GFType>* gdbtmpl = 0;

   register int mgui = 0;
   MergedGridUnit** mgu = 0;
   DAGHListLoop(mgulist, mgu, MergedGridUnit*) {
     const int finest = (*mgu)->gul.finest();
     for (register int l=0;l<levels;l++) {
       const int lev = dagh.levelnum(l);
       const int cti = dagh_timeindex(dagh.getCurrentTime(l),l);
       const int ct = dagh.getCurrentTime(l);
       int tmplcti = DAGHNull;
       if (template_flag != DAGHNull && 
           gftemplate && 
	   gftemplate->gdb[(tmplcti=gftemplate->dagh_timeindex(ct,l))] 
	   && gftemplate->gdb[tmplcti][l])
	 gdbtmpl = gftemplate->gdb[tmplcti][l][mgui];
       else gdbtmpl = 0;
       if (lev <= finest) {
   	 for (t=0;t<tsteps;t++) if (gdb[t] && gdb[t][l]) {
           gdb[t][l][mgui] = new GridDataBlock(2)<DAGH_GFType>(gfid, dagh, *gt, 
                                                               interactions,
                                                               (*mgu)->gul,
                                                               t, dagh.levelnum(l), 
                                                               bwidth, extghostwidth,
							       overlap, 
			                                       space_sten_rad, 
                                                               alignment, mindex,
                                                               comm(t,l), has_shadow,
                                                               gdbtmpl);
           if (gdbtmpl == 0 || comm(t,l)) gdbtmpl = gdb[t][l][mgui];
         }
       }
     }
     mgui++;
   } DAGHEndLoop

   if (comm()) {
     GF_GatherGhostCommInfo();
     GF_SetUpGhostCommServers();
   }

   compose_flag = DAGHTrue;
  }

/*****************************************************************************/
/**** Compose(const int T, const int L) ****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_Compose(const int T, const int L)
  {
   if (comm_flag >= DAGHTemplateComm) {
     template_flag = comm_flag - DAGHTemplateComm;
#ifdef DEBUG_PRINT
     assert(dagh.gflist[template_flag]);
#endif
     comm_flag = dagh.gflist[template_flag]->comm_type();
   }

   if (composed()) return;
    /* set up the interactions */
   interactions.compute_interactions(
                (comm_flag != DAGHCommNoFace),
                (comm_flag != DAGHCommFaceOnly && comm_flag != DAGHCommNoCorner),
                (comm_flag != DAGHCommFaceOnly && comm_flag != DAGHCommNoEdge) );

   const int me = comm_service::proc_me();
   const int pnum = comm_service::proc_num();

   const int levels = dagh.totallevels();
   const int Lnum = dagh.levelnum(L);

   /* set up storage for the current time counter */
   curtime[0] = new int[levels];
   curtime[1] = new int[levels];
   for (register int i=0;i<levels;i++) {
     curtime[0][i] = curtime[1][i] = 0;
   }

   const int tsteps = 2*time_sten_rad+1;

   GridUnitList *cgul = dagh.clist();
   const int flev = dagh.finelevel();
   const int fl = dagh.finelevelindex();
   const int mindex = dagh.maxindex()+1;

   if (L == DAGHAllLevels) {
     gt = new GridTable(gfid,*cgul,mindex,tsteps);
   }
   else if (L <= fl) {
     GridUnitList gul;
     cgul->levellist(gul,Lnum);
     gt = new GridTable(gfid,gul,mindex,tsteps);
   }
   else {
     // right now I will allow only one extra level
     assert((L-fl) == 1); 
     GridUnitList gul;
     cgul->levellist(gul,flev);
     GridUnitList *rgul = gul.refinelist(flev,L-fl);
     gt = new GridTable(gfid,*rgul,mindex,tsteps);
     if (rgul) delete rgul;
   }

   const List<MergedGridUnit*> &mgulist = dagh.mllist();
   length = mgulist.number();
 
#ifdef DEBUG_PRINT_GF_GT
     ( comm_service::log() << "\n************* Grid Table *************\n"
			   << "------ [" << gfname << "] ------" << "\n"
                           << *gt
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

   /* If memory is already allocated, delete it.... */
   GF_DeleteGDBStorage();

   register int t = 0;
   /* Allocate memory */
   gdb = new GridDataBlock(2)<DAGH_GFType> ***[tsteps];
   for (t=0;t<tsteps;t++) {
     gdb[t] = (GridDataBlock(2)<DAGH_GFType> ***) NULL;
   }
   for (t=0;t<tsteps;t++) {
     for (register int l=0;l<levels;l++) {
       if (T != DAGHAllTimes && dagh_timeindex(T,l) != time_alias[t]) continue;
       if (!gdb[time_alias[t]]) {
         gdb[time_alias[t]] = new GridDataBlock(2)<DAGH_GFType> **[levels];
         for (register int ll=0;ll<levels;ll++)
           gdb[time_alias[t]][ll] = (GridDataBlock(2)<DAGH_GFType> **) NULL;
       }
       if ((L == DAGHAllLevels || L == l) && !gdb[time_alias[t]][l]) {
          gdb[time_alias[t]][l] = new GridDataBlock(2)<DAGH_GFType> *[length];

          for (register int i=0;i<length;i++)
            gdb[time_alias[t]][l][i] = (GridDataBlock(2)<DAGH_GFType> *) NULL;
       }
     }
   }

   const int has_shadow = shadow();

   GridFunction(2)<DAGH_GFType>* gftemplate = 0;
   if (template_flag != DAGHNull) {
     gftemplate = (GridFunction(2)<DAGH_GFType>*) dagh.gflist[template_flag];
     if (gftemplate && !gftemplate->composed()) gftemplate = 0;
   }
   const GridDataBlock(2)<DAGH_GFType>* gdbtmpl = 0;

   register int mgui = 0;
   MergedGridUnit** mgu = 0;
   DAGHListLoop(mgulist, mgu, MergedGridUnit*) {
     const int finest = (*mgu)->gul.finest();
     for (register int l=0;l<levels;l++) {
       if (L != DAGHAllLevels && L != l) continue;
       const int lev = (l < fl) ? dagh.levelnum(l) : flev;
       const int cti = dagh_timeindex(dagh.getCurrentTime(l),l);
       const int ct = dagh.getCurrentTime(l);
       int tmplcti = DAGHNull;
       if (template_flag != DAGHNull && 
           gftemplate && 
	   gftemplate->gdb[(tmplcti=gftemplate->dagh_timeindex(ct,l))] 
	   && gftemplate->gdb[tmplcti][l])
	 gdbtmpl = gftemplate->gdb[tmplcti][l][mgui];
       else gdbtmpl = 0;
       if (lev <= finest) {
   	 for (t=0;t<tsteps;t++) {
           if (T != DAGHAllTimes && dagh_timeindex(T,l) != t) continue;
           if (gdb[t] && gdb[t][l]) {
             gdb[t][l][mgui] = new GridDataBlock(2)<DAGH_GFType>(gfid, dagh, *gt, 
                                                              interactions,
                                                              (*mgu)->gul,
                                                              t, dagh.levelnum(l), 
                                                              bwidth, extghostwidth,
							      overlap, 
		                                              space_sten_rad,  
                                                              alignment, mindex,
                                                              comm(t,l), has_shadow,
                                                              gdbtmpl);
             if (gdbtmpl == 0 || comm(t,l)) gdbtmpl = gdb[t][l][mgui];
           }
         }
       }
     }
     mgui++;
   } DAGHEndLoop

   if (comm()) {
     GF_GatherGhostCommInfo();
     GF_SetUpGhostCommServers();
   }

   compose_flag = DAGHTrue;
  }

/*****************************************************************************/
/*** Compose(const GridFunction(2)<DAGH_GFType>&const int T, const int L) ***/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_Compose(
                                        const GridFunction(2)<DAGH_GFType>& gf,
					const int T, const int L)
  {
   if (comm_flag >= DAGHTemplateComm) {
     template_flag = comm_flag - DAGHTemplateComm;
#ifdef DEBUG_PRINT
     assert(dagh.gflist[template_flag]);
#endif
     comm_flag = dagh.gflist[template_flag]->comm_type();
   }

   if (composed()) return;
   /* set up the interactions */
   interactions.compute_interactions(
                (comm_flag != DAGHCommNoFace),
                (comm_flag != DAGHCommFaceOnly && comm_flag != DAGHCommNoCorner),
                (comm_flag != DAGHCommFaceOnly && comm_flag != DAGHCommNoEdge) );

   const int me = comm_service::proc_me();
   const int pnum = comm_service::proc_num();

   const int levels = dagh.totallevels();
   const int Lnum = dagh.levelnum(L);

   /* set up storage for the current time counter */
   curtime[0] = new int[levels];
   curtime[1] = new int[levels];
   for (register int i=0;i<levels;i++) {
     curtime[0][i] = gf.curtime[0][i];
     curtime[1][i] = gf.curtime[1][i];
   }

   const int tsteps = 2*time_sten_rad+1;

   GridUnitList *cgul = dagh.clist();
   const int flev = dagh.finelevel();
   const int fl = dagh.finelevelindex();
   const int mindex = dagh.maxindex()+1;

   if (L == DAGHAllLevels) {
     gt = new GridTable(gfid,*cgul,mindex,tsteps);
   }
   else if (L <= fl) {
     GridUnitList gul;
     cgul->levellist(gul,dagh.levelnum(L));
     gt = new GridTable(gfid,gul,mindex,tsteps);
   }
   else {
     // right now I will allow only one extra level
     assert((L-fl) == 1);
     GridUnitList gul;
     cgul->levellist(gul,flev);
     GridUnitList *rgul = gul.refinelist(flev,L-fl);
     gt = new GridTable(gfid,*rgul,mindex,tsteps);
     if (rgul) delete rgul;
   }

   length = gf.length;

#ifdef DEBUG_PRINT_GF_GT
     ( comm_service::log() << "\n************* Grid Table *************\n"
			   << "------ [" << gfname << "] ------" << "\n"
                           << *gt
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

   /* If memory is already allocated, delete it.... */
   GF_DeleteGDBStorage();

   register int t = 0;
   /* Allocate memory */
   gdb = new GridDataBlock(2)<DAGH_GFType> ***[tsteps];
   for (t=0;t<tsteps;t++) {
     gdb[t] = (GridDataBlock(2)<DAGH_GFType> ***) NULL;
   }
   for (t=0;t<tsteps;t++) {
     for (register int l=0;l<levels;l++) {
       if (T != DAGHAllTimes && dagh_timeindex(T,l) != time_alias[t]) continue;
       if (!gdb[time_alias[t]]) {
         gdb[time_alias[t]] = new GridDataBlock(2)<DAGH_GFType> **[levels];
         for (register int ll=0;ll<levels;ll++)
           gdb[time_alias[t]][ll] = (GridDataBlock(2)<DAGH_GFType> **) NULL;
       }
       if ((L == DAGHAllLevels || L == l) && !gdb[time_alias[t]][l]) {
          gdb[time_alias[t]][l] = new GridDataBlock(2)<DAGH_GFType> *[length];

          for (register int i=0;i<length;i++)
            gdb[time_alias[t]][l][i] = (GridDataBlock(2)<DAGH_GFType> *) NULL;
       }
     }
   }

   const int has_shadow = shadow();
   const int he_has_shadow = gf.shadow();

   const List<MergedGridUnit*> &mgulist = dagh.mllist();

   GridUnitList** merged_gul = new GridUnitList*[length];
   register int m = 0;
   MergedGridUnit** mgu = 0;
   DAGHListLoop(mgulist, mgu, MergedGridUnit*) {
     merged_gul[m] = &(*mgu)->gul; m++;
   } DAGHEndLoop

   GridFunction(2)<DAGH_GFType>* gftemplate = 0;
   if (template_flag != DAGHNull) {
     gftemplate = (GridFunction(2)<DAGH_GFType>*) dagh.gflist[template_flag];
     if (gftemplate && !gftemplate->composed()) gftemplate = 0;
   }
   const GridDataBlock(2)<DAGH_GFType>* gdbtmpl = 0;

   for (register int l=0;l<levels;l++) {
     if (L != DAGHAllLevels && L != l) continue;
     for (register int i=0;i<length;i++) {
       const int cti = dagh_timeindex(dagh.getCurrentTime(l),l);
       const int ct = dagh.getCurrentTime(l);
       int tmplcti = DAGHNull;
       if (template_flag != DAGHNull && 
           gftemplate && 
	   gftemplate->gdb[(tmplcti=gftemplate->dagh_timeindex(ct,l))] 
	   && gftemplate->gdb[tmplcti][l])
	 gdbtmpl = gftemplate->gdb[tmplcti][l][i];
       else gdbtmpl = 0;
       for (t=0;t<=tsteps;t++) {
         if (T != DAGHAllTimes && dagh_timeindex(T,l) != t) continue;
         const int ll = (l < fl) ? l : fl;
         if (gdb[t] && gdb[t][l] && 
             gf.gdb[t] && gf.gdb[t][ll] && gf.gdb[t][ll][i]) { 
           gdb[t][l][i] = new GridDataBlock(2)<DAGH_GFType>(gfid, dagh, *gt, 
                                                            interactions,
                                                            *merged_gul[i],
                                                            t, dagh.levelnum(l), 
                                                            bwidth, extghostwidth,
							    overlap, 
	                                                    space_sten_rad, 
                                                            alignment, mindex,
                                                            comm(t,l), has_shadow,
                                                            gdbtmpl);

           if (gdbtmpl == 0 || comm(t,l)) gdbtmpl = gdb[t][l][i];

           // Initialize data from the other GF ....
           if (DAGHInitGFOnCreation == DAGHTrue) { 
             if (l > ll && pfunc && prolong()) { /* prolong */
               int myargc = 0; DAGH_GFType myargs[1];
	       (*pfunc)(FORTRAN_ARGS(gf.gdb[t][ll][i]->mstorage.data),
                        FORTRAN_ARGS(gdb[t][l][i]->mstorage.data),
                        BOUNDING_BOX(gdb[t][l][i]->mstorage.data),
	                myargs,&myargc);
               if (has_shadow && he_has_shadow) {/* initialize shadow */
	         (*pfunc)(FORTRAN_ARGS(gf.gdb[t][ll][i]->shstorage->data),
                          FORTRAN_ARGS(gdb[t][l][i]->shstorage->data),
                          BOUNDING_BOX(gdb[t][l][i]->shstorage->data),
	                  myargs,&myargc);
               }
               else if (has_shadow) {
                 gdb[t][l][i]->shstorage->data.copy(gdb[t][l][i]->mstorage.data);
               }
             }
             else { /* copy... */
               gdb[t][l][i]->mstorage.data.copy(gf.gdb[t][ll][i]->mstorage.data);
               if (has_shadow && he_has_shadow) /* initialize shadow */
                 gdb[t][l][i]->shstorage->data.copy(gf.gdb[t][ll][i]->shstorage->data);
               else if (has_shadow) 
                 gdb[t][l][i]->shstorage->data.copy(gdb[t][l][i]->mstorage.data);
             }
           }
         } // end inititalize from other GF
       }
     }
   }
   if (comm()) {
     GF_GatherGhostCommInfo();
     GF_SetUpGhostCommServers();
   }
   if (merged_gul) delete [] merged_gul;

   compose_flag = DAGHTrue;
  }

/*****************************************************************************/
/**** .. & Recompose  ****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_Recompose(const int omindex,
                                                const GridUnitList& ollist,
                                                GridUnitList& rlist, 
                                                GridUnitList& slist,
						GridUnitList& olist)

  {
   const int me = comm_service::proc_me();
   const int pnum = comm_service::proc_num();

   GridTable* oldgt = gt; gt = 0;
   GridDataBlock(2)<DAGH_GFType> ****oldgdb = gdb; gdb = 0;
   const int oldlength = length; length = 0;
   
   const int timesteps = 2*time_sten_rad+1;

   const int mindex = dagh.maxindex()+1;
   GridUnitList *cgul = dagh.clist();

   gt = new GridTable(gfid,*cgul,mindex,timesteps);

#ifdef DEBUG_PRINT_GF_RG_GT
     ( comm_service::log() << "\n************* New Grid Table *************\n"
                           << *gt
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

   GridUnitList &llist = *dagh.llist();

   const List<MergedGridUnit*> &mgulist = dagh.mllist();
   length = mgulist.number();

   GridUnitList** merged_gul = new GridUnitList*[length];

   register int m = 0;
   MergedGridUnit** mgu = 0;
   BBoxList merged_bbl;
   DAGHListLoop(mgulist, mgu, MergedGridUnit*) {
     merged_gul[m] = &(*mgu)->gul; m++;
     merged_bbl.add((*mgu)->bb);
   } DAGHEndLoop

   const int levels = dagh.totallevels();
   const int crslev = dagh.coarselevel();
   const int has_shadow = shadow();
   //const int daghflag = (has_shadow) ? DAGH_BothGH : DAGH_Main;
   const int shadowfactor = dagh.daghshadowfactor();

   gdb = new GridDataBlock(2)<DAGH_GFType> ***[timesteps];
   for (register int t=0;t<timesteps;t++) {
     gdb[t] = (GridDataBlock(2)<DAGH_GFType> ***) NULL;
     if (oldgdb[t]) {
       gdb[t] = new GridDataBlock(2)<DAGH_GFType> **[levels];
       for (register int l=0;l<levels;l++) {
         gdb[t][l] = new GridDataBlock(2)<DAGH_GFType> *[length];
         for (register int i=0;i<length;i++)
           gdb[t][l][i] = (GridDataBlock(2)<DAGH_GFType> *) NULL;
       }
     }
   }

   /* destroy old storage for ghost comm */
   GF_DeleteGhostCommInfo();
   
   /* destroy old storage for data comm */
   GF_DeleteDataCommInfo();

   /* Comm: Post Rcvs */
   if (comm_service::dce() && pnum > 1) {
     GridTableEntry *oldgte = 0;
     GridTableEntry *newgte = 0;
     //GridUnitList rlist(llist); rlist is passed in from GH
     //rlist -= ollist;
     if (!rlist.isempty()) {

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "\n************* Recv List *************\n"
                           << rlist
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     int oldowner = DAGHNoBody;

     register GridUnit *tmpgu = rlist.first();
     register int lev = 0;
     register int idx = 0;
     
if (template_flag == DAGHNull) {

     if (rcvsize) delete [] rcvsize;
     if (shrcvsize) delete [] shrcvsize;

     rcvsize = new unsigned[pnum];
     shrcvsize = new unsigned[pnum];
     register int p;
     for (p=0;p<pnum;p++) {
       rcvsize[p] = shrcvsize[p] = 0;
     }

     BBox *rb = new BBox[pnum*levels*omindex];
     short *rtoidx = new short[pnum*levels*omindex];
     register int ridx = 0;
    
     const GridDataBlock(2)<DAGH_GFType>* gdbtmpl = 0;

     for(;tmpgu;tmpgu=rlist.next()) {
       idx = tmpgu->guIndex();
       oldgte = oldgt->find(tmpgu->guBaseIndex());
       if (oldgte) oldowner = oldgte->myowner();
       newgte = gt->find(tmpgu->guBaseIndex());
       if ( newgte && oldgte && (tmpgu->guExtent(crslev) > oldgte->extent(crslev)) ) {
#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::Recv-Decompose "
                           << tmpgu->guExtent(crslev) - oldgte->extent(crslev)
                           << endl ).flush();
#endif
         rlist.decompose(tmpgu->guExtent(crslev) - oldgte->extent(crslev));
	 continue;
       }
       for (register int l=0;l<levels;l++) {
         lev = dagh.levelnum(l);
         if ( !tmpgu->guContains(lev) ) continue;
         gdbtmpl = 0;
         for (register int t=0;t<timesteps;t++) {
           if (!gdb[t] || !gdb[t][l]) continue;
           if (!gdb[t][l][idx]) {
           gdb[t][l][idx] = new GridDataBlock(2)<DAGH_GFType>(gfid, dagh, *gt,
                                                              interactions,
                                                              *merged_gul[idx],
                                                              t, lev,
                                                              bwidth, extghostwidth,
							      overlap,
                                                              space_sten_rad,
                                                              alignment, mindex,
                                                              comm(t,l), has_shadow,
                                                              gdbtmpl);
           if (gdbtmpl == 0 || comm(t,l)) gdbtmpl = gdb[t][l][idx];
         } }
         if (oldgte && oldgte->haslevel(lev)) {

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::RecvFromGTE[" << idx << "]"
                           << *oldgte
                           << endl ).flush();
#endif

           ridx = oldowner*levels*omindex + l*omindex + oldgte->myindex();
           //BBox gb = growupperbydim(tmpgu->guBBox(lev), overlap);
           BBox gb(tmpgu->guBBox(lev,overlap));
           gdbAlignBBox(gfrank,gb,alignment);
           if (rb[ridx].empty()) { rb[ridx] = gb; rtoidx[ridx] = idx; }
           else if (rtoidx[ridx] == idx && gb.mergable(rb[ridx], overlap)) {
#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::RecvInfo "
                           << "[Merging: " << rb[ridx] << " & " << gb << " ]"
                           << endl ).flush();
#endif
             rb[ridx] += gb;
	   }
           else {
             rcvsize[oldowner] += gdhdr::gdbsize(sizeof(DAGH_GFType)*rb[ridx].size());
             if (has_shadow == DAGHTrue) shrcvsize[oldowner] += 
             gdhdr::gdbsize(sizeof(DAGH_GFType)*coarsen(rb[ridx],shadowfactor).size());

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::RecvInfo "
                           << "[From:" << oldowner << "]"
                           << "[BB:" << rb[ridx] << "]"
                           << "[Si:" << oldgte->myindex() << "]"
                           << "[Ri:" << idx << "]"
                           << "[Sl:" << l << "]"
                           << endl ).flush();
#endif

             rb[ridx] = gb; 
             rtoidx[ridx] = idx; 
           }
         }
       }
     }
     for (p=0;p<pnum;p++) {
       for (register int l=0;l<levels;l++) {
         for (m=0;m<omindex;m++) {
           ridx = p*levels*omindex + l*omindex + m;
           if (!rb[ridx].empty()) {

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::RecvInfo "
                           << "[From:" << oldowner << "]"
                           << "[BB:" << rb[ridx] << "]"
                           << "[Si:" << oldgte->myindex() << "]"
                           << "[Ri:" << idx << "]"
                           << "[Sl:" << l << "]"
                           << endl ).flush();
#endif

             rcvsize[p] += gdhdr::gdbsize(sizeof(DAGH_GFType)*rb[ridx].size());
             if (has_shadow == DAGHTrue) shrcvsize[p] += 
             gdhdr::gdbsize(sizeof(DAGH_GFType)*coarsen(rb[ridx],shadowfactor).size());
             rb[ridx].setempty();
           }
         }
       }
     }
     for (register int t=0;t<timesteps;t++) {
       if (!gdb[t]) continue;
       for (p=0;p<pnum;p++) {
         if (me == p) continue;
         if (rcvsize[p] > 0 || shrcvsize[p] > 0) {
           if (!data_recv_server[p]) {
             data_recv_server[p] = new GridTableDataRcv *[timesteps];
             for (register int k=0; k<timesteps; k++) data_recv_server[p][k] = 0; 
           }
           data_recv_server[p][t] = 
             new GridTableDataRcv(*gt, (DAGHDataTag | t), rcvsize[p]+shrcvsize[p], p);
         }
       }
     }
     // These values will now be reused !
     //if (rcvsize) delete [] rcvsize;
     //if (shrcvsize) delete [] shrcvsize;
     if (rb) delete [] rb;
     if (rtoidx) delete [] rtoidx;

} else {

     GridFunction(2)<DAGH_GFType>* gftemplate = 
                    (GridFunction(2)<DAGH_GFType>*) dagh.gflist[template_flag];

     rcvsize = gftemplate->rcvsize;
     shrcvsize = gftemplate->shrcvsize;
    
     const GridDataBlock(2)<DAGH_GFType>* gdbtmpl = 0;

     for(;tmpgu;tmpgu=rlist.next()) {
       idx = tmpgu->guIndex();
       for (register int l=0;l<levels;l++) {
         lev = dagh.levelnum(l);
         if ( !tmpgu->guContains(lev) ) continue;
         const int cti = dagh_timeindex(dagh.getCurrentTime(l),l);
	 const int ct = dagh.getCurrentTime(l);
	 int tmplcti = DAGHNull;
	 if (gftemplate && 
	     gftemplate->gdb[(tmplcti=gftemplate->dagh_timeindex(ct,l))] 
	     && gftemplate->gdb[tmplcti][l])
	   gdbtmpl = gftemplate->gdb[tmplcti][l][idx];
         else gdbtmpl = 0;
         for (register int t=0;t<timesteps;t++) {
           if (!gdb[t] || !gdb[t][l]) continue;
           if (!gdb[t][l][idx]) {
           gdb[t][l][idx] = new GridDataBlock(2)<DAGH_GFType>(gfid, dagh, *gt,
                                                              interactions,
                                                              *merged_gul[idx],
                                                              t, lev,
                                                              bwidth, extghostwidth,
							      overlap,
                                                              space_sten_rad,
                                                              alignment, mindex,
                                                              comm(t,l), has_shadow,
                                                              gdbtmpl);
           if (gdbtmpl == 0 || comm(t,l)) gdbtmpl = gdb[t][l][idx];
         } }
       }
     }
     unsigned rsize = 0;
     for (register int t=0;t<timesteps;t++) {
       if (!gdb[t]) continue;
       for (register int p=0;p<pnum;p++) {
         if (me == p) continue;
         rsize = rcvsize[p];
         if (has_shadow == DAGHTrue) rsize += shrcvsize[p]; 
         if (rsize > 0) {
           if (!data_recv_server[p]) {
             data_recv_server[p] = new GridTableDataRcv *[timesteps];
             for (register int k=0; k<timesteps; k++) data_recv_server[p][k] = 0; 
           }
           data_recv_server[p][t] = 
             new GridTableDataRcv(*gt, (DAGHDataTag | t), rsize, p);
         }
       }
     }
     rcvsize = 0;
     shrcvsize = 0;
}

   } }

   /* Comm: Do Sends */
   if (comm_service::dce() && pnum > 1) {
     GridTableEntry *newgte = 0;
     int newowner = DAGHNoBody;
     //GridUnitList slist(ollist); // passed in from GH
     //slist -= llist;
     if (!slist.isempty()) {

     register GridUnit *tmpgu = slist.first();
     register int lev = 0;
     register int idx = 0;
     register int nidx = 0;

if (template_flag == DAGHNull) {

     slen = 2*slist.number();

     if (sndsize) delete [] sndsize;
     if (sndbbox) delete [] sndbbox;
     if (sndindex) delete [] sndindex;
     if (rcvindex) delete [] rcvindex;
     if (sndlevel) delete [] sndlevel;
     if (sndcnt) delete [] sndcnt;

     sndsize = new unsigned[pnum*levels*slen];
     sndbbox = new BBox[pnum*levels*slen];
     sndindex = new short[pnum*levels*slen];
     rcvindex = new short[pnum*levels*slen];
     sndlevel = new short[pnum*levels*slen];

     sndcnt = new short[pnum];

     register int p = 0;
     for (p=0;p<pnum;p++) sndcnt[p] = 0;

     BBox *sb = new BBox[pnum*levels*omindex];
     short *stoidx = new short[pnum*levels*omindex];
     register int sidx = 0;

     for(;tmpgu;tmpgu=slist.next()) {
       idx = tmpgu->guIndex();

       newgte = gt->find(tmpgu->guBaseIndex());
       if (newgte) newowner = newgte->myowner();

       if (newgte && (tmpgu->guExtent(crslev) > newgte->extent(crslev)) ) {
#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::Send-Decompose "
                           << tmpgu->guExtent(crslev) - newgte->extent(crslev)
                           << endl ).flush();
#endif
         slist.decompose(tmpgu->guExtent(crslev) - newgte->extent(crslev));
       }
       else {
         for (register int l=0;l<levels;l++) {
           lev = dagh.levelnum(l);
           if (!tmpgu->guContains(lev)) continue;
	   if (newgte && newgte->haslevel(lev)) { /* Send */
             sidx = newowner*levels*omindex + l*omindex + idx;
             nidx = newgte->myindex();

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::SendToGTE[" << idx << "]"
                           << *newgte
                           << endl ).flush();
#endif

             //BBox gb = growupperbydim(tmpgu->guBBox(lev), overlap);
             BBox gb(tmpgu->guBBox(lev, overlap));
             gdbAlignBBox(gfrank,gb,alignment);
             if (sb[sidx].empty()) { sb[sidx] = gb; stoidx[sidx] = nidx; }
             else if (stoidx[sidx] == nidx && gb.mergable(sb[sidx], overlap)) {
#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::SendInfo "
                           << "[Merging: " << sb[sidx] << " & " << gb << " ]"
                           << endl ).flush();
#endif
               sb[sidx] += gb;
	     }
             else {
               const int tmpid = newowner*levels*slen + sndcnt[newowner];
               sndbbox[tmpid] = sb[sidx];
               sndsize[tmpid] = sizeof(DAGH_GFType)*sb[sidx].size();
               sndindex[tmpid] = idx;
               rcvindex[tmpid] = stoidx[sidx];
               sndlevel[tmpid] = l;

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::SendInfo [" << sndcnt[newowner] << "]"
                           << "[To:" << newowner << "]"
                           << "[BB:" << sndbbox[tmpid] << "]"
                           << "[Sz:" << sndsize[tmpid] << "]"
                           << "[Si:" << sndindex[tmpid] << "]"
                           << "[Ri:" << rcvindex[tmpid] << "]"
                           << "[Sl:" << sndlevel[tmpid] << "]"
                           << endl ).flush();
#endif

               sndcnt[newowner]++;

               if (has_shadow == DAGHTrue) {
                 const BBox sbb = coarsen(sb[sidx],shadowfactor);
                 sndbbox[tmpid+1] = sbb;
                 sndsize[tmpid+1] = sizeof(DAGH_GFType)*sbb.size();
                 sndindex[tmpid+1] = idx;
                 rcvindex[tmpid+1] = stoidx[sidx];
                 sndlevel[tmpid+1] = l;

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::SendInfo [" << sndcnt[newowner] << "]"
                           << "[To:" << newowner << "]"
                           << "[BB:" << sndbbox[tmpid+1] << "]"
                           << "[Sz:" << sndsize[tmpid+1] << "]"
                           << "[Si:" << sndindex[tmpid+1] << "]"
                           << "[Ri:" << rcvindex[tmpid+1] << "]"
                           << "[Sl:" << sndlevel[tmpid+1] << "]"
                           << endl ).flush();
#endif

                 sndcnt[newowner]++;
               }
               sb[sidx] = gb; 
               stoidx[sidx] = nidx; 
             }
           }
         }
       }
     }
     for (p=0;p<pnum;p++) {
       for (register int l=0;l<levels;l++) {
         for (m=0;m<omindex;m++) {
           sidx = p*levels*omindex + l*omindex + m;
           if (!sb[sidx].empty()) {
             const int tmpid = p*levels*slen + sndcnt[p];
             sndbbox[tmpid] = sb[sidx];
             sndsize[tmpid] = sizeof(DAGH_GFType)*sb[sidx].size();
             sndindex[tmpid] = m;
             rcvindex[tmpid] = stoidx[sidx];
             sndlevel[tmpid] = l;

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::SendInfo [" << sndcnt[p] << "]"
                           << "[To:" << p << "]"
                           << "[BB:" << sndbbox[tmpid] << "]"
                           << "[Sz:" << sndsize[tmpid] << "]"
                           << "[Si:" << sndindex[tmpid] << "]"
                           << "[Ri:" << rcvindex[tmpid] << "]"
                           << "[Sl:" << sndlevel[tmpid] << "]"
                           << endl ).flush();
#endif

             sndcnt[p]++;
             if (has_shadow == DAGHTrue) {
               const BBox sbb = coarsen(sb[sidx],shadowfactor);
               sndbbox[tmpid+1] = sbb;
               sndsize[tmpid+1] = sizeof(DAGH_GFType)*sbb.size();
               sndindex[tmpid+1] = m;
               rcvindex[tmpid+1] = stoidx[sidx];
               sndlevel[tmpid+1] = l;

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::SendInfo [" << sndcnt[p] << "]"
                           << "[To:" << p << "]"
                           << "[BB:" << sndbbox[tmpid+1] << "]"
                           << "[Sz:" << sndsize[tmpid+1] << "]"
                           << "[Si:" << sndindex[tmpid+1] << "]"
                           << "[Ri:" << rcvindex[tmpid+1] << "]"
                           << "[Sl:" << sndlevel[tmpid+1] << "]"
                           << endl ).flush();
#endif

               sndcnt[p]++;
             }
             sb[sidx].setempty();
           }
         }
       }
     }
     for (register int t=0;t<timesteps;t++) {
       if (!oldgdb[t]) continue;
       for (p=0;p<pnum;p++) {
         if (p == me) continue;
         if (sndcnt[p] == 0) continue;
         register int off = p*levels*slen;
         GridDataBucket<DAGH_GFType> *gdbkt = 
           new GridDataBucket<DAGH_GFType>(sndcnt[p],(sndsize+off),DAGHPacked);
         register int s = 0;
         while (s<sndcnt[p]) {
           oldgdb[t][sndlevel[off+s]][sndindex[off+s]]->gdbWriteData(
                 DAGH_Main,DAGHNull,sndbbox[off+s],*gdbkt,s);
           (gdbkt->head(s))->index = rcvindex[off+s];

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::Sending"
                           << *gdbkt->head(s)
                           << endl ).flush();
#endif

           s++;
           if (has_shadow == DAGHTrue) {
             oldgdb[t][sndlevel[off+s]][sndindex[off+s]]->gdbWriteData(
                   DAGH_Shadow,DAGHNull,sndbbox[off+s],*gdbkt,s);
             (gdbkt->head(s))->index = rcvindex[off+s];

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::Sending"
                           << *gdbkt->head(s)
                           << endl ).flush();
#endif

             s++;
           }
         }
         gt->send((DAGHDataTag | t),gdbkt,p);
       }
     }

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "\n************* Send List *************\n"
                           << slist
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     // These will be reused !
     //if (sndsize) delete [] sndsize;
     //if (sndbbox) delete [] sndbbox;
     //if (sndindex) delete [] sndindex;
     //if (rcvindex) delete [] rcvindex;
     //if (sndlevel) delete [] sndlevel;
     //if (sndcnt) delete [] sndcnt;
     if (sb) delete [] sb;
     if (stoidx) delete [] stoidx;

} else {

     GridFunction(2)<DAGH_GFType>* gftemplate = 
                    (GridFunction(2)<DAGH_GFType>*) dagh.gflist[template_flag];

     slen = gftemplate->slen;
     sndsize = gftemplate->sndsize;
     sndbbox = gftemplate->sndbbox;
     sndindex = gftemplate->sndindex;
     rcvindex = gftemplate->rcvindex;
     sndlevel = gftemplate->sndlevel;
     sndcnt = gftemplate->sndcnt;

     register int sidx = 0;

     for (register int t=0;t<timesteps;t++) {
       if (!oldgdb[t]) continue;
       for (register int p=0;p<pnum;p++) {
         if (p == me) continue;
         if (sndcnt[p] == 0) continue;
         register int off = p*levels*slen;
         GridDataBucket<DAGH_GFType> *gdbkt = 
           new GridDataBucket<DAGH_GFType>(sndcnt[p],(sndsize+off),DAGHPacked);
         register int s = 0;
         while (s<sndcnt[p]) {
           oldgdb[t][sndlevel[off+s]][sndindex[off+s]]->gdbWriteData(
                 DAGH_Main,DAGHNull,sndbbox[off+s],*gdbkt,s);
           (gdbkt->head(s))->index = rcvindex[off+s];

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::Sending"
                           << *gdbkt->head(s)
                           << endl ).flush();
#endif

           s++;
           if (has_shadow == DAGHTrue) {
             oldgdb[t][sndlevel[off+s]][sndindex[off+s]]->gdbWriteData(
                   DAGH_Shadow,DAGHNull,sndbbox[off+s],*gdbkt,s);
             (gdbkt->head(s))->index = rcvindex[off+s];

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "GF_Recompose::Sending"
                           << *gdbkt->head(s)
                           << endl ).flush();
#endif

             s++;
           }
         }
         gt->send((DAGHDataTag | t),gdbkt,p);
       }
     }

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "\n************* Send List *************\n"
                           << slist
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     sndsize = 0;
     sndbbox = 0;
     sndindex = 0;
     rcvindex = 0;
     sndlevel = 0;
     sndcnt = 0;
}

   } }

   /* Allocate remaining GDB's */
   {
    GridFunction(2)<DAGH_GFType>* gftemplate = 0;
    if (template_flag != DAGHNull) {
      gftemplate = (GridFunction(2)<DAGH_GFType>*) dagh.gflist[template_flag];
    }
    const GridDataBlock(2)<DAGH_GFType>* gdbtmpl = 0;

    for (register int l=0;l<levels;l++) {
      const int lev = dagh.levelnum(l);
      const int cti = dagh_timeindex(dagh.getCurrentTime(l),l);
      const int ct = dagh.getCurrentTime(l);
      int tmplcti = DAGHNull;

      for ( register int idx = 0 ; idx < length ; idx++) {
        GridUnit* mytmpgu = merged_gul[idx]->first();
        if (!mytmpgu->guContains(lev)) continue;
        if (template_flag != DAGHNull &&
	    gftemplate && 
	    gftemplate->gdb[(tmplcti=gftemplate->dagh_timeindex(ct,l))] 
	    && gftemplate->gdb[tmplcti][l])
	  gdbtmpl = gftemplate->gdb[tmplcti][l][idx];
        else gdbtmpl = 0;
        for (register int t=0;t<timesteps;t++) {
          if (!gdb[t] || !gdb[t][l]) continue;

          if (!gdb[t][l][idx]) {
            gdb[t][l][idx] = new GridDataBlock(2)<DAGH_GFType>(gfid, dagh, *gt,
                                                               interactions,
                                                               *merged_gul[idx],
                                                               t, lev,
                                                               bwidth, extghostwidth,
							       overlap,
                                                               space_sten_rad,
                                                               alignment, mindex,
                                                               comm(t,l), has_shadow,
                                                               gdbtmpl);
            if (gdbtmpl == 0 || comm(t,l)) gdbtmpl = gdb[t][l][idx];
          }
        }
      }
    }
   }

   // Setup new serves
   if (comm()) {
     GF_GatherGhostCommInfo();
     GF_SetUpGhostCommServers();
   }

   /* All Data: interpolate and/or copy */
   {
    GridTableEntry *oldgte = 0;
    GridTableEntry *newgte = 0;

    register int idx = DAGHNull;
    register int oidx = DAGHNull;
    register int omidx = DAGHNull;
    register int oldowner = DAGHNoBody;

    const int olpmidx = mindex*omindex;
    short* copyflag = new short[olpmidx];

#ifdef DEBUG_PRINT_GF_RG
     ( comm_service::log() << "\n************* Overlap List *************\n"
                           << olist
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

    for (register int l=0;l<levels;l++) {
      const int lev = dagh.levelnum(l);

      const int cti = dagh_timeindex(dagh.getCurrentTime(l),l);
      const int pti = (timesteps==1) ? DAGHNull :
                      dagh_timeindex(dagh.getPreviousTime(l),l);
      const int nti = (timesteps==1) ? DAGHNull :
                      dagh_timeindex(dagh.getNextTime(l),l);

      for (register int t=0;t<timesteps;t++) {
        if (!gdb[t] || !gdb[t][l]) continue;

        for ( idx = 0 ; idx < length ; idx++) {
          if (!gdb[t][l][idx]) continue;

          /* Interpolate to initialize the data */
	  if (l > 0 && gdb[t][l-1] && gdb[t][l-1][idx]) { /* INTERPOLATE */
	    if (pfunc && prolong()) { /* Call the prolongation function */
              int myargc = 0; DAGH_GFType myargs[1];
              (*pfunc)(FORTRAN_ARGS(gdb[t][l-1][idx]->mstorage.data),
                        FORTRAN_ARGS(gdb[t][l][idx]->mstorage.data),
                        BOUNDING_BOX(gdb[t][l][idx]->mstorage.data),
			myargs,&myargc);

              if (has_shadow == DAGHTrue) {
                (*pfunc)(FORTRAN_ARGS(gdb[t][l-1][idx]->shstorage->data),
                         FORTRAN_ARGS(gdb[t][l][idx]->shstorage->data),
                         BOUNDING_BOX(gdb[t][l][idx]->shstorage->data),
                         myargs,&myargc);
              }

              /* Use my current value to time interpolate to the previous time */
	      if (t == cti && pti != DAGHNull && cti > pti && 
		  gdb[pti] && gdb[pti][l][idx]) {
                double const frac = 1.0/dagh.refinefactor();
                gdb[pti][l][idx]->mstorage.data.lin_interp(
                                  gdb[cti][l][idx]->mstorage.data,(1.0-frac),
		                  gdb[pti][l][idx]->mstorage.data,frac);

                if (has_shadow == DAGHTrue) {
                  double const shfrac = 1.0/dagh.refinefactor();
                  gdb[pti][l][idx]->shstorage->data.lin_interp(
                                    gdb[cti][l][idx]->shstorage->data,(1.0-shfrac),
                                    gdb[pti][l][idx]->shstorage->data,shfrac);
                }
              }

              /* Use my current value to time interpolate to the next time */
	      if (nti != DAGHNull && t == nti && nti > cti &&
		  gdb[cti] && gdb[cti][l][idx]) {
                double const frac = 1.0/dagh.refinefactor();
                gdb[nti][l][idx]->mstorage.data.lin_interp(
                                  gdb[cti][l][idx]->mstorage.data,(1.0-frac),
                                  gdb[nti][l][idx]->mstorage.data,frac);

                if (has_shadow == DAGHTrue) {
                  double const shfrac = 1.0/dagh.refinefactor();
                  gdb[nti][l][idx]->shstorage->data.lin_interp(
                                    gdb[cti][l][idx]->shstorage->data,(1.0-shfrac),
                                    gdb[nti][l][idx]->shstorage->data,shfrac);
                }
              }
  	    }
	    /*$else {$*/ /* Just inject for testing */
              /*$gdb[t][l][idx]->mstorage.data.copy(gdb[t][l-1][idx]->mstorage.data);
              if (has_shadow == DAGHTrue)
              gdb[t][l][idx]->shstorage->data.copy(gdb[t][l-1][idx]->shstorage->data);
  	    }$*/
	  }
          if (l > 0 && !(gdb[t][l-1] && gdb[t][l-1][idx])) {
            assert(0); /* ERROR */
	  }
	}

	/* Overlaps */
        for (oidx=0; oidx<olpmidx; oidx++) copyflag[oidx] = DAGHNull;

        for (register GridUnit* tmpgu=olist.first();
	     tmpgu;tmpgu=olist.next()) {
#ifdef DEBUG_PRINT_GF_RG
	  assert (tmpgu->guOwner() == me);
#endif
          if (tmpgu->guContains(lev)) { 
	    oidx = tmpgu->guIndex();
	    idx = (gt->find(tmpgu->guBaseIndex()))->myindex();
            omidx = oidx*mindex + idx;
            if (!gdb[t][l][idx] || copyflag[omidx] == DAGHTrue) continue;
	    gdb[t][l][idx]->mstorage.data.copy(
			    oldgdb[t][l][oidx]->mstorage.data);
	    if (has_shadow == DAGHTrue)
                    gdb[t][l][idx]->shstorage->data.copy(
                                    oldgdb[t][l][oidx]->shstorage->data);
            copyflag[omidx] = DAGHTrue;
	  }
	}

	/* Receives*/
	if (comm_service::dce() && pnum > 1) {
	  for (register int p=0; p<pnum; p++) {
	    if (data_recv_server[p] && data_recv_server[p][t]) {
	      if (!data_recv_server[p][t]->received())
		comm_service::serve(*data_recv_server[p][t]->req());
	      delete data_recv_server[p][t];
	      data_recv_server[p][t] = 0;
	    }
	  }
	  GF_ReadData(t,l);
	}

        if (comm()) {
          const int tnum = dagh_timevalue(t,l);
          GF_Sync(tnum,l,DAGH_Main);
          if (has_shadow == DAGHTrue) GF_Sync(tnum,l,DAGH_Shadow);
        }

#ifdef DEBUG_PRINT_GF_RG
	//assert(GF_maxval(dagh_timevalue(t,l),l,DAGH_Main) != 9999);
	//if (has_shadow == DAGHTrue)
	//  assert(GF_maxval(dagh_timevalue(t,l),l,DAGH_Shadow) != 9999);
#endif

      }
    }
    gt->flushdata();
    for (register int i=0;i<pnum;i++) {
     if (data_recv_server[i]) {
       delete [] data_recv_server[i];
       data_recv_server[i] = 0;
     }
    }
    if (copyflag) delete [] copyflag;
   }
   
   /* Delete Old Data */
   if (oldgdb) {
    for (register int t=0;t<timesteps;t++) {
     if (oldgdb[t])   {
       for (register int l=0;l<levels;l++) {
         if (oldgdb[t][l]) {
           for (register int i=0;i<oldlength;i++) 
             if (oldgdb[t][l][i]) delete oldgdb[t][l][i];

           delete [] oldgdb[t][l];
         }
       }
       delete [] oldgdb[t];
     } 
    } 
    delete [] oldgdb;
   }
   if (oldgt) delete oldgt;

   if (merged_gul) delete [] merged_gul;
  }

/*****************************************************************************/
/**** .Recompose  using a checkpoint file...****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_CheckpointRecompose()

  {
   const int me = comm_service::proc_me();
   const int pnum = comm_service::proc_num();

   GridTable* oldgt = gt; gt = 0;
   GridDataBlock(2)<DAGH_GFType> ****oldgdb = gdb; gdb = 0;
   const int oldlength = length; length = 0;
   
   const int timesteps = 2*time_sten_rad+1;

   const int mindex = dagh.maxindex()+1;
   GridUnitList *cgul = dagh.clist();

   gt = new GridTable(gfid,*cgul,mindex,timesteps);

#ifdef DEBUG_PRINT_GF_RG_GT
     ( comm_service::log() << "\n************* New Grid Table *************\n"
                           << *gt
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

   GridUnitList &llist = *dagh.llist();

   const List<MergedGridUnit*> &mgulist = dagh.mllist();
   length = mgulist.number();

   GridUnitList** merged_gul = new GridUnitList*[length];

   register int m = 0;
   MergedGridUnit** mgu = 0;
   BBoxList merged_bbl;
   DAGHListLoop(mgulist, mgu, MergedGridUnit*) {
     merged_gul[m] = &(*mgu)->gul; m++;
     merged_bbl.add((*mgu)->bb);
   } DAGHEndLoop

   const int levels = dagh.totallevels();
   const int crslev = dagh.coarselevel();
   const int has_shadow = shadow();
   //const int daghflag = (has_shadow) ? DAGH_BothGH : DAGH_Main;
   const int shadowfactor = dagh.daghshadowfactor();

   gdb = new GridDataBlock(2)<DAGH_GFType> ***[timesteps];
   for (register int t=0;t<timesteps;t++) {
     gdb[t] = (GridDataBlock(2)<DAGH_GFType> ***) NULL;
     if (oldgdb[t]) {
       gdb[t] = new GridDataBlock(2)<DAGH_GFType> **[levels];
       for (register int l=0;l<levels;l++) {
         gdb[t][l] = new GridDataBlock(2)<DAGH_GFType> *[length];
         for (register int i=0;i<length;i++)
           gdb[t][l][i] = (GridDataBlock(2)<DAGH_GFType> *) NULL;
       }
     }
   }

   /* destroy old storage for ghost comm */
   GF_DeleteGhostCommInfo();
   
   /* destroy old storage for data comm */
   GF_DeleteDataCommInfo();

   /* Delete Old Data */
   if (oldgdb) {
    for (register int t=0;t<timesteps;t++) {
     if (oldgdb[t])   {
       for (register int l=0;l<levels;l++) {
         if (oldgdb[t][l]) {
           for (register int i=0;i<oldlength;i++) 
             if (oldgdb[t][l][i]) delete oldgdb[t][l][i];

           delete [] oldgdb[t][l];
         }
       }
       delete [] oldgdb[t];
     } 
    } 
    delete [] oldgdb;
   }
   if (oldgt) delete oldgt;


   /* Allocate GDB's */
   {
    GridFunction(2)<DAGH_GFType>* gftemplate = 0;
    if (template_flag != DAGHNull) {
      gftemplate = (GridFunction(2)<DAGH_GFType>*) dagh.gflist[template_flag];
    }
    const GridDataBlock(2)<DAGH_GFType>* gdbtmpl = 0;

    for (register int l=0;l<levels;l++) {
      const int lev = dagh.levelnum(l);
      const int cti = dagh_timeindex(dagh.getCurrentTime(l),l);
      const int ct = dagh.getCurrentTime(l);
      int tmplcti = DAGHNull;

      for (register int idx = 0 ; idx < length ; idx++) {
        GridUnit* mytmpgu = merged_gul[idx]->first();
        if (!mytmpgu->guContains(lev)) continue;
        if (template_flag != DAGHNull &&
	    gftemplate && 
	    gftemplate->gdb[(tmplcti=gftemplate->dagh_timeindex(ct,l))] 
	    && gftemplate->gdb[tmplcti][l])
	  gdbtmpl = gftemplate->gdb[tmplcti][l][idx];
        else gdbtmpl = 0;
        for (register int t=0;t<timesteps;t++) {
          if (!gdb[t] || !gdb[t][l]) continue;

          if (!gdb[t][l][idx]) {
            gdb[t][l][idx] = new GridDataBlock(2)<DAGH_GFType>(gfid, dagh, *gt,
                                                               interactions,
                                                               *merged_gul[idx],
                                                               t, lev,
                                                               bwidth, extghostwidth,
							       overlap,
                                                               space_sten_rad,
                                                               alignment, mindex,
                                                               comm(t,l), has_shadow,
                                                               gdbtmpl);
            if (gdbtmpl == 0 || comm(t,l)) gdbtmpl = gdb[t][l][idx];
          }
        }
      }
    }
   }

   /* Setup new serves */
   if (comm()) {
     GF_GatherGhostCommInfo();
     GF_SetUpGhostCommServers();
   }

   /* Read data from checkpoint file */
   if (checkpoint()) GF_CheckpointRestart();
   
   if (merged_gul) delete [] merged_gul;
  }


/*****************************************************************************/
/* Set Up Ghost Comm Servers */
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_SetUpGhostCommServers()
  {
   if (!comm()) return;

   const int pnum = comm_service::proc_num();
   const int me = comm_service::proc_me();

   const int levels = dagh.totallevels();
   const int cnt = levels * DAGHMaxAxis * DAGHMaxDirs ;

   for (register int i=0;i<pnum;i++) {
     if (i == me || !ghost_recv_info[i]) continue;
     if (!ghost_recv_server[i]) {
       ghost_recv_server[i] = new GridTableGhostRcv *[cnt];
       for (register int c=0; c<cnt; c++) ghost_recv_server[i][c] = 0;
     }
     for (register int j=0;j<cnt;j++) {
       if (!ghost_recv_info[i][j]) continue;
       const GF_Interaction* gri = ghost_recv_info[i][j];
       ghost_recv_server[i][j] =
          new GridTableGhostRcv(*gt, (DAGHGhostTag | j), gri->tsize, i);
     }
   }
  }

/*****************************************************************************/
/**** Gather Ghost Communication Info ****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_GatherGhostCommInfo()
  {
    if (!comm()) return;

    register int t = 0;
    for (t=0;t<=2*time_sten_rad;t++) if (gdb[t]) break;

    const int pnum = comm_service::proc_num();
    const int levels = dagh.totallevels();
    const int cnt1 = levels * DAGHMaxAxis * DAGHMaxDirs ;
    const int cnt2 = DAGHMaxAxis * DAGHMaxDirs ;
    const int mindex = dagh.maxindex()+1;

    List<unsigned> rsize;
    List<unsigned> wsize;
    unsigned r=0, w=0;

    GridDataBlock(2)<DAGH_GFType> *g = 0;
    GDB_Interaction *gdbi = 0;

    for (register int p=0;p<pnum;p++) {
      for (register int l=0;l<levels;l++) {
        for (register int c=0;c<cnt2;c++) {
          const int idx1 = l*cnt2 + c;
          const int idx2 = c*mindex;
          for (register int i=0; i<length; i++) {
            if (gdb[t] && gdb[t][l] && gdb[t][l][i]) {
              g = gdb[t][l][i];
              for (register int m=0; m<mindex; m++) {
                /* Write Info */
                if (g->gdb_write_info[p] && (gdbi=g->gdb_write_info[p][idx2+m])) {
                  /* Allocate storage */
                  if (!ghost_send_info[p]) {
                    ghost_send_info[p] = new GF_Interaction* [cnt1];
                    for (register int k=0;k<cnt1;k++) ghost_send_info[p][k] = 0;
                  }
                  if (!ghost_send_info[p][idx1]) 
                    ghost_send_info[p][idx1] = new GF_Interaction;

                  w = sizeof(DAGH_GFType)*max(gdbi->mbbox.size(),gdbi->shbbox.size());
                  ghost_send_info[p][idx1]->tsize += gdhdr::gdbsize(w);
#ifdef DEBUG_PRINT
                  assert( w != 0 );
#endif
                  wsize.add(w);
                }
                /* Read Info */
                if (g->gdb_read_info[p] && (gdbi=g->gdb_read_info[p][idx2+m])) {
                  /* Allocate storage */
                  if (!ghost_recv_info[p]) {
                    ghost_recv_info[p] = new GF_Interaction* [cnt1];
                    for (register int k=0;k<cnt1;k++) ghost_recv_info[p][k] = 0;
                  }
                  if (!ghost_recv_info[p][idx1]) 
                    ghost_recv_info[p][idx1] = new GF_Interaction;
  
                  r = sizeof(DAGH_GFType)*max(gdbi->mbbox.size(),gdbi->shbbox.size());
                  ghost_recv_info[p][idx1]->tsize += gdhdr::gdbsize(r);
#ifdef DEBUG_PRINT
                  assert( r != 0 );
#endif
                  rsize.add(r); 
                }
              }
            }
          }
          if (ghost_send_info[p] && ghost_send_info[p][idx1])
            wsize.array(ghost_send_info[p][idx1]->size,ghost_send_info[p][idx1]->cnt);
          if (ghost_recv_info[p] && ghost_recv_info[p][idx1])
            rsize.array(ghost_recv_info[p][idx1]->size,ghost_recv_info[p][idx1]->cnt);
          wsize.empty(); rsize.empty();
        }
      }
#ifdef DEBUG_PRINT_GF_COMM
     ( comm_service::log() << "[GF_Interaction:[" << p << "]" << endl ).flush();
     for (register int k=0;k<cnt1;k++) {
       if (ghost_recv_info[p] && ghost_recv_info[p][k])
     ( comm_service::log() << "\t [Rcv[" << k << "]" 
                           << *ghost_recv_info[p][k] << "]"
                           << endl ).flush();
     }
     ( comm_service::log() << endl ).flush();
     for (k=0;k<cnt1;k++) {
       if (ghost_send_info[p] && ghost_send_info[p][k])
     ( comm_service::log() << "\t [Snd[" << k << "]" 
                           << *ghost_send_info[p][k] << "]"
                           << endl ).flush();
     }
     ( comm_service::log() << "]" << endl ).flush();
#endif
    }
  }

/*****************************************************************************/
/**** Swap storage for time levels  ****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_SwapTimeLevels(const int l, 
                                                     const int t1, const int t2) 
  {
    const int ti1 = dagh_timeindex(t1,l); 
    const int ti2 = dagh_timeindex(t2,l); 

    if (ti1 == ti2) return;

    assert(gdb[ti1] && gdb[ti2]);

    GridDataBlock(2)<DAGH_GFType>** gdb1 = gdb[ti1][l];
    GridDataBlock(2)<DAGH_GFType>** gdb2 = gdb[ti2][l];

    if (gdb1) {
      for (register int i=0;i<length;i++)
        if (gdb1[i]) gdb1[i]->timenum = ti2;
    }
    if (gdb2) {
      for (register int i=0;i<length;i++)
        if (gdb2[i]) gdb2[i]->timenum = ti1;
    }
    gdb[ti1][l] = gdb2;
    gdb[ti2][l] = gdb1;
  }

/* Move next -> current && current -> previous && previous -> next */
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_CycleTimeLevels(const int l)
  {
    if (time_sten_rad == 0)  return;

    const int cti = dagh_timeindex(dagh.getCurrentTime(l),l);
    const int pti = dagh_timeindex(dagh.getPreviousTime(l),l);
    const int nti = dagh_timeindex(dagh.getNextTime(l),l);

    assert(gdb[cti] && gdb[pti] && gdb[nti]);

    GridDataBlock(2)<DAGH_GFType>** cgdb = gdb[cti][l];
    GridDataBlock(2)<DAGH_GFType>** pgdb = gdb[pti][l];
    GridDataBlock(2)<DAGH_GFType>** ngdb = gdb[nti][l];

    if (cgdb && (cti != pti)) {
      for (register int i=0;i<length;i++)
        if (cgdb[i]) cgdb[i]->timenum = pti;
    }
    if (pgdb && (pti != nti)) {
      for (register int i=0;i<length;i++)
        if (pgdb[i]) pgdb[i]->timenum = nti;
    }
    if (ngdb && (nti != cti)) {
      for (register int i=0;i<length;i++)
        if (ngdb[i]) ngdb[i]->timenum = cti;
    }
    if (cti != nti) gdb[cti][l] = ngdb;
    if (pti != cti) gdb[pti][l] = cgdb;
    if (nti != pti) gdb[nti][l] = pgdb;
  }

/*****************************************************************************/
/**** BBox Queries ****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::intbboxlist(BBoxList &bbl, const int l, 
                                               const int ident)
  {
   if (!bbl.isempty()) bbl.empty();
   int t = 0;
   for (t=0;t<=2*time_sten_rad;t++) if (gdb[t]) break;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) bbl.add(gdb[t][l][i]->interiorbox(ident));
  }

template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::intbboxlist(BBoxList &bbl, const int l, 
                                               const int mgl,
                                               const int ident)
  { 
   if (!bbl.isempty()) bbl.empty();
   int t = 0;
   for (t=0;t<=2*time_sten_rad;t++) if (gdb[t]) break;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) bbl.add(gdb[t][l][i]->interiorbox(ident,mgl));
  }

template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::databboxlist(BBoxList &bbl, const int l, 
                                                const int ident)
  {
   if (!bbl.isempty()) bbl.empty();
   int t = 0;
   for (t=0;t<=2*time_sten_rad;t++) if (gdb[t]) break;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) bbl.add(gdb[t][l][i]->boundingbox(ident));
  }

template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::databboxlist(BBoxList &bbl, const int l, 
                                                const int mgl,
                                                const int ident)
  { 
   if (!bbl.isempty()) bbl.empty();
   int t = 0;
   for (t=0;t<=2*time_sten_rad;t++) if (gdb[t]) break;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) bbl.add(gdb[t][l][i]->boundingbox(ident,mgl));
  }

template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::mergedbboxlist(BBoxList &bbl, const int l, 
                                                 const int ident)
  { 
   if (!bbl.isempty()) bbl.empty();
   int t = 0;
   for (t=0;t<=2*time_sten_rad;t++) if (gdb[t]) break;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) bbl.add(gdb[t][l][i]->mergedbox(ident));
  }

/*****************************************************************************/
/**** Shadow Hierarchy Methods ****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_SetupShadow(const int time, const int level)
  {
   register const int t = dagh_timeindex(time,level);
   register const int l = level;
   
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) 
       gdb[t][l][i]->gdbSetUpShadow(overlap,bwidth,extghostwidth);

   shadow_flag = DAGHHasShadow;
  }

template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_ReleaseShadow(const int time, const int level)
  {
   register const int t = dagh_timeindex(time,level);
   register const int l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) gdb[t][l][i]->gdbReleaseShadow();

   shadow_flag = DAGHNoShadow;
  }
/*********************************************************************/

/*****************************************************************************/
/**** Multigrid Methods ****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_SetupMultiGrid(const int time, 
                                                     const int level, 
				                     const int mglc, 
                                                     const int mglf,
				                     const int ident)
  {
   register const int t = dagh_timeindex(time,level);
   register const int l = level;

   if (ident == DAGH_Main) {
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
       gdb[t][l][i]->gdbSetUpMultiGrid(mglc,mglf,
                                       overlap,bwidth,extghostwidth);
   }
   else if (shadow()) {
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
       gdb[t][l][i]->gdbSetUpShadowMultiGrid(mglc,mglf,
                                       overlap,bwidth,extghostwidth);
   }
  }

template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_SetupMultiGrid(const int time, 
                                                     const int level, 
				                     const int axis, 
                                                     const int mglc, 
                                                     const int mglf,
				                     const int ident)
  {
   register const int t = dagh_timeindex(time,level);
   register const int l = level;
   
   if (ident == DAGH_Main) {
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
       gdb[t][l][i]->gdbSetUpMultiGrid(axis,mglc,mglf,
                                       overlap,bwidth,extghostwidth);
   }
   else if (shadow()) {
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
       gdb[t][l][i]->gdbSetUpShadowMultiGrid(axis,mglc,mglf,
                                       overlap,bwidth,extghostwidth);
   }
  }

template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_ReleaseMultiGrid(const int time, 
                                                       const int level,
				                       const int ident)
  {
   register const int t = dagh_timeindex(time,level);
   register const int l = level;

   if (ident == DAGH_Main) {
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
       gdb[t][l][i]->gdbReleaseMultiGrid();
   }
   else if (shadow()) {
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
       gdb[t][l][i]->gdbReleaseShadowMultiGrid();
   }
  }
/*********************************************************************/

/*****************************************************************************/
/**** Checkpoint/Restart ****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_Checkpoint(ofstream& ofs)
  {
   assert (dagh.chkpt_restart() && checkpoint());

   const short levels = dagh.totallevels();
   const short timesteps = 2*time_sten_rad + 1;
   const int dirnum = levels*length*timesteps;
   ofs.write((char*)&levels,sizeof(short));
   ofs.write((char*)&length,sizeof(short));
   ofs.write((char*)&timesteps,sizeof(short));

   streampos* chkptdir = new streampos[dirnum];
   streampos chkptdirpos = ofs.tellp();
   ofs.write((char*)chkptdir,sizeof(streampos)*dirnum);

   ofs << *((GridFunctionVoid*)this);

   for (register int c=0; c<length; c++) {
     for (register int l=0; l<levels; l++) {
       for (register int t=0; t<timesteps; t++) {
         if (gdb[t] && gdb[t][l] && gdb[t][l][c]) {
           chkptdir[c*levels*timesteps+l*timesteps+t] = ofs.tellp();
           ofs << *gdb[t][l][c];
	 }
         else {
           chkptdir[c*levels*timesteps+l*timesteps+t] = DAGHNull;
         }
       }
     }
   }
   streampos curpos = ofs.tellp();
   ofs.seekp(chkptdirpos);
   ofs.write((char*)chkptdir,sizeof(streampos)*dirnum);
   ofs.seekp(curpos);
   if (chkptdir) delete [] chkptdir;
  }

template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_CheckpointRestart()
  {
   assert (dagh.chkpt_restart() && checkpoint());

   const int num = comm_service::proc_num();
   const int me = comm_service::proc_me();
   const int oldpnum = dagh.chkpt_pnum();
   const int levels = dagh.totallevels();
   const int timesteps = 2*time_sten_rad + 1;

   if (oldpnum == num) { /* Old dist == new dist */
     register streampos pos;
     
     ifstream ifs;
     int eflag = dagh.DAGH_GetGFChkptIStream(me,gfname,gfid,ifs);
     if (eflag == DAGHFalse) return;

     short hislevels = 0, hislength = 0, histsteps = 0;
     ifs.read((char*)&hislevels,sizeof(short));
     ifs.read((char*)&hislength,sizeof(short));
     ifs.read((char*)&histsteps,sizeof(short));

     assert (hislevels == levels);
     assert (hislength == length);

     const int dirnum = hislevels*hislength*histsteps;
     streampos* chkptdir = new streampos[dirnum];
     ifs.read((char*)chkptdir,sizeof(streampos)*dirnum);    
     for (register int c=0; c<length; c++) {
       for (register int l=0; l<levels; l++) {
         for (register int t=0; t<timesteps; t++) {
           if (gdb[t] && gdb[t][l] && gdb[t][l][c] && t < histsteps &&
	       (pos=chkptdir[c*hislevels*histsteps+l*histsteps+t])!=DAGHNull) {
             ifs.seekg(pos);
             ifs >> *gdb[t][l][c];
	   }
         } 
       }
     }
     if (chkptdir) delete [] chkptdir;
     dagh.DAGH_CloseChkptIStream(ifs);
   }
   else { /* A new dist. */
     GridUnitList* llist = dagh.llist();
     GridUnitList* oldclist = dagh.oldclist();
     const int oldmindex = oldclist->maxindex() + 1;

     const int readdirnum = oldpnum*oldmindex;

     short* readfrom = new short[oldpnum]; 
     for (register int pp=0;pp<oldpnum;pp++) readfrom[pp] = DAGHNull;

     short* readdir = new short[readdirnum];
     short* readtoindex = new short[readdirnum];
     for (register int i=0; i<readdirnum;i++) 
       { readdir[i] = DAGHNull; readtoindex[i] = DAGHNull; }
   
     GridUnitList mylist(*oldclist);
     mylist *= *llist;

     for (GridUnit* gu=mylist.first();gu;gu=mylist.next()) {
       readdir[gu->guOwner()*oldmindex + gu->guIndex()] = DAGHTrue;
       readtoindex[gu->guOwner()*oldmindex + gu->guIndex()] =
	 (gt->find(gu->guBaseIndex()))->myindex();
       readfrom[gu->guOwner()] = DAGHTrue;
     }
   
     register int idx = DAGHNull;
     register streampos pos;
     for (register int p=0; p<oldpnum; p++) if (readfrom[p] == DAGHTrue) {
       ifstream ifs;
       int eflag = dagh.DAGH_GetGFChkptIStream(p,gfname,gfid,ifs);
       if (eflag == DAGHFalse) return;

       short hislevels = 0, hislength = 0, histsteps = 0;
       ifs.read((char*)&hislevels,sizeof(short));
       ifs.read((char*)&hislength,sizeof(short));
       ifs.read((char*)&histsteps,sizeof(short));
       
       assert (hislevels == levels);
       assert (hislength <= oldmindex);
       
       const int dirnum = hislevels*hislength*histsteps;
       streampos* chkptdir = new streampos[dirnum];
       ifs.read((char*)chkptdir,sizeof(streampos)*dirnum);    
       for (register int c=0; c<oldmindex; c++) {
	 for (register int l=0; l<levels; l++) {
	   if (readdir[p*oldmindex+c] == DAGHNull) continue;
	   idx = readtoindex[p*oldmindex+c];
	   for (register int t=0; t<timesteps; t++) {
	     if (gdb[t] && gdb[t][l] && gdb[t][l][idx] && t < histsteps &&
		 (pos=chkptdir[c*hislevels*histsteps+l*histsteps+t])!=DAGHNull) {
	       ifs.seekg(pos);
	       ifs >> *gdb[t][l][idx];
	     }
	   } 
	 }
       }
       if (chkptdir) delete [] chkptdir;
       dagh.DAGH_CloseChkptIStream(ifs);
     }
     if (readfrom) delete [] readfrom;
     if (readdir) delete [] readdir;
     if (readtoindex) delete [] readtoindex;
   }

   /* Sync... */
   if (comm()) {
     for (register int l=0; l<levels; l++) {
       for (register int t=0; t<timesteps; t++) {
	 if (gdb[t] && gdb[t][l]) {
	   const int tnum = dagh_timevalue(t,l);
	   GF_Sync(tnum,l,DAGH_Main);
	   if (shadow() == DAGHTrue) GF_Sync(tnum,l,DAGH_Shadow);
         }
       } 
     }
   }
  }

/*****************************************************************************/
/**** Some debugging ****/
/*****************************************************************************/
template <class DAGH_GFType>
ostream &GridFunction(2)<DAGH_GFType>::GF_DebugPrintIntData(ostream &os,
                                                            const int time, 
                                                            const int level,
                                                            const int ident)
  {
   os << *this;
   os << "(" << time << ") ";
   os << "(" << level << ") ";
   os << "\n";
   register const int t = dagh_timeindex(time,level);
   register const int l = level;
   for (register int i=0; i<length; i++) { 
     if (gdb[t][l][i]) {
        os << "Interior: " << gdb[t][l][i]->boundingbox(ident) << "\n";
        GridData(2)<DAGH_GFType> tmpgd(gdb[t][l][i]->boundingbox(ident));
        tmpgd = gdb[t][l][i]->griddata(ident);
	os << tmpgd;
        os << "\n";
     }
   }
   return os;
  }

template <class DAGH_GFType>
ostream &GridFunction(2)<DAGH_GFType>::GF_DebugPrintData(ostream &os, 
                                                         const int time, 
                                                         const int level,
                                                         const int ident)
  {
   os << *this;
   os << "(" << time << ") ";
   os << "(" << level << ") ";
   os << "\n";
   register const int t = dagh_timeindex(time,level);
   register const int l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) os << gdb[t][l][i]->griddata(ident);
   return os;
  }

template <class DAGH_GFType>
ostream &GridFunction(2)<DAGH_GFType>::GF_DebugPrintDataBlk(ostream &os,
                                                            const int time, 
                                                            const int level)
  {
   os << *this;
   os << "(" << time << ") ";
   os << "(" << level << ") ";
   os << "\n";
   register const int t = dagh_timeindex(time,level);
   register const int l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) os << *gdb[t][l][i] << "\n";
   return os;
  }

/*****************************************************************************/
/**** Overloaded stdout ****/
/*****************************************************************************/

template <class DAGH_GFType>
ostream&  operator << (ostream& os, const GridFunction(2)<DAGH_GFType>& gf)
  {

   if (&gf == (GridFunction(2)<DAGH_GFType> *) NULL) return os;

   os << "GridFunction: " << gf.gfname << "(" << gf.curtime[0] << ") ";

   return os;
  }

  #include "GridFunctionComm2.h"
  #include "GridFunctionFuncs2.h"
  #include "GridFunctionOps2.h"
  #include "GridFunctionOpsDist2.h"
  #include "GridFunctionOpsRed2.h"
  #include "GridFunctionBndry2.h"
  #include "GridFunctionIO2.h"
  #include "GridFunctionUCD2.h"
  #include "GridFunctionViz2.h"

#endif
