#ifndef _included_GridUnitList_h
#define _included_GridUnitList_h

/*
*************************************************************************
*                                                                       *
* class GridUnitList							*
*                                                                       *
* Class GridUnitList implements a linked list of GridUnits and provides	*
* the routines to manipulate this list.					*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/*
*************************************************************************
*                                                                       *
* GridUnitList.h                                                        *
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"

#include "BBoxList.h"
#include "GridUnit.h"
#include "BucketType.h"
#include "ObjectCounter.h"

#ifndef DefGridUnitListSize
#define DefGridUnitListSize (256)
#endif

#ifndef DefMinimumGUExtent
#define DefMinimumGUExtent  (0)
#endif

#define GridUnitListNULL ((GridUnitList *) NULL)

#ifdef __GNUG__
template class Bucket<GridUnit>;
#endif

class GridUnitList : public Bucket<GridUnit>, public ObjectCounter
  {
   friend ostream& operator<<(ostream&, const GridUnitList&);
   friend ofstream& operator<<(ofstream&, const GridUnitList&);
   friend ifstream& operator>>(ifstream&, GridUnitList&);

   int tag; 
   int num;

private:
   static inline void copytypedata(GridUnit *to, GridUnit const *from)
	{ *to = *from; }

   /*************************************************************************/
   /*** Set list statistics ***/
   /*************************************************************************/
   inline void setstats(void)
     {
      num = 0;
      for ( GridUnit *g = first(); g != GridUnitNULL;  g = next() ) num++;
     }

public:
   /*************************************************************************/
   /*** Constructors ***/
   /*************************************************************************/
   GridUnitList()
     : Bucket<GridUnit>(DefGridUnitListSize), tag(0), num(0) {}

   GridUnitList(short const tg, 
		unsigned short const maxnum)
     : Bucket<GridUnit>(maxnum), tag(tg), num(0) {}

   /*$GridUnitList(short const tg, 
		unsigned short const maxnum=DefGridUnitListSize)
     : Bucket<GridUnit>(maxnum), tag(tg), num(0) {}$*/

   GridUnitList(void const *package, short const tg)
     : Bucket<GridUnit>(package), tag(tg), num(0) { setstats(); }

   GridUnitList(void *package, short const tg)
     : Bucket<GridUnit>(package), tag(tg), num(0) { setstats(); }

   GridUnitList(void const *package, unsigned const size, 
		const int n, short const tg)
     : Bucket<GridUnit>(package, size, n), tag(tg), num(0) { setstats(); }

   GridUnitList(const GridUnitList& other)
     : Bucket<GridUnit>(other), tag(other.tag), num(other.num) {}

   GridUnitList(GridUnitList**& levarray);

   /*************************************************************************/
   /*** Assignment operator ***/
   /*************************************************************************/
   GridUnitList& operator = (const GridUnitList&);

   /*************************************************************************/
   /*** The destructor ***/
   /*************************************************************************/
   inline ~GridUnitList(void) {}

   /*************************************************************************/
   /*** For the object counter ***/
   /*************************************************************************/
   inline GridUnitList *alias()
	{ return((GridUnitList *) ObjectCounter::alias()); }

   /*************************************************************************/
   /*** GUL operators ***/
   /*************************************************************************/
   void operator -= (GridUnitList const &rhs); /* Difference */
   void operator *= (GridUnitList const &rhs); /* Intersaction */
   GridUnitList *operator - (GridUnitList const &rhs); /* Abs Difference */
   GridUnitList *operator * (GridUnitList const &rhs); /* Intersection */
   GridUnitList *operator + (GridUnitList const &rhs); /* Union */

   /*************************************************************************/
   /*** GUL operations with a BBox & BBoxList ***/
   /*************************************************************************/
public: 
   void operator *= (BBox const &rhs); /* Intersection */
private: 
   GridUnitList *operator * (BBox const &rhs); /* Intersection */
   GridUnitList *operator * (BBoxList const &rhs); /* Intersection */
 
   /*************************************************************************/
   /*** GUL intersection with a BBox & BBoxList ***/
   /*************************************************************************/
public:
   void intersect(BBox const &rhs, const int lev, GridUnitList &gul, 
                  const int olap, const int extgh=0);
   void intersect(BBoxList const &rhs, const int lev, GridUnitList &gul, 
                  const int olap, const int extgh=0);
   void intersect(BBox const &rhs, const int lev, GridUnitList &gul, 
                  const short* olap, const int extgh=0);
   void intersect(BBoxList const &rhs, const int lev, GridUnitList &gul,
                  const short* olap, const int extgh=0);

   /*************************************************************************/
   /*** Query functions ***/
   /*************************************************************************/
public:
   inline short const mytag() const { return(tag); }
   inline const int isempty() const { return(num == 0); }
   inline int number() const { return(num); }

   unsigned long load(const int olap);
   unsigned long load(const int lev, const int olap);
   unsigned long numelems(const int olap);
   unsigned long numelems(const int lev, const int olap);
  
   unsigned long load(const short* olap);
   unsigned long load(const int lev, const short* olap);
   unsigned long numelems(const short* olap);
   unsigned long numelems(const int lev, const short* olap);

   int levels(void);
   int finest(void);
   int smallest(const int level);
   int smallest_merged(const int level);
   dMapIndex lowest();
   dMapIndex lowest(const int level, const int owner, const int index);
   int maxindex(void);

   /*************************************************************************/
   /*** Set list stats ***/
   /*************************************************************************/
public:
   inline void settag(short const int tg) { tag = tg; }
   void setindex(void);
   void setindex(const int idx);
   void setindex(const GridUnitList& cgul, const int idx);
   void setowner(const int p);
   void setowner(const GridUnitList& cgul, const int p);
   void setlowindex(const dMapIndex& li);
   void setlowindex(const GridUnitList& cgul, const dMapIndex& li);
   void setbbox();
   void setmergedbbox(const BBox& mbb);
   void setmergedbbox(const GridUnitList& cgul, const BBox& mbb);
   /*************************************************************************/
   /*** Empty the list ***/
   /*************************************************************************/
   void empty(void);

   /*************************************************************************/
   /*** Inlined list manupilation functions ***/
   /*************************************************************************/
   inline GridUnit *add(GridUnit const &gu) 
     { 
      num++; 
      return (Bucket<GridUnit>::add(gu)); 
     }
   inline GridUnit *insert(GridUnit const &gu)
     { 
      num++;
      return (Bucket<GridUnit>::insert(gu)); 
     }
   inline void remove(void)
      {
        GridUnit *gu = current();
        if (gu)
         { num--; Bucket<GridUnit>::remove(); }
      }

   /*************************************************************************/
   /*** Partition list across processors ***/ 
   /*************************************************************************/
   void partition(GridUnitList *& locallist, 
		  dMapIndex **& partitions, 
		  const int np, const int me, 
		  const int minw, const short* olap);

   /*************************************************************************/
   /*** Split the lsit at the current GridUnit ***/
   /*************************************************************************/
   void split(GridUnitList &gul);

   /*************************************************************************/
   /*** Array of GridUnitList's for the levels ***/
   /*************************************************************************/
   void levelarray(GridUnitList **& levarray, const int levels);

   /*************************************************************************/
   /*** GridUnitList for a particular level ***/
   /*************************************************************************/
   void levellist(GridUnitList &gul, 
		  const int lev);
   void levellist(GridUnitList &gul, 
		  const int minlev, 
		  const int maxlev);

   /*************************************************************************/
   /*** BBoxList for a particular level ***/
   /*************************************************************************/
public:
   void bboxlist(BBoxList &bbl, const int lev, const int olap);
                 //, const int extgh=0);
   void bboxlist(BBoxList &bbl, const int lev, const int olap, 
                 const int levid); //, const int extgh=0);
   void bboxlist(BBoxList &bbl, const int lev, const short* olap,
                 const int extgh);
   void bboxlist(BBoxList &bbl, const int lev, const short* olap, 
                 const int levid, const int extgh);
   /*************************************************************************/
   /** Refine everywhere ***/
   /*************************************************************************/
   GridUnitList *refinelist(const int atlev, const int levs=1);

   /*************************************************************************/
   /*** Refine as per bounding box list ***/
   /*************************************************************************/
   GridUnitList *refinelist(BBoxList const &bblist, const int atlev, 
                            const int minw);

   /*************************************************************************/
   /*** Operations on the current GridUnit ***/
   /*************************************************************************/
private:
   inline void refine(const int lev = 1)
	{ (current())->guRefine(lev); }
   inline void coarsen(const int lev = 1)
	{ (current())->guCoarsen(lev); }

public:
   void decompose(const int lev = 1);

   /*************************************************************************/
   /*** Functions I'd like to have.... ***/
   /*************************************************************************/
   //void merge(GridUnitList const *levellist, const int level);
   //void coalesce(GridUnitList**& gularray, BBoxList const &bblist, int &cnt, const int lev);
  };

#ifdef __ENABLE_INLINE__
#include "GridUnitList.inline"
#endif

ostream&  operator << (ostream& os, const GridUnitList& gul);
ofstream& operator << (ofstream& ofs, const GridUnitList& gul);
ifstream& operator >> (ifstream& ifs, GridUnitList& gul);

#endif
