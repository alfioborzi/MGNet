#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "hdf.h"
#ifdef HDF4
#include "mfhdf.h"
#else
#include "netcdf.h"
#endif

typedef struct chunk {
  char componentname[128];
  int pid;
  int level;
  int component;
  int timestep;
  int ndims;
  int dims[3];
  int lb[3];
  int ub[3];
  long totalbytes;
} chunk;

typedef struct fileID {
  char componentname[128];
  char filename[256];
  int32 id;
  struct fileID *next;
}fileID;  

static fileID *files=NULL;
static int dataport=-1,cmdport=-1;

fileID *NewFileID(char *name) {
  fileID *id=(fileID *)calloc(sizeof(fileID),1);
  strcpy(id->componentname,name);
  strcpy(id->filename,name);
  strcat(id->filename,".hdf");

  /*$printf ("  .. creating 3D output file %s\n",id->filename);$*/
  /* open SDS */
  id->id=SDstart(id->filename,DFACC_CREATE);
	
  id->next=files;
  files=id;
  return id;
}

fileID *findIDbyComponent(char *name) {
  fileID *id;
  for(id=files;id!=NULL;id=id->next)
    if(!strcmp(name,id->componentname))
      break;
  return id;
}

fileID *findIDbyFilename(char *name) {
  fileID *id;
  for(id=files;id!=NULL;id=id->next)
    if(!strcmp(name,id->filename))
      break;
  return id;
}


void FinalizeIO()
{
  
  while(files){
    /*printf ("  .. finalizing IO on %s\n", files->componentname);*/
    SDend(files->id);
    files=files->next;
  }
}

void FlushIO(char *componentname) 
{
  fileID *id;

  for(id=files;id!=NULL;id=id->next)
    if(!strcmp(componentname,id->componentname)) {
      SDend(id->id);
      id->id = SDstart(id->filename,DFACC_RDWR);
    }
}

void WriteChunk (char *componentname,
		 int pid,
		 int level,
		 int component,
		 int timestep,
		 int ndims,
		 int dims[3],
		 int lb[3],
		 int ub[3],
		 long totalbytes,
		 double *data)
{
  /* find FileID */
  char label[128],units[128];
  int32 stride[3]={1,1,1};
  int32 origin[3]={0,0,0};
  int32 sds_id, id;
  int tmp;

  fileID *file=findIDbyComponent(componentname);
  if(!file) { /* create one */
    file=NewFileID(componentname);
  }
  sds_id=SDcreate(file->id,componentname,DFNT_FLOAT64,ndims,dims);
  sprintf(label,"Proc %u: Level=%u Component=%u Timestep=%u\0",
	  pid,level,component,timestep);
  sprintf(units,"lb[%u][%u][%u]  ub[%u][%u][%u]\0",
	  lb[0],lb[1],lb[2],
	  ub[0],ub[1],ub[2]);
  /*$fprintf(stderr,"Writing component %s\n\t%s\n\t%s\n",
	  componentname,label,units);$*/
  SDsetdatastrs(sds_id,label,units,NULL,NULL);
  if (SDwritedata(sds_id,origin,stride,dims,(VOIDP)data)) {
    printf ("Error in SDwritedata for %s\n",componentname);
  }
  if (SDendaccess(sds_id)) {
    printf ("Error in SDendaccess for %s\n", componentname);
  }
}



