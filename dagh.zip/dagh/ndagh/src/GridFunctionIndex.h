#ifndef _included_GridFunctionIndex_h
#define _included_GridFunctionIndex_h

/*
*************************************************************************
*									*
* GridFunctionIndex3.h							*
*									*
*************************************************************************
*/

#include <generic.h>

#ifndef forall
#define forall(gf, t, l, c) {                                           \
   const int name2(gf,_T) = (gf).dagh_timeindex(t,l);			\
   const int name2(gf,_CU) = (gf).len();				\
   for (int c = 0; c < name2(gf,_CU); c++) {				\
     if(!(gf).exists(t,l,c)) ; else {
#endif

#ifndef end_forall_sync
#define end_forall_sync } } comm_service::barrier(); }
#endif

#ifndef end_forall
#define end_forall } } }
#endif

#ifndef forallBB
#define forallBB(gf, t, l, c, where, bb, ident) {                       \
   const int name2(gf,_T) = (gf).dagh_timeindex(t,l);			\
   const int name2(gf,_CU) = (gf).len();				\
   for (int c = 0; c < name2(gf,_CU); c++) {				\
     if(!(gf).exists(t,l,c) ||                                          \
        ((bb)=(where)*((gf).databbox(t,l,c,ident))).empty()) ; else {
#endif

#ifndef end_forallBB_sync
#define end_forallBB_sync } } comm_service::barrier(); }
#endif

#ifndef end_forallBB
#define end_forallBB } } }
#endif

#endif
