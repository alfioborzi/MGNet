#ifndef _included_GridTableCommRcv_h
#define _included_GridTableCommRcv_h

/*
*************************************************************************
*                                                                       *
* GridTableCommRcv							*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"

#include "CommServer.h"
#include "GridTable.h"

#define GridTableGhostRcvNULL 	((GridTableGhostRcv *) NULL)
#define GridTableDataRcvNULL 	((GridTableDataRcv *) NULL)

class GridTableGhostRcv : public comm_service 
  {
public:
   GridTable &Table;
   char *Request;
   const unsigned Size;
   short rcvflag;

   GridTableGhostRcv(GridTable& GT, const unsigned tag, const unsigned size, 
		     int const src=MPI_ANY_SOURCE);
   ~GridTableGhostRcv();
   void rcv_update( void * );
   void callrecv( const MPI_Status & );
   void callrecvNpost( const MPI_Status & );
   void postrcv();
   int received() { return (rcvflag == DAGHTrue); }
   const char * name() const;
  };

class GridTableDataRcv : public comm_service 
  {
public:
   GridTable &Table;
   char *Request;
   const unsigned Size;
   short rcvflag;

   GridTableDataRcv(GridTable& GT, const unsigned tag, const unsigned size, 
		     int const src=MPI_ANY_SOURCE);
   ~GridTableDataRcv();
   void rcv_update( void * );
   void callrecv( const MPI_Status & );
   void callrecvNpost( const MPI_Status & );
   void postrcv();
   int received() { return (rcvflag == DAGHTrue); }
   const char * name() const;
  };

ostream & operator << ( ostream & , const MPI_Status & );

#endif

