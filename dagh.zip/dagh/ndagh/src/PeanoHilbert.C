/*
*************************************************************************
*                                                                       *
* PeaniHilbert.C                                                        *
*                                                                       *
* Class PeanoHilbert defines the Peano-Hilbert sfc mapping. This class  *
* is derived from sfcIndex and defines mapping and inverse mapping      *
* routines.                                                             *
*                                                                       *
* Note: PeanoHilbert currently handles only 1-3 Dims !!!                *
*       I intend to expand it to 4 dimensiions.                         * *                                                     			*
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

#include "PeanoHilbert.h"

#ifndef __ENABLE_INLINE__
#include "PeanoHilbert.inline"
#endif

/*
*************************************************************************
*                                                                       *
* void PeanoHilbert::phOrient(int const level, int const pos)		*
*                                                                       *
* Member function phOrient modifys the digit corresponding to 		*
* sfcIndexUnit at level "level" as per the orientation defined by "pos".*
* This routine currently is defined for 2 and 3 dimensions. It will 	*
* have to modified to reorient for higher dimensions. 			*
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

void PeanoHilbert::phOrient(int const level, int const pos) 
  {

   assert(sfcdim <= 3);

   switch(sfcdim)
    {
    case 1:
	break;
    case 2:
	switch(pos)
          {
	  case 0:	
            phRotate(level,1,2);
	    break;
	  case 1: case 3:	
	    break;
	  case 2:	
	    phRotate(level,1,2);
            phTranslate(level,1);
            phSwapDir(level,2);
	    break;
	  default:
	    break;
	  }
	break;
    case 3:
	switch(pos)
          {
	  case 0:	
	    phRotate(level,1,3);
	    break;
	  case 1: case 3:	
	    phRotate(level,1,2);
	    break;
	  case 2: case 6:	
	    phTranslate(level,2);
	    phTranslate(level,3);
	    break;
	  case 4:	
	    phRotate(level,1,3);
	    phTranslate(level,1);
	    phSwapDir(level,3);
	    break;
	  case 5: case 7:	
	    phRotate(level,1,2);
	    phTranslate(level,1);
	    phSwapDir(level,2);
	    break;
	  default:
	    break;
	  }
	break;
    }
  }

/*
*************************************************************************
*                                                                       *
* void PeanoHilbert::Map(unsigned const *coords)			*
*                                                                       *
* Member function Map generates the sfcIndex corresponding to "c"  	*
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

void PeanoHilbert::Map(unsigned const *coords)
  {

   register unsigned cmax = GetDimMax(sfclevs);
   register int i,j;
   for(i=0;i<sfcdim;i++) assert(coords[i] <= cmax);
   //assert(coords[i] >= 0 && coords[i] <= cmax); 

   /* Initial orientation */
   /* ph_pos = 0; | */
   int ph_pos = -1; /* -> */

   sfcCreateLocNum(coords);

   for (i=1;i<=sfclevs;i++) {
     for (j=i;j<=sfclevs;j++)
       phOrient(j,ph_pos);

     ph_pos = sfcGetDigit(i);
     phGinv(i);
   }
  }

/*
*************************************************************************
*                                                                       *
* void PeanoHilbert::Invert(unsigned *coords) const 			*
*                                                                       *
* Member function Invert generates the sfcdim coordinate values 	*
* corresponding to the index currently stored in the sfcIndex.		*
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

void PeanoHilbert::Invert(unsigned *coords) const
  {

   assert(coords != 0);
   //if (!coords) coords = new unsigned[sfcdim];

   PeanoHilbert phtmp(*this);

   int i;
   for (i=sfclevs;i>0;i--)
     phtmp.phGray(i);
   
   for (i=sfclevs;i>0;i--)
     for (int j=i-1;j>0;j--)
       phtmp.phOrient(i,phtmp.sfcGetDigit(j));
 
   phtmp.sfcGetCoords(coords);

  }

/*
***************************************************************************
*                                                                         *
* PeanoHilbert *PeanoHilbert::GetBox(int const lev, int const nlev) const *
*                                                                         *
* Member function GetBox returns the index corresponding to the   	  *
* upper bound of the of the dim sfcdim cube with extent nlev		  *
* rooted at the PH index stored in "this".				  *
* This routine is used to get the bounding box of the GridUnit whose 	  *
* baseindex is 	maintained by this.					  *
*                                                                         *
* This routine has be defined of 2 and 3 dimensions only.		  *
*                                                                         *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                       *
*                                                                         *
***************************************************************************
*/

PeanoHilbert *PeanoHilbert::GetBox(int const lev, int const nlev) const 
  {

   assert(nlev >= 0 && lev >= nlev && lev <= sfclevs);
   assert(sfcdim <= 3);

   PeanoHilbert *phtmp = new PeanoHilbert(*this);

   if(nlev == 0) return phtmp;

   int i;
   switch(sfcdim)
     {
     case 3:
       /*
       // digits at lev + i should be 0 since the sfcindex
       // corresponds to a GridUnit at level lev; and so we 
       // can set it instead of xor-ing it with the original 
       // stored value.
       // phtmp->sfcSetDigit(lev+1,(sfcGetDigit(i)^5));
       // for (i=lev+2;i<=lev+nlev;i++) {
       //  phtmp->sfcSetDigit(i,(sfcGetDigit(i)^1));
       // }
       */
       phtmp->sfcSetDigit(lev-nlev+1,5);
       for (i=lev-nlev+2;i<=lev;i++)
         phtmp->sfcSetDigit(i,1);

       break;

     case 2:
       /*
       //for (i=lev+1;i<lev+nlev;i++)
       //  phtmp->sfcSetDigit(i,(sfcGetDigit(i)^2));
       */
       for (i=lev-nlev+1;i<=lev;i++)
         phtmp->sfcSetDigit(i,2);

       break;

     case 1:
       for (i=lev-nlev+1;i<=lev;i++)
         phtmp->sfcMaxDigit(i);

       break;
     }

     return phtmp;
  }

void PeanoHilbert::SetBox(int const lev, int const nlev) 
  {

   assert(nlev >= 0 && lev >= nlev && lev <= sfclevs);
   assert(sfcdim <= 3);

   if(nlev == 0) return;

   register int i;
   switch(sfcdim)
     {
     case 3:
       sfcIndex::sfcSetDigit(lev-nlev+1,5);
       for (i=lev-nlev+2;i<=lev;i++) sfcIndex::sfcSetDigit(i,1);
       for (i=lev+1;i<=sfclevs;i++) sfcIndex::sfcUnsetDigit(i);
       break;

     case 2:
       for (i=lev-nlev+1;i<=lev;i++) sfcIndex::sfcSetDigit(i,2);
       for (i=lev+1;i<=sfclevs;i++) sfcIndex::sfcUnsetDigit(i);
       break;

     case 1:
       for (i=lev-nlev+1;i<=lev;i++) sfcIndex::sfcMaxDigit(i);
       for (i=lev+1;i<=sfclevs;i++) sfcIndex::sfcUnsetDigit(i);
       break;
     }
  }

/*
***************************************************************************
*                                                                         *
* PeanoHilbert *PeanoHilbert::GetMax(int const lev, int const nlev) const *
*                                                                         *
* Member function GetMax returns the index corresponding to the   	  *
* maximum index in the dim sfcdim cube with extent nlev	rooted at the PH  *
* index stored in "this".				  		  *
*                                                                         *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                       *
*                                                                         *
***************************************************************************
*/

PeanoHilbert *PeanoHilbert::GetMax(int const lev, int const nlev) const 
  {

   assert(nlev >= 0 && lev >= nlev && lev <= sfclevs);

   PeanoHilbert *phtmp = new PeanoHilbert(*this);

   if(nlev == 0) return phtmp;

   for (register int i=lev-nlev+1;i<=lev;i++)
     phtmp->sfcMaxDigit(i);

   return phtmp;
  }

void PeanoHilbert::SetMax(int const lev, int const nlev)
  {
   assert(nlev >= 0 && lev >= nlev && lev <= sfclevs);
   if(nlev == 0) return;
   register int i;
   for (i=lev-nlev+1;i<=lev;i++) sfcMaxDigit(i);
   for (i=lev+1;i<=sfclevs;i++) sfcUnsetDigit(i);
  }

/*
*************************************************************************
*                                                                       *
* void PeanoHilbert::GetCoords(unsigned *coords, int const lev) const	*
*                                                                       *
* Member function GetCoords returns a copy of the coordinates in "c" at	*
* level "lev" of refinement.						*
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

void PeanoHilbert::GetCoords(unsigned *coords, int const lev) const
  {
   assert(lev > 0 && lev <= sfclevs);

   register unsigned h = GetDimCardinality(lev);

   Invert(coords);

   for (int i=0;i<sfcdim;i++) {
     coords[i] = (coords[i]/h)*h;
   }

  }

unsigned *PeanoHilbert::GetCoords(int const lev) const
  {
   assert(lev > 0 && lev <= sfclevs);

   register unsigned h = GetDimCardinality(lev);
   unsigned *coords = new unsigned[sfcdim];

   Invert(coords);

   for (int i=0;i<sfcdim;i++) coords[i] = (coords[i]/h)*h;

   return (coords);
  }

/***********************
ostream&  operator << (ostream& os, PeanoHilbert& ph)
  {
   if (&ph == (PeanoHilbert *)NULL) return os;

   for (int i=0;i<=ph.sfclevs;i++) os << ph.sfcGetIndex(i,1);

   os << "\n";

   return os;
  }
***********************/
