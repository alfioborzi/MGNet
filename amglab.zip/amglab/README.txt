AMGLab version 2.1
April 2010

The user interface is still under development.  
The scripts for importing custom problems are being modified for stability and robustness.  
These modifications should be in place soon.