 /*@@
   @file      Cluster1.C
   @date      Wed Apr 17 19:04:31 1996
   @author    Paul Walker
   @desc 
   A 1D "clustering" algorithm.  1D clustering is really easy. so this
   is really short.
   @enddesc 
   @comment 
   <code>$Id: Cluster1.C,v 1.6 1997/04/15 20:13:02 parashar Exp $</code>
   @endcomment 
   @include Framework.h
 @@*/

#include "DAGH.h"

 /*@@
   @routine    Cluster1
   @date       Wed Apr 17 19:05:33 1996
   @author     Paul Walker
   @desc 
   Clusters a grid function <code>flag</code> into a list of bounding
   boxes <code>result</code>.  Assuse <code>flag</code> is a 1D real array
   with values of 0.0 or 1.0 for flag or no flag.
   @enddesc 
   @calledby   RefineSystem

   @var     flag
   @vdesc   Array of points to cluster
   @vtype   GridData(1)<short>
   @vio     in
   @endvar 

   @var     Efficiency, MinWidth, BufferWidth
   @vdesc   Standard Clustering parameters
   @vtype   DNAGFTYPE
   @vio     in
   @endvar 

   @var     result
   @vdesc   The resulting BBoxList of the clustering algorithm
   @vtype   BBoxList
   @vio     out
   @vcomment since all we do is append to result, I assume you could
     call Cluster1 multiple times with the same result entry.  But I'm not
     sure why you'd want to...
   @endvar 

@@*/

void Cluster1(GridData(1)<short> &flag,
	      double Efficiency,
	      int MinWidth,
	      int BufferWidth,
	      BBoxList &result) {
  GridData(1)<short> newflag(flag.bbox());
  int l=-1, u=-1;

  /* First buffer! */
  newflag = 0;

  for_1(i,flag.bbox(),flag.bbox().stepsize()) 
    if (flag(i)) {
      BBox where(1,i,i,flag.bbox().stepsize(0));
      where.grow(BufferWidth);
      newflag.equals(1.0, where);
    }
  end_for;

  /* Now just step along looking for zero crossings or end of
     the thing.  This defines our BBox */
  if (newflag(newflag.bbox().lower(0))) {
    l = newflag.bbox().lower(0);
  }
  int i;
  for (i=newflag.bbox().lower(0)+newflag.bbox().stepsize(0); 
       i < newflag.bbox().upper(0); 
       i+= newflag.bbox().stepsize(0)) {
    if (newflag(i) && !newflag(i-newflag.bbox().stepsize(0))) {
      l = i;
    }
    if (!newflag(i) && newflag(i-newflag.bbox().stepsize(0))) {
      u = i-newflag.bbox().stepsize(0);
      if (u-l >= MinWidth) {
	BBox add(1,l,u,newflag.bbox().stepsize(0));
	result.add(add);
      } 
    }
  }
  if (u < l) {
    u = newflag.bbox().upper(0);
    BBox add(1,l,u,newflag.bbox().stepsize(0));
    result.add(add);
  }
}

