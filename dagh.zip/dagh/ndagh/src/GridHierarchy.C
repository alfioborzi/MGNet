/*
*************************************************************************
*                                                                       *
* GridHierarchy.C                                                       *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "GridHierarchy.h"

/*************************************************************************/
/* IO Functions */
/*************************************************************************/
DAGHIO_WriteFunc DAGHIO_Write[DAGHMaxIOTypes];
DAGHIO_ReadFunc DAGHIO_Read[DAGHMaxIOTypes];
/*************************************************************************/

/*************************************************************************/
/* Error messages */
/*************************************************************************/
static char const filename[] = "GridHierarchy";
static void warn(const char msg[])
        { cerr << filename << ":" << msg << "\n"; }
static void abort(const char msg[])
        { warn(msg); exit(-1); }
/*************************************************************************/

/*************************************************************************/
/* Utility macros */
/*************************************************************************/
#define log2(x) (log(x))/(log(2.0))
#define power2(x) ((unsigned) 1 << (x))

/*************************************************************************/
/* Constructor... */
/*************************************************************************/
GridHierarchy::GridHierarchy(const int ndim, 
			     const int type, 
			     const int max_level)
        : rank(ndim), basebbox(ndim,1),
	  daghtype(type), 
	  bndrytype(DAGHDefaultBoundary),
	  adaptbndrytype(DAGHDefaultAdaptBoundary),
	  bndrywidth(0), extghostwidth(0),
	  maxlev(max_level), refby(DAGHDefaultRefineFactor), reflev(1), 
	  crslev(0), finelev(0), levels(0), intbbox(ndim,1),
          updatedstep(DAGHCurrentTime),
          distribution_type(DAGHDefaultDistribution), 
	  distribution(DAGHDefaultDistribution),
	  mindex(0), complist(0), locallist(0),
	  oldcomplist(0), oldlocallist(0),
	  localarray(0),  //gdiffarray(0), ldiffarray(0),
	  origlocallist(0),
	  mergedllist(0),
	  gfnum(0), gflist(0),
          io_type(0), io_complist_server(0), io_write_server(0), 
	  io_read_server(0), io_end_server(0),
	  chkptflag(DAGHFalse), chkptpnum(0)
  { 
    chkptname[0] = '\0';
    mergedllist = new List<MergedGridUnit*>;
    DAGH_InitOverlaps(daghtype,overlap);
    DAGH_CommInit(); 
  }

/*************************************************************************/
/* Destructor... */
/*************************************************************************/
GridHierarchy::~GridHierarchy(void)
  {
    register int i;

    /* release memory */
    //if (dspecs) delete [] dspecs;
    //if (bndrybbox) delete [] bndrybbox;
    if (curtime[0]) delete [] curtime[0];
    if (curtime[1]) delete [] curtime[1];
    if (reftime[0]) delete [] reftime[0];
    if (reftime[1]) delete [] reftime[1];
    if (complist) delete complist;
    if (locallist) delete locallist;
    if (oldcomplist) delete oldcomplist;
    if (oldlocallist) delete oldlocallist;
    if (origlocallist) delete origlocallist;
    for (i=0;i<levels;i++) {
      if (localarray && localarray[i]) delete localarray[i];
      //if (gdiffarray && gdiffarray[i]) delete gdiffarray[i];
      //if (ldiffarray && ldiffarray[i]) delete ldiffarray[i];
    }
    if(localarray) delete [] localarray;
    //if(gdiffarray) delete [] gdiffarray;
    //if(ldiffarray) delete [] ldiffarray;

    if (gflist) {
      for (i=0;i<gfnum;i++)
        if (gflist[i]) gflist[i] = (GridFunctionVoid *) NULL;
      delete [] gflist;
    }

    if (mergedllist) {
      MergedGridUnit** mgul;
      DAGHListLoop(*mergedllist,mgul,MergedGridUnit*)
	if (*mgul) delete *mgul; 
        *mgul = 0;
      DAGHEndLoop

      delete mergedllist;
    }

    if (io_complist_server) {
       delete io_complist_server;
       io_complist_server = 0;
    }
    if (io_write_server) {
       delete io_write_server;
       io_write_server = 0;
    }
    if (io_read_server) {
       delete io_read_server;
       io_read_server = 0;
    }
    if (io_end_server) {
       delete io_end_server;
       io_end_server = 0;
    }

    chkptname[0] = '\0';

    /* Shut down comms */
    DAGH_CommKill();
  }

/*************************************************************************/
/* Setup the hierarchy... */
/*************************************************************************/

/* bbox[0:2*rank-1] = {xmin,xmax,ymin,ymax,zmin,zmax,...} */
/* shape[0:rank-1] = {nx,ny,nz,...} */
/* h = (max - min)/(n-1) */
void GridHierarchy::DAGH_SetBaseGrid(double const *bbox, const int *shape)
  {
    //if (!dspecs) dspecs = new struct dimspec[rank];
   for (register int i=0;i<rank;i++) { 
      dspecs[i].low = bbox[2*i]; 
      dspecs[i].high = bbox[2*i+1];
      dspecs[i].n = shape[i]; 
      dspecs[i].h = (dspecs[i].high - dspecs[i].low) / (dspecs[i].n);
      basebbox.lower(i) =  0;
      basebbox.upper(i) =  shape[i]-1;
   }
  }

void GridHierarchy::DAGH_SetTimeSpecs(double const starttime, 
			double const stoptime, const int numtsteps)
  {
   tspecs.low = starttime;
   tspecs.high = stoptime;
   tspecs.n = numtsteps;
   tspecs.h = (tspecs.high - tspecs.low) / (tspecs.n-1);
  }

void GridHierarchy::DAGH_SetRefineFactor(const int rfactor)
  {
   refby = rfactor;
   register double tmpt = (refby>0) ? log2((double)1.0*refby):0;
   if ( ((unsigned) 1 << (int) tmpt) < refby ) 
     abort("Refine factor not a power of two");
   reflev = (int) tmpt;
  }

/*************************************************************************/
/* Generate the list of merged grid units */
/*************************************************************************/
#ifndef DAGHMerge
#define DAGHMerge 1
#endif
#ifndef DAGHMergeWithClusterer
#define DAGHMergeWithClusterer 0
#endif
/*************************************************************************/
/* The Cluster Routines (by Paul Walker) */
/*************************************************************************/
#ifdef DAGHUseClusterMerge
#include "GridData.h"
void Cluster3(GridData(3)<short>&, double, int, int, BBoxList&);
void Cluster2(GridData(2)<short>&, double, int, int, BBoxList&);
void Cluster1(GridData(1)<short>&, double, int, int, BBoxList&);
#endif
/*************************************************************************/
void GridHierarchy::DAGH_MergeGridUnits()
  {
    /* I don't care here whether it is DAGHCellCentered or not... */
    short olap[DAGHMaxRank];
    DAGH_InitOverlaps(DAGHCellCentered,olap);

    /* I don't external ghosts */
    const int extgh = 0;

    GridUnitList oldllist(*locallist);

    if (!mergedllist->isempty()) mergedllist->empty();

    register int idx = 0;
    register BBox* bb = 0;
    BBoxList bbl;
    for (int l=finelev;l>=crslev;l--) {
      oldllist.bboxlist(bbl,l,olap,extgh);
      if (bbl.isempty()) continue;
      if (DAGHMerge && DAGHMergeWithClusterer && rank == 3) {
#ifdef DAGHUseClusterMerge
	Array(3)<short> flags(bbl.reduce());
	flags = 0;
	for (bb=bbl.first();bb;bb=bbl.next()) 
	  if (!bb->empty()) flags.equals(1,*bb);
	bbl.empty();
	Cluster3(flags,1.0,1,0,bbl);
#endif
      }
      else if (DAGHMerge && DAGHMergeWithClusterer && rank == 2) {
#ifdef DAGHUseClusterMerge
 	Array(2)<short> flags(bbl.reduce());
	flags = 0;
	for (bb=bbl.first();bb;bb=bbl.next()) 
	  if (!bb->empty()) flags.equals(1,*bb);
	bbl.empty();
	Cluster2(flags,1.0,1,0,bbl);
#endif
      }
      else if (DAGHMerge && DAGHMergeWithClusterer && rank == 1) {
#ifdef DAGHUseClusterMerge
	Array(1)<short> flags(bbl.reduce());
	flags = 0;
	for (bb=bbl.first();bb;bb=bbl.next()) 
	  if (!bb->empty()) flags.equals(1,*bb);
	bbl.empty();
	Cluster1(flags,1.0,1,0,bbl);
#endif
      }
      else if (DAGHMerge) {
	bbl.mergeboxes(olap);
      }
#ifdef DEBUG_PRINT_GH
   (comm_service::log() << "GridHierarchy::DAGH_MergeGridUnits "
                        << "Merged BBox List at level " << l 
                        << endl << bbl
			<< endl).flush();
#endif
      for (bb=bbl.first();bb;bb=bbl.next()) {
        if (bb->empty()) continue;
        MergedGridUnit* mgu = new MergedGridUnit;
        mgu->bb = *bb;
        oldllist.intersect(mgu->bb,l,mgu->gul,olap);
        assert(!mgu->gul.isempty());
        oldllist -= mgu->gul;

	const dMapIndex li(mgu->gul.lowest());
	const BBox& mbb(mgu->bb);
        //mgu->gul.setindex(idx);

        //mgu->gul.setindex();
        //mgu->gul.setmergedbbox(mgu->bb);
        //mgu->gul.setlowindex(li);
        {
	  GridUnitList& tmpgul = mgu->gul;
	  union record *tmpcur = tmpgul.currec();	  
	  register GridUnit *g = 0;
	  register int tmpidx = 0;
	  for ( g = tmpgul.first(); g != GridUnitNULL;  
		tmpidx++, g = tmpgul.next() ) {
	    g->guSetMergedBBox(mbb); 
	    g->guSetIndex(tmpidx); 
	    g->guSetLowIndex(li); 
	  }
	  tmpgul.setcurrec(tmpcur);
	}

        //locallist->setindex(mgu->gul,idx);
	//locallist->setmergedbbox(mgu->gul,mgu->bb);
	//locallist->setlowindex(mgu->gul,li);
	{
	  GridUnitList &tmpgul = *locallist;
	  GridUnitList &gul = mgu->gul;
	  union record *rhstmpcur = gul.currec();
	  union record *tmpcur = tmpgul.currec();

	  register GridUnit *g = tmpgul.first();
	  register GridUnit *rhsg = 0;
	  for ( rhsg = gul.first(); rhsg != GridUnitNULL;  rhsg = gul.next() )
	    for ( ; g != GridUnitNULL;  g = tmpgul.next() )
	      if (*g == *rhsg) { 
		g->guSetIndex(idx);
		g->guSetMergedBBox(mbb);
		g->guSetLowIndex(li); 
		break; 
	      }
	  gul.setcurrec(rhstmpcur);
	  tmpgul.setcurrec(tmpcur);
	}

        mergedllist->add(mgu);
        idx++;
        if(oldllist.isempty()) break;
      }
    }
    assert(oldllist.isempty());
  }
/*************************************************************************/
/* Compose the hierarchy... */
/*************************************************************************/
void GridHierarchy::DAGH_ComposeHierarchy(void)
  {
   const int me = comm_service::proc_me();
   const int num = comm_service::proc_num(); 

   int nld, ntd;
   nld = ntd = dspecs[0].n;
   register int i;
   for (i=0;i<rank;i++) {
      if (nld < dspecs[i].n) nld = dspecs[i].n;
      if (ntd > dspecs[i].n) ntd = dspecs[i].n;
   }
   int ldext = (nld>0) ? (int) floor(log2((double)1.0*nld)) : 0;
   int tdext = (ntd>0) ? (int) floor(log2((double)1.0*ntd)) : 0;

   if ( ((unsigned) 1 << ldext) < nld ) ldext++;
   if ( ((unsigned) 1 << tdext) < ntd ) tdext++;

   complist  = new GridUnitList;
   complist->settag(me);

   finelev = crslev = ldext;
   maxlev = crslev+(maxlev-1)*reflev;
   levels = (maxlev-crslev)/reflev+1;

   for (i=0;i<rank;i++) {
     dspecs[i].nfine = dspecs[i].n*(reflev << (levels-1));
     dspecs[i].hfine = dspecs[i].high/(1.0*dspecs[i].nfine) - 
                       dspecs[i].low/(1.0*dspecs[i].nfine);
   }

   GridUnit wholegu(rank,crslev,(unsigned)0,crslev,maxlev,reflev,0);

   const int step = (wholegu.guBaseIndex()).GetDimCardinality(crslev);
   BBox wholebox(rank,basebbox.lower(),basebbox.upper(),step);
   wholebox.upper() *= step;

   intbbox.setstepsize(step);
   {
     complist->add(wholegu);
     register GridUnit *gu = complist->first();
     BBox bb;
     for (;gu;gu=complist->next()) {
       bb = gu->guBBox(crslev);
       if (bb <= wholebox) intbbox += bb;
       else if (!(bb*wholebox).empty()) complist->decompose();
       else complist->remove();
     }
   }
   intbbox.growupperbydim(daghoverlap());
   {
     //assert (!bndrybbox);
     //bndrybbox = new BBox[2*rank];
     for (i=0;i<rank;i++) {
       bndrybbox[2*i] = 
	 growupper(intbbox,i,bndrywidth-intbbox.extents(i)+1);
       bndrybbox[2*i+1] = 
	 growlower(intbbox,i,intbbox.extents(i)-bndrywidth-1);
     }
   }

   /* Current Time Array */
   curtime[0] = new int[levels]; /* DAGH_Main */
   curtime[1] = new int[levels]; /* DAGH_Shadow */
   for (i=0;i<levels;i++) 
     { curtime[0][i] = curtime[1][i] = 0; }

   /* Refine Time Array */
   reftime[0] = new int[levels]; /* DAGH_Main */
   reftime[1] = new int[levels]; /* DAGH_Shadow */
   for (i=0;i<levels;i++) 
     { reftime[0][i] = reftime[1][i] = 0; }

   /* Partition the composite list & get local information */
   distribution.partition(complist,locallist,num,me,
                          DAGHDefaultPartMinGUWidth,daghoverlap());

   if ( !comm_service::io_enabled() || 
        me != comm_service::proc_io() ||
        comm_service::proc_world() == 1 ) {
     /*$gdiffarray = new GridUnitList *[levels];
     ldiffarray = new GridUnitList *[levels];
     for (i=0;i<levels;i++) {
       gdiffarray[i] = GridUnitListNULL;
       ldiffarray[i] = GridUnitListNULL;
     }$*/

     //locallist->setindex();

     if (!mergedllist->isempty()) mergedllist->empty();
     if (!locallist->isempty()) DAGH_MergeGridUnits();
     locallist->levelarray(localarray,levels);
   }

   if (comm_service::io_enabled() && 
       comm_service::proc_world() > 1 &&
       me == comm_service::proc_io()) {
     io_complist_server = 
       new DAGHIOServerPing((DAGHIOTag|DAGHIOComplistReqTag),
                            *this,&DAGHIO_ComplistPingFunction);
     io_write_server = new DAGHIOServerRcv((DAGHIOTag|DAGHIOWriteReqTag), 
                                           *this,DAGHIO_Write[io_type]);
     io_read_server = new DAGHIOServerSnd((DAGHIOTag|DAGHIOReadReqTag), 
                                           *this,DAGHIO_Read[io_type]);
     io_end_server = new DAGHIOServerPing((DAGHIOTag|DAGHIOEndReqTag),
                                           *this,&DAGHIO_EndIOPingFunction);
   }

   if (1) {
     if (comm_service::proc_world() == 1) {
       if (complist) delete complist;
       complist = new GridUnitList(*locallist);
     }
     else {
       // Since IO node is also executing this I don't need a ping
       //if (comm_service::io_enabled() && 
       //    comm_service::proc_world() > 1 && 
       //    me == 0) {
       //  DAGH_PingIONode(DAGHIOTag|DAGHIOComplistReqTag, DAGHTrue);
       //}

       int sndsize=0, rcvsize=0;
       void *sndbuf = locallist->pack(sndsize);
       void *rcvbuf = 0;
       DAGH_GlbConcat(sndbuf, sndsize, rcvbuf, rcvsize); 
       if (complist) delete complist;
       complist = new GridUnitList(rcvbuf, rcvsize, num, me);
       if (rcvbuf) delete [] rcvbuf;
     }
   }

   origlocallist = new GridUnitList(*locallist);

#ifdef DEBUG_PRINT_GH
   (comm_service::log() << "GridHierarchy::DAGH_ComposeHierarchy" << " " 
			<< comm_service::proc_me() << " "
			<< "BaseBBox: " << basebbox << " "
			<< endl).flush();

    (comm_service::log() << "\n************* Composite List *************\n"
			 << *complist
	  		 << "\n************* Localist List *************\n"
			 << *locallist
	  		 << "\n************* ***************** *************\n"
                           ).flush();

    (comm_service::log() << "\n************* Merged List *************\n").flush();
    MergedGridUnit** dbxmgul;
    DAGHListLoop(*mergedllist,dbxmgul,MergedGridUnit*)
      (comm_service::log() << **dbxmgul).flush();
    DAGHEndLoop
#endif

   mindex = complist->maxindex();

   if (comm_service::io_enabled() && 
       comm_service::proc_world() > 1 &&
       me == comm_service::proc_io()) {
     DAGH_IOServe();
   }
  }

/*************************************************************************/
/* Compose the hierarchy using a check point file ...... */
/*************************************************************************/
void GridHierarchy::DAGH_ComposeHierarchy(const char* name)
  {
   const int me = comm_service::proc_me();
   const int num = comm_service::proc_num(); 

   /* Start checkpointing */
   DAGH_InitChkpt(name);
   streampos* chkptdir = 0;
   char* chkptnamedir = 0;
   ifstream ifs;
   int eflag = DAGH_OpenChkptIStream(me, chkptdir, chkptnamedir, ifs);
  
   /* If my file does not exist open Proc 0 file */
   if (eflag != DAGHTrue)
     eflag = DAGH_OpenChkptIStream(0, chkptdir, chkptnamedir, ifs);

   assert (eflag == DAGHTrue);
 
   /* Read information from the checkpoint file */
   ifs >> *this;

   /* Close chkpt stream and delete associated data */
   DAGH_CloseChkptIStream(chkptdir, chkptnamedir, ifs);

   /* Partition the composite list & get local information */
   if (chkptpnum != num || (comm_service::io_enabled() && 
			    comm_service::proc_world() > 1 &&
			    me == comm_service::proc_io())) { 
     /* New Distribution or I am the IO server */
     if (origlocallist) delete origlocallist;
      origlocallist = 0;
     if (oldcomplist) delete oldcomplist;
     oldcomplist = new GridUnitList(*complist);
     distribution.partition(complist,locallist,num,me,
			    DAGHDefaultPartMinGUWidth,daghoverlap());
   }
   else { /* Same Distribution */
     int eflag = DAGH_OpenChkptIStream(me, chkptdir, chkptnamedir, ifs);
     assert (eflag == DAGHTrue);
 
     /* Read information from the checkpoint file */
     ifs >> *this;

     /* Close chkpt stream and delete associated data */
     DAGH_CloseChkptIStream(chkptdir, chkptnamedir, ifs);
   }

   if ( !comm_service::io_enabled() || 
        me != comm_service::proc_io() ||
        comm_service::proc_world() == 1 ) {
     /*$gdiffarray = new GridUnitList *[levels];
     ldiffarray = new GridUnitList *[levels];
     for (register int i=0;i<levels;i++) {
       gdiffarray[i] = GridUnitListNULL;
       ldiffarray[i] = GridUnitListNULL;
     }$*/

     //locallist->setindex();

     if (!mergedllist->isempty()) mergedllist->empty();
     if (!locallist->isempty()) DAGH_MergeGridUnits();
     locallist->levelarray(localarray,levels);
   }

   if (comm_service::io_enabled() && 
       comm_service::proc_world() > 1 &&
       me == comm_service::proc_io()) {
     io_complist_server = 
       new DAGHIOServerPing((DAGHIOTag|DAGHIOComplistReqTag),
			    *this,&DAGHIO_ComplistPingFunction);
     io_write_server = new DAGHIOServerRcv((DAGHIOTag|DAGHIOWriteReqTag), 
                                           *this,DAGHIO_Write[io_type]);
     io_read_server = new DAGHIOServerSnd((DAGHIOTag|DAGHIOReadReqTag), 
                                           *this,DAGHIO_Read[io_type]);
     io_end_server = new DAGHIOServerPing((DAGHIOTag|DAGHIOEndReqTag),
                                           *this,&DAGHIO_EndIOPingFunction);
   }

   if (1) {
     if (comm_service::proc_world() == 1) {
       if (complist) delete complist;
       complist = new GridUnitList(*locallist);
     }
     else {
       // Since IO node is also executing this I don't need a ping
       //if (comm_service::io_enabled() && 
       //    comm_service::proc_world() > 1 && 
       //    me == 0) {
       //  DAGH_PingIONode(DAGHIOTag|DAGHIOComplistReqTag, DAGHTrue);
       //}

       int sndsize=0, rcvsize=0;
       void *sndbuf = locallist->pack(sndsize);
       void *rcvbuf = 0;
       DAGH_GlbConcat(sndbuf, sndsize, rcvbuf, rcvsize); 
       if (complist) delete complist;
       complist = new GridUnitList(rcvbuf, rcvsize, num, me);
       if (rcvbuf) delete [] rcvbuf;
     }
   }

#ifdef DEBUG_PRINT_GH
   (comm_service::log() << "GridHierarchy::DAGH_ComposeHierarchy" << " " 
			<< comm_service::proc_me() << " "
			<< "BaseBBox: " << basebbox << " "
			<< endl).flush();

    (comm_service::log() << "\n************* Composite List *************\n"
			 << *complist
	  		 << "\n************* Localist List *************\n"
			 << *locallist
	  		 << "\n************* ***************** *************\n"
                           ).flush();

    (comm_service::log() << "\n************* Merged List *************\n").flush();
    MergedGridUnit** dbxmgul;
    DAGHListLoop(*mergedllist,dbxmgul,MergedGridUnit*)
      (comm_service::log() << **dbxmgul).flush();
    DAGHEndLoop
#endif

   mindex = complist->maxindex();

   if (comm_service::io_enabled() && 
       comm_service::proc_world() > 1 &&
       me == comm_service::proc_io()) {
     DAGH_IOServe();
   }

   if (oldlocallist) delete oldlocallist;
   oldlocallist = 0;
  }

/***************************************************************/
/* GridFunction Information/Operations */
/***************************************************************/
#ifndef GFListIncrement
#define GFListIncrement	 	(64)
#endif

int GridHierarchy::DAGH_AddGridFunction(GridFunctionVoid *gfv)
  {
   if (comm_service::dce()) 
     assert (comm_service::num_comm() == gfnum);

   if (!gflist) {
     gflist = new GridFunctionVoid *[GFListIncrement];
     for (register int i=0;i<GFListIncrement;i++) {
       gflist[i] = (GridFunctionVoid *) NULL;
     }
     if (comm_service::dce()) 
       comm_service::inc_commarray(GFListIncrement);
   }
  
   int idx = gfnum;
   while (gflist[idx] != (GridFunctionVoid *) NULL) idx--;
   gflist[idx] = gfv;
   if (comm_service::dce()) 
     comm_service::add_comm(idx);
   gfnum++;

   if (gfnum%GFListIncrement == 0) {
     GridFunctionVoid **ogflist = gflist;
     gflist = new GridFunctionVoid *[gfnum+GFListIncrement];
     register int i;
     for (i=0;i<gfnum;i++) {
       gflist[i] = ogflist[i];
       ogflist[i] = (GridFunctionVoid *) NULL;
     }
     for (i=gfnum;i<gfnum+GFListIncrement;i++)
       gflist[i] = (GridFunctionVoid *) NULL;

     delete [] ogflist; 

     if (comm_service::dce()) 
       comm_service::inc_commarray(GFListIncrement);
   }
   return (idx);
  }

/***************************************************************/
/* Recompose the hierarchy */
/***************************************************************/
void GridHierarchy::DAGH_RecomposeHierarchy(void)
  {
     const int num = comm_service::proc_num();
     const int me = comm_service::proc_me();
  
     //if (comm_service::dce()) comm_service::barrier();

     if  (chkpt_restart()) DAGH_StopChkpt();

     if (oldcomplist) delete oldcomplist;
     if (oldlocallist) delete oldlocallist;
     oldcomplist = complist; complist = 0;
     oldlocallist = locallist; locallist = 0;

     /* Let's see if this improves efficiency */
     if (origlocallist) *localarray[0] = *origlocallist;
     locallist = new GridUnitList(localarray);
     if (comm_service::proc_world() == 1) {
       complist = new GridUnitList(*locallist);
     }
     else {
       if (comm_service::io_enabled() && 
           comm_service::proc_world() > 1 && 
           me == 0) {
         DAGH_PingIONode(DAGHIOTag|DAGHIOComplistReqTag, DAGHTrue);
       }

       int sndsize=0, rcvsize=0;
       void *sndbuf = locallist->pack(sndsize);
       void *rcvbuf = 0;
       DAGH_GlbConcat(sndbuf, sndsize, rcvbuf, rcvsize); 
       complist = new GridUnitList(rcvbuf, rcvsize, num, me);
       if (rcvbuf) delete [] rcvbuf;
     }

     /* Repartition the composite list & get local information */
     distribution.partition(complist,locallist,num,me,
                            DAGHDefaultPartMinGUWidth,daghoverlap());

     //locallist->setindex();

     finelev = complist->finest();

     MergedGridUnit** mgul;
     DAGHListLoop(*mergedllist,mgul,MergedGridUnit*)
       if (*mgul) delete *mgul; 
       *mgul = 0;
     DAGHEndLoop

     if (!mergedllist->isempty()) mergedllist->empty();
     if (!locallist->isempty()) DAGH_MergeGridUnits();
     locallist->levelarray(localarray,levels);

     if (1) {
       if (comm_service::proc_world() == 1) {
         if (complist) delete complist;
         complist = new GridUnitList(*locallist);
       }
       else {
         if (comm_service::io_enabled() && 
             comm_service::proc_world() > 1 && 
             me == 0) {
           DAGH_PingIONode(DAGHIOTag|DAGHIOComplistReqTag, DAGHTrue);
         }

         int sndsize=0, rcvsize=0;
         void *sndbuf = locallist->pack(sndsize);
         void *rcvbuf = 0;
         DAGH_GlbConcat(sndbuf, sndsize, rcvbuf, rcvsize); 
         if (complist) delete complist;
         complist = new GridUnitList(rcvbuf, rcvsize, num, me);
         if (rcvbuf) delete [] rcvbuf;
       }
     }

#ifdef DEBUG_PRINT_RG
     ( comm_service::log() << "\n************* New Composite List *************\n"
			   << *complist
	  		   << "\n************* ***************** *************\n"
                           ).flush();
#endif

#ifdef DEBUG_PRINT_RG
     ( comm_service::log() << "\n************* New Local List *************\n"
			   << *locallist
	  		   << "\n************* ***************** *************\n"
                           ).flush();
#endif

#ifdef DEBUG_PRINT_RG
    (comm_service::log() << "\n************* Merged List *************\n").flush();
    MergedGridUnit** dbxmgul;
    DAGHListLoop(*mergedllist,dbxmgul,MergedGridUnit*)
      (comm_service::log() << **dbxmgul).flush();
    DAGHEndLoop
#endif

     //GridUnitList *gdiff = complist - *oldcomplist;
     //GridUnitList *ldiff = *locallist - *oldlocallist;
     //if (gdiff->isempty() && ldiff->isempty())  {
     // /* Do Not Recompose */
     //}
     //if (gdiff) delete gdiff;
     //if (ldiff) delete ldiff;

     GridUnitList rlist, slist, olist;
     if (comm_service::dce() && comm_service::proc_num() > 1) {
       rlist =  *locallist;
       rlist -= *oldlocallist;
       slist =  *oldlocallist;
       slist -= *locallist;
     }
     olist = *oldlocallist;
     olist *= *locallist;

#ifdef DEBUG_PRINT_RG
     ( comm_service::log() << "\n************* Recv List *************\n"
                           << rlist
                           << "\n************* ***************** *************\n"
                           ).flush();
     ( comm_service::log() << "\n************* Send List *************\n"
                           << slist
                           << "\n************* ***************** *************\n"
                           ).flush();
     ( comm_service::log() << "\n************* Overlap List *************\n"
                           << olist
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     const int oldmindex = mindex;
     mindex = complist->maxindex();
     register int i;
     for (i=0; i<gfnum; i++) if (gflist[i]) {
       if (comm_service::dce()) comm_service::reset_comm(gflist[i]->gfid);
       gflist[i]->GF_Recompose(oldmindex+1, *oldlocallist, rlist, slist, olist);
     }
     for (i=0; i<gfnum; i++) if (gflist[i]) {
       gflist[i]->GF_FreeTmpStorage();
     }

     if (oldcomplist) delete oldcomplist;
     if (oldlocallist) delete oldlocallist;
     oldcomplist = 0; oldlocallist = 0;
  } 

/***************************************************************/
/* Recompose the hierarchy from a checkpoint file */
/***************************************************************/
void GridHierarchy::DAGH_RecomposeHierarchy(const char* name)
  {
     const int me = comm_service::proc_me();
     const int num = comm_service::proc_num(); 

     //if (comm_service::dce()) comm_service::barrier();

     if  (chkpt_restart()) DAGH_StopChkpt();

     /* Delete old storage */
     if (oldcomplist) delete oldcomplist;
     oldcomplist = 0;
     if (oldlocallist) delete oldlocallist;
     oldlocallist = 0;

     MergedGridUnit** mgul;
     DAGHListLoop(*mergedllist,mgul,MergedGridUnit*)
       if (*mgul) delete *mgul; 
       *mgul = 0;
     DAGHEndLoop

     /* Start checkpointing */
     DAGH_InitChkpt(name);
     streampos* chkptdir = 0;
     char* chkptnamedir = 0;
     ifstream ifs;
     int eflag = DAGH_OpenChkptIStream(me, chkptdir, chkptnamedir, ifs);
     assert (eflag == DAGHTrue);

     /* Read information from the checkpoint file */
     ifs >> *this;
 
     /* Close chkpt stream and delete associated data */
     DAGH_CloseChkptIStream(chkptdir, chkptnamedir, ifs);
   
     /* The number of procs are different re-partiition */
     if (chkptpnum != num) {
       oldlocallist = locallist;
       locallist = 0;
       oldcomplist = new GridUnitList(*complist);
       distribution.partition(complist,locallist,num,me,
			      DAGHDefaultPartMinGUWidth,daghoverlap());
     }

     if (!mergedllist->isempty()) mergedllist->empty();
     if (!locallist->isempty()) DAGH_MergeGridUnits();
     locallist->levelarray(localarray,levels);

     if (1) {
       if (comm_service::proc_world() == 1) {
         if (complist) delete complist;
         complist = new GridUnitList(*locallist);
       }
       else {
         if (comm_service::io_enabled() && 
             comm_service::proc_world() > 1 && 
             me == 0) {
           DAGH_PingIONode(DAGHIOTag|DAGHIOComplistReqTag, DAGHTrue);
         }

         int sndsize=0, rcvsize=0;
         void *sndbuf = locallist->pack(sndsize);
         void *rcvbuf = 0;
         DAGH_GlbConcat(sndbuf, sndsize, rcvbuf, rcvsize); 
         if (complist) delete complist;
         complist = new GridUnitList(rcvbuf, rcvsize, num, me);
         if (rcvbuf) delete [] rcvbuf;
       }
     }

#ifdef DEBUG_PRINT_RG
     ( comm_service::log() << "\n************* New Composite List *************\n"
			   << *complist
	  		   << "\n************* ***************** *************\n"
                           ).flush();
#endif

#ifdef DEBUG_PRINT_RG
     ( comm_service::log() << "\n************* New Local List *************\n"
			   << *locallist
	  		   << "\n************* ***************** *************\n"
                           ).flush();
#endif

#ifdef DEBUG_PRINT_RG
    (comm_service::log() << "\n************* Merged List *************\n").flush();
    MergedGridUnit** dbxmgul;
    DAGHListLoop(*mergedllist,dbxmgul,MergedGridUnit*)
      (comm_service::log() << **dbxmgul).flush();
    DAGHEndLoop
    (comm_service::log() << "\n************* *********** *************\n").flush();
#endif

     //GridUnitList *gdiff = complist - *oldcomplist;
     //GridUnitList *ldiff = *locallist - *oldlocallist;
     //if (gdiff->isempty() && ldiff->isempty())  {
     // /* Do Not Recompose */
     //}
     //if (gdiff) delete gdiff;
     //if (ldiff) delete ldiff;

     const int oldmindex = mindex;
     mindex = complist->maxindex();
     register int i;
     for (i=0; i<gfnum; i++) if (gflist[i]) {
       if (comm_service::dce()) 
	 comm_service::reset_comm(gflist[i]->gfid);
       gflist[i]->GF_CheckpointRecompose();
     }

     if (oldcomplist) delete oldcomplist;
     oldcomplist = 0;
     if (oldlocallist) delete oldlocallist;
     oldlocallist = 0;

     DAGH_StopChkpt();
  } 

/***************************************************************/
/* Refine the hierarchy */
/***************************************************************/
void GridHierarchy::DAGH_Refine(const int lev)
  {
   const int l = levelnum(lev);
   GridUnitList *oldlevlist = localarray[lev+1];

   GridUnitList* gul = localarray[lev];
   if (gul != GridUnitListNULL)
     localarray[lev+1] = gul->refinelist(l);
   else 
     localarray[lev+1] = locallist->refinelist(l);

   curtime[0][lev+1] = curtime[1][lev+1] = curtime[0][lev];
   reftime[0][lev+1] = reftime[1][lev+1] = curtime[0][lev];

#ifdef DEBUG_PRINT_RG
     ( comm_service::log() 
        << "\n************* Local List at Level" << lev << " *************\n"
	<< *localarray[lev]
	<< "\n************* ***************** *************\n"
        ).flush();
     ( comm_service::log() 
       << "\n************* Local List at Level" << lev+1 << " *************\n"
       << *localarray[lev+1]
       << "\n************* ***************** *************\n"
       ).flush();
#endif

   /*$if (ldiffarray[lev+1]) delete ldiffarray[lev+1];
   if (oldlevlist && localarray[lev+1]) 
     ldiffarray[lev+1] = *oldlevlist - *localarray[lev+1];
   else if (oldlevlist && !localarray[lev+1]) 
     { ldiffarray[lev+1] = oldlevlist; oldlevlist = 0; }
   else if (!oldlevlist && localarray[lev+1]) 
     ldiffarray[lev+1] = new GridUnitList(*localarray[lev+1]);
   else if (!oldlevlist && !localarray[lev+1]) 
     ldiffarray[lev+1] = GridUnitListNULL;$*/

   if (oldlevlist) delete oldlevlist;
  }

void GridHierarchy::DAGH_Refine(BBoxList &bblist, const int lev)
  {
   const int l = levelnum(lev);
   GridUnitList *oldlevlist = localarray[lev+1];

   GridUnitList* gul = localarray[lev];
   if (gul != GridUnitListNULL)
     localarray[lev+1] = gul->refinelist(bblist,l,
                              DAGHDefaultRefineMinGUWidth);
   else 
     localarray[lev+1] = locallist->refinelist(bblist,l,
                                    DAGHDefaultRefineMinGUWidth);


   curtime[0][lev+1] = curtime[1][lev+1] = curtime[0][lev];
   reftime[0][lev+1] = reftime[1][lev+1] = curtime[0][lev];

#ifdef DEBUG_PRINT_RG
     ( comm_service::log() 
       << "\n************* Local List at Level" << lev << " *************\n"
       << *localarray[lev]
       << "\n************* ***************** *************\n"
       ).flush();
     ( comm_service::log() 
       << "\n************* Local List at Level" << lev+1 << " *************\n"
       << *localarray[lev+1]
       << "\n************* ***************** *************\n"
       ).flush();
#endif

   /*$if (ldiffarray[lev+1]) delete ldiffarray[lev+1];
   if (oldlevlist && localarray[lev+1]) 
      ldiffarray[lev+1] = *oldlevlist - *localarray[lev+1];
   else if (oldlevlist && !localarray[lev+1]) 
      { ldiffarray[lev+1] = oldlevlist; oldlevlist = 0; }
   else if (!oldlevlist && localarray[lev+1]) 
      ldiffarray[lev+1] = new GridUnitList(*localarray[lev+1]);
   else if (!oldlevlist && !localarray[lev+1]) 
      ldiffarray[lev+1] = GridUnitListNULL;$*/

   if (oldlevlist) delete oldlevlist;
  }

/***************************************************************/
/* Checkpoint file open/close/seek  */
/***************************************************************/

int GridHierarchy::DAGH_OpenChkptIStream(const int p, 
					  ifstream& ifs)
{
 assert (chkptflag == DAGHTrue);

 char buf[128];
 ostrstream obuf(buf,sizeof(buf),ios::out);
 chkpt_filename(obuf,chkptname,p);
 ifs.open(buf);
 if (!ifs) return DAGHFalse;
 ifs.read((char*)&chkptpnum,sizeof(int));
 return DAGHTrue;
 
}

int GridHierarchy::DAGH_OpenChkptIStream(const int p, 
					  streampos*& chkptdir, 
					  char*& chkptnamedir,
					  ifstream& ifs)
{
 assert (chkptflag == DAGHTrue);

 char buf[128];
 ostrstream obuf(buf,sizeof(buf),ios::out);
 chkpt_filename(obuf,chkptname,p);
 ifs.open(buf);
 if (!ifs) return DAGHFalse;
 ifs.read((char*)&chkptpnum,sizeof(int));

 int dirnum = 0;
 ifs.read((char*)&dirnum,sizeof(int));

 const int namedirnum = (dirnum-1)*DAGHBktGFNameWidth;

 chkptdir = new streampos[dirnum];
 ifs.read((char*)chkptdir,sizeof(streampos)*dirnum);
 chkptnamedir = new char[namedirnum];
 ifs.read((char*)chkptnamedir,sizeof(char)*namedirnum);

 ifs.seekg(chkptdir[dirnum-1]);
 return DAGHTrue;
}

int GridHierarchy::DAGH_GetGFChkptIStream(const int p, 
					   const char* gfname, 
					   const int gfid,
					   ifstream& ifs)
{
 assert (chkptflag == DAGHTrue);

 char buf[128];
 ostrstream obuf(buf,sizeof(buf),ios::out);
 chkpt_filename(obuf,chkptname,p);
 ifs.open(buf);
 if (!ifs) return DAGHFalse;
 ifs.read((char*)&chkptpnum,sizeof(int));

 int dirnum = 0;
 ifs.read((char*)&dirnum,sizeof(int));

 const int namedirnum = (dirnum-1)*DAGHBktGFNameWidth;

 streampos* chkptdir = new streampos[dirnum];
 ifs.read((char*)chkptdir,sizeof(streampos)*dirnum);
 char* chkptnamedir = new char[namedirnum];
 ifs.read((char*)chkptnamedir,sizeof(char)*namedirnum);

 if (!strncmp(gfname,(chkptnamedir+gfid*DAGHBktGFNameWidth),
	      DAGHBktGFNameWidth)) {
   ifs.seekg(chkptdir[gfid]);
   return DAGHTrue;
 }
 else {
   for (register int i=0; i<dirnum-1; i++) 
     if (!strncmp(gfname,(chkptnamedir+i*DAGHBktGFNameWidth),
		  DAGHBktGFNameWidth)) {
       ifs.seekg(chkptdir[i]);
       return DAGHTrue;
     }
 }
 ifs.close();
 return DAGHFalse;
}

int GridHierarchy::DAGH_OpenChkptOStream(const int p, 
					  ofstream& ofs)
{
 assert (chkptflag == DAGHTrue);

 char buf[128];
 ostrstream obuf(buf,sizeof(buf),ios::out);
 chkpt_filename(obuf,chkptname,p);
 ofs.open(buf);
 if (!ofs) return DAGHFalse;
 const int pnum = comm_service::proc_num();
 ofs.write((char*)&pnum,sizeof(int));
 return DAGHTrue;
}

/***************************************************************/
/* Write Checkpoint file! */
/***************************************************************/
void GridHierarchy::DAGH_Checkpoint(const char* name)
  {
   const int me = comm_service::proc_me();
   const int num = comm_service::proc_num(); 

   /* Start checkpointing */
   DAGH_InitChkpt(name);
   ofstream ofs;
   int eflag = DAGH_OpenChkptOStream(me,ofs);
   assert (eflag == DAGHTrue);

   const int dirnum = gfnum+1;
   const int namedirnum = gfnum*DAGHBktGFNameWidth;
   streampos* chkptdir = new streampos[dirnum];
   char* chkptnamedir = new char[namedirnum];

   ofs.write((char*)&dirnum,sizeof(int));
   
   const streampos chkptdirpos = ofs.tellp();
   ofs.write((char*)chkptdir,sizeof(streampos)*dirnum);
   ofs.write((char*)chkptnamedir,sizeof(char)*namedirnum);
   chkptdir[dirnum-1] = ofs.tellp();
   ofs << *this;

   for (register int i=0; i<gfnum; i++)
     if (gflist[i] && gflist[i]->checkpoint()) { 
       chkptdir[i] =  ofs.tellp();
       strncpy(chkptnamedir+(i*DAGHBktGFNameWidth),
	       gflist[i]->gfname,DAGHBktGFNameWidth);
       gflist[i]->GF_Checkpoint(ofs);
     }
     else chkptdir[i] = 0;   

   ofs.seekp(chkptdirpos);
   ofs.write((char*)chkptdir,sizeof(streampos)*dirnum);
   ofs.write((char*)chkptnamedir,sizeof(char)*namedirnum);

   if (chkptdir) delete [] chkptdir;
   if (chkptnamedir) delete [] chkptnamedir;

   DAGH_CloseChkptOStream(ofs);
   DAGH_StopChkpt();
  }

/***************************************************************/
/* Utitlity routines.... */
/***************************************************************/
void GridHierarchy::wlb(double *wc) const
  { 
   assert (wc != 0);
   //if (!wc) wc = new double[rank];
   for (register int i=0;i<rank;i++)
     wc[i] = toWorld(dspecs[i],basebbox.lower(i),basebbox.stepsize(i));
  }

void GridHierarchy::wub(double *wc) const
  { 
   assert (wc != 0);
   //if (!wc) wc = new double[rank];
   for (register int i=0;i<rank;i++)
     wc[i] = toWorld(dspecs[i],basebbox.upper(i),basebbox.stepsize(i));
  }

void GridHierarchy::llb(int *lc) const
  { 
   assert (lc != 0);
   //if (!lc) lc = new int[rank];
   for (register int i=0;i<rank;i++) lc[i] = basebbox.lower(i);
  }

void GridHierarchy::lub(int *lc) const
  { 
   assert (lc != 0);
   //if (!lc) lc = new int[rank];
   for (register int i=0;i<rank;i++) lc[i] = basebbox.upper(i);
  }

void GridHierarchy::worldCoords(const int *lc, const int *ls, double *wc) const
  { 
   assert (wc != 0);
   //if (!wc) wc = new double[rank];
   for (register int i=0;i<rank;i++)
     wc[i] = toWorld(dspecs[i],lc[i],ls[i]);
  }
void GridHierarchy::worldStep(const int *ls, double *ws) const
  { 
   assert (ws != 0);
   //if (!ws) ws = new double[rank];
   for (register int i=0;i<rank;i++)
     ws[i] = ls[i] * dspecs[i].hfine;
  }

DCoords GridHierarchy::worldCoords(const int *lc, const int *ls) const
  { 
   DCoords wc(rank);
   for (register int i=0;i<rank;i++)
     wc(i) = toWorld(dspecs[i],lc[i],ls[i]);

   return wc;
  }
DCoords GridHierarchy::worldCoordsUpper(const int *lc, const int *ls) const
  { 
   DCoords wc(rank);
   for (register int i=0;i<rank;i++)
     wc(i) = toWorldUpper(dspecs[i],lc[i],ls[i],daghoverlap(i));

   return wc;
  }
DCoords GridHierarchy::worldCoordsLower(const int *lc, const int *ls) const
  { 
   DCoords wc(rank);
   for (register int i=0;i<rank;i++)
     wc(i) = toWorldLower(dspecs[i],lc[i],ls[i],daghoverlap(i));

   return wc;
  }
DCoords GridHierarchy::worldStep(const int *ls) const
  { 
   DCoords ws(rank);
   for (register int i=0;i<rank;i++)
     ws(i) = ls[i] * dspecs[i].hfine;

   return ws;
  }

Coords GridHierarchy::localCoords(double const *wc) const
  { 
   Coords lc(rank,0);
   for (register int i=0;i<rank;i++)
     lc(i) = toLocal(dspecs[i],wc[i]);
 
   return lc;
  }
Coords GridHierarchy::localStep(double const *ws) const
  { 
   Coords ls(rank,0);
   for (register int i=0;i<rank;i++)
     ls(i) = (int) (ws[i] / dspecs[i].hfine);
   return ls;
  }
void GridHierarchy::localCoords(double const *wc, int *lc) const
  { 
   assert (lc != 0);
   //if (!lc) lc = new int[rank];
   for (register int i=0;i<rank;i++)
     lc[i] = toLocal(dspecs[i],wc[i]);
  }
void GridHierarchy::localStep(double const *ws, int *ls) const
  { 
   assert (ls != 0);
   //if (!ls) ls = new double[rank];
   for (register int i=0;i<rank;i++)
     ls[i] = (int) (ws[i] / dspecs[i].hfine);
  }

/***************************************************************/
/* Global BoundingBox Queries */
/***************************************************************/
void GridHierarchy::glb_bboxlist(BBoxList& bbl, 
				 const int l,
				 const int type,
                                 const int ident) const
  {
   const int lev = levelnum(l);
   const int factor = daghfactor(ident);

   short olap[DAGHMaxRank];
   DAGH_InitOverlaps(type,olap);

   if (!bbl.isempty()) bbl.empty();
   register GridUnit* gu = 0;
   for (gu=complist->first();gu;gu=complist->next()) {
     if (!gu->guContains(lev)) continue;
     bbl.add(coarsen(gu->guBBox(lev,olap),factor));
   }
  }

void GridHierarchy::glb_mergedbboxlist(BBoxList& bbl, 
				       const int l, 
				       const int type,
                                       const int ident) const
  {
   const int lev = levelnum(l);
   const int factor = daghfactor(ident);

   short olap[DAGHMaxRank];
   DAGH_InitOverlaps(type,olap);

   const int num = (mindex+1)*comm_service::proc_num(); 
  
   short* flags = new short[num];
   for (register int i=0; i<num; i++) flags[i] = DAGHNull;

   if (!bbl.isempty()) bbl.empty();
   register GridUnit* gu = 0;
   register int idx = DAGHNull;
   for (gu=complist->first();gu;gu=complist->next()) {
     if (!gu->guContains(lev)) continue;
     idx = gu->guOwner()*(mindex+1) + gu->guIndex();
     if (flags[idx] == DAGHNull) {
       bbl.add(coarsen(gu->guMergedBBox(lev,olap),factor));
       flags[idx] = DAGHTrue;
     }
   }
   if (flags) delete [] flags;
  }

void GridHierarchy::glb_bboxlist(BBoxList& bbl, 
				 const int minl,
				 const int maxl,
				 const int type,
                                 const int ident) const
  {
   const int minlev = levelnum(minl);
   const int maxlev = levelnum(maxl);

   const int factor = daghfactor(ident);

   short olap[DAGHMaxRank];
   DAGH_InitOverlaps(type,olap);

   if (!bbl.isempty()) bbl.empty();
   register GridUnit* gu = 0;
   for (gu=complist->first();gu;gu=complist->next()) {
     if (!gu->guContains(minlev,maxlev)) continue;
     bbl.add(coarsen(gu->guBBox(minlev,maxlev,olap),factor));
   }
  }

void GridHierarchy::glb_mergedbboxlist(BBoxList& bbl, 
				       const int minl,
				       const int maxl, 
				       const int type,
                                       const int ident) const
  {
   const int minlev = levelnum(minl);
   const int maxlev = levelnum(maxl);
   const int factor = daghfactor(ident);

   short olap[DAGHMaxRank];
   DAGH_InitOverlaps(type,olap);

   const int num = (mindex+1)*comm_service::proc_num(); 
  
   short* flags = new short[num];
   for (register int i=0; i<num; i++) flags[i] = DAGHNull;

   if (!bbl.isempty()) bbl.empty();
   register GridUnit* gu = 0;
   register int idx = DAGHNull;
   for (gu=complist->first();gu;gu=complist->next()) {
     if (!gu->guContains(minlev,maxlev)) continue;
     idx = gu->guOwner()*(mindex+1) + gu->guIndex();
     if (flags[idx] == DAGHNull) {
       bbl.add(coarsen(gu->guMergedBBox(minlev,maxlev,olap),factor));
       flags[idx] = DAGHTrue;
     }
   }
   if (flags) delete [] flags;
  }

/***************************************************************/
/* Compress a GUL !*/
/***************************************************************/
void GridHierarchy::compress_gul(GridUnitList& gul) const
  {
   const int num = (mindex+1)*comm_service::proc_num(); 
  
   short* flags = new short[num];
   for (register int i=0; i<num; i++) flags[i] = DAGHNull;

   register GridUnit* gu = 0;
   register int idx = DAGHNull;
   for (gu=gul.first();gu;gu=gul.next()) {
     idx = gu->guOwner()*(mindex+1) + gu->guIndex();
     if (flags[idx] == DAGHNull) flags[idx] = DAGHTrue;
     else gul.remove();
   }
   if (flags) delete [] flags;
  }

/***************************************************************/
/* Multigrid Support */
/***************************************************************/
int GridHierarchy::DAGH_MultiGridLevels(const int level, const int ident) const
  {
    //const int sext = complist->smallest(levelnum(level));
   const int sext = complist->smallest_merged(levelnum(level));
   const int olap = daghoverlapCC_or_NCC();
   const int minn = 2 + olap;
   //int n = olap + ((unsigned)1 << sext);
   int n = olap + sext;
   int nl = 0;
   while ((n+(1-olap))%2 != 0 && n >= minn) { nl++; n = (n+olap)/2; }
   return ( (ident == DAGH_Main) ? nl : nl-1);
  }

/***************************************************************/
/* IO Routines */
/***************************************************************/

void GridHierarchy::DAGH_IOServe(void)
  { 
   if (comm_service::comminit() && io_end_server) {
#ifdef DEBUG_PRINT_COMM_IO
   (comm_service::log() << "GridHierarchy::DAGH_IOServe " 
                        << comm_service::proc_me() << " "
                        << "Serving ! "
                        << endl ).flush();
#endif
     comm_service::serve(*io_end_server->req());
   }
  }

/***************************************************************/
/* Print it..... */
/***************************************************************/
ostream&  operator << (ostream& os, const struct dimspec& ds)
  { 
   if (&ds == (struct dimspec *) NULL) return os;
   os << "[" << ds.low << "," << ds.high << "," << ds.h << "," << ds.n << "]"; 
   return os;
  }

ostream&  operator << (ostream& os, const struct MergedGridUnit& mgul)
  {
    os << "*************** Bounding Box ***************" << endl;
    os << mgul.bb << endl;
    os << "*************** GridUnitList ***************" << endl;
    os << mgul.gul;
    os << "***************              ***************" << endl;
    return os;
  }

ostream&  operator << (ostream& os, const GridHierarchy& gh)
  {
   if (&gh == (GridHierarchy *) NULL) return os;

   os << "DAGH(" << gh.rank << ") ";
   os << gh.tspecs;
   register int i;
   for (i=0;i<gh.rank;i++) os << gh.dspecs[i];
   os << endl;

   os << "BBBox: " << gh.basebbox << " ";
   os << "IBBox: " << gh.intbbox << " ";
   os << endl;

   os << "Mlev: " << gh.maxlev << " ";
   os << "Rby: " << gh.refby << " ";
   os << "Rlev: " << gh.reflev << " ";
   os << endl;

   os << "Clev: " << gh.crslev << " ";
   os << "Flev: " << gh.finelev << " ";
   os << "Levels: " << gh.levels << " ";
   os << endl;

   os << "BoundaryType: " << gh.bndrytype << " ";
   os << "AdaptBoundaryType: " << gh.adaptbndrytype << " ";
   os << "BoundaryWidth: " << gh.bndrywidth << " ";
   os << "ExternalGhostWidth: " << gh.extghostwidth << " ";
   os << endl;
   for (i=0;i<gh.rank;i++) os << gh.bndrybbox[2*i] 
			      << gh.bndrybbox[2*i+1];
   os << endl;

   MergedGridUnit** mgul;
   DAGHListLoop(*gh.mergedllist,mgul,MergedGridUnit*)
     os << **mgul << endl;
   DAGHEndLoop

   os << "NumGF: " << gh.gfnum << endl;
   for (i=0;i<gh.gfnum;i++) 
     os << "\t[" << gh.gflist[i]->GF_Name() << "] " << endl;

   os << endl;
   return os;
  }

/***************************************************************/
/* Binary IO. */
/***************************************************************/
ofstream&  operator << (ofstream& ofs, const GridHierarchy& gh)
  {
   if (&gh == (GridHierarchy *) NULL) return ofs;

   ofs.write((char*)&gh,sizeof(GridHierarchy));
  
   ofs.write((char*)gh.curtime[0],sizeof(int)*gh.levels);
   ofs.write((char*)gh.curtime[1],sizeof(int)*gh.levels);
   ofs.write((char*)gh.reftime[0],sizeof(int)*gh.levels);
   ofs.write((char*)gh.reftime[1],sizeof(int)*gh.levels);
   
   ofs << *gh.complist;
   ofs << *gh.locallist;
   ofs << *gh.origlocallist;

   return ofs;
  }

ifstream&  operator >> (ifstream& ifs, GridHierarchy& gh)
  {
   if (&gh == (GridHierarchy *) NULL) return ifs;

   const int me = comm_service::proc_me();
   const int num = comm_service::proc_num();

   /* Save pointers & Cheackpoint info */
   GridUnitList* tmp_complist = gh.complist;
   GridUnitList* tmp_locallist = gh.locallist;
   GridUnitList* tmp_oldcomplist = gh.oldcomplist;
   GridUnitList* tmp_oldlocallist = gh.oldlocallist;
   GridUnitList* tmp_origlocallist = gh.origlocallist;

   GridUnitList** tmp_localarray = gh.localarray;

   //GridUnitList** tmp_gdiffarray = gh.gdiffarray;
   //GridUnitList** tmp_ldiffarray = gh.ldiffarray;
  
   const int tmp_gfnum = gh.gfnum;
   GridFunctionVoid** tmp_gflist = gh.gflist;
   
   DAGHIOServerPing* tmp_io_complist_server = gh.io_complist_server;
   DAGHIOServerRcv * tmp_io_write_server = gh.io_write_server;
   DAGHIOServerSnd* tmp_io_read_server = gh.io_read_server;
   DAGHIOServerPing* tmp_io_end_server = gh.io_end_server;

   int old_chkptflag = gh.chkptflag;
   int old_chkptpnum = gh.chkptpnum;
   char old_chkptname[DAGHChkPtTagNameSize];
   strncpy(old_chkptname,gh.chkptname,DAGHChkPtTagNameSize);

   int* tmp_curtime0 = gh.curtime[0]; 
   int* tmp_curtime1 = gh.curtime[1]; 

   int* tmp_reftime0 = gh.reftime[0]; 
   int* tmp_reftime1 = gh.reftime[1]; 

   List<MergedGridUnit*>* tmp_mergedllist = gh.mergedllist;

   ifs.read((char*)&gh,sizeof(GridHierarchy));

   /* Reset pointers */
   gh.complist = tmp_complist;
   gh.locallist = tmp_locallist;
   gh.oldcomplist = tmp_oldcomplist;
   gh.oldlocallist = tmp_oldlocallist;
   gh.origlocallist = tmp_origlocallist;

   gh.localarray = tmp_localarray;

   gh.mergedllist = tmp_mergedllist;

   //gh.gdiffarray = tmp_gdiffarray;
   //gh.ldiffarray = tmp_ldiffarray;
   
   gh.gfnum = tmp_gfnum;
   gh.gflist = tmp_gflist;
   
   gh.io_complist_server = tmp_io_complist_server;
   gh.io_write_server = tmp_io_write_server;
   gh.io_read_server = tmp_io_read_server;
   gh.io_end_server = tmp_io_end_server;

   gh.chkptflag = old_chkptflag;
   gh.chkptpnum = old_chkptpnum;
   strncpy(gh.chkptname,old_chkptname,DAGHChkPtTagNameSize);

   gh.curtime[0] = tmp_curtime0;
   gh.curtime[1] = tmp_curtime1;

   gh.reftime[0] = tmp_reftime0;
   gh.reftime[1] = tmp_reftime1;

   register int i;
   /* Allocate Current Time Array */
   if (gh.curtime[0]) delete [] gh.curtime[0];
   gh.curtime[0] = new int[gh.levels]; /* DAGH_Main */
   if (gh.curtime[1]) delete [] gh.curtime[1];
   gh.curtime[1] = new int[gh.levels]; /* DAGH_Shadow */
   for (i=0;i<gh.levels;i++) 
     { gh.curtime[0][i] = gh.curtime[1][i] = 0; }

   /* Read Current Time Array */
   ifs.read((char*)gh.curtime[0],sizeof(int)*gh.levels);
   ifs.read((char*)gh.curtime[1],sizeof(int)*gh.levels);

   /* Allocate Refine Time Array */
   if (gh.reftime[0]) delete [] gh.reftime[0];
   gh.reftime[0] = new int[gh.levels]; /* DAGH_Main */
   if (gh.reftime[1]) delete [] gh.reftime[1];
   gh.reftime[1] = new int[gh.levels]; /* DAGH_Shadow */
   for (i=0;i<gh.levels;i++) 
     { gh.reftime[0][i] = gh.reftime[1][i] = 0; }

   /* Read Refine Time Array */
   ifs.read((char*)gh.reftime[0],sizeof(int)*gh.levels);
   ifs.read((char*)gh.reftime[1],sizeof(int)*gh.levels);

   /* Allocate and read Composite List */
   if (gh.complist) gh.complist->empty();
   else {
     gh.complist  = new GridUnitList;
     gh.complist->settag(me);
   }
   ifs >> *gh.complist;

   /* Allocate and read Local List */
   if (gh.locallist) gh.locallist->empty();
   else {
     gh.locallist  = new GridUnitList;
     gh.locallist->settag(me);
   }
   ifs >> *gh.locallist;

   /* Allocate and read Orig Composite List */
   if (gh.origlocallist) gh.origlocallist->empty();
   else {
     gh.origlocallist  = new GridUnitList;
     gh.origlocallist->settag(me);
   }
   ifs >> *gh.origlocallist;

   return ifs;
  }
