#ifndef CoordsIterator_h
#define CoordsIterator_h
#include "BBox.h"
#include "Coords.h"

class CoordsIterator {
	BBox b;
	int i[3];
	int r;

	void set(BBox& bi) {
		b = bi;
		for(int n=0;n<b.rank;n++)
			i[n]=b.lower(n);
		r = b.rank - 1;
	}
	void inc(int n) {
		i[n] += b.stepsize(n);
		if(n < r && i[n] > b.upper(n)) {
			i[n] = b.lower(n);
			inc(n+1);
		}
	}
public:
	CoordsIterator() {}
	CoordsIterator(BBox bi) { set(bi); }
	CoordsIterator& operator=(BBox& bi) {
		set(bi);
		return *this;
	}
	~CoordsIterator() {}
	void operator++() { inc(0); }
	void operator++(int) { inc(0); }
	int good() {
		return i[r] <= b.upper(r);
	}
	operator int() { return good(); }
	Coords operator*() { return Coords(r+1,i); }
};

inline ostream&
operator<<(ostream& o,CoordsIterator& bbi) {
	return o << *bbi;
}
#endif
