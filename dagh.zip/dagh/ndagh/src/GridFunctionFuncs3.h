#ifndef _included_GridFunctionFunc3_h
#define _included_GridFunctionFunc3_h

/*
*************************************************************************
*                                                                       *
* GridFunctionFunc3.h                                                   *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/*****************************************************************************/
/**** Use Pred-defined Functions  ****/
/*****************************************************************************/

/**** Initialization ****/
template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_Init(int const time, int const level, 
			                   GF_TYPE *args, int const cnt,
                                           int const ident)
  {
   if (!initialize()) return;
   assert (ifunc != 0);
   register int const t = dagh_timeindex(time,level);
   register int const l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) 
       (*ifunc)(FORTRAN_ARGS(gdb[t][l][i]->griddata(ident)), 
	        BOUNDING_BOX(gdb[t][l][i]->griddata(ident)),
                args, &cnt);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_Init(int const time, int const level, 
			                   BBox const &bb,
			                   GF_TYPE *args, int const cnt,
                                           int const ident)
  {
   if (!initialize()) return;
   assert (ifunc != 0);
   register int const t = dagh_timeindex(time,level);
   register int const l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i]) 
       (*ifunc)(FORTRAN_ARGS(gdb[t][l][i]->griddata(ident)), 
	        BOUNDING_BOX(bb),
                args, &cnt);
  }

/**** Update ****/
template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_Update(int const time_from, int const time_to, 
                                             int const level, 
			                     GF_TYPE *args, int const cnt,
                                             int const ident)
  {
   if (!update()) return;
   assert (ufunc != 0);
   register int const t_from = dagh_timeindex(time_from,level);
   register int const t_to = dagh_timeindex(time_to,level);
   register int const l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t_from][l][i] && gdb[t_to][l][i]) 
       (*ufunc)(FORTRAN_ARGS(gdb[t_from][l][i]->griddata(ident)), 
		FORTRAN_ARGS(gdb[t_to][l][i]->griddata(ident)),
	        BOUNDING_BOX(gdb[t_to][l][i]->griddata(ident)),
		args, &cnt);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_Update(int const time_from, int const time_to, 
                                             int const level, 
			                     BBox const &bb,
			                     GF_TYPE *args, int const cnt,
                                             int const ident)
  {
   if (!update()) return;
   assert (ufunc != 0);
   register int const t_from = dagh_timeindex(time_from,level);
   register int const t_to = dagh_timeindex(time_to,level);
   register int const l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t_from][l][i] && gdb[t_to][l][i]) 
       (*ufunc)(FORTRAN_ARGS(gdb[t_from][l][i]->griddata(ident)), 
		FORTRAN_ARGS(gdb[t_to][l][i]->griddata(ident)),
	        BOUNDING_BOX(bb),
		args, &cnt);
  }

/**** Prolong ****/
template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_Prolong(int const time_from, int const level_from,
                                              int const time_to, int const level_to, 
			                      GF_TYPE *args, int const cnt,
			                      int const ident)
  {
   if (!prolong()) return;
   assert (pfunc != 0);
   register int const fl = level_from;
   register int const ft = dagh_timeindex(time_from,fl);
   register int const tl = level_to;
   register int const tt = dagh_timeindex(time_to,tl);
   //assert (ft == tt); /* To Check */
   for (register int i=0; i<length; i++) {
     if (gdb[ft][fl][i] && gdb[tt][tl][i])  {
       (*pfunc)(FORTRAN_ARGS(gdb[ft][fl][i]->griddata(ident)), 
		FORTRAN_ARGS(gdb[tt][tl][i]->griddata(ident)),
	        BOUNDING_BOX(gdb[tt][tl][i]->griddata(ident)),
		args, &cnt);
     }
   }
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_Prolong(int const time_from, int const level_from,
                                              int const time_to, int const level_to, 
                                              BBox const &bb,
			                      GF_TYPE *args, int const cnt,
			                      int const ident)
  {
   if (!prolong()) return;
   assert (pfunc != 0);
   register int const fl = level_from;
   register int const ft = dagh_timeindex(time_from,fl);
   register int const tl = level_to;
   register int const tt = dagh_timeindex(time_to,tl);
   //assert (ft == tt); /* To Check */
   for (register int i=0; i<length; i++) {
     if (gdb[ft][fl][i] && gdb[tt][tl][i])  {
       (*pfunc)(FORTRAN_ARGS(gdb[ft][fl][i]->griddata(ident)), 
		FORTRAN_ARGS(gdb[tt][tl][i]->griddata(ident)),
	        BOUNDING_BOX(bb),
		args, &cnt);
     }
   }
  }

/**** Restrict ****/
template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_Restrict(int const time_from, int const level_from, 
                                               int const time_to, int const level_to, 
			                       GF_TYPE *args, int const cnt,
			                       int const ident)
  {
   if (!Restrict()) return;
   assert (rfunc != 0);
   register int const fl = level_from;
   register int const ft = dagh_timeindex(time_from,fl);
   register int const tl = level_to;
   register int const tt = dagh_timeindex(time_to,tl);
   //assert (ft == tt); /* To Check */
   for (register int i=0; i<length; i++) {
     if (gdb[ft][fl][i] && gdb[tt][tl][i])  {
       (*rfunc)(FORTRAN_ARGS(gdb[ft][fl][i]->griddata(ident)), 
		FORTRAN_ARGS(gdb[tt][tl][i]->griddata(ident)),
	        BOUNDING_BOX(gdb[tt][tl][i]->griddata(ident)),
		args, &cnt);
     }
   }
  }
template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_Restrict(int const time_from, int const level_from, 
                                               int const time_to, int const level_to, 
                                               BBox const &bb,
			                       GF_TYPE *args, int const cnt,
			                       int const ident)
  {
   if (!Restrict()) return;
   assert (rfunc != 0);
   register int const fl = level_from;
   register int const ft = dagh_timeindex(time_from,fl);
   register int const tl = level_to;
   register int const tt = dagh_timeindex(time_to,tl);
   //assert (ft == tt); /* To Check */
   for (register int i=0; i<length; i++) {
     if (gdb[ft][fl][i] && gdb[tt][tl][i])  {
       (*rfunc)(FORTRAN_ARGS(gdb[ft][fl][i]->griddata(ident)), 
		FORTRAN_ARGS(gdb[tt][tl][i]->griddata(ident)),
	        BOUNDING_BOX(bb),
		args, &cnt);
     }
   }
  }

/**** IO ****/
template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_IO(int const time, int const level,
			                 GF_TYPE *args, int const cnt,
                                         int const ident)
  {
   if (!io()) return;
   assert (iofunc != 0);
   register int const t = dagh_timeindex(time,level);
   register int const l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i])
       (*iofunc)(FORTRAN_ARGS(gdb[t][l][i]->griddata(ident)), 
	         BOUNDING_BOX(gdb[t][l][i]->griddata(ident)),
		 args, &cnt);
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_IO(int const time, int const level,
                                         BBox const &bb,
			                 GF_TYPE *args, int const cnt,
                                         int const ident)
  {
   if (!io()) return;
   assert (iofunc != 0);
   register int const t = dagh_timeindex(time,level);
   register int const l = level;
   for (register int i=0; i<length; i++)
     if (gdb[t][l][i])
       (*iofunc)(FORTRAN_ARGS(gdb[t][l][i]->griddata(ident)), 
	         BOUNDING_BOX(bb),
		 args, &cnt);
  }
#endif
