#ifndef _included_fastAlloc_h
#define _included_fastAlloc_h

/*
*********************************************************************************
*                              							*
* fastAlloc.h                           					*
*                              							*
* This file defines a simple memory block allocator for fixed-size memory   	*
* blocks.  									*
*                              							*
* This class is similar to the one described in Bjarne Stroustrup's "The C++   	*
* Programming Language", Second Edition.               				*
*                             							*
* Adapted from implementation by  Scott Kohn (skohn@cs.ucsd.edu)                *
*                              							*
*********************************************************************************
*/

#include <assert.h>

class fastAlloc 
  {
public:
   struct link { struct link *next; };  // A pointer structure for linked list
   struct longlink { 
      struct link *item; struct longlink *next;  
      inline longlink() :item(0), next(0) {} 
      inline ~longlink() { 
        if (item) delete [] (char*) item; 
        if (next) delete next; 
      }
   };
private:                                       
   unsigned int blocksize;              // Size of the block to allocate
   unsigned int nblocks;                // Number of blocks to allocate at a time
   link *head;                   // Head of the linked list
   longlink *top;                // Top of the linked list
   longlink *cur;                // Top of the current memory block
   fastAlloc(const fastAlloc&);         // Don't allow users to copy this class
   void operator = (const fastAlloc&);  // Don't allow users to assign this class
   void malloc();                       // Get some more memory space
public:
   fastAlloc(const unsigned int size, const unsigned int atatime);
   inline ~fastAlloc() { delete top; }

   inline void *alloc()
     {
      if (head == ((struct link *) 0)) malloc();
      struct link *block = head;
      head = block->next;
      return(block);
     }

   inline void free(void *block)
     {
      ((struct link *) block)->next = head;
      head = (struct link *) block;
     }
  };

#endif
