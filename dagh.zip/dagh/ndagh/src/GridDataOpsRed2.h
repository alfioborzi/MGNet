#ifndef _included_GridDataOpsRed_2_h
#define _included_GridDataOpsRed_2_h

/*
*************************************************************************
*                                                                       *
* GridDataOpsRed2.h                                                     *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/


/****************************** maxval ***************************************/

template <class Type>
Type GridData(2)<Type>::maxval (BBox const &where)

  {
    Type max_val = (Type) DAGHSmall;
    short flag = DAGHTrue;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(2)<Type> &dst = *this;

       BeginFastIndex2(dst, dst._bbox, dst._data, Type);

       for_2(i, j, intersection, max_step)
         if (flag == DAGHTrue) 
           { max_val = FastIndex2(dst,i,j); flag = DAGHFalse; }
         else if (FastIndex2(dst,i,j) > max_val) 
           max_val = FastIndex2(dst,i,j);
       end_for

       EndFastIndex2(dst);

      }
    return (max_val);
  }

/************************************************************************/

/****************************** minval ***************************************/

template <class Type>
Type GridData(2)<Type>::minval (BBox const &where)

  {
    Type min_val = MAXLIM(Type);
    short flag = DAGHTrue;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(2)<Type> &dst = *this;

       BeginFastIndex2(dst, dst._bbox, dst._data, Type);

       for_2(i, j, intersection, max_step)
         if (flag == DAGHTrue) 
           { min_val = FastIndex2(dst,i,j); flag = DAGHFalse; }
         else if (FastIndex2(dst,i,j) < min_val) 
	   min_val = FastIndex2(dst,i,j);
       end_for

       EndFastIndex2(dst);

      }
    return (min_val);
  }

/************************************************************************/

/****************************** sum ***************************************/

template <class Type>
Type GridData(2)<Type>::sum (BBox const &where)

  {
    Type sum_val = (Type) 0;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(2)<Type> &dst = *this;

       BeginFastIndex2(dst, dst._bbox, dst._data, Type);

       for_2(i, j, intersection, max_step)
         sum_val += FastIndex2(dst,i,j);
       end_for

       EndFastIndex2(dst);

      }
    return (sum_val);
  }

/************************************************************************/

/****************************** product ***************************************/

template <class Type>
Type GridData(2)<Type>::product (BBox const &where)

  {
    Type prod_val = (Type) 1;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(2)<Type> &dst = *this;

       BeginFastIndex2(dst, dst._bbox, dst._data, Type);

       for_2(i, j, intersection, max_step)
         prod_val *= FastIndex2(dst,i,j);
       end_for

       EndFastIndex2(dst);

      }
    return (prod_val);
  }

/************************************************************************/

/****************************** moment1 ***************************************/
template <class Type>
Type GridData(2)<Type>::moment1 (int const axis, BBox const &where)

  {
    Type m1 = (Type) 0;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(2)<Type> &dst = *this;

       BeginFastIndex2(dst, dst._bbox, dst._data, Type);

       if (axis == DAGH_X) {
         for_2(i, j, intersection, max_step)
           m1 += FastIndex2(dst,i,j) * i;
         end_for
       }
       else if (axis == DAGH_Y) {
         for_2(i, j, intersection, max_step)
           m1 += FastIndex2(dst,i,j) * j;
         end_for
       }

       EndFastIndex2(dst);
      }
    return (m1); 
  }
/************************************************************************/

/****************************** sumsqrd ***************************************/

template <class Type>
void GridData(2)<Type>::sumsqrd (BBox const &where, Type &s, int &c)

  {
    s = (Type) 0;
    c = 0;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(2)<Type> &dst = *this;

       BeginFastIndex2(dst, dst._bbox, dst._data, Type);

       for_2(i, j, intersection, max_step)
         s += FastIndex2(dst,i,j) * FastIndex2(dst,i,j);
  	 c++;
       end_for

       EndFastIndex2(dst);

      }
  }

/************************************************************************/

#endif
