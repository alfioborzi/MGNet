/*
*********************************************************************************
*                                                                               *
* fastAlloc.C                                                                   *
*                                                                               *
* This file defines a simple memory block allocator for fixed-size memory       *
* blocks.                                                                       *
* This class is similar to the one described in Bjarne Stroustrup's "The C++    *
* Programming Language", Second Edition.                                        *
*                                                                               *
* Adapted from implementation by  Scott Kohn (skohn@cs.ucsd.edu)                *
*                                                                               *
* Author Manish Parashar: <parashar@cs.utexas.edu>				*
*                                                                              	*
*********************************************************************************
*/

#include "fastAlloc.h"

#define MINALLOC (1)

inline unsigned int max(const unsigned int a, const unsigned int b)
  {
   return((a > b) ? a : b);
  }

/*
*************************************************************************
*									*
* fastAlloc::fastAlloc(const unsigned int size,				*
*                      const unsigned int atatime)			*
*									*
* Class constructor fastAlloc() creates a class instance which returns	*
* blocks of size bytes.  When new blocks are allocated, atatime blocks	*
* are allocated.							*
*									*
* We want to align the data on powers-of-two boundaries 4, 8, or 16	*
* since many architectures restrict the address of some data objects	*
* such as doubles.							*
*									*
*************************************************************************
*/

fastAlloc::fastAlloc(const unsigned int size, const unsigned int atatime)
  {
   const unsigned int block = max(size, sizeof(struct link *));
   const unsigned int align = ((block > 8) ? 16 : ((block > 4) ? 8 : 4));
   blocksize = (block+align-1) & (~(align-1));
   nblocks = max(atatime, MINALLOC);
   head = ((struct link *) 0);
   top = new longlink;
   cur = top;
  }

/*
*************************************************************************
*									*
* fastAlloc::malloc()							*
*									*
* Function malloc() allocates new memory, which is linked into the free	*
* memory list.								*
*									*
*************************************************************************
*/

void fastAlloc::malloc()
  {
   char *chunk, *end;

   chunk = new char[blocksize*nblocks];
   assert (chunk != 0);

   end = chunk+(nblocks-1)*blocksize;
   for (char *p = chunk; p < end; p += blocksize)
      ((struct link *) p)->next = (struct link *) (p+blocksize);

   cur->item = head = (struct link *) chunk;
   if (!cur->next) cur->next = new longlink;
   cur = cur->next;
   ((struct link *) end)->next = ((struct link *) 0);
  }
