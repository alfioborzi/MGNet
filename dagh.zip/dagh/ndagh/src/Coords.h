#ifndef _included_Coords_h
#define _included_Coords_h

/*
*************************************************************************
*									*
* Coords.h								*
*									*
* This class implements a point in the computational domain.		*
* This class is sort of an adaptation and extension of the from Class 	*
* PointX of LPARX developed by  Scott Kohn (skohn-at-cs.ucsd.edu)       *
*									*
* Author:  Manish Parashar (parashar@cs.utexas.edu)			*
*									*
*************************************************************************
*/

#include "lparx_copyright.h"
#include <iostream.h>
#include <fstream.h>
#include <assert.h>

#define CoordsMaxDim	(3)

#define CoordsNULL	((Coords *)NULL)

class CoordsIterator;

class Coords
  {
   friend istream& operator >> (istream& s, Coords& c);
   friend ostream& operator << (ostream& s, const Coords& c);
   friend ifstream& operator >> (ifstream& s, Coords& c);
   friend ofstream& operator << (ofstream& s, const Coords& c);

   int c[CoordsMaxDim];

public:
   int rank;
   static class Coords _empty_coords;

public:
   typedef CoordsIterator Iterator;

   inline Coords(void) : rank(0) 
     { c[0] = 0; c[1] = 0; c[2] = 0; }
   /*$inline Coords(int const r) : rank(r) 
     { c[0] = 0; c[1] = 0; c[2] = 0; }$*/
   inline Coords(int const r, int const val) : rank(r)
     { c[0] = val; c[1] = val; c[2] = val; }

   inline Coords(int const r, int const *val) : rank(r)
     { register int i; for (i=0; i<rank; i++) c[i] = val[i]; }

   inline Coords(Coords const &other) : rank(other.rank)
	{ c[0] = other.c[0]; c[1] = other.c[1]; c[2] = other.c[2]; }

   /* Specific constructors for 2 & 3 D */
   inline Coords(int const r, int const i, int const j) : rank(r) 
	{ assert(r == 2); c[0] = i; c[1] = j; }
   inline Coords(int const r, int const i, int const j, int const k) : rank(r) 
	{ assert(r == 3); c[0] = i; c[1] = j; c[2] = k; }

   Coords &operator = (Coords const &rhs)
	{ 
          rank = rhs.rank, 
          c[0] = rhs.c[0]; c[1] = rhs.c[1]; c[2] = rhs.c[2]; 
          return *this;
        }

   inline ~Coords() {}

   /* Some simple operators on Coords -- const and non-const ones */
   
   inline int& operator () (int const i) { return(c[i]); }
   inline int operator () (int const i) const { return(c[i]); }

   inline int * operator () (void) { return(c); }
   inline int const *operator () (void) const { return(c); }

   inline operator int * () { return(c); }
   inline operator const int * () const { return(c); }

   /* For the clustering hdf calls */
   inline operator long int * () { return((long int *)c); }
   inline operator const long int * () const { return((long int *)c); }

   /* Define all of the operators between two Coords */
#define Point_Point_Operator(ope,op)                            \
   Coords& operator ope (Coords const &rhs)                     \
     {                                                          \
      c[0] ope rhs.c[0];                                        \
      if (rank>1) c[1] ope rhs.c[1];                            \
      if (rank>2) c[2] ope rhs.c[2];                            \
      return(*this);                                            \
     }                                                          \
   Coords operator op (Coords const &rhs) const                 \
     {                                                          \
      Coords coords(*this);                                     \
      coords ope rhs;                                           \
      return(coords);                                           \
     }
   Point_Point_Operator(+=,+)
   Point_Point_Operator(-=,-)
   Point_Point_Operator(*=,*)
   Point_Point_Operator(/=,/)
   Point_Point_Operator(%=,%)
#undef Point_Point_Operator

   /* Define all of the operators between a point and an integer */
#define Point_Scalar_Operator(ope,op)                           \
   Coords& operator ope (int const rhs)                         \
     {                                                          \
      c[0] ope rhs;                                             \
      if (rank>1) c[1] ope rhs;                                 \
      if (rank>2) c[2] ope rhs;                                 \
      return(*this);                                            \
     }                                                          \
   Coords operator op (int const rhs) const                     \
     {                                                          \
      Coords coords(*this);                                     \
      coords ope rhs;                                           \
      return(coords);                                           \
     }
   Point_Scalar_Operator(+=,+)
   Point_Scalar_Operator(-=,-)
   Point_Scalar_Operator(*=,*)
   Point_Scalar_Operator(/=,/)
   Point_Scalar_Operator(%=,%)
#undef Point_Scalar_Operator

   /* Define the negation operator for a point */
   inline Coords operator - () const
     { 
       Coords coords(rank,0);
       coords.c[0] = -c[0]; coords.c[1] = -c[1]; coords.c[2] = -c[2]; 
       return(coords);
     }

   /* Define the equality and inequality operators for Coords */
   inline int operator != (Coords const &rhs) const
     {
      return ( ((rank > 0) && (c[0] != rhs.c[0])) || 
               ((rank > 1) && (c[1] != rhs.c[1])) || 
               ((rank > 2) && (c[2] != rhs.c[2]))
             ) ;
     }
   inline int operator == (Coords const &rhs) const
     { return(!(*this != rhs)); }

   /* Define the greater-than & less-than operators for Coords */
   inline int operator > (Coords const &rhs) const
     {
      return (!(((rank > 0) && (c[0] <= rhs.c[0])) || 
               ((rank > 1) && (c[1] <= rhs.c[1])) || 
               ((rank > 2) && (c[2] <= rhs.c[2])))
             ) ;
     }
   inline int operator < (Coords const &rhs) const
     {
      return (!(((rank > 0) && (c[0] >= rhs.c[0])) || 
               ((rank > 1) && (c[1] >= rhs.c[1])) || 
               ((rank > 2) && (c[2] >= rhs.c[2])))
             ) ;
     }

    inline void setval(int const val)
      { c[0] = val; c[1] = val; c[2] = val; }
    inline void setval(Coords const rhs)
      { c[0] = rhs.c[0]; c[1] = rhs.c[1]; c[2] = rhs.c[2]; }
  
   /* Define elementwise minimum and maximum functions for Coords */
   inline void min(Coords const &rhs)
     {
       //assert (rank == rhs.rank);
       c[0] = (rhs.c[0] < c[0]) ? rhs.c[0] : c[0];
       c[1] = (rank > 1 && rhs.c[1] < c[1]) ? rhs.c[1] : c[1];
       c[2] = (rank > 2 && rhs.c[2] < c[2]) ? rhs.c[2] : c[2];
     }

   inline void max(Coords const &rhs)
     {
       //assert (rank == rhs.rank);
       c[0] = (rhs.c[0] > c[0]) ? rhs.c[0] : c[0];
       c[1] = (rank > 1 && rhs.c[1] > c[1]) ? rhs.c[1] : c[1];
       c[2] = (rank > 2 && rhs.c[2] > c[2]) ? rhs.c[2] : c[2];
     }

   inline Coords getmin(Coords const &rhs) const
     { Coords other(*this); other.min(rhs); return other; }

   inline Coords getmax(Coords const &rhs) const
     { Coords other(*this); other.max(rhs); return other; }
  };

inline Coords max(const Coords& a, const Coords &b)
       { return(a.getmax(b)); }
inline Coords min(const Coords& a, const Coords &b)
       { return(a.getmin(b)); }


#ifdef __ENABLE_INLINE__
#include "Coords.inline"
#endif

ostream& operator << (ostream& s, const Coords& c);
istream& operator >> (istream& s, Coords& c);
ifstream& operator>>(ifstream& s, Coords& c);
ofstream& operator<<(ofstream& s, const Coords& c);

#endif

