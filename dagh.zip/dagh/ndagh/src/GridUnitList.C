/*
************************************************************************* 
*                                                                       *
* class GridUnitList							*
*                                                                       *
* Class GridUnitList implements a linked list of GridUnits and provides	*
* the routines to manipulate this list.					*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/*
*************************************************************************
*                                                                       *
* GridUnitList.C                                                        *
*                                                                       *
*************************************************************************
*/

#include "GridUnitList.h"

#ifndef __ENABLE_INLINE__
#include "GridUnitList.inline"
#endif

#ifdef DEBUG_PRINT
#include "CommServer.h"
#endif

/*************************************************************************/
static char const filename[] = "GridUnitList.C";

static void warn( const char msg[] )
  { cerr << filename << ":" << msg << "\n"; }

static void abort( const char msg[])
  { warn(msg); exit(-1); }
/*************************************************************************/

/*
*************************************************************************
*                                                                       *
* GridUnitList constructors from an array of GridUnitLists per level	*
* (The other constructors are in the GridUnitList.inline file)		*
*                                                                       *
*************************************************************************
*/

GridUnitList::GridUnitList(GridUnitList**& levarray)
	: Bucket<GridUnit>(DefBucketSize), tag(DAGHNull), 
	  num(0)
  {
   register GridUnitList *gul = levarray[0];
   if (gul == GridUnitListNULL) return;
   tag = gul->tag;
   register GridUnit const *tmpgu = gul->first();
   register const int nlev = tmpgu->guLevels();

   for (;tmpgu;tmpgu=gul->next()) add(*tmpgu);

   for (register int i=1;i<nlev;i++) {
     if (levarray[i])  {
       gul = levarray[i];
       tmpgu = gul->first();
       register GridUnit const *gu = first();
       for (;tmpgu;tmpgu=gul->next()) {
         //assert (tmpgu && gu);
         for (;gu;gu=next()) {
	   if (*tmpgu == *gu)
             { refine(); gu=next(); break; }
	   else if (*gu >= *tmpgu) {
             if (gu->guExtent(gu->crslev) <= 0) {
               refine(); break;
             }
	     else {  
               decompose(tmpgu->baselev - gu->baselev);
             }
           }
	   else if (*gu <= *tmpgu)
             { gul->decompose(gu->baselev - tmpgu->baselev); break; }
	 }
         if (tmpgu && !gu) gu = first();
       }
     }
   }
  }

/*
*************************************************************************
*                                                                       *
* The overloaded assignment operator					*
*                                                                       *
*************************************************************************
*/

GridUnitList& GridUnitList::operator = (const GridUnitList& cother)
  {
    GridUnitList &other = (GridUnitList &)cother;
    union record *tmpcur = other.currec();
    empty();
    GridUnit *gu = 0;
    for (gu=other.first();gu;gu=other.next()) {
      add(*gu);
    }
    assert(num==other.num);
    other.setcurrec(tmpcur);
    return *this;
  }

/*
*************************************************************************
*                                                                       *
* Operate between GridUnitLists !					*
* -= : difference (deletes all overlaps with the rhs)			*
* *= : intersetion							*
* The following allocate a new GUL and returns a pointer to it		*
* -  : abs difference (returns a GUl with all GU in lhs or rhs but	*
       not both)							*
* *  : intersection 							*
* +  : union 								*
*                                                                       *
*************************************************************************
*/

void GridUnitList::operator -= (GridUnitList const &rhs)
  {
   GridUnitList *diff = this;
   GridUnitList r(rhs);
   register GridUnit const *rhsgu = r.first();
   register GridUnit *gu = diff->first();
   for (;rhsgu;rhsgu=r.next())  {
     for (;gu;gu=diff->next()) {
       if (*rhsgu == *gu)
         { diff->remove(); break; }
       else if (*gu >= *rhsgu)
         diff->decompose(rhsgu->baselev - gu->baselev);
       else if (*gu <= *rhsgu)
         { r.decompose(gu->baselev - rhsgu->baselev); break; }
     }
     if (!gu) {
       gu=diff->first();
     }
   }
  }

GridUnitList *GridUnitList::operator - (GridUnitList const &rhs)
  {
   GridUnitList *diff = new GridUnitList(*this);
   GridUnitList r(rhs);
   GridUnitList tmpd;
   register GridUnit const *rhsgu = r.first();
   register GridUnit *gu = diff->first();
   for (;rhsgu;rhsgu=r.next())  {
     for (;gu;gu=diff->next()) {
       if (*rhsgu == *gu)
         { diff->remove(); break; }
       else if (*gu >= *rhsgu)
         diff->decompose(rhsgu->baselev - gu->baselev);
       else if (*gu <= *rhsgu)
         { r.decompose(gu->baselev - rhsgu->baselev); break; }
     }
     if (!gu) {
       tmpd.add(*rhsgu);
       gu=diff->first();
     }
   }
   register GridUnit const *tmpgu = tmpd.first();
   gu=diff->first();
   for (;tmpgu;tmpgu=tmpd.next()) {
     for (;gu;gu=diff->next()) {
       if (tmpgu->guBaseIndex() < gu->guBaseIndex())
         { diff->prev(); diff->insert(*tmpgu); gu = diff->next(); break; }
     }
     if (!gu) diff->add(*tmpgu);
   }
   
   return diff;
  }

void GridUnitList::operator *= (GridUnitList const &rhs)
  {
   GridUnitList *intersect = this;
   GridUnitList r(rhs);
   register GridUnit const *rhsgu = r.first();
   register GridUnit *gu = intersect->first();
   for (;gu;gu=intersect->next()) {
     for (;rhsgu;rhsgu=r.next())  {
       if (*rhsgu == *gu) break;
       else if (*gu >= *rhsgu)
         { intersect->decompose(rhsgu->baselev - gu->baselev); break; }
       else if (*gu <= *rhsgu)
         { r.decompose(gu->baselev - rhsgu->baselev); }
     }
     if (!rhsgu) {
       intersect->remove();
       rhsgu = r.first();
     }
   }
  }

GridUnitList *GridUnitList::operator * (GridUnitList const &rhs)
  {
   GridUnitList *intersect = new GridUnitList(*this);
   GridUnitList r(rhs);
   register GridUnit const *rhsgu = r.first();
   register GridUnit *gu = intersect->first();
   for (;gu;gu=intersect->next()) {
     for (;rhsgu;rhsgu=r.next())  {
       if (*rhsgu == *gu) break;
       else if (*gu >= *rhsgu)
         { intersect->decompose(rhsgu->baselev - gu->baselev); break; }
       else if (*gu <= *rhsgu)
         { r.decompose(gu->baselev - rhsgu->baselev); }
     }
     if (!rhsgu) {
       intersect->remove();
       rhsgu = r.first();
     }
   }
   
   return intersect;
  }

GridUnitList *GridUnitList::operator + (GridUnitList const &rhs)
  {
   GridUnitList *sum = new GridUnitList(*this);
   GridUnitList r(rhs);
   GridUnitList tmpu;
   register GridUnit const *rhsgu = r.first();
   register GridUnit *gu = sum->first();
   for (;rhsgu;rhsgu=r.next())  {
     for (;gu;gu=sum->next()) {
       if (*rhsgu == *gu) break;
       else if (*gu >= *rhsgu)
         sum->decompose(rhsgu->baselev - gu->baselev);
       else if (*gu <= *rhsgu)
         { r.decompose(gu->baselev - rhsgu->baselev); break; }
     }
     if (!gu) {
       tmpu.add(*rhsgu);
       gu=sum->first();
     }
   }

   register GridUnit const *tmpgu = tmpu.first();
   gu=sum->first();
   for (;tmpgu;tmpgu=tmpu.next()) {
     for (;gu;gu=sum->next()) {
       if (tmpgu->guBaseIndex() < gu->guBaseIndex())
         { sum->prev(); sum->insert(*tmpgu); gu = sum->next(); break; }
     }
     if (!gu) sum->add(*tmpgu);
   }
   
   return sum;
  }

/*
*************************************************************************
*                                                                       *
* Operations with a BBox & BBoxList					*
* *= : intersetion							*
* *  : intersection 							*
* intersect : a more specialized intersection				*
* Note: * allocates a new GUL and returns a pointer to it		*
*                                                                       *
*************************************************************************
*/

void GridUnitList::operator *= (BBox const &rhs)
  {
   if (rhs.empty()) {
     empty();
   }
   else {
     register GridUnit *gu = first();
     BBox bb;
     for (;gu;gu=next()) {
       int lev = gu->guFineLev();
       bb = gu->guBBox(lev);
       if (bb <= rhs) ;
       else if (!(bb*rhs).empty()) decompose();
       else remove(); 
     }
   }
  }

GridUnitList *GridUnitList::operator * (BBox const &rhs)
  {
   GridUnitList *intersect = new GridUnitList;

   if (!rhs.empty()) {
     register GridUnit *gu = first();
     BBox bb;
     for (;gu;gu=next()) {
      int lev = gu->guFineLev();
       bb = gu->guBBox(lev);
       if (!(rhs * bb).empty()) {
          intersect->add(*gu);
       }
     }
   }
   return intersect;
  }

GridUnitList *GridUnitList::operator * (BBoxList const &crhs)
  {
   BBoxList &rhs = (BBoxList &) crhs;
   union record *tmpcur = rhs.currec();

   GridUnitList *intersect = new GridUnitList;

   register BBox *rhsbb = 0;

   BBox bb;
   int lev = 0;
   register GridUnit *gu = first();
   for (;gu;gu=next()) {
     lev = gu->guFineLev();
     bb = gu->guBBox(lev);
     for (rhsbb=rhs.first();rhsbb;rhsbb=rhs.next()) {
       if (!rhsbb->empty() && !(*rhsbb * bb).empty()) {
         intersect->add(*gu);
         break;
       }
     }
   }
   rhs.setcurrec(tmpcur);
   return intersect;
  }

void GridUnitList::intersect(BBox const &rhs, const int lev,
                             GridUnitList &gul, const int olap,
                             const int extgh)
  {
   gul.empty();
   if (!rhs.empty()) {
     register GridUnit *gu = first();
     BBox bb;
     for (;gu;gu=next()) {
       bb = gu->guBBox(lev,olap,extgh);
       if (!(rhs * bb).empty()) {
          gul.add(*gu);
       }
     }
   }
  }

void GridUnitList::intersect(BBoxList const &crhs, const int lev,
                             GridUnitList &gul, const int olap, 
                             const int extgh)
  {
   BBoxList &rhs = (BBoxList &) crhs;
   union record *tmpcur = rhs.currec();

   gul.empty();

   register BBox *rhsbb = 0;

   BBox bb;
   register GridUnit *gu = first();
   for (;gu;gu=next()) {
     bb = gu->guBBox(lev,olap,extgh);
     if(!bb.empty()) { 
       for (rhsbb=rhs.first();rhsbb;rhsbb=rhs.next()) {
         if (!rhsbb->empty() && !(*rhsbb * bb).empty()) {
           gul.add(*gu);
           break;
         }
       }
     }
   }

   rhs.setcurrec(tmpcur);
  }

void GridUnitList::intersect(BBox const &rhs, const int lev,
                             GridUnitList &gul, const short* olap,
                             const int extgh)
  {
   gul.empty();
   if (!rhs.empty()) {
     register GridUnit *gu = first();
     BBox bb;
     for (;gu;gu=next()) {
       bb = gu->guBBox(lev,olap,extgh);
       if (!(rhs * bb).empty()) {
          gul.add(*gu);
       }
     }
   }
  }

void GridUnitList::intersect(BBoxList const &crhs, const int lev,
                             GridUnitList &gul, const short* olap, 
                             const int extgh)
  {
   BBoxList &rhs = (BBoxList &) crhs;
   union record *tmpcur = rhs.currec();

   gul.empty();

   register BBox *rhsbb = 0;

   BBox bb;
   register GridUnit *gu = first();
   for (;gu;gu=next()) {
     bb = gu->guBBox(lev,olap,extgh);
     if(!bb.empty()) { 
       for (rhsbb=rhs.first();rhsbb;rhsbb=rhs.next()) {
         if (!rhsbb->empty() && !(*rhsbb * bb).empty()) {
           gul.add(*gu);
           break;
         }
       }
     }
   }

   rhs.setcurrec(tmpcur);
  }

/*
*************************************************************************
*                                                                       *
* Set GridUnit information based on a sub GUL				*
*                                                                       *
*************************************************************************
*/

void GridUnitList::setindex(const GridUnitList& cgul, const int idx)
  {
   GridUnitList &gul = (GridUnitList &) cgul;
   union record *rhstmpcur = gul.currec();
   union record *tmpcur = currec();

   register GridUnit *g = first();
   register GridUnit *rhsg = 0;
   for ( rhsg = gul.first(); rhsg != GridUnitNULL;  rhsg = gul.next() )
      for ( ; g != GridUnitNULL;  g = next() )
        if (*g == *rhsg) { g->index = idx; break; }

   gul.setcurrec(rhstmpcur);
   setcurrec(tmpcur);
  }

void GridUnitList::setowner(const GridUnitList& cgul, const int p)
  {
   GridUnitList &gul = (GridUnitList &) cgul;
   union record *rhstmpcur = gul.currec();
   union record *tmpcur = currec();

   register GridUnit *g = first();
   register GridUnit *rhsg = 0;
   for ( rhsg = gul.first(); rhsg != GridUnitNULL;  rhsg = gul.next() )
     for ( ; g != GridUnitNULL;  g = next() )
       if (*g == *rhsg) { g->owner = p; break; }

   gul.setcurrec(rhstmpcur);
   setcurrec(tmpcur);
  }

void GridUnitList::setlowindex(const GridUnitList& cgul, const dMapIndex& li)
  {
   GridUnitList &gul = (GridUnitList &) cgul;
   union record *rhstmpcur = gul.currec();
   union record *tmpcur = currec();

   register GridUnit *g = first();
   register GridUnit *rhsg = 0;
   for ( rhsg = gul.first(); rhsg != GridUnitNULL;  rhsg = gul.next() )
     for ( ; g != GridUnitNULL;  g = next() )
       if (*g == *rhsg) { g->lowindex = li; break; }

   gul.setcurrec(rhstmpcur);
   setcurrec(tmpcur);
  }

void GridUnitList::setmergedbbox(const GridUnitList& cgul, const BBox& mbb)
  {
   GridUnitList &gul = (GridUnitList &) cgul;
   union record *rhstmpcur = gul.currec();
   union record *tmpcur = currec();

   register GridUnit *g = first();
   register GridUnit *rhsg = 0;
   for ( rhsg = gul.first(); rhsg != GridUnitNULL;  rhsg = gul.next() )
      for ( ; g != GridUnitNULL;  g = next() )
        if (*g == *rhsg) { g->mbb = mbb; break; }

   gul.setcurrec(rhstmpcur);
   setcurrec(tmpcur);
  }

/*
*************************************************************************
*                                                                       *
* Partition GUL across processors...					*
*                                                                       *
*************************************************************************
*/

void GridUnitList::partition(GridUnitList*& locallist, dMapIndex**& partitions, 
                             const int np, const int me, const int minw, 
                             const short* olap)
  { 
    if (num == 0) abort("partitioning an empty list");
    if (np == 0) abort("num of procs == 0");

    if (partitions) {
      register int i;
      for (i=0;i<np;i++)
        if (partitions[i]) { delete partitions[i]; partitions[i] = 0; }
    }
    else {
     partitions = new dMapIndex *[np];
      for (register int i=0;i<np;i++) partitions[i] = 0;
    }

    if (locallist) locallist->empty();
    else {
      locallist = new GridUnitList;
      locallist->settag(me);
    }

    unsigned long work = load(olap);
    unsigned long thresh = (unsigned) ((1.0*(work/np))+0.5);
    register unsigned long curthresh = thresh;

    int p = 0;
    unsigned long tmpw = 0, w = 0;

    register GridUnit *tmpgu = first();
    partitions[p] = new dMapIndex(tmpgu->baseindex);

    int cnt;
    for (cnt=0;tmpgu;cnt++,tmpgu=next()) {
      w += (tmpw = tmpgu->guWork(olap));
     
#ifdef DEBUG_PRINT_GC
     ( comm_service::log() << "\n***** Partitioning: "
                           << cnt << " " << p << " "
                           << tmpgu->guBaseIndex()  << " "
                           << *currec()
                           << "\n"
                           ).flush();

#endif

      if (w <= curthresh) {

#ifdef DEBUG_PRINT_GC
     if (p>=np)
     ( comm_service::log() << "\n************* Current Composite List *************\n"
                           << *this
                           << "\n************* ***************** *************\n"
                           << "\n************* Current Bucket *************\n"
                           << *((SimpleBucketVoid *) this)
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

        assert (p<np); 
        tmpgu->owner = p;
        if (p == me)  locallist->add(*tmpgu); 
        if(!partitions[p]) partitions[p] = new dMapIndex(tmpgu->baseindex);
      }
      else if (w-curthresh < tmpw/4) {

#ifdef DEBUG_PRINT_GC
     if (p>=np)
     ( comm_service::log() << "\n************* Current Composite List *************\n"
                           << *this
                           << "\n************* ***************** *************\n"
                           << "\n************* Current Bucket *************\n"
                           << *((SimpleBucketVoid *) this)
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

        assert(p<np);
        tmpgu->owner = p;
        if (p == me)  locallist->add(*tmpgu);
        p++; 
        curthresh = w + (unsigned) ((1.0*((work-w)/(np-p)))+0.5);
      }
      //else if (tmpw > thresh || tmpw >= ThresholdLoad) {
      else if (tmpw > thresh && tmpgu->guExtent(tmpgu->minlev) > minw) { 
	w -= tmpw; 
        cnt--;
        unsigned long oldwork = work;
        decompose(); 
        work = load(olap);

#ifdef DEBUG_PRINT_GC
     ( comm_service::log() << "\n************* After Decompose *************\n"
                           << "Cur Proc:" << p << " "
                           << tmpgu->guBaseIndex() << " "
                           << *currec() << "\n"
                           << "Cur GU:" << *current() << "\n"
                           //<< (current())->guOwner() << "  "
                           //<< (current())->guBaseIndex() << "\n"
                           << "\n************* ***************** *************\n"
                           //<< *this
                           //<< "\n************* ***************** *************\n "

                           ).flush();
#endif

        thresh = (unsigned) ((1.0*(work/np))+0.5); 
        curthresh = curthresh+(unsigned)((1.0*((work-oldwork)/(np-p)))+0.5);
      }
      else  {
        p++; 

#ifdef DEBUG_PRINT_GC
     if (p>=np)
     ( comm_service::log() << "\n************* Current Composite List *************\n"
                           << *this
                           << "\n************* ***************** *************\n"
                           << "\n************* Current Bucket *************\n"
                           << *((SimpleBucketVoid *) this)
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

        assert(p<np);
        partitions[p] = new dMapIndex(tmpgu->baseindex);
        tmpgu->owner = p;
        if (p == me) locallist->add(*tmpgu);
        curthresh = (w-tmpw) + (unsigned) ((1.0*((work-(w-tmpw))/(np-p)))+0.5);
        if (w >= curthresh) {
          p++; 
          if (p < np)
            curthresh = w + (unsigned) ((1.0*((work-w)/(np-p)))+0.5);
        }
      }
    }
  }
    
/*
*************************************************************************
*                                                                       *
* Get GUL for the levels						*
* levellist : GUL for a paticular level					*
* levelarray : An array of GULs for the levels				*
*                                                                       *
*************************************************************************
*/

void GridUnitList::levellist(GridUnitList &gul, const int lev)
  { 
    if(!gul.isempty()) gul.empty();

    GridUnit levgu;
    register GridUnit *tmpgu = first();
    for (;tmpgu;tmpgu=next()) {
      if (tmpgu->guContains(lev)) {
        tmpgu->guGetLevels(levgu,lev);
        gul.add(levgu);
      }
    }
  }

void GridUnitList::levellist(GridUnitList &gul, 
			     const int minlev,
			     const int maxlev)
  { 
    if(!gul.isempty()) gul.empty();

    register int flev = 0;
    register int clev = 0;
    GridUnit levgu;
    register GridUnit *tmpgu = first();
    for (;tmpgu;tmpgu=next()) {
      flev = tmpgu->guFineLev();
      clev = tmpgu->guCrsLev();
      if (minlev > flev || maxlev < clev) continue;
      else if (maxlev >= flev) {
        tmpgu->guGetLevels(levgu,flev);
        gul.add(levgu);
      }
      else if (maxlev < flev) {
        tmpgu->guGetLevels(levgu,flev);
        gul.add(levgu);
      }
    }
  }
    
void GridUnitList::levelarray(GridUnitList**& levarray, const int levels)
  { 
    if (!levarray) {
      levarray = new GridUnitList *[levels];
      for (register int i=0;i<levels;i++)
	levarray[i] = GridUnitListNULL;
    }
    else {
      for (register int i=0;i<levels;i++)
	if (levarray[i]) levarray[i]->empty();
    }

    GridUnit** gus = 0;
    register GridUnit *tmpgu = first();
    for (;tmpgu;tmpgu=next()) {
      register int numlev = tmpgu->guNumLev();
      tmpgu->guGetLevels(gus);
      for (register int i=0;i<numlev;i++) {
        if (!levarray[i]) 
	  levarray[i] = new GridUnitList(tag,SimpleBucketVoid::blks());
	levarray[i]->add(*gus[i]);
	if (gus[i]) delete gus[i];
      }
      if (gus) delete [] gus;
      gus = 0;
    }
  }
    
/*
*************************************************************************
*                                                                       *
* Get a BBoxList corresponding to a particular level			*
*                                                                       *
*************************************************************************
*/

void GridUnitList::bboxlist(BBoxList &bbl, const int lev, 
                            const int olap) //, const int extgh)
  {
    const int extgh = 0;
    if(!bbl.isempty()) bbl.empty();

    GridUnit levgu;
    register GridUnit *tmpgu = first();
    for (;tmpgu;tmpgu=next()) {
      bbl.add(tmpgu->guBBox(lev,olap,extgh));
    }
  }

/* I actually want the bboxlist for the shadow (i.e. lev-levid) but only
   if the main (i.e. lev) exits */
void GridUnitList::bboxlist(BBoxList &bbl, const int lev,
                            const int olap, const int levid)
                            //,const int extgh)
  {
    const int extgh = 0;
    if(!bbl.isempty()) bbl.empty();

    GridUnit levgu;
    register GridUnit *tmpgu = first();
    for (;tmpgu;tmpgu=next()) {
      if (tmpgu->guContains(lev))
        bbl.add(tmpgu->guBBoxAbs(lev-levid,olap,extgh));
      else {
        BBox b;
        bbl.add(b);
      }
    }
  }

void GridUnitList::bboxlist(BBoxList &bbl, const int lev, 
                            const short* olap, const int extgh)
  {
    if(!bbl.isempty()) bbl.empty();

    GridUnit levgu;
    register GridUnit *tmpgu = first();
    for (;tmpgu;tmpgu=next()) {
      bbl.add(tmpgu->guBBox(lev,olap,extgh));
    }
  }

/* I actually want the bboxlist for the shadow (i.e. lev-levid) but only
   if the main (i.e. lev) exits */
void GridUnitList::bboxlist(BBoxList &bbl, const int lev,
                            const short* olap, const int levid, 
                            const int extgh)
  {
    if(!bbl.isempty()) bbl.empty();

    GridUnit levgu;
    register GridUnit *tmpgu = first();
    for (;tmpgu;tmpgu=next()) {
      if (tmpgu->guContains(lev))
        bbl.add(tmpgu->guBBoxAbs(lev-levid,olap,extgh));
      else {
        BBox b;
        bbl.add(b);
      }
    }
  }

/*
*************************************************************************
*                                                                       *
* Refine the GUL							*
*                                                                       *
*************************************************************************
*/

GridUnitList *GridUnitList::refinelist(const int atlev, const int levs)
  {
   GridUnitList *refgul = new GridUnitList;
   refgul->settag(tag);
   GridUnit refgu;

   GridUnitList levgul;
   levellist(levgul,atlev);
   register GridUnit *levgu = 0;

   for (levgu=levgul.first();levgu;levgu=levgul.next()) {
     levgu->guRefine(refgu,levs); 
     refgul->add(refgu);
   }
   return refgul;
  }

GridUnitList *GridUnitList::refinelist(BBoxList const &cbblist, const int atlev, 
                                       const int minw)
  {
   BBoxList &bblist = (BBoxList &)cbblist;
   union record *tmpcur = bblist.currec();

   GridUnitList *refgul = new GridUnitList;
   refgul->settag(tag);
   GridUnit refgu;

   GridUnitList levgul;
   levellist(levgul,atlev);
   register GridUnit *levgu = 0;

   BBox levbb;
   register BBox *bb = 0;

   for (levgu=levgul.first();levgu;levgu=levgul.next()) {
     levbb = levgu->guBBox(atlev);
     for (bb=bblist.first();bb;bb=bblist.next()) {
     if (!bb->empty()) {
       BBox bbb(*bb);
       //bbb.upper() -= 1;
       BBox interestion = bbb * levbb;
       if (interestion.empty() ) { 
       }
       else if (*bb == levbb) { 
	 levgu->guRefine(refgu); 
	 refgul->add(refgu);
	 levgul.remove();
	 break;
       }
       else if (interestion == levbb) { 
	 levgu->guRefine(refgu); 
	 refgul->add(refgu);
	 levgul.remove();
	 break;
       }
       else if (interestion < levbb && (levgu->guExtent(atlev) <= DefMinimumGUExtent || 
	        levgu->guExtentAbs(levgu->minlev) <= minw)) {
	 levgu->guRefine(refgu); 
	 refgul->add(refgu);
	 levgul.remove();
         BBox tmpbb = *bb+levbb;
         bblist.remove();
         bb = bblist.insert(tmpbb);
	 break;
       }
       else if (interestion < levbb && levgu->guExtent(atlev) > DefMinimumGUExtent &&
	        levgu->guExtentAbs(levgu->minlev) > minw) {
         levgul.decompose();
	 break;
       }
     } }
   }
   bblist.setcurrec(tmpcur);
   return refgul;
  }

/*
*************************************************************************
*                                                                       *
* Operations on the current GU						*
* decompose 								*
*                                                                       *
*************************************************************************
*/

void GridUnitList::decompose(const int lev)
  {
   register GridUnit *tmpgu = current();

   if (tmpgu == GridUnitNULL) return;

   GridUnit** gu=0; 
   int cnt=0;
   tmpgu->guDecompose(gu,cnt,lev);
   remove();
   for(register int i=cnt-1;i>=0;i--) {
     insert(*gu[i]); 
     prev(); 
     if (gu[i])  delete gu[i];
   }
   if (gu) delete [] gu;
   gu = 0;
  }

/*
*************************************************************************
*                                                                       *
* And overload << for the GUL class....					*
*                                                                       *
*************************************************************************
*/

ostream&  operator << (ostream& os, const GridUnitList& cgul)
  {
   if (&cgul == GridUnitListNULL) return os;

   GridUnitList &gul = (GridUnitList &) cgul;
   union record *tmpcur = gul.currec();
 
   os << "Tag:" << gul.tag << " ";
   os << "Num:" << gul.num << " ";
   os <<  "\n";

   if (gul.num == 0) return os;

   GridUnit *g = 0;
   os << *gul.first();
   os << "\n**********************************\n";

   while ( (g=gul.next()) != GridUnitNULL ) {
        os << *g;
        os << "\n**********************************\n";
        os << flush;
   }

   gul.setcurrec(tmpcur);

   return os;
  }

/*
*************************************************************************
*                                                                       *
* And overload BINARY << for the GUL class....					*
*                                                                       *
*************************************************************************
*/

ofstream&  operator << (ofstream& ofs, const GridUnitList& cgul)
  {
   if (&cgul == GridUnitListNULL) return ofs;

   GridUnitList &gul = (GridUnitList &) cgul;
   union record *tmpcur = gul.currec();
 
   if (gul.num == 0) return ofs;
   

   ofs.write((char*)&gul.tag,sizeof(int));
   ofs.write((char*)&gul.num,sizeof(int));

   GridUnit *g = 0;
   for (g = gul.first(); g != GridUnitNULL; g = gul.next())
     ofs << *g;

   gul.setcurrec(tmpcur);

   return ofs;
  }

ifstream&  operator >> (ifstream& ifs, GridUnitList& cgul)
  {
   if (&cgul == GridUnitListNULL) return ifs;

   GridUnitList &gul = (GridUnitList &) cgul;
   union record *tmpcur = gul.currec();
 
   int numin, tagin;
   ifs.read((char*)&tagin,sizeof(int));
   ifs.read((char*)&numin,sizeof(int));

   if (numin == 0) return ifs;

   GridUnit gu;
   for (register int n=0; n<numin; n++) {
     ifs >> gu;
     gul.add(gu);
   }

   gul.setcurrec(tmpcur);

   return ifs;
  }
