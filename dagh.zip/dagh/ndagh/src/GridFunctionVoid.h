#ifndef _included_GridFunctionVoid_h
#define _included_GridFunctionVoid_h

/*
*************************************************************************
*                                                                       *
* GridFunctionVoid.h                                                    *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"

#include "GridUnit.h"
#include "GridUnitList.h"

#include "DAGHInteraction.h"

#include "GridTable.h"
#include "CommRcvServer.h"

#include "GFInteraction.h"

#ifndef DAGHGFVFlagType
#define DAGHGFVFlagType    short
#endif

#ifndef DAGHGFVFlagNum
#define DAGHGFVFlagNum     10
#endif

class GridHierarchy;

class GridFunctionVoid
  {
   friend ostream& operator<<(ostream&, const GridFunctionVoid&);
   friend ofstream& operator<<(ofstream&, const GridFunctionVoid&);
   friend ifstream& operator>>(ifstream&, GridFunctionVoid&);

   /* All that has to be accesed by the GridHierarchy will go here */
   friend class GridHierarchy;

protected:
   /* General information */
   short gfid;		/* my unique id */
   short gftype;    	/* type ? DAGHCellCentered/DAGHNonCellCentered/.. */
   short gfrank; 	/* rank */
   char const *gfname;  /* print name */

   short overlap[DAGHMaxRank]; /* Overlap info... */

   /* alignment (if rank < dagh.rank) */
   short alignment;

   /* boundary width */
   short bwidth;

   /* External ghost width */
   short extghostwidth;

   /* Attributes */
   short comm_flag;	/* communication type */
   short shadow_flag;	/* do I have a shadow ? */
   short bndry_flag;    /* boundary type */
   short adaptbndry_flag; /* adaptive boundary type */
   short extghost_flag; /* ext. ghost or no ext. ghost */
   short compose_flag;	/* have I already been composed */
   short template_flag;	/* am I using a precomputed template */

   /* Other Attributes */
   short init_flag;       /* to init or not to init */
   short update_flag;     /* to update or not to update */
   short prolong_flag;    /* to prolong or not to prolong */
   short restrict_flag;   /* to restrict or not to restrict */
   short bndry_update_flag; /* to update boundary or not */
   short adaptbndry_update_flag; /* to update adaptive boundary or not */
   short io_flag;         /* to io or not to io */
   short chkpt_flag;      /* to checkpoint or not to checkpoint */

   /* Stencil information */
   short time_sten_rad;
   short* space_sten_rad;

   /* Time aliasing information */
   short *time_alias;

   /* Interactions */
   GhostInteraction interactions;

   /* Ghost Communication Stuff [np][levels * axis * dir] */
   GF_Interaction*** ghost_send_info;
   GF_Interaction*** ghost_recv_info;
   GridTableGhostRcv*** ghost_recv_server;

   /* Data Communication Stuff [np][time * level * length * 2] */
   GridTableDataRcv*** data_recv_server;

   /* Current time information */
   int *curtime[2];   /* Current time array */
                      /* curtime[0] -> DAGH_Main */
                      /* curtime[1] -> DAGH_Shadow */
   /* Current, I do not maintain it on a per GF basis */
   /* One curtime array is maintained in GH for all GFs */

   int updatedstep;     /* Where does the updated timestep reside ? */

   /* My Grid Table */
   GridTable *gt;

   /* and a ref to the GridHierarchy */
   GridHierarchy &dagh;

   /* some flags for the user */
   DAGHGFVFlagType userflags[DAGHGFVFlagNum];

   /* For Efficient Recompose */
   /* Recv */
   unsigned *rcvsize;
   unsigned *shrcvsize;
   /* Send */
   short slen;
   unsigned* sndsize;
   BBox* sndbbox;
   short* sndindex;
   short* rcvindex;
   short* sndlevel;
   short* sndcnt;

public:
   /*****************************************************************************/
   /* constructor */
   /*****************************************************************************/
   GridFunctionVoid(const int type, 
		    const int rank,
		    char const name[], 
                    GridHierarchy &gh,
  		    const int align,
                    const int bndrywidth,
                    const int extghwidth,
                    const int cflag, 
		    const int sflag, 
		    const int bflag,
		    const int adptbflag,
                    const int extghflag);

   GridFunctionVoid(const int type, 
		    const int rank,
		    char const name[], 
                    const int tsten, 
		    const int ssten, 
                    GridHierarchy &gh,
  		    const int align,
                    const int bndrywidth,
                    const int extghwidth,
                    const int cflag, 
		    const int sflag, 
		    const int bflag,
		    const int adptbflag,
                    const int extghflag);

   GridFunctionVoid(const int type, 
		    const int rank,
		    char const name[], 
                    const int tsten, 
		    const int *ssten, 
                    GridHierarchy &gh,
  		    const int align,
                    const int bndrywidth,
                    const int extghwidth,
                    const int cflag, 
		    const int sflag, 
		    const int bflag,
		    const int adptbflag,
		    const int extghflag);
 
   GridFunctionVoid(char const name[], 
		    const int rank,
                    const GridFunctionVoid& gfv,
                    const int cflag, 
		    const int sflag, 
		    const int bflag,
		    const int adptbflag,
		    const int extghflag);
   /*****************************************************************************/
   /* destructor */
   /*****************************************************************************/
   virtual ~GridFunctionVoid();

public:
   /*****************************************************************************/
   /* Set GF Type */
   /*****************************************************************************/
   void GF_SetGridFunctionType(const int gft); 

   /*****************************************************************************/
   /* set flags */
   /*****************************************************************************/
   inline void GF_SetCommType(const int cflag) 
     { comm_flag = cflag; }
   inline void GF_SetShadowFlag(const int sflag) 
     { shadow_flag = sflag; }
   inline void GF_SetBoundaryType(const int bflag) 
     { bndry_flag = bflag; }
   inline void GF_SetAdaptBoundaryType(const int adptbflag) 
     { adaptbndry_flag = adptbflag; }
   inline void GF_SetExternalGhostFlag(const int egflag) 
     { extghost_flag = egflag; }

   /*****************************************************************************/
   /* set/test attributes */
   /*****************************************************************************/
   inline void GF_SetInitializeFlag(const int flag) 
     { init_flag = flag; }
   inline void GF_SetUpdateFlag(const int flag) 
     { update_flag = flag; }
   inline void GF_SetProlongFlag(const int flag) 
     { prolong_flag = flag; }
   inline void GF_SetRestrictFlag(const int flag) 
     { restrict_flag = flag; }
   inline void GF_SetBndryUpdateFlag(const int flag) 
     { bndry_update_flag = flag; }
   inline void GF_SetAdaptBndryUpdateFlag(const int flag) 
     { adaptbndry_update_flag = flag; }
   inline void GF_SetIOFlag(const int flag) 
     { io_flag = flag; }
   inline void GF_SetCheckpointFlag(const int flag) 
     { chkpt_flag = flag; }

   inline int initialize() 
     { return init_flag == DAGHTrue; }
   inline int update() 
     { return update_flag == DAGHTrue; }
   inline int prolong() 
     { return prolong_flag == DAGHTrue; }
   inline int Restrict()  // On the Cray restrict is well.. restricted ;-)
     { return restrict_flag == DAGHTrue; }
   inline int bndry_update() 
     { return bndry_update_flag == DAGHTrue; }
   inline int adaptbndry_update() 
     { return adaptbndry_update_flag == DAGHTrue; }
   inline int io() 
     { return io_flag == DAGHTrue; }
   inline int checkpoint() 
     { return chkpt_flag == DAGHTrue; }

   /*****************************************************************************/
   /* set boundary width */
   /*****************************************************************************/
   inline void GF_BoundaryWidth(const int width) { bwidth = width; }

   /*****************************************************************************/
   /* set external ghost width */
   /*****************************************************************************/
   inline void GF_ExternalGhostWidth(const int width) 
        { extghostwidth = width; }

   /*****************************************************************************/
   /* define Stencils */
   /*****************************************************************************/
   void GF_SetSpaceStencil(const int s_sten);
   void GF_SetSpaceStencil(const int* s_sten);

   /*****************************************************************************/
   /* set time stencil */
   /* time goes from -time_sten_rad to time_sten_rad i.e. 2*time_sten_rad+1 */
   /*****************************************************************************/
   void GF_SetTimeStencil(const int t_sten);

   /*****************************************************************************/
   /* set alignment - used when rank < dagh.rank */
   /*****************************************************************************/
   inline void GF_SetAlignment(const int align) { alignment = align; }
 	
   /*****************************************************************************/
   /* set time aliases */
   /*****************************************************************************/
   inline void GF_SetTimeAlias(const int t, const int alias_to)
        { GF_DeleteGDBStorage(t + time_sten_rad);
	  time_alias[t+time_sten_rad] = (alias_to+time_sten_rad); }

   /*****************************************************************************/
   /* general queries */
   /*****************************************************************************/
   inline int GF_Id() const { return (gfid); }
   inline int GF_Type() const { return (gftype); }
   inline char const *GF_Name() const { return gfname; }

   inline int GF_Alignment() const { return alignment; }

   inline int comm() const 
     { return (comm_flag != DAGHNoComm); }
   inline int shadow() const 
     { return (shadow_flag != DAGHNoShadow); }
   inline int externalboundary() const 
     { return (bndry_flag != DAGHNoBoundary); }
   inline int adaptiveboundary() const 
     { return (adaptbndry_flag != DAGHNoAdaptBoundary); }

   inline int externalghost() const 
     { return (extghost_flag != DAGHTrue); }

   inline int composed() const 
     { return (compose_flag == DAGHTrue); }

   inline int comm_type() const 
     { return (comm_flag); }
   inline int boundary_type() const 
     { return (bndry_flag); }
   inline int adaptiveboundary_type() const 
     { return (adaptbndry_flag); }

   inline int boundary_width() const
     { return (bwidth); }
   inline int externalghost_width() const
     { return (extghostwidth); }

   /*************************************************************************/
   /* Set/Query Updated Timestep Info */
   /*************************************************************************/
   inline int updatedvaluestep() const { return updatedstep; }
   inline void setupdatedvaluestep(const int ustep) { updatedstep = ustep; }

   /*****************************************************************************/
   /* set and query user flags */
   /*****************************************************************************/
   inline void GF_SetUserFlag(const int id, const DAGHGFVFlagType& f)
     { assert (id < DAGHGFVFlagNum); userflags[id] = f; }

   inline DAGHGFVFlagType GF_GetUserFlag(const int id)
     { assert (id < DAGHGFVFlagNum); return (userflags[id]); }

   /*****************************************************************************/
   /* Free temporary storage */
   /*****************************************************************************/
   void GF_FreeTmpStorage();

   /*****************************************************************************/
   /* virtual methods for time aliasing */
   /*****************************************************************************/
   virtual void GF_DeleteGDBStorage(const int t);

   /*****************************************************************************/
   /* virtual methods that will be called by GridHierarchy */
   /*****************************************************************************/
   /* time, level */
   inline virtual void GF_Sync(const int time, const int level)
     { cerr << "Dummy GF_Sync(time, level) function\n"; }

   /* time, level, ident */
   inline virtual void GF_Sync(const int time, const int level, 
			       const int ident)
     { cerr << "Dummy GF_Sync(time, level, ident) function\n"; }

   /* time, level, mgl, ident=DAGH_Main */
   inline virtual void GF_Sync(const int time, const int level,
                               const int mgl, const int ident)
     { cerr << "Dummy GF_Sync(time, level, mgl, ident) function\n"; }

   /* time, level, axis, dir, ident=DAGH_Main */
   inline virtual void GF_Sync(const int time, const int level,
                               const int axis, const int dir,
                               const int ident)
     { cerr << "Dummy GF_Sync(time, level, axis, dir, ident) function\n"; }

   /* time, level, mgl, axis, dir, ident=DAGH_Main */
   inline virtual void GF_Sync(const int time, const int level, 
			       const int mgl,
                               const int axis, const int dir,
                               const int ident)
     { cerr << "Dummy GF_Sync(time, level, mgl, axis, dir, ident)"
            << "function\n"; }

   inline virtual void GF_WriteGhosts(const int time, const int level)
     { cerr << "Dummy GF_WriteGhosts(time, level) function\n"; }

   inline virtual void GF_WriteGhosts(const int time, const int level,
                       const int ident)
     { cerr << "Dummy GF_WriteGhosts(time, level, ident) function\n"; }

   inline virtual void GF_WriteGhosts(const int time, const int level,
                       const int mgl, const int ident)
     { cerr << "Dummy GF_WriteGhosts(time, level, mgl, ident) function\n"; }

   inline virtual void GF_WriteGhosts(const int time, const int level,
                       const int axis, const int dir, const int ident)
     { cerr << "Dummy GF_WriteGhosts(time, level, axis, dir, ident)"
            << "function\n"; }

   inline virtual void GF_WriteGhosts(const int time, const int level,
                       const int mgl, const int axis, const int dir,
                       const int ident)
     { cerr << "Dummy GF_WriteGhosts(time, level, mgl, axis, dir, ident)"
            << "function\n"; }

   inline virtual void GF_ReadGhosts(const int time, const int level)
     { cerr << "Dummy GF_ReadGhosts(time, level) function\n"; }

   inline virtual void GF_ReadGhosts(const int time, const int level,
                      const int ident)
     { cerr << "Dummy GF_ReadGhosts(time, level, ident) function\n"; }

   inline virtual void GF_ReadGhosts(const int time, const int level,
                      const int mgl, const int ident)
     { cerr << "Dummy GF_ReadGhosts(time, level, mgl, ident) function\n"; }

   inline virtual void GF_ReadGhosts(const int time, const int level,
                      const int axis, const int dir, const int ident)
     { cerr << "Dummy GF_ReadGhosts(time, level, axis, dir, ident)"
            << "function\n"; }

   inline virtual void GF_ReadGhosts(const int time, const int level,
                      const int mgl, const int axis, const int dir,
                      const int ident)
     { cerr << "Dummy GF_ReadGhosts(time, level, mgl, axis. dir, ident)"
            << "function\n"; }

   virtual void GF_Compose();
   virtual void GF_Recompose(const int omindex, const GridUnitList& ollist,
                             GridUnitList& rlist, GridUnitList& slist, GridUnitList& olist);

   virtual void GF_CheckpointRecompose();
   virtual void GF_Checkpoint(ofstream& ofs);   
   virtual void GF_CheckpointRestart();

private:
   /* disable this */
   GridFunctionVoid const &operator= (GridFunctionVoid const &other);
  };

ostream& operator<<(ostream& os, const GridFunctionVoid& gfv);
ofstream& operator<<(ofstream& ofs, const GridFunctionVoid& gfv);
ifstream& operator>>(ifstream& ifs, GridFunctionVoid& gfv);

#endif
