#ifndef _included_GridFunctionViz3_h
#define _included_GridFunctionViz3_h

/*
*************************************************************************
*                                                                       *
* GridFunctionViz3.h                                                    *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#define DIE(X) { cerr << X << flush; exit(-1); }
#define BUFFER_LENGTH (128)

template <class Type>
void GridFunction(3)<Type>::GF_View(const int time, const int l, 
				    const int axis, 
                                    const BBox& where,
                                    const int pserver,
                                    const int type,
                                    const char* xg,
                                    const char* dserver,
                                    const int ident)
  {
   assert (where.rank == dagh.rank);
  
   if (where.empty()) return;

   const int me = comm_service::proc_me();

   GridData(3)<Type> gd;
   GF_gather_one(time,l,where,where,gd,pserver,ident);
  
   if (me == pserver) {

     FILE *xgraph;
     char buffer [BUFFER_LENGTH];

     if (type == DAGHViz_XGRAPH) {
       if (!dserver)
         sprintf(buffer, "%s", xg);
       else
         sprintf(buffer, "%s -display %s", xg, dserver);

       if (!(xgraph = popen(buffer, "w")))
          DIE("GridFunction::GF_View -- Cannot start application ``" <<
                  buffer << "''\n");
     }
     else if (type == DAGHViz_FILE) {
       sprintf(buffer, "%s", xg);
       if (!(xgraph = fopen(buffer, "w")))
          DIE("GridFunction::GF_View -- Cannot write file``" <<
                  buffer << "''\n");
     }
     else {
       comm_service::log() << gd; /* For Now */
       return;
     }

     fprintf(xgraph, "TitleText: %s\n", gfname);
     fprintf(xgraph, "Markers: True\n");

     const Coords& lb = gd.bbox().lower();
     const Coords& ub = gd.bbox().upper();
     const Coords& step = gd.bbox().stepsize();

     double wlb[3], wub[3], wstep[3];
     dagh.worldCoords(lb,step,wlb);
     dagh.worldCoords(ub,step,wub);
     dagh.worldStep(step,wstep);

     const int a0 = axis;
     const int a1 = (a0+1)%3;
     const int a2 = (a0+2)%3;

     switch(axis)
        {
         case DAGH_X:
            fprintf(xgraph, "XUnitText: X Slice\n");
            break;
         case DAGH_Y:
            fprintf(xgraph, "XUnitText: Y Slice\n");
            break;
         case DAGH_Z:
            fprintf(xgraph, "XUnitText: Z Slice\n");
            break;
        }

     fprintf(xgraph, "YUnitText: Grid Data Values\n");

     Type data;

     for (int i2 = lb(a2); i2 <= ub(a2); i2 += step(a2)) {
       for (int i1 = lb(a1); i1 <= ub(a1); i1 += step(a1)) {

          int i0 = lb(a0);
          const int ii1 = i1 - lb(a1);
          const int ii2 = i2 - lb(a2);

          switch(axis)
            {
             case DAGH_X:
                fprintf(xgraph, "\"X (Y=%g, Z=%g)\n", wlb[1]+(wstep[1]*ii1),
                                                      wlb[2]+(wstep[2]*ii2));
                fprintf(xgraph, "move %18.10e %18.10e\n", wlb[0], gd(i0,i1,i2));
                break;
             case DAGH_Y:
                fprintf(xgraph, "\"Y (X=%g, Z=%g)\n", wlb[0]+(wstep[0]*ii2), 
                                                      wlb[2]+(wstep[2]*ii1));
                fprintf(xgraph, "move %18.10e %18.10e\n", wlb[1], gd(i2,i0,i1));
                break;
             case DAGH_Z:
                fprintf(xgraph, "\"Z (X=%g, Y=%g)\n", wlb[0]+(wstep[0]*ii1), 
                                                      wlb[1]+(wstep[1]*ii2));
                fprintf(xgraph, "move %18.10e %18.10e\n", wlb[2], gd(i1,i2,i0));
                break;
            }

            i0 += step(a0);
            for (int i = 1; i0 <= ub(a0); i++, i0 += step(a0)) {
              switch(axis)
                {
                 case DAGH_X:
                    data = gd(i0,i1,i2);
                    fprintf(xgraph, "draw %18.10e %18.10e\n", wlb[0]+i*wstep[0], data);
                    break;
                 case DAGH_Y:
                    data = gd(i2,i0,i1);
                    fprintf(xgraph, "draw %18.10e %18.10e\n", wlb[1]+i*wstep[1], data);
                    break;
                 case DAGH_Z:
                    data = gd(i1,i2,i0);
                    fprintf(xgraph, "draw %18.10e %18.10e\n", wlb[2]+i*wstep[2], data);
                    break;
                }
            }
            fprintf(xgraph, "\n");
            fflush(xgraph);
        }
      }

      if (type == DAGHViz_XGRAPH) {
        if (xgraph) pclose(xgraph);
      }
      else if (type == DAGHViz_FILE) {
        if (xgraph) fclose(xgraph);
      }
   }
  }
#endif
