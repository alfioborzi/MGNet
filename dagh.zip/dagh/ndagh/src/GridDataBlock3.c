#ifndef _included_GridDataBlock3_c
#define _included_GridDataBlock3_c

/*
*************************************************************************
*                                                                       *
* GridDataBlock(3).c                                                    *
*                                                                       *
*                                                                       *
*************************************************************************
*/

template <class Type>
GridDataBlock(3)<Type>::GridDataBlock(3)(const int gf,
                                         GridHierarchy& gh,
                                         GridTable& gt,
                                         const GhostInteraction& gi,
                                         GridUnitList& mgul,
                                         const int time,
                                         const int level,
                                         const int bwidth,
					 const int extghwidth,
                                         const short* olap,
                                         const short *sten,
                                         const int align,
                                         const int mindex, 
                                         const int cflag,
                                         const int sflag,
                                         const GridDataBlock(3)<Type>* gdbtmpl)
     : gfid(gf), 
       timenum(time), levelnum(level),
       shflag(DAGHFalse), shstorage(0), 
       mgflag(DAGHNull), mglfine(0), mglcoarse(0), mglevels(0), mgstorage(0),
       shmgflag(DAGHNull), shmglfine(0), shmglcoarse(0), shmglevels(0), shmgstorage(0),
       mygte(0), comm_flag(cflag), maxindex(mindex), 
       gdb_write_info(0), gdb_read_info(0), gdb_data_rcv(0),
       gtable(gt), dagh(gh)
  { 
   const int myrank = 3;
   const int reuse = (gdbtmpl == (GridDataBlock(3)<Type>*) 0) ? DAGHFalse : DAGHTrue;

   if (reuse) baseindex = gdbtmpl->baseindex;
   else baseindex = (mgul.first())->guLowIndex();
   //else baseindex = mgul.lowest();

   mygte = gtable.find(baseindex);

   const int shadowfactor = dagh.daghshadowfactor();
   const int daghrank = dagh.rank;

   register int i;
   for ( i = 0 ; i < myrank ; i++ ) {
     ranks[i] = i;

     sten_rad[2*i] = sten[2*i];
     sten_rad[2*i+1] = sten[2*i+1];

     ghost_prolong_flag[2*i] = DAGHFalse;
     ghost_prolong_flag[2*i+1] = DAGHFalse;

     bndryflags[2*i] = DAGHFalse;
     bndryflags[2*i+1] = DAGHFalse;
   }

   GridUnitList* cgul = dagh.clist();

   if (reuse == DAGHFalse) {

     short *dagh_rad = 0;
     if (align != DAGH_All) {
       gdbSetRanks(myrank, align, ranks);
       dagh_rad = new short[2*daghrank];
       for (i = 0 ; i < 2*daghrank ; i++) dagh_rad[i] = 0;
       for (i = 0 ; i < myrank ; i++) {
         dagh_rad[2*ranks[i]] = sten[2*i];
         dagh_rad[2*ranks[i]+1] = sten[2*i+1];
       }
     }
     else { 
       dagh_rad = sten_rad;
     }

     /* get my bounding box at the level */
     BBoxList merged_bbl;

     int levid = levelnum - mgul.finest();
     levid = (levid < 0) ? 0 : levid;
     assert (levid <= 1);
 
     /* DAGH_Main */
     mgul.bboxlist(merged_bbl,levelnum-levid,0,-levid);
     merged_bbox = merged_bbl.reduce();
     GridUnitList mcgul;
     cgul->intersect(growbydim(merged_bbox,dagh_rad),levelnum,mcgul,0);
     mcgul -= mgul;

     /* DAGH_Shadow */
     shmerged_bbox = coarsen(merged_bbox,shadowfactor);
     GridUnitList scgul;
     if (sflag == DAGHTrue) {
       cgul->intersect(growbydim(shmerged_bbox,dagh_rad),levelnum,scgul,0);
       scgul -= mgul;
     }
     merged_bbox.growupperbydim(olap);
     shmerged_bbox.growupperbydim(olap);

     gdbSetUpBoundaryFlags(mcgul,gi,olap,dagh_rad);

     /* make copies of the orig bbox */
     BBox dagh_merged_bbox(merged_bbox);
     BBox dagh_shmerged_bbox(shmerged_bbox);

     /* align the bounding box */
     if (align != DAGH_All) {
       gdbAlignBBox(myrank, merged_bbox, align);
       gdbAlignBBox(myrank, shmerged_bbox, align);
     }

     gdbSetUpMain(olap, bwidth, extghwidth);

     if (sflag == DAGHTrue) gdbSetUpShadow(olap, bwidth, extghwidth);

     if (comm_flag == DAGHTrue)  {
       const int pnum = comm_service::proc_num();

       /* Allocate memory for the communication stuff */
       gdb_write_info = new GDB_Interaction** [pnum]; 
       gdb_read_info = new GDB_Interaction** [pnum]; 

       for (register int p=0; p<pnum; p++) {
         gdb_write_info[p] = 0;
         gdb_read_info[p] = 0;
       }

       gdbSetUpGhostInteractionInfo(mcgul, scgul, mgul, align, gi, olap, 
                                    dagh_merged_bbox, dagh_shmerged_bbox, dagh_rad);
     }

     if (align != DAGH_All) delete [] dagh_rad;
   }

   else { /* reuse == DAGHTrue */

     merged_bbox = gdbtmpl->merged_bbox;
     shmerged_bbox = gdbtmpl->shmerged_bbox;

     for (i = 0 ; i < 2*myrank ; i++) 
       bndryflags[i] = gdbtmpl->bndryflags[i]; 

     gdbSetUpMain(olap, bwidth, extghwidth);

     if (sflag == DAGHTrue) gdbSetUpShadow(olap, bwidth, extghwidth);

     if (comm_flag == DAGHTrue)  {
       const int pnum = comm_service::proc_num();

       /* Allocate memory for the communication stuff */
       gdb_write_info = new GDB_Interaction** [pnum];
       gdb_read_info = new GDB_Interaction** [pnum];

       for (register int p=0; p<pnum; p++) {
         gdb_write_info[p] = 0;
         gdb_read_info[p] = 0;
       }

       gdbSetUpGhostInteractionInfo(gdbtmpl);
     }
   }

  }

/*
*************************************************************************
*                                                                       *
* GridDataBlock(3)::~GridDataBlock(3) (void)				*
*                                                                       *
*************************************************************************
*/
template <class Type>
GridDataBlock(3)<Type>::~GridDataBlock(3) (void)
  {
   if (comm_flag == DAGHTrue)  {
     const int pnum = comm_service::proc_num();
     const int inter_cnt = DAGHMaxAxis * DAGHMaxDirs * maxindex;

     for (register int p=0;p<pnum;p++) {
       if (gdb_write_info[p] || gdb_read_info[p]) {
         for (register int j=0;j<inter_cnt;j++) {
           if (gdb_write_info[p] && gdb_write_info[p][j])
             delete gdb_write_info[p][j];
           if (gdb_read_info[p] && gdb_read_info[p][j])
             delete gdb_read_info[p][j];
         }
         if (gdb_write_info[p]) delete [] gdb_write_info[p];
         if (gdb_read_info[p]) delete [] gdb_read_info[p];
       }
     }
     if (gdb_write_info) delete [] gdb_write_info;
     gdb_write_info = 0;
     if (gdb_read_info) delete [] gdb_read_info;
     gdb_read_info = 0;
   }
   if (gdb_data_rcv) delete gdb_data_rcv;
   gdb_data_rcv = 0;

   if (shflag != DAGHFalse) gdbReleaseShadow();
   if (mgflag != DAGHNull) gdbReleaseMultiGrid();
   if (shmgflag != DAGHNull) gdbReleaseShadowMultiGrid();
  }

/*
*************************************************************************
*                                                                       *
* Set up GDB internals 		 *
*                                                                       *
*************************************************************************
*/

/*************************************************************************/
/* Set flags defining adaptive/external boundaries */
/*************************************************************************/
template <class Type>
void GridDataBlock(3)<Type>::gdbSetUpBoundaryFlags(GridUnitList& gul,
                                                   const GhostInteraction& gi,
                                                   const short* olap,
                                                   const short* rad)
 {
  const int myrank = 3 ;
  const short* faces = gi.faces();
  const int crslevel = dagh.coarselevel();
  const int daghrank = dagh.rank;

  GridUnitList igul;
 
  const BBox wholebb(growupperbydim(dagh.wholebbox(),olap));

  short *myrad = new short[2*daghrank];
  for ( register int rr = 0 ; rr < daghrank ; rr++ ) {
    myrad[2*rr] = max(rad[2*rr],1);
    myrad[2*rr+1] = max(rad[2*rr+1],1);
  }

  for ( register int r = 0, dr = ranks[0] ; r < myrank ; ++r, dr = ranks[r] ) {
    const int facebi = faces[2*dr];
    const int facefi = faces[2*dr+1];

    if ((gi.Ibbox(merged_bbox,facebi,myrad)*wholebb).empty())
      bndryflags[2*r] = DAGH_ExternalBoundary;
    else if (levelnum > crslevel) {
      gul.intersect(gi.Ibbox(merged_bbox,facebi,myrad),levelnum,igul,olap);
      if ( igul.isempty() )
        bndryflags[2*r] = DAGH_AdaptiveBoundary;
    }

    if ((gi.Ibbox(merged_bbox,facefi,myrad)*wholebb).empty())
      bndryflags[2*r+1] = DAGH_ExternalBoundary;
    else if (levelnum > crslevel) {
      gul.intersect(gi.Ibbox(merged_bbox,facefi,myrad),levelnum,igul,olap);
      if ( igul.isempty() )
        bndryflags[2*r+1] = DAGH_AdaptiveBoundary;
    }
  }

  if (myrad) delete [] myrad;
 }
/*************************************************************************/

/*************************************************************************/
/* Add communication information is a particular axis & direction */
/* Allocate memory if required */
/*************************************************************************/
template <class Type>
void GridDataBlock(3)<Type>::gdbAddGhostInteractionInfo(
                                            const int axis, 
					    const int dir, 
                                            const BBox& rb, 
					    const BBox& wb, 
                                            const BBox& hisbb, 
                                            const int owner, 
					    const int idx,
					    const dMapIndex& li)
 {
  GridUnitList* cgul = dagh.clist();
  const int inter_cnt = DAGHMaxAxis * DAGHMaxDirs * maxindex;
  const int index = ( DAGHMaxDirs * maxindex * axis ) + ( maxindex * dir ) + idx; 
  const int hisindex = ( DAGHMaxDirs * maxindex * axis ) + 
                       ( maxindex * DAGHHisDir(dir) ) + idx; 

   const BBox thewb(growbydim(hisbb,sten_rad) * wb);
   const BBox therb(hisbb * rb);
   
   if (!thewb.empty()) { /* Write Info */
   if (!gdb_write_info[owner]) {
     gdb_write_info[owner] = new GDB_Interaction* [inter_cnt];
     for ( register int j = 0 ; j < inter_cnt ; j++ ) gdb_write_info[owner][j] = 0;
   }
   if (!gdb_write_info[owner][index])
     gdb_write_info[owner][index] = new GDB_Interaction;

   gdb_write_info[owner][index]->mbbox += thewb;
#ifdef DEBUG_PRINT
   assert (!gdb_write_info[owner][index]->mbbox.empty());
#endif
   if (!gdb_write_info[owner][index]->gte) 
     gdb_write_info[owner][index]->gte = mygte;
   }

   if (!therb.empty()) { /* Read Info */
   if (!gdb_read_info[owner]) {
     gdb_read_info[owner] = new GDB_Interaction* [inter_cnt];
     for ( register int j = 0 ; j < inter_cnt ; j++ ) gdb_read_info[owner][j] = 0;
   }
   if (!gdb_read_info[owner][hisindex])
     gdb_read_info[owner][hisindex] = new GDB_Interaction;

   gdb_read_info[owner][hisindex]->mbbox += therb;
#ifdef DEBUG_PRINT
   assert (!gdb_read_info[owner][hisindex]->mbbox.empty());
#endif
   //if (!gdb_read_info[owner][hisindex]->gte) 
   //  gdb_read_info[owner][hisindex]->gte = 
   //                       gtable.find(cgul->lowest(levelnum,owner,idx));
   if (!gdb_read_info[owner][hisindex]->gte) 
     gdb_read_info[owner][hisindex]->gte = gtable.find(li);
   }
 }

template <class Type>
void GridDataBlock(3)<Type>::gdbAddShadowGhostInteractionInfo(
                                            const int axis, 
					    const int dir, 
                                            const BBox& srb, 
					    const BBox& swb, 
                                            const BBox& shisbb, 
                                            const int owner, 
					    const int idx,
					    const dMapIndex& li)
 {
  GridUnitList* cgul = dagh.clist();
  const int inter_cnt = DAGHMaxAxis * DAGHMaxDirs * maxindex;
  const int index = ( DAGHMaxDirs * maxindex * axis ) + ( maxindex * dir ) + idx; 
  const int hisindex = ( DAGHMaxDirs * maxindex * axis ) + 
                       ( maxindex * DAGHHisDir(dir) ) + idx; 

   BBox sthewb(growbydim(shisbb,sten_rad) * swb);
   BBox stherb(shisbb * srb);
   
   if (!sthewb.empty()) { /* Write Info */
   if (!gdb_write_info[owner]) {
     gdb_write_info[owner] = new GDB_Interaction* [inter_cnt];
     for ( register int j = 0 ; j < inter_cnt ; j++ ) gdb_write_info[owner][j] = 0;
   }
   if (!gdb_write_info[owner][index])
     gdb_write_info[owner][index] = new GDB_Interaction;

   if (!gdb_write_info[owner][index]->gte) 
     gdb_write_info[owner][index]->gte = mygte;
   gdb_write_info[owner][index]->shbbox += sthewb;
#ifdef DEBUG_PRINT
   assert (!gdb_write_info[owner][index]->shbbox.empty());
#endif
   if (!gdb_write_info[owner][index]->gte) 
     gdb_write_info[owner][index]->gte = mygte;
   }

   if (!stherb.empty()) { /* Read Info */
   if (!gdb_read_info[owner]) {
     gdb_read_info[owner] = new GDB_Interaction* [inter_cnt];
     for ( register int j = 0 ; j < inter_cnt ; j++ ) gdb_read_info[owner][j] = 0;
   }
   if (!gdb_read_info[owner][hisindex])
     gdb_read_info[owner][hisindex] = new GDB_Interaction;

   gdb_read_info[owner][hisindex]->shbbox += stherb;
#ifdef DEBUG_PRINT
   assert (!gdb_read_info[owner][hisindex]->shbbox.empty());
#endif
   //if (!gdb_read_info[owner][hisindex]->gte) 
   //  gdb_read_info[owner][hisindex]->gte = 
   //                       gtable.find(cgul->lowest(levelnum,owner,idx));
   if (!gdb_read_info[owner][hisindex]->gte) 
     gdb_read_info[owner][hisindex]->gte = gtable.find(li);
   }
 }
/*************************************************************************/

/*************************************************************************/
/* Setup ghost interactions info */ 
/*************************************************************************/
template <class Type>
void GridDataBlock(3)<Type>::gdbSetUpGhostInteractionInfo(
                                                GridUnitList& mcgul,
                                                GridUnitList& scgul,
                                                GridUnitList& mgul,
                                                const int align,
                                                const GhostInteraction& gi,
                                                const short* olap,
                                                const BBox& dmerged_bbox,
                                                const BBox& dshmerged_bbox,
                                                const short* dsten_rad)
 {
  if (mcgul.isempty() && scgul.isempty()) return;

  const int myrank = 3 ;
  const int ti = gi.total_interactions();
  const int slevelnum = levelnum - dagh.daghindex(DAGH_Shadow);
  const int shadowfactor = dagh.daghshadowfactor();

  const BBox wholebb(growupperbydim(dagh.wholebbox(),olap));

  GridUnit *gu = 0;

  BBoxList mmbbl(mcgul.number(),0), mabbl(mcgul.number(),0);
  BBoxList smbbl(scgul.number(),0), sabbl(scgul.number(),0);
  BBox* mbb = 0;
  BBox* abb = 0;
  short flag = DAGHTrue;

  for ( register int r = 0, dr = 0 ; r < DAGHMaxAxis ; ++r ) {
    if ( r >= myrank && r != DAGH_All ) continue;
    dr = ( r < myrank ) ? ranks[r] : r ;

    short const *bi = gi.interactions(dr,DAGH_Backward);
    short const *fi = gi.interactions(dr,DAGH_Forward);
    short const *bothi = gi.interactions(dr,DAGH_Both);
    
    BBox bbb, shbbb, fbb, shfbb, rbbb, rfbb;
  
    register int i;
    for ( i = 0 ; i < ti ; i++ ) {
      if( bi[i] != DAGHTrue && fi[i] != DAGHTrue ) continue;

      BBox rb = gi.Ibbox(dmerged_bbox, i, dsten_rad);
      if (align != DAGH_All) gdbAlignBBox(myrank, rb, align);

      BBox srb = gi.Ibbox(dshmerged_bbox, i, dsten_rad);
      if (align != DAGH_All) gdbAlignBBox(myrank, srb, align);

      if ( r != DAGH_All && bndryflags[2*r] == DAGHFalse && bi[i] == DAGHTrue ) {
        bbb += rb; shbbb += srb;
      }
      if ( r != DAGH_All && bndryflags[2*r+1] == DAGHFalse && fi[i] == DAGHTrue ) {
        fbb += rb; shfbb += srb;
      }

      /* Do DAGH_Main */
      if (flag != DAGHTrue) { mmbbl.first(); mabbl.first(); }
      for ( gu = mcgul.first(); gu ; gu = mcgul.next() ) {
        const int idx = gu->guIndex();
        const int owner = gu->guOwner();
	const dMapIndex& li = gu->guLowIndex();

	if (flag == DAGHTrue) {
	  mbb = mmbbl.add(gu->guMergedBBox(levelnum,olap));
	  abb = mabbl.add(growupperbydim(gu->guBBoxAbs(levelnum),olap));
	}
	else {
	  mbb = mmbbl.current();
	  abb = mabbl.current();
	}

        //BBox hismbb = gu->guMergedBBox(levelnum,olap);
	BBox wb(dmerged_bbox * gi.Ibbox(*mbb,gi.complement(i),dsten_rad));
        if (align != DAGH_All) gdbAlignBBox(myrank, wb, align);

        //BBox hisbb = growupperbydim(gu->guBBoxAbs(levelnum),olap);
	BBox hisbb(*abb);
        if (align != DAGH_All) gdbAlignBBox(myrank, hisbb, align);

        if ( bi[i] == DAGHTrue ) { /* Backward... */
          gdbAddGhostInteractionInfo(r,DAGH_Backward,rb,wb,hisbb,owner,idx,li);
          rbbb += (hisbb * rb);
        }
        if ( fi[i] == DAGHTrue ) { /* Forward... */
          gdbAddGhostInteractionInfo(r,DAGH_Forward,rb,wb,hisbb,owner,idx,li);
          rfbb += (hisbb * rb);
        }
        if ( r >= myrank && bothi[i] == DAGHTrue ) { /* Both... */
          gdbAddGhostInteractionInfo(r,DAGH_Both,rb,wb,hisbb,owner,idx,li);
        }
	if (flag != DAGHTrue) { mmbbl.next(); mabbl.next(); }
      }

      if (shflag == DAGHTrue)  { /* Do DAGH_Shadow */
        if (flag != DAGHTrue) { smbbl.first(); sabbl.first(); }
        for (gu = scgul.first() ; gu ; gu = scgul.next()) {
          const int idx = gu->guIndex();
          const int owner = gu->guOwner();
	  const dMapIndex& li = gu->guLowIndex();

	  if (flag == DAGHTrue) {
	    mbb = smbbl.add(gu->guMergedBBox(slevelnum,olap));
	    abb = sabbl.add(growupperbydim(gu->guBBoxAbs(slevelnum),olap));
	  }
	  else {
	    mbb = smbbl.current();
	    abb = sabbl.current();
	  }

          //BBox shismbb = gu->guMergedBBox(slevelnum,olap);
          BBox swb(dshmerged_bbox * gi.Ibbox(*mbb,gi.complement(i),dsten_rad));
          if (align != DAGH_All) gdbAlignBBox(myrank, swb, align);
  
          //BBox shisbb = growupperbydim(gu->guBBoxAbs(slevelnum),olap);
	  BBox shisbb(*abb);
          if (align != DAGH_All) gdbAlignBBox(myrank, shisbb, align);
  
          if ( bi[i] == DAGHTrue ) { /* Backward... */
            gdbAddShadowGhostInteractionInfo(r,DAGH_Backward,srb,swb,shisbb,owner,idx,li);
          }
          if ( fi[i] == DAGHTrue ) { /* Forward... */
            gdbAddShadowGhostInteractionInfo(r,DAGH_Forward,srb,swb,shisbb,owner,idx,li);
          }
          if ( r >= myrank && bothi[i] == DAGHTrue ) { /* Both... */
            gdbAddShadowGhostInteractionInfo(r,DAGH_Both,srb,swb,shisbb,owner,idx,li);
          }
	  if (flag != DAGHTrue) { smbbl.next(); sabbl.next(); }
        }
      }
      flag = DAGHFalse;
    }
    bbb *= mstorage.bbox;
    fbb *= mstorage.bbox;
    if (shflag == DAGHTrue) {
      shbbb *= shstorage->bbox;
      shfbb *= shstorage->bbox;
    } 
    if (r < myrank) {
      //if (bndryflags[2*r] == DAGHFalse && bbb != rbbb) { 
      if (bndryflags[2*r] == DAGHFalse) {
#ifdef DEBUG_PRINT
        //assert(bbb > rbbb);
#endif
        ghost_prolong_flag[2*r] = DAGHTrue;
        ghost_prolong_info[2*r].mbbox = bbb;
        if (shflag == DAGHTrue) ghost_prolong_info[2*r].shbbox = shbbb;
      }
      //if (bndryflags[2*r+1] == DAGHFalse && fbb != rfbb) {
      if (bndryflags[2*r+1] == DAGHFalse) {
#ifdef DEBUG_PRINT
        //assert(fbb > rfbb);
#endif
        ghost_prolong_flag[2*r+1] = DAGHTrue;
        ghost_prolong_info[2*r+1].mbbox = fbb;
        if (shflag == DAGHTrue) ghost_prolong_info[2*r+1].shbbox = shfbb;
      }
    }
  }
 }

template <class Type>
void GridDataBlock(3)<Type>::gdbSetUpGhostInteractionInfo(
					const GridDataBlock(3)<Type>* gdbtmpl)

 {
  const int myrank = 3 ;
  const int pnum = comm_service::proc_num();
  const int inter_cnt = DAGHMaxAxis * DAGHMaxDirs * maxindex;

  GridUnitList* cgul = dagh.clist();

  GDB_Interaction*** mw = gdb_write_info;
  GDB_Interaction*** mr = gdb_read_info;

  GDB_Interaction*** hw = gdbtmpl->gdb_write_info;
  GDB_Interaction*** hr = gdbtmpl->gdb_read_info;

  for ( register int p = 0 ; p < pnum ; p++ ) if ( hw[p] || hr[p] ) {
    if ( hw[p] ) mw[p] = new GDB_Interaction* [inter_cnt];
    if ( hr[p] ) mr[p] = new GDB_Interaction* [inter_cnt];

    for ( register int j = 0 ; j < inter_cnt ; j++ ) {

      if ( mw[p] ) mw[p][j] = 0;
      if ( mr[p] ) mr[p][j] = 0;

      if ( hw[p] && hw[p][j] ) {
        mw[p][j] = new GDB_Interaction;
        mw[p][j]->mbbox = hw[p][j]->mbbox;
        if ( shflag == DAGHTrue ) mw[p][j]->shbbox = hw[p][j]->shbbox;
        mw[p][j]->gte = mygte;
      }

      if ( hr[p] && hr[p][j] ) {
        mr[p][j] = new GDB_Interaction;
        mr[p][j]->mbbox = hr[p][j]->mbbox;
        if ( shflag == DAGHTrue ) mr[p][j]->shbbox = hr[p][j]->shbbox;
        mr[p][j]->gte = 
            gtable.find(cgul->lowest(levelnum,p,hr[p][j]->gte->myindex()));
      }
    }
  }
  for ( register int r = 0 ; r < myrank ; r++ ) {
    ghost_prolong_flag[2*r] = gdbtmpl->ghost_prolong_flag[2*r];
    ghost_prolong_info[2*r].mbbox = gdbtmpl->ghost_prolong_info[2*r].mbbox;
    if ( shflag == DAGHTrue ) 
      ghost_prolong_info[2*r].shbbox = gdbtmpl->ghost_prolong_info[2*r].shbbox;

    ghost_prolong_flag[2*r+1] = gdbtmpl->ghost_prolong_flag[2*r+1];
    ghost_prolong_info[2*r+1].mbbox = gdbtmpl->ghost_prolong_info[2*r+1].mbbox;
    if ( shflag == DAGHTrue ) 
      ghost_prolong_info[2*r+1].shbbox = gdbtmpl->ghost_prolong_info[2*r+1].shbbox;
  }
 }
/*************************************************************************/

/*
*************************************************************************
*                                                                       *
* Set up storage for the Main Hierarchy 				*
*                                                                       *
*************************************************************************
*/
template <class Type>
void GridDataBlock(3)<Type>::gdbSetUpMain(const short*  olap, 
                                          const int bwidth,
					  const int extghwidth)
  {
    const int myrank = 3;

    const Coords &cl = merged_bbox.lower();
    const Coords &cu = merged_bbox.upper();
    const Coords &step = merged_bbox.stepsize();

    BBox& db = mstorage.bbox; db = merged_bbox;
    BBox& ib = mstorage.ibbox; ib = merged_bbox;
    BBox* bndrybb = mstorage.bndrybbox;

    for (register int i=0; i<myrank; i++) {
     register int itimes2 = 2*i;

     if (bndryflags[itimes2] == DAGHFalse) {
       db.lower(i) -= step(i)*sten_rad[itimes2];
     }
     else if (bwidth > 0) {
       bndrybb[itimes2] = merged_bbox;
       bndrybb[itimes2].upper(i) = (cl(i) + step(i)*(bwidth-1));
     }

     if (bndryflags[itimes2+1] == DAGHFalse) {
       db.upper(i) += step(i)*sten_rad[itimes2+1];
       ib.upper(i) -= (olap[i]*step(i));
     }
     else if (bwidth > 0) {
       bndrybb[itimes2+1] = merged_bbox;
       bndrybb[itimes2+1].lower(i) = (cu(i) - step(i)*(bwidth-1));
     }
    }

    if (extghwidth > 0) db.grow(extghwidth);
    mstorage.allocate();
#ifdef DEBUG_PRINT_GDB
   ( comm_service::log() << "gdbSetUpMain" << "[" << gfid << "] "
                         << mstorage << " "
                         << endl ).flush();
#endif
  }

/******************************************************************/
/* Shadow Hierarchy Routines */
/******************************************************************/
template <class Type>
void GridDataBlock(3)<Type>::gdbSetUpShadow(const short* olap, 
                                            const int bwidth,
					    const int extghwidth)
 {
   if (shflag != DAGHFalse) gdbReleaseShadow();
   shflag = DAGHTrue;

   const int myrank = 3;

   const Coords &cl = shmerged_bbox.lower();
   const Coords &cu = shmerged_bbox.upper();
   const Coords &step = shmerged_bbox.stepsize();

   shstorage = new GridDataBlockStorage(3)<Type>;

   BBox& db = shstorage->bbox; db = shmerged_bbox;
   BBox& ib = shstorage->ibbox; ib = shmerged_bbox;
   BBox* bndrybb = shstorage->bndrybbox;

   for (register int i=0; i<myrank; i++) {
     register int itimes2 = 2*i;

     if (bndryflags[itimes2] == DAGHFalse) {
       db.lower(i) -= step(i)*sten_rad[itimes2];
     }
     else if (bwidth > 0) {
       bndrybb[itimes2] = shmerged_bbox;
       bndrybb[itimes2].upper(i) = (cl(i) + step(i)*(bwidth-1));
     }

     if (bndryflags[itimes2+1] == DAGHFalse) {
       db.upper(i) += step(i)*sten_rad[itimes2+1];
       ib.upper(i) -= (olap[i]*step(i));
     }
     else if (bwidth > 0) {
       bndrybb[itimes2+1] = shmerged_bbox;
       bndrybb[itimes2+1].lower(i) = (cu(i) - step(i)*(bwidth-1));
     }
   }
   if (extghwidth > 0) db.grow(extghwidth);
   shstorage->allocate();
#ifdef DEBUG_PRINT_GDB_SH
   ( comm_service::log() << "gdbSetUpShadow" << "[" << gfid << "]"
			 << *shstorage << " "
                         << endl ).flush();
#endif
 }

template <class Type>
void GridDataBlock(3)<Type>::gdbReleaseShadow(void)
 {
   if (shflag == DAGHFalse) return;
   if (shstorage) delete shstorage;
   shflag = DAGHFalse;
 }
/******************************************************************/

/******************************************************************/
/* MultiGrid Routines */
/******************************************************************/
template <class Type>
void GridDataBlock(3)<Type>::gdbSetUpMultiGrid(const int lc, const int lf,
                                               const short* olap,
                                               const int bwidth,
					       const int extghwidth)
 {
   if (mgflag != DAGHNull) gdbReleaseMultiGrid();

   mgflag = DAGH_All;
   mglfine = lf;
   mglcoarse = lc;
   mglevels = lf-lc+1;
   if (mglevels == 1) return;

   mgstorage = new GridDataBlockStorage(3)<Type> *[mglevels-1];

#ifdef DEBUG_PRINT_GDB_MG
       ( comm_service::log() << "gdbSetUpMultiGrid" << "[" << gfid << "]"
			 << "[MGLevel: " << lf << "]"
			 << mstorage << " "
                         << endl ).flush();
#endif

   const int myrank = 3;
   const int multigridfactor = dagh.daghmultigridfactor();

   register int lindex = 0;
   register int factor = 1;

   for ( register int l = lf-1 ; l >= lc ; l-- ) {
     lindex = l-lc;  
     factor *= multigridfactor;

     mgstorage[lindex] = new GridDataBlockStorage(3)<Type>;
     GridDataBlockStorage(3)<Type>* mg = mgstorage[lindex];

     const BBox mgbb = coarsen(merged_bbox,factor);
     const Coords &cl = mgbb.lower();
     const Coords &cu = mgbb.upper();
     const Coords &step = mgbb.stepsize();

     BBox& db = mg->bbox; db = mgbb;
     BBox& ib = mg->ibbox; ib = mgbb;
     BBox* bndrybb = mg->bndrybbox;
 
     for ( register int i = 0 ; i < myrank ; i++ ) {
       register int itimes2 = 2*i;

       if (bndryflags[itimes2] == DAGHFalse) {
         db.lower(i) -= step(i)*sten_rad[itimes2];
       }
       else if (bwidth > 0) {
         bndrybb[itimes2] = mgbb;
         bndrybb[itimes2].upper(i) = (cl(i) + step(i)*(bwidth-1));
       }

       if (bndryflags[itimes2+1] == DAGHFalse) {
         db.upper(i) += step(i)*sten_rad[itimes2+1];
         ib.upper(i) -= (olap[i]*step(i));
       }
       else if (bwidth > 0) {
         bndrybb[itimes2+1] = mgbb;
         bndrybb[itimes2+1].lower(i) = (cu(i) - step(i)*(bwidth-1));
       }
     }
     if (extghwidth > 0) db.grow(extghwidth);
     mg->allocate();
#ifdef DEBUG_PRINT_GDB_MG
     ( comm_service::log() << "gdbSetUpMultiGrid" << "[" << gfid << "]"
			   << "[MGLevel: " << lindex << "]"
			   << *mg << " "
                           << endl ).flush();
#endif
   }

   /* Setup MG Info */
   const int pnum = comm_service::proc_num();
   const int inter_cnt = DAGHMaxAxis * DAGHMaxDirs * maxindex;

   /* Setup MG Ghosts */
#ifdef DEBUG_PRINT_GDB_MG
     ( comm_service::log() << "gdbSetUpMultiGridGhost" << "[" << gfid << "]"
                           ).flush();
#endif
   for ( register int p = 0 ; p < pnum ; p++ ) {
     if ( !gdb_write_info[p] ) continue;
     for ( register int i = 0 ; i < inter_cnt ; i++ ) {
       if ( !gdb_write_info[p][i] ) continue;
#ifdef DEBUG_PRINT_GDB_MG
     ( comm_service::log() << endl << "[" << p << "," << i << "]").flush();
#endif
       gdb_write_info[p][i]->mmgbbox = new BBox [mglevels-1];
       BBox *b = gdb_write_info[p][i]->mmgbbox;
       factor = 1;
       for ( register int ll = lf-1 ; ll >= lc ; ll-- ) {
         lindex = ll-lc;  factor *= multigridfactor;
         b[lindex] = coarsen(gdb_write_info[p][i]->mbbox,factor);
         if (olap[0] > 0 || olap[1] > 0 || olap[2] > 0) {
           BBox& bb = b[lindex];
           BBox mgbb = mgstorage[lindex]->bbox;
           if (extghwidth > 0) mgbb.grow(-extghwidth);
           for ( register int r = 0 ; r < myrank ; r++ ) {
             if (olap[r] > 0 && 
                 bb.lower(r)==mgbb.lower(r) && bb.upper(r)==mgbb.lower(r))
               bb.shift(r,olap[r]);
           }
         }
#ifdef DEBUG_PRINT_GDB_MG
     ( comm_service::log() << "[MGL:" << lindex << b[lindex] << "]").flush();
#endif
       }
     } /* We don't need to setup read ghosts */
   } /* End setup MG Ghosts */
#ifdef DEBUG_PRINT_GDB_MG
     ( comm_service::log() << endl).flush();
#endif

   /* Setup MG Prolong Info */
   for ( register int r = 0 ; r < 2*myrank ; r++ ) {
     if ( ghost_prolong_flag[r] == DAGHFalse ) continue;
     ghost_prolong_info[r].mmgbbox = new BBox [mglevels-1];
     BBox *b = ghost_prolong_info[r].mmgbbox;
     factor = 1;
     for ( register int ll = lf-1 ; ll >= lc ; ll-- ) {
       lindex = ll-lc;  factor *= multigridfactor;
       b[lindex] = coarsen(ghost_prolong_info[r].mbbox,factor);
       if (olap[0] > 0 || olap[1] > 0 || olap[2] > 0) {
         BBox& bb = b[lindex];
         BBox mgbb = mgstorage[lindex]->bbox;
         if (extghwidth > 0) mgbb.grow(-extghwidth);
         for ( register int rr = 0 ; rr < myrank ; rr++ ) {
           if (olap[rr] > 0 &&
               bb.lower(rr)==mgbb.lower(rr) && bb.upper(rr)==mgbb.lower(rr))
             bb.shift(rr,olap[rr]);
         }
       }
     }
   } /* End Setup MG Prolong Info */
 }

template <class Type>
void GridDataBlock(3)<Type>::gdbSetUpMultiGrid(const int axis, 
                                               const int lc, const int lf,
                                               const short* olap, 
                                               const int bwidth,
					       const int extghwidth)
 {
   assert (axis == DAGH_X || axis == DAGH_Y || axis == DAGH_Z);

   if (mgflag != DAGHNull) gdbReleaseMultiGrid();

   mgflag = axis;
   mglfine = lf;
   mglcoarse = lc;
   mglevels = lf-lc+1;
   if (mglevels == 1) return;

   mgstorage = new GridDataBlockStorage(3)<Type> *[mglevels-1];

#ifdef DEBUG_PRINT_GDB_MG
       ( comm_service::log() << "gdbSetUpMultiGrid" << "[" << gfid << "]"
			 << "[MGLevel: " << lf << "]"
			 << mstorage << " "
                         << endl ).flush();
#endif

   const int myrank = 3;
   const int multigridfactor = dagh.daghmultigridfactor();

   register int lindex = 0;
   register int factor = 1;

   for ( register int l = lf-1 ; l >= lc ; l-- ) {
     lindex = l-lc;  
     factor *= multigridfactor;

     mgstorage[lindex] = new GridDataBlockStorage(3)<Type>;
     GridDataBlockStorage(3)<Type>* mg = mgstorage[lindex];

     const BBox mgbb = coarsen(merged_bbox,axis,factor);
     const Coords &cl = mgbb.lower();
     const Coords &cu = mgbb.upper();
     const Coords &step = mgbb.stepsize();

     BBox& db = mg->bbox; db = mgbb;
     BBox& ib = mg->ibbox; ib = mgbb;
     BBox* bndrybb = mg->bndrybbox;
 
     for ( register int i = 0 ; i < myrank ; i++ ) {
       register int itimes2 = 2*i;

       if (bndryflags[itimes2] == DAGHFalse) {
         db.lower(i) -= step(i)*sten_rad[itimes2];
       }
       else if (bwidth > 0) {
         bndrybb[itimes2] = mgbb;
         bndrybb[itimes2].upper(i) = (cl(i) + step(i)*(bwidth-1));
       }

       if (bndryflags[itimes2+1] == DAGHFalse) {
         db.upper(i) += step(i)*sten_rad[itimes2+1];
         ib.upper(i) -= (olap[i]*step(i));
       }
       else if (bwidth > 0) {
         bndrybb[itimes2+1] = mgbb;
         bndrybb[itimes2+1].lower(i) = (cu(i) - step(i)*(bwidth-1));
       }
     }
     if (extghwidth > 0) db.grow(extghwidth);
     mg->allocate();
#ifdef DEBUG_PRINT_GDB_MG
     ( comm_service::log() << "gdbSetUpMultiGrid" << "[" << gfid << "]"
			   << "[MGLevel: " << lindex << "]"
			   << *mg << " "
                           << endl ).flush();
#endif
   }

   /* Setup MG Info */
   const int pnum = comm_service::proc_num();
   const int inter_cnt = DAGHMaxAxis * DAGHMaxDirs * maxindex;

   /* Setup MG Ghosts */
   for ( register int p = 0 ; p < pnum ; p++ ) {
     if ( !gdb_write_info[p] ) continue;
     for ( register int i = 0 ; i < inter_cnt ; i++ ) {
       if ( !gdb_write_info[p][i] ) continue;
       gdb_write_info[p][i]->mmgbbox = new BBox [mglevels-1];
       BBox *b = gdb_write_info[p][i]->mmgbbox;
       factor = 1;
       for ( register int ll = lf-1 ; ll >= lc ; ll-- ) {
         lindex = ll-lc;  factor *= multigridfactor;
         b[lindex] = coarsen(gdb_write_info[p][i]->mbbox,axis,factor);
         if (olap[0] > 0 || olap[1] > 0 || olap[2] > 0) {
           BBox& bb = b[lindex];
           BBox mgbb = mgstorage[lindex]->bbox;
           if (extghwidth > 0) mgbb.grow(-extghwidth);
           for ( register int r = 0 ; r < myrank ; r++ ) {
             if (olap[r] > 0 &&
                 bb.lower(r)==mgbb.lower(r) && bb.upper(r)==mgbb.lower(r))
               bb.shift(r,olap[r]);
           }
         }
       }
     }
     /* We don't need to setup read ghosts */
   } /* End setup MG Ghosts */

   /* Setup MG Prolong Info */
   for ( register int r = 0 ; r < 2*myrank ; r++ ) {
     if ( ghost_prolong_flag[r] == DAGHFalse ) continue;
     ghost_prolong_info[r].mmgbbox = new BBox [mglevels-1];
     BBox *b = ghost_prolong_info[r].mmgbbox;
     factor = 1;
     for ( register int ll = lf-1 ; ll >= lc ; ll-- ) {
       lindex = ll-lc;  factor *= multigridfactor;
       b[lindex] = coarsen(ghost_prolong_info[r].mbbox,axis,factor);
       if (olap[0] > 0 || olap[1] > 0 || olap[2] > 0) {
         BBox& bb = b[lindex];
         BBox mgbb = mgstorage[lindex]->bbox;
         if (extghwidth > 0) mgbb.grow(-extghwidth);
         for ( register int rr = 0 ; rr < myrank ; rr++ ) {
           if (olap[rr] > 0 &&
               bb.lower(rr)==mgbb.lower(rr) && bb.upper(rr)==mgbb.lower(rr))
             bb.shift(rr,olap[rr]);
         }
       }
     }
   } /* End Setup MG Prolong Info */
 }

template <class Type>
void GridDataBlock(3)<Type>::gdbReleaseMultiGrid(void)
 {
   if (mgflag == DAGHNull) return;

   const int myrank = 3;

   /* Storage */
   register int i;
   for ( i = 0 ; i < mglevels-1 ; i++ ) 
     if (mgstorage[i]) delete mgstorage[i];
 
   if (mgstorage) delete [] mgstorage;

   /* Ghost Info */
   const int pnum = comm_service::proc_num();
   const int inter_cnt = DAGHMaxAxis * DAGHMaxDirs * maxindex;

   if (gdb_write_info) for ( register int p = 0 ; p < pnum ; p++ ) {
     if ( !gdb_write_info[p] ) continue;
     for ( i = 0 ; i < inter_cnt ; i++ ) {
       if (gdb_write_info[p][i] && gdb_write_info[p][i]->mmgbbox)
         delete [] gdb_write_info[p][i]->mmgbbox;
     } 
   }
   for ( register int r = 0 ; r < 2*myrank ; r++ ) {
     if (ghost_prolong_flag[r]==DAGHTrue && ghost_prolong_info[r].mmgbbox) 
       delete [] ghost_prolong_info[r].mmgbbox;
   }

   mgflag = DAGHNull;
 }
/******************************************************************/

/******************************************************************/
/* Shadow MultiGrid Routines */
/******************************************************************/
template <class Type>
void GridDataBlock(3)<Type>::gdbSetUpShadowMultiGrid(const int lc, const int lf,
                                                     const short* olap, 
                                                     const int bwidth,
						     const int extghwidth)
 {
   if (shmgflag != DAGHNull) gdbReleaseShadowMultiGrid();

   shmgflag = DAGH_All;
   shmglfine = lf;
   shmglcoarse = lc;
   shmglevels = lf-lc+1;
   if (shmglevels == 1) return;

   shmgstorage = new GridDataBlockStorage(3)<Type> *[mglevels-1];

#ifdef DEBUG_PRINT_GDB_MG
       ( comm_service::log() << "gdbSetUpShadowMultiGrid" << "[" << gfid << "]"
                         << "[MGLevel: " << lf << "]"
                         << shstorage << " "
                         << endl ).flush();
#endif


   const int myrank = 3;
   const int multigridfactor = dagh.daghmultigridfactor();

   register int lindex = 0;
   register int factor = 1;

   for ( register int l = lf-1 ; l >= lc ;l-- ) {
     lindex = l-lc; 
     factor *= multigridfactor;

     shmgstorage[lindex] = new GridDataBlockStorage(3)<Type>;
     GridDataBlockStorage(3)<Type>* shmg = shmgstorage[lindex];

     const BBox shmgbb = coarsen(shmerged_bbox,factor);
     const Coords &cl = shmgbb.lower();
     const Coords &cu = shmgbb.upper();
     const Coords &step = shmgbb.stepsize();

     BBox& db = shmg->bbox; db = shmgbb;
     BBox& ib = shmg->ibbox; ib = shmgbb;
     BBox* bndrybb = shmg->bndrybbox;

     for (register int i=0; i<myrank; i++) {
       register int itimes2 = 2*i;

       if (bndryflags[itimes2] == DAGHFalse) {
         db.lower(i) -= step(i)*sten_rad[itimes2];
       }
       else if (bwidth > 0) {
         bndrybb[itimes2] = shmgbb;
         bndrybb[itimes2].upper(i) = (cl(i) + step(i)*(bwidth-1));
       }

       if (bndryflags[itimes2+1] == DAGHFalse) {
         db.upper(i) += step(i)*sten_rad[itimes2+1];
         ib.upper(i) -= (olap[i]*step(i));
       }
       else if (bwidth > 0) {
         bndrybb[itimes2+1] = shmgbb;
         bndrybb[itimes2+1].lower(i) = (cu(i) - step(i)*(bwidth-1));
       }
     }
     if (extghwidth > 0) db.grow(extghwidth);
     shmg->allocate();
#ifdef DEBUG_PRINT_GDB_MG
     ( comm_service::log() << "gdbSetUpMultiGrid" << "[" << gfid << "]"
                           << "[MGLevel: " << lindex << "]"
                           << *shmg << " "
                           << endl ).flush();
#endif
   }

   /* Setup Shadow MG Info */
   const int pnum = comm_service::proc_num();
   const int inter_cnt = DAGHMaxAxis * DAGHMaxDirs * maxindex;

   /* Setup Shadow MG Ghosts */
   for ( register int p = 0 ; p < pnum ; p++ ) {
     if ( !gdb_write_info[p] ) continue;
     for ( register int i = 0 ; i < inter_cnt ; i++ ) {
       if ( !gdb_write_info[p][i] ) continue;
       gdb_write_info[p][i]->shmgbbox = new BBox [shmglevels-1];
       BBox *b = gdb_write_info[p][i]->shmgbbox;
       factor = 1;
       for ( register int ll = lf-1 ; ll >= lc ; ll-- ) {
         lindex = ll-lc;  factor *= multigridfactor;
         b[lindex] = coarsen(gdb_write_info[p][i]->shbbox,factor);
	 if (olap[0] > 0 || olap[1] > 0 || olap[2] > 0) {
           BBox& bb = b[lindex];
           BBox shmgbb = shmgstorage[lindex]->bbox;
           if (extghwidth > 0) shmgbb.grow(-extghwidth);
           for ( register int r = 0 ; r < myrank ; r++ ) {
             if (olap[r] > 0 &&
                 bb.lower(r)==shmgbb.lower(r) && bb.upper(r)==shmgbb.lower(r))
               bb.shift(r,olap[r]);
           }
         }
       }
     } /* We don't need to setup read ghosts */
   } /* End setup Shadow MG Ghosts */

   /* Setup Shadow Prolong Info */
   for ( register int r = 0 ; r < 2*myrank ; r++ ) {
     if ( ghost_prolong_flag[r] == DAGHFalse ) continue;
     ghost_prolong_info[r].shmgbbox = new BBox [shmglevels-1];
     BBox *b = ghost_prolong_info[r].shmgbbox;
     factor = 1;
     for ( register int ll = lf-1 ; ll >= lc ; ll-- ) {
       lindex = ll-lc;  factor *= multigridfactor;
       b[lindex] = coarsen(ghost_prolong_info[r].shbbox,factor);
       if (olap[0] > 0 || olap[1] > 0 || olap[2] > 0) {
         BBox& bb = b[lindex];
         BBox shmgbb = shmgstorage[lindex]->bbox;
         if (extghwidth > 0) shmgbb.grow(-extghwidth);
         for ( int rr = 0 ; rr < myrank ; rr++ ) {
           if (olap[rr] > 0 &&
               bb.lower(rr)==shmgbb.lower(rr) && bb.upper(rr)==shmgbb.lower(rr))
             bb.shift(rr,olap[rr]);
         }
       }
     }
   } /* End Setup Shadow Prolong Info */
 }

template <class Type>
void GridDataBlock(3)<Type>::gdbSetUpShadowMultiGrid(const int axis, 
                                                     const int lc, const int lf,
                                                     const short* olap,
                                                     const int bwidth,
						     const int extghwidth)
 {
   assert (axis == DAGH_X || axis == DAGH_Y || axis == DAGH_Z);

   if (shmgflag != DAGHNull) gdbReleaseShadowMultiGrid();

   shmgflag = axis;
   shmglfine = lf;
   shmglcoarse = lc;
   shmglevels = lf-lc+1;
   if (shmglevels == 1) return;

   shmgstorage = new GridDataBlockStorage(3)<Type> *[mglevels-1];

#ifdef DEBUG_PRINT_GDB_MG
       ( comm_service::log() << "gdbSetUpShadowMultiGrid" << "[" << gfid << "]"
                         << "[MGLevel: " << lf << "]"
                         << shstorage << " "
                         << endl ).flush();
#endif

   const int myrank = 3;
   const int multigridfactor = dagh.daghmultigridfactor();

   register int lindex = 0;
   register int factor = 1;

   for ( register int l = lf-1 ; l >= lc ; l-- ) {
     lindex = l-lc; 
     factor *= multigridfactor;

     shmgstorage[lindex] = new GridDataBlockStorage(3)<Type>;
     GridDataBlockStorage(3)<Type>* shmg = shmgstorage[lindex];

     const BBox shmgbb = coarsen(shmerged_bbox,axis,factor);
     const Coords &cl = shmgbb.lower();
     const Coords &cu = shmgbb.upper();
     const Coords &step = shmgbb.stepsize();

     BBox& db = shmg->bbox; db = shmgbb;
     BBox& ib = shmg->ibbox; ib = shmgbb;
     BBox* bndrybb = shmg->bndrybbox;

     for ( register int i = 0 ; i < myrank ; i++ ) {
       register int itimes2 = 2*i;

       if (bndryflags[itimes2] == DAGHFalse) {
         db.lower(i) -= step(i)*sten_rad[itimes2];
       }
       else if (bwidth > 0) {
         bndrybb[itimes2] = shmgbb;
         bndrybb[itimes2].upper(i) = (cl(i) + step(i)*(bwidth-1));
       }

       if (bndryflags[itimes2+1] == DAGHFalse) {
         db.upper(i) += step(i)*sten_rad[itimes2+1];
         ib.upper(i) -= (olap[i]*step(i));
       }
       else if (bwidth > 0) {
         bndrybb[itimes2+1] = shmgbb;
         bndrybb[itimes2+1].lower(i) = (cu(i) - step(i)*(bwidth-1));
       }
     }
     if (extghwidth > 0) db.grow(extghwidth);
     shmg->allocate();
#ifdef DEBUG_PRINT_GDB_MG
     ( comm_service::log() << "gdbSetUpMultiGrid" << "[" << gfid << "]"
                           << "[MGLevel: " << lindex << "]"
                           << *shmg << " "
                           << endl ).flush();
#endif
   }

   /* Setup Shadow MG Info */
   const int pnum = comm_service::proc_num();
   const int inter_cnt = DAGHMaxAxis * DAGHMaxDirs * maxindex;

   /* Setup Shadow MG Ghosts */
   for ( register int p = 0 ; p < pnum ; p++ ) {
     if ( !gdb_write_info[p] ) continue;
     for ( register int i = 0 ; i < inter_cnt ; i++ ) {
       if ( !gdb_write_info[p][i] ) continue;
       gdb_write_info[p][i]->shmgbbox = new BBox [shmglevels-1];
       BBox *b = gdb_write_info[p][i]->shmgbbox;
       factor = 1;
       for ( register int ll = lf-1 ; ll >= lc ; ll-- ) {
         lindex = ll-lc;  factor *= multigridfactor;
         b[lindex] = coarsen(gdb_write_info[p][i]->shbbox,axis,factor);
	 if (olap[0] > 0 || olap[1] > 0 || olap[2] > 0) {
           BBox& bb = b[lindex];
           BBox shmgbb = shmgstorage[lindex]->bbox;
           if (extghwidth > 0) shmgbb.grow(-extghwidth);
           for ( register int r = 0 ; r < myrank ; r++ ) {
             if (olap[r] > 0 &&
                 bb.lower(r)==shmgbb.lower(r) && bb.upper(r)==shmgbb.lower(r))
               bb.shift(r,olap[r]);
           }
         }
       }
     } /* We don't need to setup read ghosts */
   } /* End setup Shadow MG Ghosts */

   /* Setup Shadow Prolong Info */
   for ( register int r = 0 ; r < 2*myrank ; r++ ) {
     if ( ghost_prolong_flag[r] == DAGHFalse ) continue;
     ghost_prolong_info[r].shmgbbox = new BBox [shmglevels-1];
     BBox *b = ghost_prolong_info[r].shmgbbox;
     factor = 1;
     for ( register int ll = lf-1 ; ll >= lc ; ll-- ) {
       lindex = ll-lc;  factor *= multigridfactor;
       b[lindex] = coarsen(ghost_prolong_info[r].shbbox,axis,factor);
       if (olap[0] > 0 || olap[1] > 0 || olap[2] > 0) {
         BBox& bb = b[lindex];
         BBox shmgbb = shmgstorage[lindex]->bbox;
         if (extghwidth > 0) shmgbb.grow(-extghwidth);
         for ( register int rr = 0 ; rr < myrank ; rr++ ) {
           if (olap[rr] > 0 &&
               bb.lower(rr)==shmgbb.lower(rr) && bb.upper(rr)==shmgbb.lower(rr))
             bb.shift(rr,olap[rr]);
         }
       }
     }
   } /* End Setup Shadow Prolong Info */
 }

template <class Type>
void GridDataBlock(3)<Type>::gdbReleaseShadowMultiGrid(void)
 {
   if (shmgflag == DAGHNull) return;

   const int myrank = 3;

   /* Storage */
   register int i;
   for ( i = 0 ; i < shmglevels-1 ; i++ )
     if (shmgstorage[i]) delete shmgstorage[i];

   if (shmgstorage) delete [] shmgstorage;

   /* Ghost Info */
   const int pnum = comm_service::proc_num();
   const int inter_cnt = DAGHMaxAxis * DAGHMaxDirs * maxindex;

   if (gdb_write_info) for ( register int p = 0 ; p < pnum ; p++ ) {
     if ( !gdb_write_info[p] ) continue;
     for ( i = 0 ; i < inter_cnt ; i++ ) {
       if (gdb_write_info[p][i] && gdb_write_info[p][i]->shmgbbox)
         delete [] gdb_write_info[p][i]->shmgbbox;
     }
   }
   for ( register int r = 0 ; r < 2*myrank ; r++ ) {
     if (ghost_prolong_flag[r]==DAGHTrue && ghost_prolong_info[r].shmgbbox)
       delete [] ghost_prolong_info[r].shmgbbox;
   }

   shmgflag = DAGHNull;
 }
/******************************************************************/

/******************************************************************/
/* Ghost Communications */
/******************************************************************/
template <class Type>
void GridDataBlock(3)<Type>::gdbReadGhosts(const int proc,
                                           const int axis, 
                                           const int dir, 
                                           const int ident,
                                           const int mgl)
 {
  assert (dir==DAGH_Backward || dir==DAGH_Forward || axis==DAGH_All);

  const int me = comm_service::proc_me();
  const int index = ( DAGHMaxDirs * maxindex * axis ) + 
                       ( maxindex * dir );
  int off = DAGHNull;

  GridDataBucket<Type> *gdb = 0;

#ifdef DEBUG_PRINT_GDB_COMM
  ( comm_service::log() << "gdbReadGhosts:" << "[" << proc << "]"
                        << "[" << me << "]"
                        << "[" << timenum << "]" << "[" << levelnum << "]" 
                        << "[" << axis << "]" << "[" << dir << "]" 
                        << "[" << ident << "]" << "[" << mgl << "]" 
                        << endl ).flush();
#endif

  if (gdb_read_info[proc]) {
    for ( register int m = 0 ; m < maxindex ; m++ ) {
      if (gdb_read_info[proc][index+m]) {

#ifdef DEBUG_PRINT_GDB_COMM
   ( comm_service::log() << "Reading { " 
                         << *gdb_read_info[proc][index+m] << " }"
                         << endl ).flush();
#endif

        gdb = (GridDataBucket<Type> *)
        gtable.read_only(*gdb_read_info[proc][index+m]->gte,
                         timenum,levelnum,axis,dir,
                         mygte->myindex(),off);

        if (gdb) {

#ifdef DEBUG_PRINT_GDB_COMM
   ( comm_service::log() << "gdbReadGhosts:Copying { "
                         << *gdb->head(off) << " [" << off << "]" 
                         << " }"
                         << endl ).flush();
#endif

          (griddata(ident,mgl)).copy(*gdb,off);
        }
        else {
#ifdef DEBUG_PRINT_GDB_COMM
   ( comm_service::log() << "gdbReadGhosts: [" << me << "] Did Not Recv { " 
                         << *gdb_read_info[proc][index+m] << " }"
                         << " from [" << proc << "]" << endl ).flush();
#endif
          cerr << "gdbReadGhosts:" << me <<" Did not receive ghost from " 
               << proc << "!" << endl << flush;
          MPI_Finalize();
          exit (-1);
        }
        gdb->free();
        gdb = 0;
      }
    }
  }
 }

template <class Type>
int GridDataBlock(3)<Type>::gdbWriteGhosts(const int proc,
                                           const int axis, 
                                           const int dir, 
                                           const int ident,
                                           const int mgl,
                                           GridDataBucket<Type>& gdb,
                                           const int at)
 {
  assert (dir==DAGH_Backward || dir==DAGH_Forward || axis==DAGH_All);

  
  const int myindex = mygte->myindex();
  const int index = ( DAGHMaxDirs * maxindex * axis ) + 
                    ( maxindex * dir );
  const int me = comm_service::proc_me();

#ifdef DEBUG_PRINT_GDB_COMM
  ( comm_service::log() << "gdbWriteGhosts:" << "[" << proc << "]"
                        << "[" << me << "]"
                        << "[" << timenum << "]" << "[" << levelnum << "]" 
                        << "[" << axis << "]" << "[" << dir << "]" 
                        << "[" << ident << "]" << "[" << mgl << "]" 
                        << "[" << baseindex << "]" << endl ).flush();
#endif

  GDB_Interaction* gdbi = 0;
  int cnt = 0;
  if (gdb_write_info[proc]) {
    for ( register int i = 0, idx = at ; i < maxindex ; i++ ) {
      if (gdbi=gdb_write_info[proc][index+i]) {

#ifdef DEBUG_PRINT_GDB_COMM
   ( comm_service::log() << "Writing { " << *gdbi << " }" << endl ).flush();
#endif

       BBox bb = ghostbox(*gdbi,ident,mgl);
       gdb.add(bb, gfid, timenum, levelnum, index+i, me, baseindex, 
                ident, idx);
       (griddata(ident,mgl)).PackRegion(gdb.data(idx), bb);
       cnt++; idx++;
      }
    }
  }
  return cnt;
 }

/******************************************************************/
/* Data Communications */
/******************************************************************/
template <class Type>
void GridDataBlock(3)<Type>::gdbReadData(const int ident, const int mgl)
 {
  const int me = comm_service::proc_me();
  const int inside = mygte->myinside();
  int off = DAGHNull;

#ifdef DEBUG_PRINT_GDB_COMM
  ( comm_service::log() << "gdbReadData:" 
                        << "[" << me << "]"
                        << "[" << timenum << "]" << "[" << levelnum << "]"
                        << "[" << inside << "]" 
                        << "[" << ident << "]" << "[" << mgl << "]"
                        << "[" << baseindex << "]" << endl ).flush();
#endif

  GridDataBucket<Type>*& gdb = 
       (GridDataBucket<Type> *&) (*mygte)(timenum,levelnum,inside,off);
  if (gdb) {
    (griddata(ident,mgl)).copy(*gdb,off);
    gdb->free();
    gdb = 0;
  }
  else if (comm_service::dce()) {
    comm_service::serve(*gdb_data_rcv->req());
    (griddata(ident,mgl)).copy(*gdb,off);
    gdb->free();
    gdb = 0;
  }
 }

template <class Type>
void GridDataBlock(3)<Type>::gdbWriteData(const int ident, const int mgl,
                                         GridDataBucket<Type>& gdb,
                                         const int at)
 {
  const int me = comm_service::proc_me();
  const int inside = mygte->myinside();

  //const BBox bb = interiorbox(ident,mgl);
  const BBox bb = boundingbox(ident,mgl);

#ifdef DEBUG_PRINT_GDB_COMM
  ( comm_service::log() << "gdbWriteData:" << "[" << me << "]"
                        << "[" << timenum << "]" << "[" << levelnum << "]" 
                        << "[" << ident << "]" << "[" << mgl << "]" 
                        << "[" << baseindex << "]" << bb << endl ).flush();
#endif

  gdb.add(bb, gfid, timenum, levelnum, inside, me, baseindex, 
                ident, at);
  (griddata(ident,mgl)).PackRegion(gdb.data(at), bb);
 }

template <class Type>
void GridDataBlock(3)<Type>::gdbWriteData(const int ident, const int mgl,
                                         const BBox& where,
                                         GridDataBucket<Type>& gdb,
                                         const int at)
 {
  const int me = comm_service::proc_me();
  const int inside = mygte->myinside();

  //const BBox bb = interiorbox(ident,mgl) * where;
  const BBox bb = boundingbox(ident,mgl) * where;

#ifdef DEBUG_PRINT_GDB_COMM
  ( comm_service::log() << "gdbWriteData:" << "[" << me << "]"
                        << "[" << timenum << "]" << "[" << levelnum << "]" 
                        << "[" << ident << "]" << "[" << mgl << "]" 
                        << "[" << baseindex << "]" << bb << endl ).flush();
#endif

  gdb.add(bb, gfid, timenum, levelnum, inside, me, baseindex, 
                ident, at);
  (griddata(ident,mgl)).PackRegion(gdb.data(at), bb);
 }

/******************************************************************/
/* Overloaded output */
/******************************************************************/
template <class Type>
ostream&  operator << (ostream& os, const GridDataBlock(3)<Type>& gdb)
  {
   if (&gdb == (GridDataBlock(3)<Type> *) NULL) return os;

   const int myrank = 3;

   os << "GridDataBlock(3)<Type>: ";
   os << "[GFid:" << gdb.gfid << "]" ;
   os << "[Time:" << gdb.timenum << "]";
   os << "[Level:" << gdb.levelnum << "]";
   os << "[BaseIndex:" << gdb.baseindex << "]";
   os << endl;
   os << "[Main:" << gdb.merged_bbox << "]";
   os << "[Shadow:" << gdb.shmerged_bbox << "]";
   os << endl;

   os << "[Boundary Flags: ";
   register int b;
   for (b = 0 ; b < myrank ; b++) 
   os << gdb.bndryflags[2*b] << " " 
      << gdb.bndryflags[2*b+1] << " ";
   os << "]" << endl;

   os << "[Ghost Prolong Flags: ";
   for (b = 0 ; b < myrank ; b++) 
   os << gdb.ghost_prolong_flag[2*b] << " " 
      << gdb.ghost_prolong_flag[2*b+1] << " ";
   os << "]" << endl;

   os << "[Ghost Prolong Interactions:" << endl;
   for (b = 0 ; b < myrank ; b++)  {
     if (gdb.ghost_prolong_flag[2*b] == DAGHTrue) 
       os << "  [" << 2*b << ":" << gdb.ghost_prolong_info[2*b] << "]" << endl;
     if (gdb.ghost_prolong_flag[2*b+1] == DAGHTrue) 
       os << "  [" << 2*b+1 << ":" << gdb.ghost_prolong_info[2*b+1] << "]" << endl;
   }
   os << "]" << endl;

   os << "Main Storage:" << endl;
   os << "  " << gdb.mstorage;

   if (gdb.shflag == DAGHTrue) {
     os << "Shadow Storage:" << endl;
     os << "  " << *gdb.shstorage;
   }
   const int np = comm_service::proc_num();
   const int inter_cnt = DAGHMaxAxis * DAGHMaxDirs * gdb.maxindex;

   if (gdb.gdb_write_info) {
     os << "Write Interactions: " << endl;
     for (register int n=0; n<np; n++) {
       if (gdb.gdb_write_info[n])
         for (register int i=0;i<inter_cnt;i++)
           if (gdb.gdb_write_info[n][i]) 
             os << "  gdb_write_info[" << n << "][" << i/gdb.maxindex << "]"
                << *gdb.gdb_write_info[n][i]
                << endl;
     }
   }
   if (gdb.gdb_read_info) {
     os << "Read Interactions: " << endl; 
     for (register int n=0; n<np; n++) {
       if (gdb.gdb_read_info[n])
         for (register int i=0;i<inter_cnt;i++)
           if (gdb.gdb_read_info[n][i])
             os << "  gdb_read_info[" << n << "][" << i/gdb.maxindex << "]"
                << *gdb.gdb_read_info[n][i]
                << endl;
     }
   }

   return os;
  }

template <class Type>
ostream& operator<<(ostream& os, const GridDataBlockStorage(3)<Type>& gdbs)
  {
    if (&gdbs == (GridDataBlockStorage(3)<Type> *) NULL) return os;

    const int myrank = 3;

    os << "GDBStorage: ";
    os << gdbs.bbox << gdbs.ibbox;
    os << "[ ";
    for (register int b = 0 ; b < myrank ; b++) {
      if (!gdbs.bndrybbox[2*b].empty()) os << gdbs.bndrybbox[2*b];
      if (!gdbs.bndrybbox[2*b+1].empty()) os << gdbs.bndrybbox[2*b+1];
    }
    os << " ]" << endl;
    return os;
  }

/******************************************************************/
/* binary output for checkpointing */
/******************************************************************/
template <class Type>
ofstream&  operator << (ofstream& ofs, const GridDataBlock(3)<Type>& gdb)
  {
   if (&gdb == (GridDataBlock(3)<Type> *) NULL) return ofs;

   ofs.write((char*)&gdb.timenum,sizeof(short));
   ofs.write((char*)&gdb.levelnum,sizeof(short));
   ofs.write((char*)&gdb.shflag,sizeof(short));

   ofs << gdb.griddata(DAGH_Main,DAGHNull);
   if (gdb.shflag == DAGHTrue)
     ofs << gdb.griddata(DAGH_Shadow,DAGHNull);

   return ofs;
  }

template <class Type>
ifstream&  operator >> (ifstream& ifs, GridDataBlock(3)<Type>& gdb)
  {
   if (&gdb == (GridDataBlock(3)<Type> *) NULL) return ifs;

   short tmptimenum, tmplevelnum, tmpshflag;
   ifs.read((char*)&tmptimenum,sizeof(short));
   ifs.read((char*)&tmplevelnum,sizeof(short));
   ifs.read((char*)&tmpshflag,sizeof(short));
   
   assert (tmptimenum == gdb.timenum && tmplevelnum == gdb.levelnum);
   ifs >> gdb.griddata(DAGH_Main,DAGHNull);
   if (gdb.shflag == DAGHTrue && tmpshflag == DAGHTrue)
     ifs >> gdb.griddata(DAGH_Shadow,DAGHNull);

   return ifs;
  }

#endif
