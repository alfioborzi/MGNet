#ifndef _included_DAGHIO_hdf_rnpl_h
#define _included_DAGHIO_hdf_rnpl_h

/*@@
  @file     DAGHIO_hdf_rnpl.h
  @author   Manish Parashar
  @desc
      <pre>
 DAGHIO_hdf_rnpl.h                                                     
                                                                       
 Author:  Manish Parashar <parashar@cs.utexas.edu>                     
                                                                       
      </pre>
  @enddesc
  @comment
      <code>
      $Id: DAGHIO_hdf_rnpl.h,v 1.6 1997/04/15 20:13:07 parashar Exp $
      </code>
  @endcomment
@@*/

#include "DAGH.h"
#include "DAGHParams.h"
#include "DAGHIOParams.h"
#include "PackedGridDataBucket.h"

#ifdef IO_RNPLIO
extern "C" {
#include <bbhutil.h>
}

#define c_hdf_rnpl_write (gft_write_full)
#endif

#endif
