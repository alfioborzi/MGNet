#ifndef _included_PeanoHilbert_h
#define _included_PeanoHilbert_h

/*
*************************************************************************
*                                                                       *
* PeanoHilbert.h                                                        *
*                                                                       *
* Class PeanoHilbert defines the Peano-Hilbert sfc mapping. This class  *
* is derived from sfcIndex and defines mapping and inverse mapping 	*
* routines.								*
*                                                                       *
* Note: PeanoHilbert currently handles only 1-3 Dims !!!		*
*       I intend to expand it to 4 dimensiions.				*
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

#include "sfcIndex.h"

#ifndef PeanoHibertBase
#define PeanoHibertBase (2)
#endif

class PeanoHilbert : public sfcIndex
  {

public:

   /* Default Constructor */
   inline PeanoHilbert()
	: sfcIndex() {}

   /* Other Constructors */
   inline PeanoHilbert(int const dim, int const levs)
	: sfcIndex(dim,levs,PeanoHibertBase)
	{assert(dim<=3);}

   /* The copy constructor */
   inline PeanoHilbert(PeanoHilbert const &other)
  	: sfcIndex((sfcIndex const &)other) {}

   /* Mapping routines */
private:
   void Invert(unsigned *coords) const;

public:
   inline void SetIndex(unsigned const index, int const idxlev)
	{ sfcSetIndex(index,idxlev); }
   inline void SetIndex(unsigned const index, int const idxlev, int const nlev)
   	{ sfcSetIndex(index,idxlev,nlev); }

   void Map(unsigned const *coords);
   void Invert(unsigned *coords, unsigned const index);
   void Invert(unsigned *coords, unsigned const index, int const idxlev);
   void Invert(unsigned *coords, unsigned const index, 
	       int const idxlev, int const nlev);

   /* Get the bounding box for the GridUnit whose base is 
      maintained by "this" */
   PeanoHilbert *GetBox(int const lev, int const nlev) const;
   void SetBox(int const lev, int const nlev);

   /* Get the maximum index in the GridUnit whose base is 
      maintained by "this" */
   PeanoHilbert *GetMax(int const lev, int const nlev) const;
   void SetMax(int const lev, int const nlev);

   /* Set the index to the baseindex at that level */
   void ResetBase(int const lev, int const nlev);
   
   /* Query routines */
   void GetCoords(unsigned *coords, int const lev = 1) const;
   unsigned *GetCoords(int const lev = 1) const;

   /* number of cells at a level */
   inline unsigned GetCardinality(const int dim, const int lev) const
	{return (unsigned)1<<(lev*dim);}
   inline unsigned GetCardinality(const int lev) const
	{return (unsigned)1<<(lev*sfcdim);}

   /* essentially the step size at a level */
   inline unsigned GetDimCardinality(const int lev) const
	{return (unsigned)1<<(sfclevs-lev);}

   /* max value of an index along a dimension */
   inline unsigned GetDimMax(const int lev) const
	{return (((unsigned)1<<lev)-1)*((unsigned)1<<(sfclevs-lev));}
   
private:

/*
// The following operations are used to orient the seed
// curve as required. The seed curve is "->"
// Axis are numbered as follows:
// "->" x: 1
// "|"  y: 2
// "/"  z: 3
// Directions are numbered as follows:
// "->" (positive x): 1
// "|" (positive y): 2
// "/" (positive z): 3
// phSwapDir ->(PH) = <-(PH)
// phTranslate ->(PH) = (PH)->
// phRotate ->(PH) (1,2) = |(PH)
// phRotate ->(PH) (1,3) = /(PH)
// phRotate |(PH) (2,1) = ->(PH)
// phRotate /(PH) (3,1) = ->(PH)
// Note:
// (1) "phRotate" is valid to/from the seed orientation only !
//     i.e. "to" or "from" should be "->" or 1.
// (2) Bit are numbered from 0 to DIM-1 such that the msb is 0 and
//     the lsb is Dim-1.
//     i.e. x = xb0 xb1 xb2 xb3 ... xbDIM-1
*/

   inline void phSwapDir(int const level, int const axis)
	{sfcToggleDigitWd(level,axis-1);}
   inline void phTranslate(int const level, int const axis)
	{sfcToggleDigitWd(level,axis-1);}
   inline void phRotate(int const level, int const from_axis, int const to_axis)
   	{sfcSwapDigitWd(level,from_axis-1,to_axis-1);}

   void phOrient(int const level, int const pos);
   unsigned phGray(int const level);
   unsigned phGinv(int const level);

  };

#ifdef __ENABLE_INLINE__
#include "PeanoHilbert.inline"
#endif

#endif
