/*
*************************************************************************
* DAGHGhostInteractions.C						*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGHGhostInteraction.h"

static int ipow(int b, int p)
 {
   register int tmpr = 1;
   while (p--) tmpr *= b;
   return tmpr;
 }

GhostInteraction::GhostInteraction( const int rank, 
                                    const int type,
                                    const int width )
	: Irank(rank), Itype(type), Iwidth(2*width+1),
	  Iinside(DAGHNull),
          FaceFlag(0), CornerFlag(0), EdgeFlag(0)
  {
   assert( Itype == DAGHGhostInteraction );

   Itotal = ipow( Iwidth , Irank ); 

   /* Initialise.... */
   for (register int a=0 ; a<DAGHMaxAxis ; a++ ) {
     for (register int d=0 ; d<DAGHMaxDirs ; d++ ) {
       if (a < rank || a == DAGH_All) {
         Ilists[a][d] = new short [Itotal];
         for (register int i=0 ; i<Itotal ; i++ ) {
            Ilists[a][d][i] = DAGHFalse;
         }
       }
       else {
         Ilists[a][d] = 0;
       }
     }
   }
   Iface_cnt = 2*Irank;
   Ifaces = new short[Iface_cnt];
  }

GhostInteraction::GhostInteraction( const int rank, 
                                    const int face_flag,
                                    const int corner_flag, 
                                    const int edge_flag,
                                    const int type,
                                    const int width )
	: Irank(rank), Itype(type), Iwidth(2*width+1),
	  Iinside(DAGHNull),
          FaceFlag(face_flag), CornerFlag(corner_flag), EdgeFlag(edge_flag)
  {
   assert( Itype == DAGHGhostInteraction );

   Itotal = ipow( Iwidth , Irank ); 

   /* Initialise.... */
   for (register int a=0 ; a<DAGHMaxAxis ; a++ ) {
     for (register int d=0 ; d<DAGHMaxDirs ; d++ ) {
       if (a < Irank || a == DAGH_All) {
         Ilists[a][d] = new short [Itotal];
         for (register int i=0 ; i<Itotal ; i++ ) {
            Ilists[a][d][i] = DAGHFalse;
         }
       }
       else {
         Ilists[a][d] = 0;
       }
     }
   }
   Iface_cnt = 2*Irank;
   Ifaces = new short[Iface_cnt];

   /* Setup Counts */
   int all_axis_cnt = 0;
   /* DAGH_X, DAGH_Y, & DAGH_Z */
   register int i;
   for (i=0 ; i<Irank ; i++ ) {
     /* FORWARD & BACKWARD */
     Icounts[i][DAGH_Backward] =  Icounts[i][DAGH_Forward] = ipow( Iwidth , Irank-1 );
     /* BOTH */
     Icounts[i][DAGH_Both] =  2*ipow( Iwidth , Irank-1 );
     all_axis_cnt += ipow( Iwidth , Irank-1-i ) * ipow( Iwidth-1 , i );
   }
   /* DAGH_All */
   Icounts[DAGH_All][0] = all_axis_cnt;
   Icounts[DAGH_All][1] = all_axis_cnt;
   Icounts[DAGH_All][2] =  Itotal-1;

   register int x, y, z;
   /* Fill In */
   const int Ir = width;
   for (i=0 ; i<Itotal ; i++ ) {
      x = (Irank == 3) ? (i/ipow(Iwidth,Irank-1))%Iwidth : 
          (Irank == 2) ? (i/Iwidth)%Iwidth : i%Iwidth;
      y = (Irank == 3) ? (i/Iwidth)%Iwidth : (Irank == 2) ? i%Iwidth : Ir;
      z = (Irank == 3) ? i%Iwidth : Ir;

      if ( is_inside(x,y,z) ) {
         Iinside = i;
         continue;
      }

      if (is_face(x,y,z)) {
         int idx = (x!=1) ? (2*DAGH_X)+(x/2) : 
                   (y!=1) ? (2*DAGH_Y)+(y/2) : 
                            (2*DAGH_Z)+(z/2) ;
         Ifaces[idx] = i;
      }

      if ( !FaceFlag && is_face(x,y,z)) continue;
      if ( !CornerFlag && is_corner(x,y,z)) continue;
      if ( !EdgeFlag && is_edge(x,y,z)) continue;

      if ( x==0 ) {
        Ilists[DAGH_X][DAGH_Backward][i] = DAGHTrue;
        Ilists[DAGH_X][DAGH_Both][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Backward][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Both][i] = DAGHTrue;
      }
      else if ( x==2 ) {
        Ilists[DAGH_X][DAGH_Forward][i] = DAGHTrue;
        Ilists[DAGH_X][DAGH_Both][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Forward][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Both][i] = DAGHTrue;
      }

      if ( y==0 ) {
        Ilists[DAGH_Y][DAGH_Backward][i] = DAGHTrue;
        Ilists[DAGH_Y][DAGH_Both][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Backward][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Both][i] = DAGHTrue;
      }
      else if ( y==2 ) {
        Ilists[DAGH_Y][DAGH_Forward][i] = DAGHTrue;
        Ilists[DAGH_Y][DAGH_Both][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Forward][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Both][i] = DAGHTrue;
      }

      if ( z==0 ) {
        Ilists[DAGH_Z][DAGH_Backward][i] = DAGHTrue;
        Ilists[DAGH_Z][DAGH_Both][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Backward][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Both][i] = DAGHTrue;
      }
      else if ( z==2 ) {
        Ilists[DAGH_Z][DAGH_Forward][i] = DAGHTrue;
        Ilists[DAGH_Z][DAGH_Both][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Forward][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Both][i] = DAGHTrue;
      }
   }
  }

GhostInteraction::GhostInteraction( GhostInteraction const &other)
	: Irank(other.Irank), Itype(other.Itype), Iwidth(other.Iwidth),
	  Iinside(other.Iinside),
          Iface_cnt(other.Iface_cnt), Ifaces(0),
          //Iface_cnt(other.Iface_cnt), Ifaces(0),
          //Icorner_cnt(other.Icorner_cnt), Icorners(0),
          //Iedge_cnt(other.Iedge_cnt), Iedges(0),
          FaceFlag(other.FaceFlag), 
          CornerFlag(other.CornerFlag), 
          EdgeFlag(other.EdgeFlag)
  {
   register int a;
   for (a=0 ; a<DAGHMaxAxis ; a++ ) {
     for (register int d=0 ; d<DAGHMaxDirs ; d++ ) {
       Icounts[a][d] = other.Icounts[a][d];
       if (other.Ilists[a][d]) {
         Ilists[a][d] = new short [Itotal];
         for (register int i=0 ; i<Itotal ; i++ )
            Ilists[a][d][i] = other.Ilists[a][d][i];
       }
       else {
         Ilists[a][d] = 0;
       }
     }
   }
   Ifaces = new short[Iface_cnt];
   for (a=0 ; a<Iface_cnt ; a++) {
     Ifaces[a] = other.Ifaces[a];
   }
  }

GhostInteraction::~GhostInteraction( )
 {
   for (register int a=0 ; a<DAGHMaxAxis ; a++ ) {
     for (register int d=0 ; d<DAGHMaxDirs ; d++ ) {
       if (Ilists[a][d]) delete [] Ilists[a][d];  
     }
   }
   if (Ifaces) delete [] Ifaces;
 }

void GhostInteraction::compute_interactions( const int face_flag,
                                             const int corner_flag, 
                                             const int edge_flag )
  {
   FaceFlag = face_flag;
   CornerFlag = corner_flag;
   EdgeFlag = edge_flag;

   /* Setup Counts */
   int all_axis_cnt = 0;
   /* DAGH_X, DAGH_Y, & DAGH_Z */
   register int i;
   for (i=0 ; i<Irank ; i++ ) {
     /* FORWARD & BACKWARD */
     Icounts[i][DAGH_Backward] =  Icounts[i][DAGH_Forward] = ipow( Iwidth , Irank-1 );
     /* BOTH */
     Icounts[i][DAGH_Both] =  2*ipow( Iwidth , Irank-1 );
     all_axis_cnt += ipow( Iwidth , Irank-1-i ) * ipow( Iwidth-1 , i );
   }
   /* DAGH_All */
   Icounts[DAGH_All][0] = all_axis_cnt;
   Icounts[DAGH_All][1] = all_axis_cnt;
   Icounts[DAGH_All][2] =  Itotal-1;

   register int x, y, z;
   /* Fill In */
   const int Ir = (Iwidth-1)/2;
   for (i=0 ; i<Itotal ; i++ ) {
      x = (Irank == 3) ? (i/ipow(Iwidth,Irank-1))%Iwidth : 
          (Irank == 2) ? (i/Iwidth)%Iwidth : i%Iwidth;
      y = (Irank == 3) ? (i/Iwidth)%Iwidth : (Irank == 2) ? i%Iwidth : Ir;
      z = (Irank == 3) ? i%Iwidth : Ir;

      if ( is_inside(x,y,z) ) {
         Iinside = i;
         continue;
      }

      if (is_face(x,y,z)) {
         int idx = (x!=1) ? (2*DAGH_X)+(x/2) : 
                   (y!=1) ? (2*DAGH_Y)+(y/2) : 
                            (2*DAGH_Z)+(z/2) ;
         Ifaces[idx] = i;
      }

      if ( !FaceFlag && is_face(x,y,z)) continue;
      if ( !CornerFlag && is_corner(x,y,z)) continue;
      if ( !EdgeFlag && is_edge(x,y,z)) continue;

      if ( x==0 ) {
        Ilists[DAGH_X][DAGH_Backward][i] = DAGHTrue;
        Ilists[DAGH_X][DAGH_Both][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Backward][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Both][i] = DAGHTrue;
      }
      else if ( x==2 ) {
        Ilists[DAGH_X][DAGH_Forward][i] = DAGHTrue;
        Ilists[DAGH_X][DAGH_Both][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Forward][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Both][i] = DAGHTrue;
      }

      if ( y==0 ) {
        Ilists[DAGH_Y][DAGH_Backward][i] = DAGHTrue;
        Ilists[DAGH_Y][DAGH_Both][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Backward][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Both][i] = DAGHTrue;
      }
      else if ( y==2 ) {
        Ilists[DAGH_Y][DAGH_Forward][i] = DAGHTrue;
        Ilists[DAGH_Y][DAGH_Both][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Forward][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Both][i] = DAGHTrue;
      }

      if ( z==0 ) {
        Ilists[DAGH_Z][DAGH_Backward][i] = DAGHTrue;
        Ilists[DAGH_Z][DAGH_Both][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Backward][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Both][i] = DAGHTrue;
      }
      else if ( z==2 ) {
        Ilists[DAGH_Z][DAGH_Forward][i] = DAGHTrue;
        Ilists[DAGH_Z][DAGH_Both][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Forward][i] = DAGHTrue;
        Ilists[DAGH_All][DAGH_Both][i] = DAGHTrue;
      }
   }
  }

BBox GhostInteraction::Ibbox(BBox const &mybb, const int dir, short const *rad) const
 {
   if (mybb.empty()) return mybb;

   const int Ir = (Iwidth-1)/2;
   const int x = -Ir + ((Irank == 3) ? (dir/ipow(Iwidth,Irank-1))%Iwidth : 
                        (Irank == 2) ? (dir/Iwidth)%Iwidth : dir%Iwidth);
   const int y = -Ir + ((Irank == 3) ? (dir/Iwidth)%Iwidth : 
                        (Irank == 2) ? dir%Iwidth : Ir);
   const int z = -Ir + ((Irank == 3) ? dir%Iwidth : Ir);

   Coords const step = mybb.stepsize();
   BBox gbb(mybb);

   if ( x < 0 ) {
     gbb.lower(0) += x * rad[2*DAGH_X] * step(0);
     gbb.upper(0) = mybb.lower(0) - step(0);
   }
   else if ( x > 0 ) {
     gbb.lower(0) = mybb.upper(0) + step(0);
     gbb.upper(0) += x * rad[2*DAGH_X+1] * step(0);
   }
   
   if ( y < 0 ) {
     gbb.lower(1) += y * rad[2*DAGH_Y] * step(1);
     gbb.upper(1) = mybb.lower(1) - step(1);
   }
   else if ( y > 0 ) {
     gbb.lower(1) = mybb.upper(1) + step(1);
     gbb.upper(1) += y * rad[2*DAGH_Y+1] * step(1);
   }
   
   if ( z < 0 ) {
     gbb.lower(2) += z * rad[2*DAGH_Z] * step(2);
     gbb.upper(2) = mybb.lower(2) - step(2);
   }
   else if ( z > 0 ) {
     gbb.lower(2) = mybb.upper(2) + step(2);
     gbb.upper(2) += z * rad[2*DAGH_Z+1] * step(2);
   }

   return gbb;
 }

BBox GhostInteraction::Ibbox(BBox const &mybb, 
                             const int Axis, const int Dir, 
                             short const *rad) const
 {
   if (mybb.empty()) return mybb;

   const short* ll = Ilists[Axis][Dir];
   BBox whole_gbb;

   for ( register int idir = 0 ; idir < Itotal ; idir++ ) {

   if ( ll[idir] != DAGHTrue ) continue;

   const int dir = idir;
   
   const int Ir = (Iwidth-1)/2;
   const int x = -Ir + ((Irank == 3) ? (dir/ipow(Iwidth,Irank-1))%Iwidth : 
                        (Irank == 2) ? (dir/Iwidth)%Iwidth : dir%Iwidth);
   const int y = -Ir + ((Irank == 3) ? (dir/Iwidth)%Iwidth : 
                        (Irank == 2) ? dir%Iwidth : Ir);
   const int z = -Ir + ((Irank == 3) ? dir%Iwidth : Ir);

   Coords const step = mybb.stepsize();
   BBox gbb(mybb);

   if ( x < 0 ) {
     gbb.lower(0) += x * rad[2*DAGH_X] * step(0);
     gbb.upper(0) = mybb.lower(0) - step(0);
   }
   else if ( x > 0 ) {
     gbb.lower(0) = mybb.upper(0) + step(0);
     gbb.upper(0) += x * rad[2*DAGH_X+1] * step(0);
   }
   
   if ( y < 0 ) {
     gbb.lower(1) += y * rad[2*DAGH_Y] * step(1);
     gbb.upper(1) = mybb.lower(1) - step(1);
   }
   else if ( y > 0 ) {
     gbb.lower(1) = mybb.upper(1) + step(1);
     gbb.upper(1) += y * rad[2*DAGH_Y+1] * step(1);
   }
   
   if ( z < 0 ) {
     gbb.lower(2) += z * rad[2*DAGH_Z] * step(2);
     gbb.upper(2) = mybb.lower(2) - step(2);
   }
   else if ( z > 0 ) {
     gbb.lower(2) = mybb.upper(2) + step(2);
     gbb.upper(2) += z * rad[2*DAGH_Z+1] * step(2);
   }

   whole_gbb += gbb;

   }
   return whole_gbb;
 }

BBox GhostInteraction::IbboxFrom(BBox const &mybb, const int dir, 
                                 short const *rad, const short* olap) const
 {
   if (mybb.empty()) return mybb;

   const int Ir = (Iwidth-1)/2;
   const int x = -Ir + ((Irank == 3) ? (dir/ipow(Iwidth,Irank-1))%Iwidth : 
                        (Irank == 2) ? (dir/Iwidth)%Iwidth : dir%Iwidth);
   const int y = -Ir + ((Irank == 3) ? (dir/Iwidth)%Iwidth : 
                        (Irank == 2) ? dir%Iwidth : Ir);
   const int z = -Ir + ((Irank == 3) ? dir%Iwidth : Ir);

   Coords const step = mybb.stepsize();
   Coords const cl = mybb.lower();
   Coords const cu = mybb.upper();

   BBox gbb(mybb);

   if ( x < 0 ) {
     gbb.lower(0) += olap[0] * step(0);
     gbb.upper(0) = cl(0) - (x * rad[2*DAGH_X+1] * step(0)) - (1-olap[0]) * step(0);
   }
   else if ( x > 0 ) {
     gbb.lower(0) = cu(0) - (x * rad[2*DAGH_X] * step(0)) + (1-olap[0]) * step(0);
     gbb.upper(0) -= olap[0] * step(0);
   }
   
   if ( y < 0 ) {
     gbb.lower(1) += olap[1] * step(1);
     gbb.upper(1) = cl(1) - (y * rad[2*DAGH_Y+1] * step(1)) - (1-olap[1]) * step(1);
   }
   if ( y > 0 ) {
     gbb.lower(1) = cu(1) - (y * rad[2*DAGH_Y] * step(1)) + (1-olap[1]) * step(1);
     gbb.upper(1) -= olap[1] * step(1);
   }
   
   if ( z < 0 ) {
     gbb.lower(2) += olap[2] * step(2);
     gbb.upper(2) = cl(2) - (z * rad[2*DAGH_Z+1] * step(2)) - (1-olap[2]) * step(2);
   }
   if ( z > 0 ) {
     gbb.lower(2) = cu(2) - (z * rad[2*DAGH_Z] * step(2)) + (1-olap[2]) * step(2);
     gbb.upper(2) -= olap[2] * step(2);
   }

   return gbb;
 }

ostream& operator << (ostream& os, GhostInteraction const & gi)
 {
   os << "[IRank:" << gi.Irank << "]"; 
   os << "[IWidth:" << gi.Iwidth << "]"; 
   os << "[ITotal:" << gi.Itotal << "]"; 
   os << "[IInside:" << gi.Iinside << "]"; 
   os << endl;
   os << "***** FACES *****" << endl;
   register int r;
   for(r=0;r<gi.Irank;r++) {
     os << "[AXIS: " << r << "] "; 
     os << "[ ";
     os << gi.Ifaces[2*r] << " ";
     os << gi.Ifaces[2*r+1] << " ";
     os << "]" << endl;
   }
   os << "***** BACKWARD *****" << endl;
   for(r=0;r<DAGHMaxAxis;r++) {
     if (!gi.Ilists[r][DAGH_Backward]) continue;
     os << "[AXIS: " << r << "] "; 
     os << "[CNT: " << gi.Icounts[r][DAGH_Backward] << "] "; 
     os << "[ ";
     for(register int i=0;i<gi.Itotal;i++) 
       if (gi.Ilists[r][DAGH_Backward][i]) os << i << " ";
     os << "]" << endl;
   }
   os << "***** FORWARD *****" << endl;
   for(r=0;r<DAGHMaxAxis;r++) {
     if (!gi.Ilists[r][DAGH_Forward]) continue;
     os << "[AXIS: " << r << "] "; 
     os << "[CNT: " << gi.Icounts[r][DAGH_Forward] << "] "; 
     os << "[ ";
     for(register int i=0;i<gi.Itotal;i++) 
       if (gi.Ilists[r][DAGH_Forward][i]) os << i << " ";
     os << "]" << endl;
   }
   os << "***** BOTH *****" << endl;
   for(r=0;r<DAGHMaxAxis;r++) {
     if (!gi.Ilists[r][DAGH_Both]) continue;
     os << "[AXIS: " << r << "] "; 
     os << "[CNT: " << gi.Icounts[r][DAGH_Both] << "] "; 
     os << "[ ";
     for(register int i=0;i<gi.Itotal;i++) 
       if (gi.Ilists[r][DAGH_Both][i]) os << i << " ";
     os << "]" << endl;
   }

   return os;
 }
