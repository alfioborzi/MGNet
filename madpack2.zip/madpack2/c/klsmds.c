/***********************************************************************
*
* Subroutine KLSMDS  Call either a smoothing iterator or the direct
*                    solver - all scratch vectors are allocated and
*                    freed here
*
* Key: n  integer     i  input        1  vector
*      r  real        o  output       2  matrix
*      d  real*8      s  scratch
*      c  character
*
*      Argument  Description
*      --------  -----------
* ri1  a         matrix stored in sparse form with n rows
* ni   atype     type of matrix
*                   0  symmetric
*                   1  nonsymmetric
*                  -1  nonsymmetric, solve with a transpose
* ri1  b         right hand side, size n
* no   flag      information flag
*                   0  no error
*                  -4  illegal method for klsmds
*                  -5  out of real space in smoothing routines
*                  -6  out of integer space in direct solver
*                  -7  incorrect matrix type for matrix-vector multiply
* ni1  ija       pointers to rows of matrix a followed by column
*                indices of matrix
* ni   iscr      integer scratch vector, size niscr
* ni   iters     number of iterations
* nio  method    iterator or direct solver technique
*                 <=0  no action
*                   1  factor + solve
*                   2  factor only
*                   3  solve only
*                   ?  factor + iterative improvement
*                   ?  iterative improvement
*                  11  symmetric gauss seidel
*                  12  symmetric gauss seidel-conjugate gradient accel
*                  13  symmetric gauss seidel-minimum residual accel
* ni   n         number of rows in matrix
* ni   niscr     size of iscr
* ni   nscr      size of scr
* ni   nu        size of u
* ro1  res       residual, size n
* ri   scr       real scratch vector, size nscr
* ri1  u         matrix u stored in sparse form with n rows
* ri1  x         initial guess and solution vector, size n
*
***********************************************************************/

#include "defnc.pre"

klsmds(method, iters, n, a, ija, jushft, u, x, b, res, iscr,
       scr, nu, niscr, nscr, uused, atype, flag)

        INT     *atype, *flag, *iters, *ija, *iscr, *jushft, *method,
                *n, *niscr, *nscr, *uused;
        REAL    *a, *b, *res, *scr, *u, *x;
  {
  /*********************************************************************
  *----local variables */
  INT     i1, i2;
  /********************************************************************/

*flag = 0;

/* no action */
if (*method <= 0) return;

/* factor matrix                                                  */
/* uses 4 integer scratch vectors of length n and 1 of length n+1 */
if (*method <= 2) {
  if (5 * (*n) < *niscr) {
    i1 = 1;
    kldsnf(n, a, ija, jushft, &iscr[*n], u, iscr, &iscr[2*(*n)+1],
           &iscr[3*(*n)+1], &iscr[4*(*n)+1], atype, &i1, uused, flag);
    }
  else
    *flag = -6;
  if (*flag != 0 || *method == 2) return;
  }

/* solve using factored matrix */
/* uses 2n+1 integer scratch vectors */
if (*method == 1 || *method == 3) {
  if (3 * (*n) < *niscr) {
    i1 = 3;
    i2 = 1;
    kldsss(n, a, ija, jushft, &iscr[*n], u, iscr, &iscr[2*(*n)+1], x,
           b, atype, &i1, &i2, flag);
    i1 = 4;
    i2 = 0;
    kldsss(n, a, ija, jushft, &iscr[*n], u, iscr, &iscr[2*(*n)+1], x,
           b, atype, &i1, &i2, flag);
    }
  else
    *flag = -6;
  }

/* symmetric gauss-seidel                 */
/* uses 1 real scratch vector of length n */
else if (*method == 11) {
  if (*n <= *nscr)
    klsgs(iters, n, ija, a, x, b, res, scr, atype, flag);
  else
    *flag = -5;
  }

/* symmetric gauss-seidel/conjugate gradients */
/* uses 3 real scratch vectors of length n    */
else if (*method == 12) {
  if (3 * *n <= *nscr)
    klsgsc(iters, n, ija, a, x, b, res, scr,
           &scr[*n], &scr[2*(*n)], atype, flag);
  else
    *flag = -5;
  }

/* symmetric gauss-seidel/minimum residual */
/* uses 4 real scratch vectors of length n */
else if (*method == 13) {
  if (4 * *n <= *nscr)
    klsgsm(iters, n, ija, a, x, b, res, scr, &scr[*n],
           &scr[2*(*n)], &scr[3*(*n)], atype, flag);
  else
    *flag = -5;
  }

/* illegal method */
else
  *flag = -4;

  }
