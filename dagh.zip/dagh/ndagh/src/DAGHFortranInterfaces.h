#ifndef _included_FortranInterfaces_h
#define _included_FortranInterfaces_h

/*
Define the Fortran name mangling convention for various machines

#define FortRoutine FORTRAN_NAME(fortroutine_, FORTROUTINE, fortroutine)

AIX:            all lowercase, no trailing underscore
Cray, nCUBE/2:  all uppercase, no trailing underscore
otherwise:      all lowercase, trailing underscore
*/

#if (defined(RS6000) || defined(SPX))
#define FORTRAN_NAME(x,y,z) z
#else
#if (defined(nCUBE2) || defined(CRAYC90) || defined(CRAYT3D) || defined(CRAYT3E))
#define FORTRAN_NAME(x,y,z) y
#else
#define FORTRAN_NAME(x,y,z) x
#endif
#endif

/* Fortran interface generation macros */
/* Interfaces with local coordinates */
#ifndef LOCAL_FORTRAN_ARGS
#define LOCAL_FORTRAN_ARGS(X)		(X).data(), \
					(X).lower()/(X).stepsize(), \
					(X).upper()/(X).stepsize(), \
					(X).extents()
#endif
#define LFA				LOCAL_FORTRAN_ARGS

#ifndef LOCAL_FORTRAN_INTERFACE
#define LOCAL_FORTRAN_INTERFACE(T)	T *, INTEGER *, INTEGER *, INTEGER *
#endif
#define LFI				LOCAL_FORTRAN_INTERFACE

#ifndef LOCAL_BBOX_ARGS
#define LOCAL_BBOX_ARGS(X)		(X).lower()/(X).stepsize(), \
					(X).upper()/(X).stepsize(), \
					(X).extents()
#endif
#define LBA				LOCAL_BBOX_ARGS

#ifndef LOCAL_BBOX_INTERFACE
#define LOCAL_BBOX_INTERFACE		INTEGER *, INTEGER *, INTEGER *
#endif
#define LBI				LOCAL_BBOX_INTERFACE

/* Interfaces with global coordinates */
#ifndef GLOBAL_FORTRAN_ARGS
#define GLOBAL_FORTRAN_ARGS(X)		(X).data(), \
					(X).lower(), \
					(X).upper(), \
					(X).stepsize(), \
					(X).extents()
#endif
#define GFA				GLOBAL_FORTRAN_ARGS

#ifndef GLOBAL_FORTRAN_INTERFACE
#define GLOBAL_FORTRAN_INTERFACE(T)	T *, INTEGER *, INTEGER *, INTEGER *, INTEGER *
#endif
#define GFI				GLOBAL_FORTRAN_INTERFACE

#ifndef GLOBAL_BBOX_ARGS
#define GLOBAL_BBOX_ARGS(X)		(X).lower(), \
					(X).upper(), \
					(X).stepsize(), \
					(X).extents()
#endif
#define GBA				GLOBAL_BBOX_ARGS

#ifndef GLOBAL_BBOX_INTERFACE
#define GLOBAL_BBOX_INTERFACE		INTEGER *, INTEGER *, INTEGER *, INTEGER *
#endif
#define GBI				GLOBAL_BBOX_INTERFACE

/* Interfaces with world coordinates */
#ifndef WORLD_FORTRAN_ARGS
#define WORLD_FORTRAN_ARGS(GH,X)	(X).data(), \
					(GH).worldCoordsLower((X).lower(),(X).stepsize()), \
					(GH).worldCoordsUpper((X).upper(),(X).stepsize()), \
					(GH).worldStep((X).stepsize()), \
					(X).extents()
#endif
#define WFA				WORLD_FORTRAN_ARGS

#ifndef WORLD_FORTRAN_INTERFACE
#define WORLD_FORTRAN_INTERFACE(T)	T *, DOUBLE *, DOUBLE *, DOUBLE *, DOUBLE *,
#endif
#define WFI				WORLD_FORTRAN_INTERFACE

#ifndef WORLD_BBOX_ARGS
#define WORLD_BBOX_ARGS(GH,X)		(GH).worldCoordsLower((X).lower(),(X).stepsize()), \
					(GH).worldCoordsUpper((X).upper(),(X).stepsize()), \
					(GH).worldStep((X).stepsize()), \
					(X).extents()
#endif
#define WBA				WORLD_BBOX_ARGS

#ifndef WORLD_BBOX_INTERFACE
#define WORLD_BBOX_INTERFACE		DOUBLE *, DOUBLE *, DOUBLE *, DOUBLE *,
#endif
#define WBI				WORLD_BBOX_INTERFACE

/* The data only */
#ifndef DATA_ARGUMENT
#define DATA_ARGUMENT(X)		(X).data() 
#endif
#define DA				DATA_ARGUMENT

#ifndef DATA_INTERFACE
#define DATA_INTERFACE(T)		T *
#endif
#define DI				DATA_INTERFACE

/* Original interfaces */
#ifndef FORTRAN_ARGS
#define FORTRAN_ARGS(X)         (X).data(), \
                                (X).lower(), \
                                (X).upper(), \
                                (X).extents()
#endif
#define FA			FORTRAN_ARGS

#ifndef FORTRAN_INTERFACE
#define FORTRAN_INTERFACE(T)    T *, INTEGER const *, INTEGER const *, \
                                INTEGER const *
#endif
#define FI			FORTRAN_INTERFACE

#ifndef BOUNDING_BOX
#define BOUNDING_BOX(X)         (X).lower(), \
                                (X).upper(), \
                                (X).extents()
#endif
#define BB			BOUNDING_BOX

#ifndef BBOX_INTERFACE
#define BBOX_INTERFACE          INTEGER const *, INTEGER const *, INTEGER const *
#endif
#define BI			BBOX_INTERFACE

#ifndef FORTRAN_DATA_INTERFACE
#define FORTRAN_DATA_INTERFACE(T)     T *
#endif
#define FDI			FORTRAN_DATA_INTERFACE

#ifndef FDA
#define FDA(X)                  (X).data()
#endif

#ifndef FBA
#define FBA			BOUNDING_BOX
#endif

#ifndef FA
#define FA			FORTRAN_ARGS
#endif

#endif
