/*
*************************************************************************
*									*
* Coords.C								*
*									*
* Author: Manish Parashar  <parashar@cs.utexas.edu>			*
*									*
*************************************************************************
*/

#include "Coords.h"

#ifndef __ENABLE_INLINE__
#include "Coords.inline"
#endif

#define MATCH(s, c) while ((s).get() != (c))

/*************************************************************************/
/* Static empty coords */
/*************************************************************************/
class Coords Coords::_empty_coords;
/*************************************************************************/

/*
*************************************************************************
*									*
* istream& operator >> (istream& s, Coords& c)				*
*									*
* Operator >> reads in Coords information in the form:			*
*									*
*			 (c(0),c(1), ... ,c(N)).			*
*									*
*************************************************************************
*/

istream& operator >> (istream& s, Coords& c)
  {
   MATCH(s, '('); s >> c(0);
   register int i; for (i=1;i<c.rank;i++) {MATCH(s, ','); s >> c(i);}
   MATCH(s, ')');
   return(s); 
  }

/*
*************************************************************************
*                                                                       *
* ostream& operator << (ostream& s, const Coords& c)                    *
*                                                                       *
* Operator << writes the point information in p in the form:            *
*                                                                       *
*                        (c(0),c(1), ..., c(N)).                        *
*                                                                       *
*************************************************************************
*/

ostream& operator << (ostream& s, const Coords& c)
  {
   s << '(' << c(0);
   for (register int i=1;i<c.rank;i++) s << ',' << c(i);
   s << ')';
   return(s);
  }

/*
*************************************************************************
*									*
* ifstream& operator >> (ifstream& s, Coords& c)			*
* ofstream& operator << (ofstream& s, const Coords& c)                  *
*									*
*************************************************************************
*/

ifstream&  operator >> (ifstream& s, Coords& c)
  {
   if (&c == (Coords *)NULL) return s;

   s.read((char*)&c,sizeof(Coords));

   return s;
  }

ofstream&  operator << (ofstream& s, const Coords& c)
  {
   if (&c == (Coords *)NULL) return s;

   s.write((char*)&c,sizeof(Coords));

   return s;
  }
