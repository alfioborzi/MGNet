#ifndef _included_SimpleBucketVoid_h
#define _included_SimpleBucketVoid_h

/*
*************************************************************************
* SimpleBucketVoid.h                           				*
*                              						*
*************************************************************************
*/

#include <stdlib.h>
#include <assert.h>
#include <memory.h>
#include <string.h>
#include <iostream.h>

#ifdef DEBUG_PRINT_BKT_MEMORY
#include "DAGHMemoryTrace.h"
#endif

#include "System.h"

#ifndef DefBucketSize
#define DefBucketSize (256)
#endif

#ifndef DefIncrement
#define DefIncrement (128)
#endif

#define NullRec ((unsigned) (0))
#define EmptyBkt ((unsigned) (0))
#define FullBkt ((unsigned) (-1))

struct rechdr 
  {
   unsigned short mysize; unsigned short myoff;
   unsigned short noff; unsigned short poff;
   pointer head;
  };

struct reclink 
  {
   unsigned short mysize; unsigned short myoff;
   unsigned short noff; unsigned short poff;
   pointer head;
   unsigned short next;
  };

struct recdata 
  {
   unsigned short mysize; unsigned short myoff;
   unsigned short noff; unsigned short poff;
   pointer head;
   unsigned data[1];
  };

struct bkthdr 
  {
   unsigned short blksize; unsigned short nblks;
   unsigned short headoff; unsigned short tailoff;
   unsigned short freeoff; unsigned short cnt;
  };

union record 
  {
   struct bkthdr bhdr;
   struct rechdr hdr;
   struct reclink link;
   struct recdata rec;
   unsigned data[1];
 
   inline isempty(void) { return (hdr.mysize == 0); }
   friend ostream& operator<<(ostream&, union record&);
  };
   
struct bkt
  {
   union record *head;

   inline bkt(void) : head(0) {}
   bkt(unsigned short const blksize, unsigned short const nblks);
   bkt(struct bkt const &other);
   bkt(union record const *hdr);
   bkt(union record *hdr);
   inline ~bkt(void) 
     { 

#ifdef DEBUG_PRINT_BKT_MEMORY
      DAGHMemoryTrace::free(sizeof(char)*head->bhdr.blksize*head->bhdr.nblks);
#endif

      delete [] ((char *)head); 
     }

   friend ostream& operator<<(ostream&, struct bkt&);
  };

#define recordNULL ((union record *) 0)
#define bkthdrNULL ((struct bkthdr *) 0)
#define bktNULL ((struct bkt *) 0)
#define SimpleBucketVoidNULL ((class SimpleBucketVoid *) 0)

class SimpleBucketVoid 
  {
   friend ostream& operator<<(ostream&, SimpleBucketVoid&);

   unsigned short blksize;
   unsigned short nblks;

   struct bkt *bktptr;
   unsigned short freeoff;

   void operator = (const SimpleBucketVoid&);

public:
   inline SimpleBucketVoid(void)
	: blksize(0), nblks(0), bktptr(0), freeoff(0) {}

   SimpleBucketVoid(unsigned short const bktsize, unsigned short const bktnum);
   SimpleBucketVoid(union record *hdr);
   SimpleBucketVoid(union record const *hdr);
   SimpleBucketVoid(union record const *hdr, unsigned const size, int const n);
   SimpleBucketVoid(const SimpleBucketVoid&);	

   inline ~SimpleBucketVoid(void) { delete bktptr; }

private:
   void allocbkt(int const incr = DefIncrement);
   
   inline union record *copydata(union record *to, union record const *from)
	{
          memcpy((void *)(((char *)to)+sizeof(struct rechdr)),
                 (void *)(((char const *)from)+sizeof(struct rechdr)),
	         blksize-sizeof(struct rechdr));
	  //for (register int i=sizeof(struct rechdr);i<blksize;i++)
	  //  ((char *) to)[i] = ((char *) from)[i];
          return (to);
	}

   /* Operation on the bkt header */

   inline union record *bktGetHeadRec(union record const *bhead) const
	{ return ((union record *)
		((char const *)(bhead)+(blksize*bhead->bhdr.headoff))); }

   inline union record *bktGetTailRec(union record const *bhead) const
	{ return ((union record *)
		((char const *)(bhead)+(blksize*bhead->bhdr.tailoff))); }

   inline union record *bktGetFreeRec(union record const *bhead) const
	{ return ((union record *)
		((char const *)(bhead)+(blksize*bhead->bhdr.freeoff))); }

   inline union record *bktGetAtRec(union record const *bhead,
		unsigned short const off) const
	{ return ((union record *)
		((char const *)(bhead)+(blksize*off))); }
  
   inline unsigned short const bktGetheadoff(union record const *bhead) const
	{ return (bhead->bhdr.headoff); }
   inline void bktSetheadoff(union record *bhead, unsigned short const off) 
	{ bhead->bhdr.headoff = off; }

   inline unsigned short const bktGettailoff(union record const *bhead) const
	{ return (bhead->bhdr.tailoff); }
   inline void bktSettailoff(union record *bhead, unsigned short const off) 
	{ bhead->bhdr.tailoff = off; }

   inline unsigned short const bktGetfreeoff(union record const *bhead) const
	{ return (bhead->bhdr.freeoff); }
   inline void bktSetfreeoff(union record *bhead, unsigned short const off) 
	{ bhead->bhdr.freeoff = off; }

   inline unsigned short const bktGetcnt(union record const *bhead) const
	{ return (bhead->bhdr.cnt); }
   inline void bktSetcnt(union record *bhead, unsigned short const cnt) 
	{ bhead->bhdr.cnt = cnt; }
   inline void bktIncrcnt(union record *bhead)
	{ bhead->bhdr.cnt++; }
   inline void bktDecrcnt(union record *bhead)
	{ bhead->bhdr.cnt--; }

   /* Operations on a record */
  
   inline union record *recPrevRec(union record const *rec) const
        {
 	 return ( (rec->hdr.poff != NullRec) ?
         (union record *) ((char *)(rec->hdr.head)+(blksize*rec->hdr.poff)) :
         (union record *) (0) );
        }

   inline union record *recNextRec(union record const *rec) const
        {
 	 return ( (rec->hdr.noff != NullRec) ?
         (union record *) ((char *)(rec->hdr.head)+(blksize*rec->hdr.noff)) :
         (union record *) (0) );
        }
  
   inline union record *recAtRec(union record const *rec,
		unsigned short const off) const
        {
 	 return ( (off != NullRec) ?
         (union record *) ((char *)(rec->hdr.head)+(blksize*off)) :
         (union record *) (0) );
        }

   union record *bktaddrec(union record *bhead);
   inline union record *bktaddrec(union record *bhead, union record const *rec)
	{
	 //union record *tmprec = bktaddrec(bhead);
	 //copydata(tmprec,rec);
	 //return (tmprec);
	 return ( copydata(bktaddrec(bhead),rec) );
	}

   void bktaddfree(union record *bhead, union record *rec);

protected:
   inline short int const blks(void) { return (nblks-1);}
   inline short int const bsize(void) { return (blksize);}

   union record *addrec(void);
   inline union record *addrec(union record const *rec)
	{
	 //union record *tmprec = addrec();
	 //copydata(tmprec,rec);
	 //return (tmprec);
	 return ( copydata(addrec(),rec) );
	}

   union record *insertrec(union record *after);
   inline union record *insertrec(union record const *rec, union record *after)
	{
	 //union record *tmprec = insertrec(after);
	 //copydata(tmprec,rec);
	 //return (tmprec);
	 return ( copydata(insertrec(after),rec) );
	}

   void removerec(union record *rec);

   /* Walk the bucket */
   inline union record *nextrec(union record const *rec) const
	{ 
         return ( 
 	 (rec->hdr.myoff != bktGettailoff((union record *)rec->hdr.head)) ?
         (union record *) ((char *)(rec->hdr.head)+(blksize*rec->hdr.noff)) :
         (union record *) (0) );
	} 

   inline union record *prevrec(union record const *rec) const
	{ 
	 return (
         (rec->hdr.myoff != bktGetheadoff((union record *)rec->hdr.head)) ?
         (union record *) ((char *)(rec->hdr.head)+(blksize*rec->hdr.poff)) :
         (union record *) (0) );
	} 

   inline union record *headrec(void) const
	{
         return ( (bktptr->head->bhdr.cnt > 0) ?
	 bktGetHeadRec(bktptr->head) : recordNULL );
	} 

   inline union record *tailrec(void) const
	{
         return ( (bktptr->head->bhdr.cnt > 0) ?
	 bktGetTailRec(bktptr->head) : recordNULL );
	} 

   inline short const count(void) const
	{ return (bktGetcnt(bktptr->head)); }

public:
   /* Utility routines */
   inline int isemptybkt(void) { return (bktptr->head->bhdr.cnt == 0); }
   void emptybkt(void);

   void splitbkt(SimpleBucketVoid &sbv, union record *atrec);

   void *pack(unsigned &size);
   void pack(void *&package, unsigned &size);
   void *pack(int &size);
   void pack(void *&package, int &size);
  };

#endif
