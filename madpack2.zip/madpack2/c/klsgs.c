/***********************************************************************
*
* Subroutine KLSGS   Symmetric Gauss Seidel iteration (no acceleration)
*
* Key: n  integer     i  input        1  vector
*      r  real        o  output       2  matrix
*      d  real*8      s  scratch
*      c  character
*
*      Argument  Description
*      --------  -----------
* ri1  a         matrix stored in sparse form with n rows
* ni   atype     type of matrix
*                   0  symmetric
*                   1  nonsymmetric
*                  -1  nonsymmetric, solve with a transpose
* ri1  b         right hand side, size n
* no   flag      error flag
*                   0  no error
*                  -1  illegal matrix type
* ni1  ija       pointers to rows of matrix followed by column indices
*                of matrix
* ni   iters     number of iterations
* ni   n         number of rows in matrix
* ro1  res       residual, size n
* ri1  x         initial guess and solution vector, size n
* rs1  z         scratch vector, size n
*
* Algorithm
* ---------
*   (1) r(0) = b - Dx(0) - Ux(0)
*   (2) For i = 1 to iters
*       (a) Dw(i) = r(i) - L(x(i)+w(i)) = q(i)
*       (b) r(i+1) = r(i) - q(i)
*       (c) (D+U)z(i) = q(i)
*       (d) x(i+1) = x(i) + z(i)
*   (3) r(iters+1) = r(iters) - Lx(iters)
*
* Multiplies/Divides
* ------------------
*   If M = cost of computing Av (any vector v), then the cost is
*       iters*(M+3N) + M
*   which is approximately half the cost of the standard implementation.
*
* Reference
* ---------
* Randolph E. Bank and Craig C. Douglas, An efficient implementation
*   for ssor and incomplete factorization preconditionings, Applied
*   Numerical Mathematics, 1 (1985), pp. 489-492.
*
***********************************************************************/

#include "defnc.pre"

klsgs(iters, n, ija, a, x, b, res, z, atype, flag)

        INT     *atype, *flag, *iters, *ija, *n;
        REAL    *a, *b, *res, *x, *z;
  {
  /*********************************************************************
  *****local variables */
  INT     i, *ipija, itno, j, j1, j2, jaj, lshift, niters, ushift;
  REAL    *pa, *pres, *px, *pz, sum, zi;
  /********************************************************************/

  *flag = -1;
  if (*atype < -1 || *atype > 1) return;
  *flag = 0;

  /* determine matrix index shifts */
  lshift = 0;
  ushift = 0;
  if (*atype == 1)  lshift = ija[*n] - *ija;
  if (*atype == -1) ushift = ija[*n] - *ija;

  /* set z = res = b - Dx + Ux, where A = D - L - U                   */
  /* note that res is a pseudo-residual (completed at end of program) */
  for (i = 0; i < *n; i++)
    res[i] = b[i] - a[i] * x[i];
  ipija = ija;
  for (i = 0; i < *n; i++) {
    j1 = *ipija++ - 1;
    j2 = *ipija - 1;
    zi = x[i];
    for (j = j1; j < j2; j++) {
      jaj = ija[j] - 1;
      res[jaj] -= (a[j+ushift] * zi);
      }
    }
 
  /* main loop */
  niters = *iters;
  if (niters <= 0) niters = 1;
  for (itno = 0; itno < niters; itno++) {

    /* forward sweep: compute q = Dw = r - L(x+w) */
    /*                    and r = r - q           */
    ipija = ija;
    for (i = 0; i < *n; i++) {
      j1 = *ipija++ - 1;
      j2 = *ipija - 1;
      sum = res[i];
      for (j = j1; j < j2; j++) {
        jaj = ija[j] - 1;
        sum -= (a[j+lshift] * (x[jaj] + z[jaj]));
        }
      z[i] = sum / a[i];
      }
    pa = a;
    pres = res;
    pz = z;
    for (i = 0; i < *n; i++) {
      *pz *= *pa++;
      *pres++ -= *pz++;
      }

    /* backward sweep: compute (D+U)z = q */
    for (i = *n; i--; ) {
      j1 = ija[i] - 1;
      j2 = ija[i+1] - 1;
      zi = z[i] / a[i];
      z[i] = zi;
      for (j = j1; j < j2; j++) {
        jaj = ija[j] - 1;
        z[jaj] -= (a[j+ushift] * zi);
        }
      }

    /* update x: compute x = x + z */
    px = x;
    pz = z;
    for (i = 0; i < *n; i++)
      *px++ += *pz++;
    }

  /* complete the residual */

  pres = res;
  for (i = 0; i < *n; i++) {
    j1 = ija[i] - 1;
    j2 = ija[i+1] - 1;
    sum = res[i];
    for (j = j1; j < j2; j++) {
      sum -= (a[j+lshift] * x[ija[j]-1]);
      }
    *pres++ = sum;
    }
  }
