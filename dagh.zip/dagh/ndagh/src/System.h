#ifndef _included_System_h
#define _included_System_h

/*
*************************************************************************
* System.h                                                           	*
*                                                                       *
*************************************************************************
*/

typedef unsigned long pointer;

#endif
