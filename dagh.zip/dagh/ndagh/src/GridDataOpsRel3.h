#ifndef _included_GridDataOpsRel_3_h
#define _included_GridDataOpsRel_3_h

/*
*************************************************************************
*                                                                       *
* GridDataOpsRel3.h                                                     *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/****************************** == ***************************************/

template <class Type>
BBox GridData(3)<Type>::is_eq (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       BBox bb(3,max_step);
       gd_OperateRegion(is_eq)(val, to, from, max_step, bb);
       return (bb);
      }
    else 
     { BBox bb(3,1); return (bb); }
  }

template <class Type>
BBox GridData(3)<Type>::is_eq (GridData(3)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      BBox bb(3,max_step);
      gd_OperateRegion(is_eq)(gd, newto, newfrom, max_step, bb);
      return (bb);
     }
    else 
     { BBox bb(3,1); return (bb); }
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(is_eq) (Type const &val, 
			BBox const &to, BBox const &from, Coords const &step, 
			BBox &bb)
  {
   GridData(3)<Type> &dst = *this;

   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      if (FastIndex3(dst,i,j,k) == val) bb += Coords(3,i,j,k);
   end_for

   EndFastIndex3(dst);
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(is_eq) (GridData(3)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step,
			BBox &bb)
  {
   GridData(3)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);
   const int dk = from.lower(2)-to.lower(2);

   BeginFastIndex3(src, src._bbox, src._data, const Type);
   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      if (FastIndex3(dst,i,j,k) == FastIndex3(src,i+di,j+dj,k+dk))
	bb += Coords(3,i,j,k);
   end_for

   EndFastIndex3(dst);
   EndFastIndex3(src);
  }

/************************************************************************/

/****************************** != ***************************************/

template <class Type>
BBox GridData(3)<Type>::is_neq (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       BBox bb(3,max_step);
       gd_OperateRegion(is_neq)(val, to, from, max_step, bb);
       return (bb);
      }
    else 
     { BBox bb(3,1); return (bb); }
  }

template <class Type>
BBox GridData(3)<Type>::is_neq (GridData(3)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      BBox bb(3,max_step);
      gd_OperateRegion(is_neq)(gd, newto, newfrom, max_step, bb);
      return (bb);
     }
    else 
     { BBox bb(3,1); return (bb); }
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(is_neq) (Type const &val, 
			BBox const &to, BBox const &from, Coords const &step, 
			BBox &bb)
  {
   GridData(3)<Type> &dst = *this;

   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      if (FastIndex3(dst,i,j,k) != val) bb += Coords(3,i,j,k);
   end_for

   EndFastIndex3(dst);
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(is_neq) (GridData(3)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step,
			BBox &bb)
  {
   GridData(3)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);
   const int dk = from.lower(2)-to.lower(2);

   BeginFastIndex3(src, src._bbox, src._data, const Type);
   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      if (FastIndex3(dst,i,j,k) != FastIndex3(src,i+di,j+dj,k+dk))
	bb += Coords(3,i,j,k);
   end_for

   EndFastIndex3(dst);
   EndFastIndex3(src);
  }

/************************************************************************/

/****************************** > ***************************************/

template <class Type>
BBox GridData(3)<Type>::is_gt (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       BBox bb(3,max_step);
       gd_OperateRegion(is_gt)(val, to, from, max_step, bb);
       return (bb);
      }
    else 
     { BBox bb(3,1); return (bb); }
  }

template <class Type>
BBox GridData(3)<Type>::is_gt (GridData(3)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      BBox bb(3,max_step);
      gd_OperateRegion(is_gt)(gd, newto, newfrom, max_step, bb);
      return (bb);
     }
    else 
     { BBox bb(3,1); return (bb); }
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(is_gt) (Type const &val, 
			BBox const &to, BBox const &from, Coords const &step, 
			BBox &bb)
  {
   GridData(3)<Type> &dst = *this;

   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      if (FastIndex3(dst,i,j,k) > val) bb += Coords(3,i,j,k);
   end_for

   EndFastIndex3(dst);
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(is_gt) (GridData(3)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step,
			BBox &bb)
  {
   GridData(3)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);
   const int dk = from.lower(2)-to.lower(2);

   BeginFastIndex3(src, src._bbox, src._data, const Type);
   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      if (FastIndex3(dst,i,j,k) > FastIndex3(src,i+di,j+dj,k+dk))
	bb += Coords(3,i,j,k);
   end_for

   EndFastIndex3(dst);
   EndFastIndex3(src);
  }

/************************************************************************/

/****************************** >= ***************************************/

template <class Type>
BBox GridData(3)<Type>::is_ge (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       BBox bb(3,max_step);
       gd_OperateRegion(is_ge)(val, to, from, max_step, bb);
       return (bb);
      }
    else 
     { BBox bb(3,1); return (bb); }
  }

template <class Type>
BBox GridData(3)<Type>::is_ge (GridData(3)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      BBox bb(3,max_step);
      gd_OperateRegion(is_ge)(gd, newto, newfrom, max_step, bb);
      return (bb);
     }
    else 
     { BBox bb(3,1); return (bb); }
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(is_ge) (Type const &val, 
			BBox const &to, BBox const &from, Coords const &step, 
			BBox &bb)
  {
   GridData(3)<Type> &dst = *this;

   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      if (FastIndex3(dst,i,j,k) >= val) bb += Coords(3,i,j,k);
   end_for

   EndFastIndex3(dst);
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(is_ge) (GridData(3)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step,
			BBox &bb)
  {
   GridData(3)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);
   const int dk = from.lower(2)-to.lower(2);

   BeginFastIndex3(src, src._bbox, src._data, const Type);
   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      if (FastIndex3(dst,i,j,k) >= FastIndex3(src,i+di,j+dj,k+dk))
	bb += Coords(3,i,j,k);
   end_for

   EndFastIndex3(dst);
   EndFastIndex3(src);
  }

/************************************************************************/

/****************************** < ***************************************/

template <class Type>
BBox GridData(3)<Type>::is_lt (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       BBox bb(3,max_step);
       gd_OperateRegion(is_lt)(val, to, from, max_step, bb);
       return (bb);
      }
    else 
     { BBox bb(3,1); return (bb); }
  }

template <class Type>
BBox GridData(3)<Type>::is_lt (GridData(3)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      BBox bb(3,max_step);
      gd_OperateRegion(is_lt)(gd, newto, newfrom, max_step, bb);
      return (bb);
     }
    else 
     { BBox bb(3,1); return (bb); }
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(is_lt) (Type const &val, 
			BBox const &to, BBox const &from, Coords const &step, 
			BBox &bb)
  {
   GridData(3)<Type> &dst = *this;

   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      if (FastIndex3(dst,i,j,k) < val) bb += Coords(3,i,j,k);
   end_for

   EndFastIndex3(dst);
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(is_lt) (GridData(3)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step,
			BBox &bb)
  {
   GridData(3)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);
   const int dk = from.lower(2)-to.lower(2);

   BeginFastIndex3(src, src._bbox, src._data, const Type);
   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      if (FastIndex3(dst,i,j,k) < FastIndex3(src,i+di,j+dj,k+dk))
	bb += Coords(3,i,j,k);
   end_for

   EndFastIndex3(dst);
   EndFastIndex3(src);
  }

/************************************************************************/

/****************************** <= ***************************************/

template <class Type>
BBox GridData(3)<Type>::is_le (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       BBox bb(3,max_step);
       gd_OperateRegion(is_le)(val, to, from, max_step, bb);
       return (bb);
      }
    else 
     { BBox bb(3,1); return (bb); }
  }

template <class Type>
BBox GridData(3)<Type>::is_le (GridData(3)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      BBox bb(3,max_step);
      gd_OperateRegion(is_le)(gd, newto, newfrom, max_step, bb);
      return (bb);
     }
    else 
     { BBox bb(3,1); return (bb); }
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(is_le) (Type const &val, 
			BBox const &to, BBox const &from, Coords const &step, 
			BBox &bb)
  {
   GridData(3)<Type> &dst = *this;

   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      if (FastIndex3(dst,i,j,k) <= val) bb += Coords(3,i,j,k);
   end_for

   EndFastIndex3(dst);
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(is_le) (GridData(3)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step,
			BBox &bb)
  {
   GridData(3)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);
   const int dk = from.lower(2)-to.lower(2);

   BeginFastIndex3(src, src._bbox, src._data, const Type);
   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      if (FastIndex3(dst,i,j,k) <= FastIndex3(src,i+di,j+dj,k+dk))
	bb += Coords(3,i,j,k);
   end_for

   EndFastIndex3(dst);
   EndFastIndex3(src);
  }

/************************************************************************/

#endif
