#ifndef _included_GridFunction_h
#define _included_GridFunction_h

/*
*************************************************************************
*                                                                       *
* GridFunction.h                                                        *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"

#include "List.h"

#include "GridUnit.h"
#include "GridUnitList.h"

#include "GridDataParams.h"

#include "GridHierarchy.h"

#include "DAGHUCD.h"

#include "GridFunctionVoid.h"

#include "GridFunction1.h"
#include "GridFunction2.h"
#include "GridFunction3.h"

/*********************************************************************/
/*** Set it up ***/
/*********************************************************************/
inline void SetGridFunctionType(GridFunctionVoid& GFV,
				const int type) 
  { GFV.GF_SetGridFunctionType(type); }

inline void SetCommType(GridFunctionVoid& GFV, const int c)
  { GFV.GF_SetCommType(c); }
inline void SetShadowFlag(GridFunctionVoid& GFV, const int s)
  { GFV.GF_SetShadowFlag(s); }
inline void SetBoundaryType(GridFunctionVoid& GFV, const int b)
  { GFV.GF_SetBoundaryType(b); }
inline void SetAdaptBoundaryType(GridFunctionVoid& GFV, const int ab)
  { GFV.GF_SetAdaptBoundaryType(ab); }
inline void SetExternalGhostFlag(GridFunctionVoid& GFV, const int e)
  { GFV.GF_SetExternalGhostFlag(e); }

inline void SetUpdateFlag(GridFunctionVoid& GFV, const int f)
  { GFV.GF_SetUpdateFlag(f); }
inline void SetProlongFlag(GridFunctionVoid& GFV, const int f)
  { GFV.GF_SetProlongFlag(f); }
inline void SetRestrictFlag(GridFunctionVoid& GFV, const int f)
  { GFV.GF_SetRestrictFlag(f); }
inline void SetBndryUpdateFlag(GridFunctionVoid& GFV, const int f)
  { GFV.GF_SetBndryUpdateFlag(f); }
inline void SetAdaptBndryUpdateFlag(GridFunctionVoid& GFV, const int f)
  { GFV.GF_SetAdaptBndryUpdateFlag(f); }
inline void SetIOFlag(GridFunctionVoid& GFV, const int f)
  { GFV.GF_SetIOFlag(f); }
inline void SetCheckpointFlag(GridFunctionVoid& GFV, const int f)
  { GFV.GF_SetCheckpointFlag(f); }

inline void SetBoundaryWidth(GridFunctionVoid& GFV, const int bw)
  { GFV.GF_BoundaryWidth(bw); }

inline void SetExternalGhostWidth(GridFunctionVoid& GFV, const int ew)
  { GFV.GF_ExternalGhostWidth(ew); }

inline void SetSpaceStencil(GridFunctionVoid& GFV, const int ss)
  { GFV.GF_SetSpaceStencil(ss); }
inline void SetSpaceStencil(GridFunctionVoid& GFV, const int* ss)
  { GFV.GF_SetSpaceStencil(ss); }

inline void SetTimeStencil(GridFunctionVoid& GFV, const int ts)
   { GFV.GF_SetTimeStencil(ts); }

inline void SetTimeAlias(GridFunctionVoid& GFV, const int t, const int to)
   { GFV.GF_SetTimeAlias(t, to); }

inline void SetAlignment(GridFunctionVoid& GFV, const int a)
   { GFV.GF_SetAlignment(a); }

/*************************************************************************/
/* Set/Query Updated Timestep Info */
/*************************************************************************/
inline int UpdatedValueAt(GridFunctionVoid &GFV)
   { return GFV.updatedvaluestep(); }
inline void SetUpdatedValueStep(GridFunctionVoid& GFV, const int ustep) 
   { GFV.setupdatedvaluestep(ustep); }


/*****************************************************************************/
/* set and query user flags */
/*****************************************************************************/
inline void SetUserFlag(GridFunctionVoid& GFV,
			const int id, const DAGHGFVFlagType& f)
   { GFV.GF_SetUserFlag(id, f); }

inline DAGHGFVFlagType GetUserFlag(GridFunctionVoid& GFV,
				   const int id)
   { return (GFV.GF_GetUserFlag(id)); }

/*************************************************************************/
/* Ghost communications */
/*************************************************************************/
inline void Sync(List<GridFunctionVoid*> &gfvlist, const int t, const int l,
                 const int ident=DAGH_Main)
  {
    GridFunctionVoid** gfv = 0;
    DAGHListLoop(gfvlist, gfv, GridFunctionVoid*) {
      if ((*gfv)->comm()) (*gfv)->GF_WriteGhosts(t,l,ident);
      if ((*gfv)->comm()) (*gfv)->GF_ReadGhosts(t,l,ident);
    } DAGHEndLoop
  }
  
inline void Sync(List<GridFunctionVoid*> &gfvlist, const int t, const int l,
                 const int mgl, const int ident)
  {
    GridFunctionVoid** gfv = 0;
    DAGHListLoop(gfvlist, gfv, GridFunctionVoid*) {
      if ((*gfv)->comm()) (*gfv)->GF_WriteGhosts(t,l,mgl,ident);
      if ((*gfv)->comm()) (*gfv)->GF_ReadGhosts(t,l,mgl,ident);
    } DAGHEndLoop
  }
  
inline void Sync(List<GridFunctionVoid*> &gfvlist, const int t, const int l,
                 const int axis, const int dir,
                 const int ident)
  {
    GridFunctionVoid** gfv = 0;
    DAGHListLoop(gfvlist, gfv, GridFunctionVoid*) {
      if ((*gfv)->comm()) (*gfv)->GF_WriteGhosts(t,l,axis,dir,ident);
      if ((*gfv)->comm()) (*gfv)->GF_ReadGhosts(t,l,axis,dir,ident);
    } DAGHEndLoop
  }

inline void Sync(List<GridFunctionVoid*> &gfvlist, const int t, const int l,
                 const int mgl, const int axis, const int dir,
                 const int ident)
  {
    GridFunctionVoid** gfv = 0;
    DAGHListLoop(gfvlist, gfv, GridFunctionVoid*) {
      if ((*gfv)->comm()) (*gfv)->GF_WriteGhosts(t,l,mgl,axis,dir,ident);
      if ((*gfv)->comm()) (*gfv)->GF_ReadGhosts(t,l,mgl,axis,dir,ident);
    } DAGHEndLoop
  }

#endif
