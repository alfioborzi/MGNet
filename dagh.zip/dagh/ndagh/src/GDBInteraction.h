#ifndef _included_GDBInteraction_h
#define _included_GDBInteraction_h

/*
*************************************************************************
*                                                                       *
* GDBInteraction.h							*
*                                                                       *
* Structure GDB_Interaction stores infromation about a single 		*
* interaction for this GDB.						*
*                                                                       *
*************************************************************************
*/

struct GDB_Interaction {
   friend ostream& operator<<(ostream&, const GDB_Interaction&);
   BBox mbbox; 
   BBox* mmgbbox;
   BBox shbbox; 
   BBox* shmgbbox;

   GridTableEntry* gte;

   inline GDB_Interaction() : mmgbbox(0), shmgbbox(0), gte(0) {}

   inline ~GDB_Interaction()
    {
      if (mmgbbox) delete [] mmgbbox;
      if (shmgbbox) delete [] shmgbbox;
      gte = 0;
    }
};

ostream& operator<<(ostream& os, const GDB_Interaction&);

#endif
