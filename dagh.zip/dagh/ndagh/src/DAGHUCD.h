#ifndef _included_DAGHUCD
#define _included_DAGHUCD

/*
*************************************************************************
*                                                                                                                            *
* DAGHUCD.h			                                                      *
*                                                                                                                            *
* 1, 2 & 3D UCD infromation..		                                                      *
*                                                                                                                            *
*************************************************************************
*/

#include "DAGHParams.h"
#include "GridHierarchy.h"
#include "GridData.h"

#ifndef DAGHUCDName
#define DAGHUCD(dim)	name2(DAGHUCD,dim)
#define DAGHUCDName
#endif

/*************************************************************************/
/* 3-D UCD Information */
/*************************************************************************/
class DAGHUCD(3)
{
public:
  DAGHUCD(3)(const int minl, 
	     const int maxl, 
	     const GridHierarchy& GH,
	     const int ident = DAGH_Main);

  void GetUCDInfo(int& numnodes, 
		  double**& nodesx,
		  int& numcells, 
		  int**& cells,
		  const int coordtype);

  const short minlev;
  const short maxlev;
  
  const short ident_flag;
   
  int totalnodes;
  int totalcells;
   
  int numblks;
  int* blkcnts;
  GridData(3)<int>* blks;
   
  const GridHierarchy& dagh;

  inline ~DAGHUCD(3)()
    {  
      if (blkcnts) delete [] blkcnts;
      if (blks) delete [] blks;
    }
};

/*************************************************************************/
/* 2-D UCD Information */
/*************************************************************************/
class DAGHUCD(2)
{
public:
  DAGHUCD(2)(const int minl, 
	     const int maxl, 
	     const GridHierarchy& GH,
	     const int ident = DAGH_Main);

  void GetUCDInfo(int& numnodes, 
		  double**& nodesx,
		  int& numcells, 
		  int**& cells,
		  const int coordtype);

  const short minlev;
  const short maxlev;
  
  const short ident_flag;
   
  int totalnodes;
  int totalcells;
   
  int numblks;
  int* blkcnts;
  GridData(2)<int>* blks;
   
  const GridHierarchy& dagh;

  inline ~DAGHUCD(2)()
    {  
      if (blkcnts) delete [] blkcnts;
      if (blks) delete [] blks;
    }
};

/*************************************************************************/
/* 1-D UCD Information */
/*************************************************************************/
class DAGHUCD(1)
{
public:
  DAGHUCD(1)(const int minl, 
	     const int maxl, 
	     const GridHierarchy& GH,
	     const int ident = DAGH_Main);

  void GetUCDInfo(int& numnodes, 
		  double**& nodesx,
		  int& numcells, 
		  int**& cells,
		  const int coordtype);

  const short minlev;
  const short maxlev;
  
  const short ident_flag;
   
  int totalnodes;
  int totalcells;
   
  int numblks;
  int* blkcnts;
  GridData(1)<int>* blks;
   
  const GridHierarchy& dagh;

  inline ~DAGHUCD(1)()
    {  
      if (blkcnts) delete [] blkcnts;
      if (blks) delete [] blks;
    }
};

#endif






