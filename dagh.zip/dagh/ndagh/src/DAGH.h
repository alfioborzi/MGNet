#ifndef _included_DAGH_h
#define _included_DAGH_h

/*
*************************************************************************
* DAGH.h                                                        	*
*                                                                       *
*************************************************************************
*/

#include "GridHierarchy.h"
#include "GridHierarchyCalls.h"
#include "GridHierarchyIndex.h"

#include "DAGHUCD.h"

#include "GridFunction.h"
#include "GridFunctionCalls.h"
#include "GridFunctionIndex.h"

#include "GridData.h"

#include "DAGHFortranInterfaces.h"

#include "CommServer.h"

#include "Coords.h"
#include "DCoords.h"
#include "BBox.h"
#include "BBoxList.h"

/*$inline static void DAGHCommInit(void)
  { comm_service::init(MPI_COMM_WORLD); }$*/

/*$inline static void DAGHIOEnable(void)
  { comm_service::set_io_enable(); }$*/

inline static void DAGHMPI_Finalize(void)
  { comm_service::clean(); MPI_Finalize(); }

#ifndef MY_PROC
#define MY_PROC(GH)	  (comm_service::proc_me())
#endif

#ifndef NUM_PROC
#define NUM_PROC(GH)	  (comm_service::proc_num())
#endif

#ifndef BEGIN_COMPUTE
#define BEGIN_COMPUTE       if ( (comm_service::proc_world() == 1) || \
                                 (comm_service::proc_me() != comm_service::proc_io()) ) {
#endif

/*$#ifndef BEGIN_COMPUTE
#define BEGIN_COMPUTE       if ( (!comm_service::io_enabled()) || \
                                 (comm_service::proc_world() == 1) || \
                                 (comm_service::proc_me() != comm_service::proc_io()) ) {
#endif$*/

#ifndef END_COMPUTE
#define END_COMPUTE         }
#endif

#ifndef BEGIN_IO
#define BEGIN_IO            if ( (comm_service::io_enabled()) && \
                                 (comm_service::proc_me() == comm_service::proc_io()) ) {
#endif

#ifndef END_IO
#define END_IO         }
#endif

#ifndef NUM_PROC
#define NUM_PROC(GH)      (comm_service::proc_num())
#endif

#endif
