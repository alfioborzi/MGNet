#ifndef _included_BucketType_h
#define _included_BucketType_h

/*
*************************************************************************
* BucketType.h                           				*
*                              						*
*************************************************************************
*/

#include "SimpleBucketVoid.h"

template <class Type>
class Bucket : public SimpleBucketVoid
  {
   union record *cur;

   static inline void copytypedata(char *to, char const *from)
	{ 
          memcpy((void *)to, (void *)from, sizeof(Type));
          //for (register int i=0;i<sizeof(Type);i++) to[i] = from[i]; 
        }

public:
   inline Bucket(const unsigned bktnum)
	:SimpleBucketVoid(sizeof(Type),bktnum), cur(0) {}

   inline Bucket(void const *package)
	:SimpleBucketVoid((union record const *) package), cur(0) {}

   inline Bucket(void *package)
	:SimpleBucketVoid((union record *) package), cur(0) {}

   inline Bucket(void const *package,unsigned const size, int const n)
	:SimpleBucketVoid((union record const *) package, size, n), cur(0) {}

   inline Bucket(Bucket<Type> const &other)
	:SimpleBucketVoid(other), cur(0) {}

   inline Type* add(void)
	{ cur = addrec(); return ( ((Type *) cur->rec.data) ); }
   inline Type* add(Type const &t)
	{ 
	 cur = addrec(); 
	 copytypedata((char *) cur->rec.data, (char *) &t);
	 return ( ((Type *) cur->rec.data) );
        }

   inline Type* insert(void)
	{ cur = insertrec(cur); return ( ((Type *) cur->rec.data) ); }
   inline Type* insert(Type const &t)
	{ 
	 cur = insertrec(cur); 
	 copytypedata((char *) cur->rec.data, (char *) &t);
	 return ( ((Type *) cur->rec.data) );
        }

   inline Type* first(void)
	{ 
	 cur = headrec(); 
         return ( (cur != recordNULL && !cur->isempty()) ? \
	   (Type *) cur->rec.data : (Type *) NULL );
	}

   inline Type* last(void) 
	{ 
	 cur = tailrec(); 
         return ( (cur != recordNULL && !cur->isempty()) ? \
	   (Type *) cur->rec.data : (Type *) NULL );
	}

   inline Type* current(void) const
	{ 
         return ( (cur != recordNULL && !cur->isempty()) ? \
	   (Type *) cur->rec.data : (Type *) NULL );
	}

   Type *remove(void);
   Type *prev(void);
   Type *next(void);

   inline union record *currec(void)
        { return (cur); }

   inline void setcurrec(union record *c)
        { cur = c; }

   inline void empty(void)
	{ SimpleBucketVoid::emptybkt(); cur = recordNULL; }

   inline void split(Bucket<Type>& bt)
	{
         union record *r = prevrec(cur); 
         SimpleBucketVoid::splitbkt((SimpleBucketVoid &)bt, cur);
 	 bt.cur = recordNULL;
         cur = r;
	}
  };

#if defined(Want_c_files) || (!defined(RS6000) && !defined(SPX))
#include "BucketType.c"
#endif

#endif
