/*@@
  @file     DAGHIO_hdf_rnpl.C
  @author   Manish Parashar
  @desc
      <pre>
 DAGHIO_hdf_rnpl.C							
                                                                       
 IO Interface using RNPL BBH Utils                                     
                                                                       
 Author:  Manish Parashar <parashar@cs.utexas.edu>                     
                                                                       
      </pre>
  @enddesc
  @comment
      <code>
      $Id: DAGHIO_hdf_rnpl.C,v 1.6 1997/04/15 20:13:06 parashar Exp $
      </code>
  @endcomment
@@*/

#include "DAGHIO_hdf_rnpl.h"

void DAGHIO_HDF_RNPL_Write(GridHierarchy& gh, struct gdhdr* hdr, void* data)
  {
#ifdef IO_RNPLIO
   assert (hdr->gfdatatype == DAGH_Double);

   const BBox &bb = hdr->bbox;
   const int rank = bb.rank;
   const double time = 1.0*hdr->time;
   const char* gfname = hdr->gfname;

   const Coords& shape = bb.extents();
   const Coords& ub = bb.upper();
   const Coords& lb = bb.lower();
   const Coords& step = bb.stepsize();

   const DCoords& wub = gh.worldCoords(ub,step);
   const DCoords& wlb = gh.worldCoords(lb,step);
   const DCoords& wstep = gh.worldStep(step);

   double* bbox = new double[2*rank];
   int i;
   for (i=0;i<rank;i++) {
     bbox[2*i] = wlb(i);
     bbox[2*i+1] = wub(i);
   }

   int flag = gft_write_bbox (
              gfname,
                    time,
              bb.extents(),
              rank,
              bbox,
              (double *) data
              );

   if (bbox) delete [] bbox;

#endif
  }

void DAGHIO_HDF_RNPL_Read(GridHierarchy& gh, struct gdhdr* hdr, void* data)
  {
   assert (hdr->gfdatatype == DAGH_Double);

   cerr << "DAGHIO_hdf_rnpl.C" << "DAGHIO_HDF_RNPL_Read is not defined !" << "\n";

  }
