/*
*************************************************************************
*                                                                       *
* GridTableDataRcv							*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "CommRcvServer.h"

/*************************************************************************/
/* class GridTableDataRcv */
/*************************************************************************/
GridTableDataRcv::GridTableDataRcv(GridTable& GT, const unsigned tag,
                                     const unsigned size, const int src)
 	: Table(GT), Size(size), comm_service(GT.gfid, tag, src), Request(0), 
          rcvflag(DAGHFalse)
  {
    if (req() == 0) { 
      setreq(Id,Tag,Src); 
      return; 
    }

    Request = new char[Size];
    assert (Request != 0);

#ifdef DAGH_NO_MPI
#else

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTableDataRcv::GridTableDataRcv " 
			 << "(" << comm_service::proc_me() << ") "
			 << "MPI_Irecv: "
			 << "Tag: " << Tag << " " 
			 << "Size: " << Size << " "
			 << "From: " << Src << " "
			 << endl ).flush();
#endif

    int R = MPI_Irecv(Request,Size,MPI_BYTE,
                      Src,Tag,comm_service::comm(Id),req());

    if ( MPI_SUCCESS != R ) 
      comm_service::error_die("GridTableDataRcv::GridTableDataRcv","MPI_Irecv",R);

#endif
  }

GridTableDataRcv::~GridTableDataRcv(void)
  { if ( Request ) delete [] Request; }

void GridTableDataRcv::callrecv( const MPI_Status & MS )
  {
   rcvflag = DAGHTrue;
   rcv_update(Request);
   Request = (char *) NULL;
   Request = new char[Size];
   assert (Request != 0);
  }

void GridTableDataRcv::postrcv(void)
  {

#ifdef DAGH_NO_MPI
#else
   if (!Request) return;
   if (*req() != MPI_REQUEST_NULL) return;

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTableDataRcv::postrcv " 
                         << "(" << comm_service::proc_me() << ") "
			 << "MPI_Irecv: "
			 << "Tag: " << Tag << " " 
			 << "Size: " << Size << " "
			 << "From: " << Src << " "
			 << endl ).flush();
#endif

    int R = MPI_Irecv(Request,Size,MPI_BYTE,
                      Src,Tag,comm_service::comm(Id),req());

   if ( MPI_SUCCESS != R ) 
     comm_service::error_die("GridTableDataRcv::postrcv","MPI_Irecv",R);

#endif

   rcvflag = DAGHFalse;
  }

void GridTableDataRcv::callrecvNpost( const MPI_Status & MS )
  {
   rcvflag = DAGHTrue;
   rcv_update(Request);
   Request = (char *) NULL;
   Request = new char[Size];
   assert (Request != 0);

#ifdef DAGH_NO_MPI
#else

   assert (*req() == MPI_REQUEST_NULL);
#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTableDataRcv::postrcv " 
                         << "(" << comm_service::proc_me() << ") "
			 << "MPI_Irecv: "
			 << "Tag: " << Tag << " " 
			 << "Size: " << Size << " "
			 << "From: " << Src << " "
			 << endl ).flush();
#endif

    int R = MPI_Irecv(Request,Size,MPI_BYTE,
                      Src,Tag,comm_service::comm(Id),req());

   if ( MPI_SUCCESS != R ) 
     comm_service::error_die("GridTableDataRcv::callrecv","MPI_Irecv",R);

#endif

   rcvflag = DAGHFalse;
  }

void GridTableDataRcv::rcv_update(void *Rcv)
  {
   GridDataBucketVoid *rcvbkt = new GridDataBucketVoid(Rcv);

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTableDataRcv::rcv_update " 
                         << "(" << comm_service::proc_me() << ") "
			 << "Recieved { " 
			 << *rcvbkt->head() 
			 << " }" 
			 << endl ).flush();
#endif

   int type = rcvbkt->type();
   struct gdhdr *gdh = rcvbkt->head();
   List<GridDataBucketVoid*>& lgdbkt = Table(gdh->time);
   lgdbkt.add(rcvbkt->alias());
   rcvbkt->free();
  }

const char * GridTableDataRcv::name( void ) const
  {
   static const char Name[] = "GridTableDataRcv" ;
   return Name ;
  }



