#include "defnc.pre"
#include "defnc.v2"

#define DEBUG_KUGENA    0
#define DEBUG_KUGENR    0

/**********************************************************************/

REAL kusoln(x, y, z) REAL x, y, z; {

  static REAL pi = 3.141592653589793;

  return (REAL)(exp((double)x) * sin((double)(pi * x)) 
                               * sin((double)(pi * y))
                               * sin((double)(pi * z)));
  }

/**********************************************************************/

ksgena(k, nn, levinf) 
        INT k, *nn;
        struct  stlevinf **levinf;
  {

  INT  i, *ijap, j, kz, kk, lena, n, n1, n12, n2, n3;
  REAL h1, h2, h3, *pa, *px, yj, zk;
#if DEBUG_KUGENA
  REAL *pb;
#endif

  /* set size and matrix type */
  n1 = *nn;
  n2 = *(nn + 1);
  n3 = *(nn + 2);
  n12 = n1 * n2;
  n = n12 * n3;
  NACOLS(k) = n;
  NAROWS(k) = n;
  ATYPE(k)  = 0;

  /* allocate space */
  if ((ijap = PTRIJA(k) = (INT *)malloc(4 * n * sizeof(INT))) == NULL)
    return;
  if ((pa = PTRA(k) = (REAL *)malloc(4 * n * sizeof(REAL))) == NULL) {
    free(PTRIJA(k));
    PTRIJA(k) = NULL;
    return;
    }
  if ((px = PTRX(k) = (REAL *)malloc(n * sizeof(REAL))) == NULL) {
    free(PTRA(k));
    free(PTRIJA(k));
    PTRIJA(k) = NULL;
    PTRA(k) = NULL;
    return;
    }
  if ((PTRB(k) = (REAL *)malloc(n * sizeof(REAL))) == NULL) {
    free(PTRX(k));
    free(PTRA(k));
    free(PTRIJA(k));
    PTRIJA(k) = NULL;
    PTRA(k) = NULL;
    PTRX(k) = NULL;
    return;
    }

  /* get the solution and setup the main diagonal of a */
  h1 = 1. / ((REAL)(n1 + 1));
  h2 = 1. / ((REAL)(n2 + 1));
  h3 = 1. / ((REAL)(n3 + 1));
  for (kz = 1; kz <= n3; kz++) {
    zk = (REAL)kz * h3;
    for (j = 1; j <= n2; j++) {
      yj = (REAL)j * h2;
      for (i = 1; i <= n1; i++) {
        *px++ = kusoln((REAL)i*h1,yj,zk);
        *pa++ = 6.;
        }
      }
    }
  *pa++ = 0.;

  /* generate upper part of a */
  kk = 1;
  lena = n + 2;
  ijap = PTRIJA(k) - 1;
  pa = PTRA(k) - 1;
  for (kz = 0; kz < n3; kz++)
    for (j = 0; j < n2; j++)
      for (i = 0; i < n1; i++) {
        *(ijap+kk) = lena;
        if (kz) {
          *(ijap+lena) = kk - n12;
          *(pa+lena++) = -1.;
          }
        if (j) {
          *(ijap+lena) = kk - n1;
          *(pa+lena++) = -1.;
          }
        if (i) {
          *(ijap+lena) = kk - 1;
          *(pa+lena++) = -1.;
          }
        kk++;
        }
  *(ijap+n+1) = lena;
  lena--;

  /* generate rhs b */
  j = 0;
  klax(&j, &n, &n, PTRIJA(k), PTRA(k), PTRX(k), PTRB(k), &ATYPE(k), &i);
  
#if DEBUG_KUGENA
  pa = PTRA(k);
  pb = PTRB(k);
  px = PTRX(k);
  ijap = PTRIJA(k);
  printf("===== gena =====\n");
  printf("n,lena,atype,flag = %d,%d,%d,%d\n", n, lena, 0,  i);
  printf("     i  ija             a             x             b\n");
  for (i = 0; i < n; i++)
    printf(" %5d%5d %13.5e %13.5e %13.5e\n", i+1, *(ijap+i),
                                          *(pa+i), *(px+i), *(pb+i));
  for (i = n; i < lena; i++)
    printf(" %5d%5d %13.5e\n", i+1, *(ijap+i), *(pa+i));
#endif

  }

/**********************************************************************/

ksgenr(k, cols, rows, nnf, nnc, levinf)
        INT  cols, *nnc, *nnf, rows;
        struct  stlevinf **levinf;
  {

  INT  i, *ijrp, j, kz, l, l2, l3, n, nf1, nf12, *p;
  static REAL desc3[ ] = 
                { 0.,
                  .125, .250, .125, .250, .500, .250, .125, .250, .125,
                  .250, .500, .250, .500, 1.00, .500, .250, .500, .250,
                  .125, .250, .125, .250, .500, .250, .125, .250, .125,
                  0.
                };
  static REAL desc4[ ] = 
                { .125, 0., 0., 0., 0., 0., 0., 0., 0.,
                  .250, 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0., 0.,
                  .500, 0., 0., 0., 0., 0., 0.,
                  1.00, 0.,
                  0., 0.,
                };
  REAL *dp, *rp;

  /* set size and matrix type */
  NRCOLS(k) = cols;
  NRROWS(k) = rows;
  RTYPE(k)  = 4;
  n = *nnc;
  nf12 = *(nnf+1) * (nf1 = *nnf);

  /* allocate space */
  if ((ijrp = PTRIJR(k) = (INT *)malloc((n * n * n + 100) * sizeof(INT)))
        == NULL)
    return;
  if ((rp = PTRR(k) = (REAL *)malloc(100 * sizeof(REAL))) == NULL) {
    free(PTRIJR(k));
    PTRIJR(k) = NULL;
    return;
    }

  /* store r matrix */
  *rp = 0.;
  switch (RTYPE(k)) {
    case 3:     /* simple stencil */
      dp = desc3;
      l = 29;
      for (i = 1 ; i <= l; i++) {
        *(rp+   i) = *dp;
        *(rp+30+i) = *dp;
        *(rp+59+i) = *dp++;
        }
      l2 = 31;
      l3 = 60;
      break;
    case 4:     /* complex stencil */
      dp = desc4;
      l = 33;
      for (i = 1 ; i <= l; i++) {
        *(rp+   i)    = *dp;
        *(rp+l+i)     = *dp;
        *(rp+(2*l)+i) = *dp++;
        }
      l2 = l + 2;
      l3 = 2 * l + 2;
      break;
    }

  /* store simple stencil part of ijr */
  switch (RTYPE(k)) {
    case 3:     /* simple stencil */
      *ijrp      = 88;
      *(ijrp+ 1) = 27;
      *(ijrp+ 2) = 0;
      *(ijrp+ 3) = 1;
      *(ijrp+ 4) = 2;
      *(ijrp+ 5) = nf1;
      *(ijrp+ 6) = nf1 + 1;
      *(ijrp+ 7) = nf1 + 2;
      *(ijrp+ 8) = 2 * nf1;
      *(ijrp+ 9) = 2 * nf1 + 1;
      *(ijrp+10) = 2 * nf1 + 2;
      for (j = 2; j <= 10; j++)
        *(ijrp+18+j) = nf12 + (*(ijrp+9+j) = *(ijrp+j) + nf12);
      *(ijrp+29) = 2;
      for (j = 1; j <= 29; j++)
        *(ijrp+58+j) = (*(ijrp+29+j) = *(ijrp+j));
      *(ijrp+58) = nf1 + 3;
      *(ijrp+87) = nf12 + 2 * nf1 + 3;
      break;
    case 4:     /* complex stencil */
/*                  0     1     2     n    n+1   n+2   2n   2n+1  2n+2
                0 .125, .250, .125, .250, .500, .250, .125, .250, .125,
              n*n .250, .500, .250, .500, 1.00, .500, .250, .500, .250,
             2n*n .125, .250, .125, .250, .500, .250, .125, .250, .125,   */
      *ijrp      = 3 * l + 1;
      *(ijrp+ 1) = 8;                       /* .125 */
      *(ijrp+ 2) =     0;
      *(ijrp+ 3) =     2;
      *(ijrp+ 4) =     2 * nf1;
      *(ijrp+ 5) =     2 * nf1 + 2;
      *(ijrp+ 6) =     2 * nf12;
      *(ijrp+ 7) =     2 * nf12 + 2;
      *(ijrp+ 8) =     2 * (nf12 + nf1);
      *(ijrp+ 9) =     2 * (nf12 + nf1) + 2;
      *(ijrp+10) = 12;                      /* .250 */
      *(ijrp+11) =     1;
      *(ijrp+12) =     nf1;
      *(ijrp+13) =     nf1 + 2;
      *(ijrp+14) =     2 * nf1 + 1;
      *(ijrp+15) =     nf12;
      *(ijrp+16) =     nf12 + 2;
      *(ijrp+17) =     nf12 + 2 * nf1;
      *(ijrp+18) =     nf12 + 2 * nf1 + 2;
      *(ijrp+19) =     2 * nf12 + 1;
      *(ijrp+20) =     2 * nf12 + nf1;
      *(ijrp+21) =     2 * nf12 + nf1 + 2;
      *(ijrp+22) =     2 * (nf12 + nf1) + 1;
      *(ijrp+23) = 6;                       /* .500 */
      *(ijrp+24) =     nf1 + 1;
      *(ijrp+25) =     nf12 + 1;
      *(ijrp+26) =     nf12 + nf1;
      *(ijrp+27) =     nf12 + nf1 + 2;
      *(ijrp+28) =     nf12 + 2 * nf1 + 1;
      *(ijrp+29) =     2 * nf12 + nf1 + 1;
      *(ijrp+30) = 1;                       /* 1.00 */
      *(ijrp+31) =     nf12 + nf1 + 1;
      *(ijrp+32) = 0;
      *(ijrp+33) = 2;
      for (j = 1; j <= l; j++) {
        *(ijrp+l+j) = *(ijrp+j);
        *(ijrp+(2*l)+j) = *(ijrp+j);
        }
      *(ijrp+(2*l)) = nf1 + 3;
      *(ijrp+(3*l)) = nf12 + 2 * nf1 + 3;
      break;
    }

  /* store pointers to correct simple stencil */
  p = ijrp + *ijrp;
  for (kz = 0; kz < n; kz++)
    for (j = 1; j <= n; j++)
      for (i = 1; i <= n; i++) {
        if (j < n)
          *p++ = (i < n) ? 2 : l2;
        else
          *p++ = (i < n) ? 2 : l3;
        }

#if DEBUG_KUGENR
  printf("\n ===== genr =====");
  printf(" cols,rows,lenr,lenijr,rtype,n = %d,%d,%d,%d,%d,%d\n", 
         cols, rows, *ijrp, *ijrp + n*n*n, 3, n);
  printf("     i   ijr             r\n");
  for (j = 0; j < *ijrp; j++)
    printf("%6d%6d%14.5e\n", j+1, *(ijrp+j), *(rp+j));
  for (j = *ijrp; j < *ijrp + n*n*n ; j++)
    printf("%6d%6d\n", j+1, *(ijrp+j));
#endif

  }

/**********************************************************************/

ksgennir(k, cols, rows, nnf, nnc, levinf)
        INT  cols, *nnc, *nnf, rows;
        struct  stlevinf **levinf;
  {
  return;
  }


/**********************************************************************/

kun(nn, nodims) INT *nn, *nodims; {

  *nn++   = 7;
  *nn++   = 7;
  *nn     = 7;
  *nodims = 3;
  }

/**********************************************************************/

kunewn(nnf, nnc, nodims) INT *nnc, *nnf, nodims; {

  int  j;

  for (j = 0; j < nodims; j++)
    *nnc++ = (*nnf++ - 1) / 2;
  }
