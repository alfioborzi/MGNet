#ifndef _included_GridTable_h
#define _included_GridTable_h

/*
*************************************************************************
*                                                                       *
* class GridTable							*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/*
*************************************************************************
*                                                                       *
* GridTable.h                                                        	*
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"

#include "GridUnit.h"
#include "GridUnitList.h"

#include "PackedGridDataBucket.h"

#include "List.h"

#include "CommServer.h"

class GridTableEntry;
class GridTableArray;
class GridTable;

struct TableEntry {
  int am_decomp;
  union {
    GridTableEntry *entry;
    GridTableArray *array;
  };
 
  inline TableEntry(void) :am_decomp(0) {}
};

#define GridTableEntryNULL ((GridTableEntry *) NULL)
#define GridTableArrayNULL ((GridTableArray *) NULL)
#define TableEntryNULL ((struct TableEntry *) NULL)
#define GridTableNULL ((GridTable *) NULL)

class GridTableEntry
  {
   friend ostream& operator<<(ostream&, const GridTableEntry&);
   friend class GridTableArray;
   friend class GridTable;

private:
   const short index;
   const short owner;
   const short crslev;
   const short crsext;
   const short levstep;
   const short numlev;
   const short numtsteps;
   const short maxindex;

   short **offset;
   GridDataBucketVoid ***data;

   static GridDataBucketVoid *_nulldata;

   /* To prevent user from copying/assigning this class */
private:
   void operator = (const GridTableEntry&);
   GridTableEntry(const GridTableEntry&);

public:
   GridTableEntry(GridUnit const &gu, const int maxi, const int ntsteps);
   ~GridTableEntry();

   void allocate(const int idx);

   inline int hastime(const int t) const
	{ return (t < numtsteps); }
   inline int haslevel(const int l) const
	{ return (l>=crslev && l<=(crslev+(numlev-1)*levstep)); }
   inline int extent(const int l) const
	{ return (crsext+(l-crslev)); }
   inline int numlevels() const
	{ return (numlev); }
   inline int numtimesteps() const
	{ return (numtsteps); }
   inline int levelnum(const int l) const
	{ return ((l-crslev)/levstep); }
   inline int myowner() const
	{ return (owner); }
   inline int myindex() const
	{ return (index); }
   inline int myinside()
	{ return (DAGHMaxAxis*DAGHMaxDirs*maxindex); }
   inline int idx1(const int t, const int l)
	{ return ((t*numlev) + (l-crslev)/levstep); }
   inline int idx2base(const int a, const int d)
   	{ return (a*(DAGHMaxDirs*maxindex) + d*(maxindex)); }
   inline int idx2(const int a, const int d, const int m)
	{ return (a*(DAGHMaxDirs*maxindex) + d*(maxindex) + m); }

   void flush();
   void flush(const int t, const int l);
   void flush(const int t, const int l, const int id);
   void flush(const int t, const int l, const int a, const int d);

   GridDataBucketVoid *&operator () (const int t, const int l, 
                                     const int id, int& off);
   GridDataBucketVoid *&operator () (const int t, const int l, 
                                     const int id);

   inline short& dataoffset (const int t, const int l, const int id)
 	{ return offset[idx1(t,l)][id]; }

   GridDataBucketVoid *&operator () (const int t, const int l, 
                                     const int a, const int d, 
                                     const int m);
   GridDataBucketVoid *&operator () (const int t, const int l, 
                                     const int a, const int d, 
                                     const int m, int& off);

   inline short& dataoffset (const int t, const int l,
                             const int a, const int d, const int m)
 	{ return offset[idx1(t,l)][idx2(a,d,m)]; }
  };

class GridTableArray
  {
   friend ostream& operator<<(ostream&, const GridTableArray&);
   friend class GridTableEntry;
   friend class GridTable;

   unsigned key;
   unsigned short baselev;
   unsigned short extent;
  
   int number;

   TableEntry *contents;

private:
   /* To prevent user from copying/assigning this class */
   GridTableArray(const GridTableArray&);
   void operator = (const GridTableArray&);

   inline GridTableArray()
	: key(0), baselev(0), extent(0), number(0), contents(0) {}

   GridTableArray(const unsigned k, const unsigned short blev, 
                  const unsigned short ext, const int num);

   ~GridTableArray();

   void flush();
   void flush(const int t, const int l);
   void flush(const int t, const int l, const int id);
   void flush(const int t, const int l, const int a, const int d);

   void add(const GridUnit& gu, const int maxi, const int ntsteps);

   GridTableEntry* find(const dMapIndex& bindex);
   int find_baselev(const dMapIndex& bindex);
  };

class GridTable
  {
   friend ostream& operator<<(ostream&, const GridTable&);
   friend class GridTableEntry;
   
public:
   const short gfid;
   short gtinside;

private:
   GridTableArray table;

   short numtsteps;
   List<GridDataBucketVoid*>* data;
   static List<GridDataBucketVoid*>* _nulldata;

private:
   /* To prevent user from copying/assigning this class */
   GridTable(const GridTable&);
   void operator = (const GridTable&);

public:
   inline GridTable(int const gf) 
     : gfid(gf), gtinside(DAGHNull), numtsteps(0) {}

   GridTable(const int gf, GridUnitList& complist, 
             const int maxi, const int ntsteps);

   inline ~GridTable() { if (data) delete [] data; }

   void construct(GridUnitList& complist, 
                  const int maxi, const int ntsteps);

   inline void add(const GridUnit& gu, 
                   const int maxi, const int ntsteps) 
	{ table.add(gu,maxi,ntsteps); }

   inline GridTableEntry *find(const dMapIndex& index)
	{ return (table.find(index)); }
   inline int find_baselev(const dMapIndex& index)
	{ return (table.find_baselev(index)); }

   inline int hastime(const int t) const
	{ return (t < numtsteps); }

   inline List<GridDataBucketVoid*>& operator () (const int t)
     	{ return (data[t]); }
 
   inline void flush() { table.flush(); }
   inline void flush(const int t, const int l) { table.flush(t,l); }
   inline void flush(const int t, const int l, const int id)
          { table.flush(t,l,id); }
   inline void flush(const int t, const int l, const int a, const int d) 
          { table.flush(t,l,a,d); }

   void flushdata();
   void flushdata(const int t); 

   /* Access methods */
   const GridDataBucketVoid* read_destroy(GridTableEntry& gte, 
					  const int t, const int l, 
					  const int a, int const d, 
                                          const int m, int& off);
   const GridDataBucketVoid* read_destroy(const dMapIndex& index, 
					  const int t, int const l, 
					  const int a, int const d, 
                                          const int m, int& off);

   const GridDataBucketVoid* read_only(GridTableEntry& gte, 
				       const int t, int const l, 
				       const int a, int const d, 
                                       const int m, int& off);
   const GridDataBucketVoid* read_only(const dMapIndex& index, 
				       const int t, int const l, 
				       const int a, int const d, 
                                       const int m, int& off);

   int write(GridTableEntry& gte, const int dest, GridDataBucketVoid* gdbkt, 
             const int t, const int l, const int a, const int d, const int m,
             const unsigned tag);
   int write(GridTableEntry& gte, GridDataBucketVoid* gdbkt, 
             const int t, const int l, const int a, const int d, const int m,
             const unsigned tag);
   int write(const dMapIndex& baseindex, GridDataBucketVoid* gdbkt,
             const int t, const int l, const int a, const int d, const int m,
             const unsigned tag);

   /* Communications methods */
   int send(const unsigned tag, GridDataBucketVoid* gdbkt, const int dest);
  };

#endif
