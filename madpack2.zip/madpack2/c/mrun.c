/*
  MRUN          Return something for time accounting in seconds.
                For example, the FORTRAN code fragment

                   real*8  mrun, t1, t2
                   t1 = mrun(0)
                        ...
                   t2 = mrun(0) - t1
                   
                puts the elapsed running time in t2.  No guarantees are
                made about what resolution mrun has other than it will
                try to get down to the microsecond level.
*/

#define uSecScale       1.0e-6      /* Microsecond conversions */

#define BSD             1           /* 1 for Berkeley UNIX systems */
#define SysV            0           /* 1 for AT&T System V systems */
#define MsC             0           /* 1 for Microsoft C compiler */

#include <stdio.h>

#if BSD
#include <sys/time.h>
#endif

#ifdef BRAIN_DEAD_F77
double MRUN (dummy) int dummy; {    /* Ardent, ... */
#else
#ifdef C_PROGRAM
double mrun (dummy) int dummy; {    /* AIX, ... */
#else
double mrun_(dummy) int dummy; {    /* Portable f77 compilers */
#endif
#endif

  double  ret;

#if BSD
  struct timeval tp;
  struct timezone tzp;

  gettimeofday(&tp,&tzp);
  
  ret = (((double)tp.tv_usec) * uSecScale) + (double)tp.tv_sec;
#endif

#if SysV
  long clock();

  ret = ((double)clock()) * uSecScale;
#endif

  return ret;
  }
