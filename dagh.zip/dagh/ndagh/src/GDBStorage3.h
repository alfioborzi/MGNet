#ifndef _included_GDBStorage3_h
#define _included_GDBStorage3_h

/*
*************************************************************************
*                                                                       *
* GDBStorage3.h								*
*                                                                       *
* One unit of GDB storage						*
*                                                                       *
*************************************************************************
*/

#ifndef GridDataBlockStorage
#define GridDataBlockStorage(dim)	name2(GridDataBlockStorage,dim)
#endif

template <class Type> class GridDataBlock(3);
template <class Type> class GridFunction(3);

template <class Type>
class GridDataBlockStorage(3)
  {
   friend ostream& operator<<(ostream&, const GridDataBlockStorage(3)<Type>&);
   friend class GridDataBlock(3)<Type>;
   friend class GridFunction(3)<Type>;

   BBox bbox;
   BBox ibbox;
   BBox bndrybbox[2*3];
   GridData(3)<Type> data;

   inline GridDataBlockStorage(3)() {}
   inline void allocate() { data.allocate(bbox); }
  };

template <class Type>
ostream& operator<<(ostream& os, const GridDataBlockStorage(3)<Type>& gdbs);

#endif
