/*
*************************************************************************
*                                                                                                                            *
* DAGHUCD.C						*
*                                                                                                                            *
* Maintains 1,2&3D UCD information.                                                               *
*                                                                                                                            *
*************************************************************************
*/

#include "DAGHUCD.h"

/*************************************************************************/
/* 3-D UCD Information */
/*************************************************************************/
DAGHUCD(3)::DAGHUCD(3)(const int minl, 
		       const int maxl, 
		       const GridHierarchy& GH,
		       const int ident)
  : minlev(minl), maxlev(maxl), ident_flag(ident),
    totalnodes(0), totalcells(0),
    numblks(0), blkcnts(0), blks(0),
    dagh(GH)

{
  BBoxList bbl;
  dagh.glb_mergedbboxlist(bbl,minlev,maxlev,
			  DAGHNonCellCentered,ident);
  if (bbl.isempty()) return;

  numblks = bbl.number();
  blks = new GridData(3)<int>[numblks];
  blkcnts = new int[numblks];

  BBoxList dbbl;
  register BBox* bb = 0;
  register BBox* dbb = 0;
  register int idx = 0, didx = 0;
  int tmpcnt = 0, lastcnt = 0;
  for (idx=0,bb=bbl.first();bb;idx++,bb=bbl.next()) {
    blks[idx].allocate(*bb);
    blks[idx].fill(DAGHNull);
    lastcnt = (idx == 0) ? 0 : lastcnt+blkcnts[idx-1];
    
    /* Overwrite values for nodes already done */
    for (didx=0,dbb=dbbl.first();dbb;didx++,dbb=dbbl.next()) {
      BBox intersect((*dbb)*(*bb));
      const Coords max_step(max(bb->stepsize(),dbb->stepsize()));
      if (intersect.empty()) continue;
      for_3(i,j,k,intersect,max_step) {
	blks[idx](i,j,k) = blks[didx](i,j,k);
      } end_for
    }

    /* Initialize remaining nodes in the block */
    tmpcnt = 0;
    for_3(i,j,k,*bb,bb->stepsize()) if (blks[idx](i,j,k) == DAGHNull) {
      blks[idx](i,j,k) = lastcnt + tmpcnt++;
    } end_for   

    blkcnts[idx] = tmpcnt;
    totalnodes += tmpcnt;
    totalcells += (growupper(*bb,-1)).size();
    dbbl.add(*bb);
    assert (blks[idx].maxval() <= totalnodes);
  }    
}

void DAGHUCD(3)::GetUCDInfo(int& numnodes, 
		       double**& nodes,
		       int& numcells, 
		       int**& cells,
		       const int coordtype)
{
  const int myrank = 3;
  const int myvertices = 8;

  register int idx = 0;

  assert (!nodes);
  numnodes = totalnodes;
  nodes = new double*[myrank];
  for (idx=0;idx<myrank;idx++) nodes[idx] = new double[numnodes];

  assert (!cells);
  numcells = totalcells;
  cells = new int*[numcells];

  int tmpcellcnt = 0;
  for (idx=0; idx < numblks; idx++) {
    const BBox& bb = blks[idx].bbox();
    const Coords& s = blks[idx].stepsize();
    for_3(i,j,k,bb,s) {
      const int nid = blks[idx](i,j,k);
      if (coordtype == DAGHWorldCoords) {
	Coords c(myrank,i,j,k);
        DCoords dc = dagh.worldCoords(c,s);
	nodes[0][nid] = dc(0);
	nodes[1][nid] = dc(1);
	nodes[2][nid] = dc(2);
      }
      else {
	nodes[0][nid] = (double) 1.0*i;
	nodes[1][nid] = (double) 1.0*j;
	nodes[2][nid] = (double) 1.0*k;
      }

      if (i < bb.upper(0) && j < bb.upper(1) && k < bb.upper(2)) {

	cells[tmpcellcnt] = new int[myvertices];

	cells[tmpcellcnt][0] = blks[idx](i,     j+s(1),k+s(2));
	cells[tmpcellcnt][1] = blks[idx](i,     j+s(1),k     );
	cells[tmpcellcnt][2] = blks[idx](i+s(0),j+s(1),k     );
	cells[tmpcellcnt][3] = blks[idx](i+s(0),j+s(1),k+s(2));
	cells[tmpcellcnt][4] = blks[idx](i,     j,     k+s(2));
	cells[tmpcellcnt][5] = blks[idx](i,     j,     k     );
	cells[tmpcellcnt][6] = blks[idx](i+s(0),j,     k     );
	cells[tmpcellcnt][7] = blks[idx](i+s(0),j,     k+s(2));

	tmpcellcnt++;
      }
    } end_for
  }
  assert (tmpcellcnt == numcells);
}

/*************************************************************************/
/* 2-D UCD Information */
/*************************************************************************/
DAGHUCD(2)::DAGHUCD(2)(const int minl, 
		       const int maxl, 
		       const GridHierarchy& GH,
		       const int ident)
  : minlev(minl), maxlev(maxl), ident_flag(ident),
    totalnodes(0), totalcells(0),
    numblks(0), blkcnts(0), blks(0),
    dagh(GH)
{
  BBoxList bbl;
  dagh.glb_mergedbboxlist(bbl,minlev,maxlev,
			  DAGHNonCellCentered,ident);
  if (bbl.isempty()) return;

  numblks = bbl.number();
  blks = new GridData(2)<int>[numblks];
  blkcnts = new int[numblks];

  BBoxList dbbl;
  register BBox* bb = 0;
  register BBox* dbb = 0;
  register int idx = 0, didx = 0;
  int tmpcnt = 0, lastcnt = 0;
  for (idx=0,bb=bbl.first();bb;idx++,bb=bbl.next()) {
    blks[idx].allocate(*bb);
    blks[idx].fill(DAGHNull);
    lastcnt = (idx == 0) ? 0 : lastcnt+blkcnts[idx-1];
    
    /* Overwrite values for nodes already done */
    for (didx=0,dbb=dbbl.first();dbb;didx++,dbb=dbbl.next()) {
      BBox intersect((*dbb)*(*bb));
      const Coords max_step(max(bb->stepsize(),dbb->stepsize()));
      if (intersect.empty()) continue;
      for_2(i,j,intersect,max_step) {
	blks[idx](i,j) = blks[didx](i,j);
      } end_for
    }

    /* Initialize remaining nodes in the block */
    tmpcnt = 0;
    for_2(i,j,*bb,bb->stepsize()) if (blks[idx](i,j) == DAGHNull) {
      blks[idx](i,j) = lastcnt + tmpcnt++;
    } end_for   

    blkcnts[idx] = tmpcnt;
    totalnodes += tmpcnt;
    totalcells += (growupper(*bb,-1)).size();
    dbbl.add(*bb);

    assert (blks[idx].maxval() <= totalnodes);
  }    
}

void DAGHUCD(2)::GetUCDInfo(int& numnodes, 
		       double**& nodes,
		       int& numcells, 
		       int**& cells,
		       const int coordtype)
{
  const int myrank = 2;
  const int myvertices = 4;

  register int idx = 0;

  assert (!nodes);
  numnodes = totalnodes;
  nodes = new double*[myrank];
  for (idx=0;idx<myrank;idx++) nodes[idx] = new double[numnodes];

  assert (!cells);
  numcells = totalcells;
  cells = new int*[numcells];

  int tmpcellcnt = 0;
  for (idx=0; idx < numblks; idx++) {
    const BBox& bb = blks[idx].bbox();
    const Coords& s = blks[idx].stepsize();
    for_2(i,j,bb,s) {
      const int nid = blks[idx](i,j);
      if (coordtype == DAGHWorldCoords) {
	Coords c(myrank,i,j);
        DCoords dc = dagh.worldCoords(c,s);
	nodes[0][nid] = dc(0);
	nodes[1][nid] = dc(1);
      }
      else {
	nodes[0][nid] = (double) 1.0*i;
	nodes[1][nid] = (double) 1.0*j;
      }

      if (i < bb.upper(0) && j < bb.upper(1)) {

	cells[tmpcellcnt] = new int[myvertices];

	cells[tmpcellcnt][0] = blks[idx](i,     j+s(1));
	cells[tmpcellcnt][1] = blks[idx](i,     j);
	cells[tmpcellcnt][2] = blks[idx](i+s(0),j);
	cells[tmpcellcnt][3] = blks[idx](i+s(0),j+s(1));

	tmpcellcnt++;
      }
    } end_for
  }
  assert (tmpcellcnt == numcells);
}

/*************************************************************************/
/* 1-D UCD Information */
/*************************************************************************/
DAGHUCD(1)::DAGHUCD(1)(const int minl, 
		       const int maxl, 
		       const GridHierarchy& GH,
		       const int ident)
  : minlev(minl), maxlev(maxl), ident_flag(ident),
    totalnodes(0), totalcells(0),
    numblks(0), blkcnts(0), blks(0),
    dagh(GH)
{
  BBoxList bbl;
  dagh.glb_mergedbboxlist(bbl,minlev,maxlev,
			  DAGHNonCellCentered,ident);
  if (bbl.isempty()) return;

  numblks = bbl.number();
  blks = new GridData(1)<int>[numblks];
  blkcnts = new int[numblks];

  BBoxList dbbl;
  register BBox* bb = 0;
  register BBox* dbb = 0;
  register int idx = 0, didx = 0;
  int tmpcnt = 0, lastcnt = 0;
  for (idx=0,bb=bbl.first();bb;idx++,bb=bbl.next()) {
    blks[idx].allocate(*bb);
    blks[idx].fill(DAGHNull);
    lastcnt = (idx == 0) ? 0 : lastcnt+blkcnts[idx-1];
    
    /* Overwrite values for nodes already done */
    for (didx=0,dbb=dbbl.first();dbb;didx++,dbb=dbbl.next()) {
      BBox intersect((*dbb)*(*bb));
      const Coords max_step(max(bb->stepsize(),dbb->stepsize()));
      if (intersect.empty()) continue;
      for_1(i,intersect,max_step) {
	blks[idx](i) = blks[didx](i);
      } end_for
    }

    /* Initialize remaining nodes in the block */
    tmpcnt = 0;
    for_1(i,*bb,bb->stepsize()) if (blks[idx](i) == DAGHNull) {
      blks[idx](i) = lastcnt + tmpcnt++;
    } end_for   

    blkcnts[idx] = tmpcnt;
    totalnodes += tmpcnt;
    totalcells += (growupper(*bb,-1)).size();
    dbbl.add(*bb);
    assert (blks[idx].maxval() <= totalnodes);
  }    
}

void DAGHUCD(1)::GetUCDInfo(int& numnodes, 
		       double**& nodes,
		       int& numcells, 
		       int**& cells,
		       const int coordtype)
{
  const int myrank = 1;
  const int myvertices = 2;

  register int idx = 0;

  assert (!nodes);
  numnodes = totalnodes;
  nodes = new double*[myrank];
  for (idx=0;idx<myrank;idx++) nodes[idx] = new double[numnodes];

  assert (!cells);
  numcells = totalcells;
  cells = new int*[numcells];

  int tmpcellcnt = 0;
  for (idx=0; idx < numblks; idx++) {
    const BBox& bb = blks[idx].bbox();
    const Coords& s = blks[idx].stepsize();
    for_1(i,bb,s) {
      const int nid = blks[idx](i);
      if (coordtype == DAGHWorldCoords) {
	Coords c(myrank,i);
        DCoords dc = dagh.worldCoords(c,s);
	nodes[0][nid] = dc(0);

      }
      else {
	nodes[0][nid] = (double) 1.0*i;
      }

      if (i < bb.upper(0)) {

	cells[tmpcellcnt] = new int[myvertices];

	cells[tmpcellcnt][0] = blks[idx](i     );
	cells[tmpcellcnt][1] = blks[idx](i+s(0));

	tmpcellcnt++;
      }
    } end_for
  }
  assert (tmpcellcnt == numcells);
}
