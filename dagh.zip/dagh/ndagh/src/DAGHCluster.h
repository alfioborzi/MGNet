#ifndef _included_DAGHCluster_h
#define _included_DAGHCluster_h

/*
*************************************************************************
*                                                                       *
* DAGHCluster.h                                                       	*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGH.h"

/*************************************************************************/
/* The Cluster Routines (by Paul Walker) */
/*************************************************************************/
void Cluster3(GridData(3)<short>&, double, int, int, BBoxList&);
void Cluster2(GridData(2)<short>&, double, int, int, BBoxList&);
void Cluster1(GridData(1)<short>&, double, int, int, BBoxList&);
/*************************************************************************/

template <class Type>
void DAGHCluster3d(GridFunction(3)<Type>& gf, const int time, const int level, 
                   const int blk_width, const int buf_width, 
                   const double min_eff, const Type thresh, 
                   BBoxList& bbl, const int IDENT);

template <class Type>
void DAGHCluster3d(GridFunction(3)<Type>& gf, const int time, const int level, 
                   const int blk_width, const int buf_width, 
                   const double min_eff, const Type thresh, 
                   BBoxList& nestbbl, BBoxList& bbl, const int IDENT);

template <class Type>
void DAGHCluster2d(GridFunction(2)<Type>& gf, const int time, const int level, 
                   const int blk_width, const int buf_width, 
                   const double min_eff, const Type thresh, 
                   BBoxList& bbl, const int IDENT);
    
template <class Type>
void DAGHCluster2d(GridFunction(2)<Type>& gf, const int time, const int level, 
                   const int blk_width, const int buf_width, 
                   const double min_eff, const Type thresh, 
                   BBoxList& nestbbl, BBoxList& bbl, const int IDENT);

template <class Type>
void DAGHCluster1d(GridFunction(1)<Type>& gf, const int time, const int level, 
                   const int blk_width, const int buf_width, 
                   const double min_eff, const Type thresh, 
                   BBoxList& bbl, const int IDENT);

template <class Type>
void DAGHCluster1d(GridFunction(1)<Type>& gf, const int time, const int level, 
                   const int blk_width, const int buf_width, 
                   const double min_eff, const Type thresh, 
                   BBoxList& nestbbl, BBoxList& bbl, const int IDENT);
    
#if defined(Want_c_files) || (!defined(RS6000) && !defined(SPX))
#include "DAGHCluster.c"
#endif

#endif
