#ifndef _included_List_h
#define _included_List_h

/*
*************************************************************************
*									*
* List.h								*
* A generic linked list...						*
*									*
*************************************************************************
*/

#ifdef DEC_ALPHA
#include <sys/types.h>
#endif
#include <malloc.h>
#include "fastAlloc.h"

#ifndef ListItemsAtATime
#define ListItemsAtATime (32)
#endif

template <class Type> class List;

template <class Type>
class ListItem
  {
   Type item;
   class ListItem<Type> *next;

   inline ListItem(const Type& t) : item(t), next(0) { }
   inline void *operator new(size_t size, void *buf) { return buf; }
#ifdef __GNUG__
   void *operator new(size_t size);
#endif

   friend class List<Type>;
  };

template <class Type>
class List
  {
   fastAlloc block;

   int n;			// Number of items in the list
   ListItem<Type> *head;	// Pointer to the start of the list
   ListItem<Type> *tail;	// Pointer to the end of the list

private:
   void operator = (const List<Type>&);
   List(const List<Type>&);

public:
   inline List() : block(sizeof(ListItem<Type>), ListItemsAtATime), 
		   n(0), head(0), tail(0) { }
   inline List(const int cnt) 
        : block(sizeof(ListItem<Type>), cnt), 
          n(0), head(0), tail(0) { }
   inline int number() const { return(n); }
   inline int isempty() const { return(n == 0); }
   ~List();

   /* Methods to add/delete to/from the list */
   void add(const Type& t);
   void add(const List<Type>& other);
   void combine(List<Type>& other);
   void pop();
   void empty();
   inline const Type& first() const { return(head->item); }
   void array(Type **& array, int &cnt) const;
   void array(Type *& array, int &cnt) const;
   inline void reset() { n = 0; head = 0; tail = 0; }

   /* Methods to traverse the list */
   inline ListItem<Type> *Head() const { return(head); }
   inline ListItem<Type> *Tail() const { return(tail); }
   inline ListItem<Type> *Next(ListItem<Type> *listitem)  const
	{ return(listitem->next); }
   inline Type& Item(ListItem<Type> *listitem) const
	{ return(listitem->item); }
 };

#if defined(Want_c_files) || (!defined(RS6000) && !defined(SPX))
#include "List.c"
#endif

#ifndef DAGHListLoop
#define DAGHListLoop(list,item,Type)  {                 \
   ListItem<Type> *li = 0;                              \
   for (li=(list).Head();li;li=(list).Next(li)) {       \
   (item) = &(list).Item(li);
#define DAGHEndLoop	} }
#endif

#endif
