#include "defnc.pre"
#include "defnc.v2"
#include "drivc.v2"
 
#define PARMVAL_SCR_SIZE  1000000
#define PARMVAL_U_SIZE    1000000

extern  double mrun();
 
#define DSIZE           20
#define TTYBUFSIZE      256
 
#define MGMETHODS       4
char    *parmname_mg[MGMETHODS] = { "mg", "ni", "pmg", "pni" };
INT     parmval_mg[MGMETHODS]   = { 1, 2, 3, 4 };
 
#define SMMETHODS       3
char    *parmname_sm[SMMETHODS] = { "sgs", "sgs-cg", "sgs-mr" };
INT     parmval_sm[SMMETHODS]   = { 11, 12, 13 };
 
#define ENMETHODS       2
char    *parmname_en[ENMETHODS] = { "err", "a" };
INT     parmval_en[ENMETHODS]   = { 1, 2 };
 
#define MAXCMDS         15
#define MAXNOARGS       4
char    *parmname_cmds[MAXCMDS] = 
           { "i", "?", "q", "x",
             "n", "mg", "sm", "l", "s", "iters", "corrs", "errn",
             "time", "ssize", "usize" };
 
/**********************************************************************/
 
kdexe(opt, kf, kc, levinf, madinf, params)
        INT  kc, kf, *madinf, opt;
        struct  stdrivparams params;
        struct  stlevinf **levinf;
  {
 
  INT  j, k, nnl[3], nnn[3];
 
  /* setup option */
  if (opt) {
 
    /* set up madinf */
    LEVFINE = kf + 1;
    LEVCOR =  kc + 1;
    ITRSM =   params.smoothing_iters;
    ITRFINE = params.finegrid_iters;
    ITRCOR =  params.coarsegrid_corrections;
 
    /* set up levinf and generate a problem on each level */
    for (j = 0; j < params.nodims; j++)
      nnl[j] = params.nn[j];
    for (k = kf; k <= kc; k++) {
      ksgena(k, nnl, levinf);
      kunewn(nnl, nnl, params.nodims);
      }
  
    /* generate restriction matrices */
    for (j = kf; j < params.nodims; j++)
      nnl[j] = params.nn[j];
    for (k = kf; k <= kc; k++) {
      kunewn(nnl, nnn, params.nodims);
      if (k < kc)
        ksgenr(k, NACOLS(k), NACOLS(k+1), nnl, nnn, levinf);
      if (k > kf)
        ksgennir(k, NACOLS(k), NACOLS(k+1), nnl, nnn, levinf);
      for (j = kf; j < params.nodims; j++)
        nnl[j] = nnn[j];
      }
    }
 
  /* free memory option */
  else {
    for (k = 0; k < params.levels; k++) {
      if (PTRIJA(k) != NULL) {
        free(PTRIJA(k));
        PTRIJA(k) = NULL;
        }
      if (PTRA(k) != NULL) {
        free(PTRA(k));
        PTRA(k) = NULL;
        }
      if (PTRX(k) != NULL) {
        free(PTRX(k));
        PTRX(k) = NULL;
        }
      if (PTRB(k) != NULL) {
        free(PTRB(k));
        PTRB(k) = NULL;
        }
      if (PTRR(k) != NULL) {
        free(PTRR(k));
        PTRR(k) = NULL;
        }
      if (PTRP(k) != NULL) {
        free(PTRP(k));
        PTRP(k) = NULL;
        }
      if (NIPTRR(k) != NULL) {
        free(NIPTRR(k));
        NIPTRR(k) = NULL;
        }
      }
    }
 
  }
 
/**********************************************************************/
 
int kdparmid(n, names, cmd) INT n; char *names[], *cmd; {
 
  int  j;
 
  for (j = 0; j < n; j++)
    if (strcmp(cmd,names[j]) == 0)
      return j;
  printf("%s: unknown argument - legal values are\n", cmd);
  for (j = 0; j < n; j++)
    printf("%s ", names[j]);
  putchar('\n');
  return -1;
  }
 
/**********************************************************************/
 
int main(argc, argv) int argc; char **argv; {
 
  REAL *res, *scr, *u, *y;
  INT  *iscr, *madinf, *mp;
  struct  stlevinf **levinf, **lp;
 
  char *cmd;
  REAL errl2, errmax, *px, *py, tstart, times;
  INT  flag, i, it, j, k;
  struct  stdrivparams params;
 
  /* initialization */
  cmd  = (char *)malloc(TTYBUFSIZE);
  iscr = NULL;
  res  = NULL;
  scr  = NULL;
  u    = NULL;

  lp = levinf = (struct stlevinf **)malloc(DSIZE * sizeof(struct stlevinf *));
  for (i = 0; i < DSIZE; i++) {
    *lp = (struct stlevinf *)malloc(sizeof(struct stlevinf));
    SMMETH(i)   = 0;
    PTRB(i)     = NULL;
    PTRX(i)     = NULL;  
    JUSHFT(i)   = 0;  
    PTRU(i)     = NULL;  
    LEVELNO(i)  = 0;  
    PARENT(i)   = 0;  
    NCHILD(i)   = 0;  
    NACOLS(i)   = 0;  
    NAROWS(i)   = 0;  
    ATYPE(i)    = 0;  
    PTRA(i)     = NULL;  
    PTRIJA(i)   = NULL;  
    NRCOLS(i)   = 0;  
    NRROWS(i)   = 0;  
    RTYPE(i)    = 0;  
    PTRR(i)     = NULL;  
    PTRIJR(i)   = NULL;  
    NPCOLS(i)   = 0;  
    NPROWS(i)   = 0;  
    PTYPE(i)    = 0;  
    PTRP(i)     = NULL;  
    PTRIJP(i)   = NULL;  
    NINRCOLS(i) = 0;
    NINRROWS(i) = 0;
    NIRTYPE(i)  = 0;
    NIPTRR(i)   = NULL;
    NIPTRIJR(i) = NULL;
    lp++;
    }
 
  mp = madinf = (INT *)malloc(MGMADINFDIM * sizeof(INT));
  for (j = 0; j < MGMADINFDIM; j++)
    *mp++ = 0;
  LENISCR = PARMVAL_SCR_SIZE;
  LENSCR  = PARMVAL_SCR_SIZE;
  LENU    = PARMVAL_U_SIZE;
 
  /* get commands from the user and do something */
  i = -123;
  while (1) {
 
    /* get command */
    if (i != -123) {
      printf("> ");
      scanf("%s", cmd);
 
      /* determine which command */
      for (i = 0; i < MAXCMDS; i++)
        if (strcmp(cmd,parmname_cmds[i]) == 0)
          break;
      if (i >= MAXCMDS) {
        printf ("%s: unknown command\n", cmd);
        continue;
        }
      }
    else
      i = 0;
 
    /* get argument value */
    switch (i) {
 
      case 0: /* i: initialization */
        kun(params.nn, &params.nodims);
        params.levels                 = 2;
        params.mg_method              = 1;
        params.smoothing_method       = 2;
        params.smoothing_iters        = 2;
        params.finegrid_iters         = 1;
        params.coarsegrid_corrections = 2;
        params.error_norm             = 1;
        params.timings                = 1;
        params.s_size                 = PARMVAL_SCR_SIZE;
        params.u_size                 = PARMVAL_U_SIZE;
        if (u    != NULL) free(u);
        if (scr  != NULL) free(scr);
        if (iscr != NULL) free(iscr);
        iscr = (INT *)malloc(params.s_size * sizeof(INT));
        scr  = (REAL *)malloc(params.s_size * sizeof(REAL));
        u    = (REAL *)malloc(params.u_size * sizeof(REAL));
 
      case 1: /* ?: help */
        printf("%s:", parmname_cmds[MAXNOARGS]);
        for (j = 0; j < params.nodims; j++)
          printf("\t%d", params.nn[j]);
        printf("\n%s:\t%s\t\t%s:\t%s\t\t%s:\t%d\n",
               parmname_cmds[MAXNOARGS+1], parmname_mg[params.mg_method], 
               parmname_cmds[MAXNOARGS+2], parmname_sm[params.smoothing_method], 
               parmname_cmds[MAXNOARGS+3], params.levels);
        printf("%s:\t%d\t\t%s:\t%d\t\t%s:\t%d\n",
               parmname_cmds[MAXNOARGS+4], params.smoothing_iters,
               parmname_cmds[MAXNOARGS+5], params.finegrid_iters,
               parmname_cmds[MAXNOARGS+6], params.coarsegrid_corrections);
        printf("%s:\t%s\t\t%s:\t%d\t\t%s\t%d\n",
               parmname_cmds[MAXNOARGS+7], parmname_en[params.error_norm],
               parmname_cmds[MAXNOARGS+8], params.timings,
               parmname_cmds[MAXNOARGS+9], params.s_size);
        printf("%s:\t%d\n",
               parmname_cmds[MAXNOARGS+10], params.u_size);
        printf("%s: re-initialize, ", parmname_cmds[0]);
        printf("%s: help, ", parmname_cmds[1]);
        printf("%s: quit, ", parmname_cmds[2]);
        printf("%s: execute problem\n", parmname_cmds[3]);
        break;
 
      case 2: /* q: quit */
        return 0;
 
      case 3: /* x: execute problem */
        /* set up problems on each level */
        kdexe((INT)1, (INT)0, (INT)(params.levels - 1), levinf, madinf,
              params);
     
        /* save real solution and allocate residual vector */
        px = PTRX(0);
        py = y = (REAL *)malloc(NACOLS(0) * sizeof(REAL));
        res = (REAL *)malloc(2 * NACOLS(0) * sizeof(REAL));
        for (j = NACOLS(0); j--; )
          *py++ = *px++;
 
        /* solve the problem */
        it = params.timings;
        times = 0.;
        do {
 
          /* zero the initial guesses */
          for (k = 0; k < params.levels; k++) {
            SMMETH(k) = parmval_sm[params.smoothing_method];
            JUSHFT(k) = 0;
            px = PTRX(k);
            for (j = NACOLS(k); j--; )
              *px++ = 0;
            }
          SMMETH(params.levels-1) = 1;
 
          /* pick an algorithm */
          flag = 0;
          switch (params.mg_method) {
            case 0: /* mg */
              tstart = mrun();
              klmg(madinf, levinf, u, res, iscr, scr, &flag);
              times += (mrun() - tstart);
              break;
 
            case 1: /* ni */
              tstart = mrun();
              klni(madinf, levinf, u, res, iscr, scr, &flag);
              times += (mrun() - tstart);
              break;
 
            default: 
              printf("Not implemented\n");
              break;
            }
          
          } while (--it > 0);
 
        printf("flag = %d\n", flag);
        if (params.timings > 0)
          printf("%12.3e seconds per run\n", times / params.timings);
 
        /* determine the error */
        if (flag == 0) {
          j = parmval_en[params.error_norm];
          kderr(&j, &NACOLS(0), &ATYPE(0), PTRIJA(0), PTRA(0), PTRX(0), 
                y, scr, scr + NACOLS(0), &errmax, &errl2);
          printf("errm = %e   err2 = %e\n", errmax, errl2);
          }
 
        /* free space used on each level */
        kdexe((INT)0, (INT)0, (INT)params.levels - 1, levinf, madinf, params);
        free(res);
        free(y);
        break;
 
 
      case 4: /* n: number of unknowns */
        for (j = 0; j < params.nodims; j++)
          scanf("%d", &params.nn[j]);
        break;
 
      case 5: /* mg: multigrid algorithm */
        scanf("%s", cmd);
        if ((j = kdparmid(MGMETHODS, parmname_mg, cmd)) >= 0)
          params.mg_method = j;
        break;
 
      case 6: /* sm: smoothing algorithm */
        scanf("%s", cmd);
        if ((j = kdparmid(SMMETHODS, parmname_sm, cmd)) >= 0)
          params.smoothing_method = j;
        break;
 
      case 7: /* l: number of levels */
        scanf("%d", &j);
        if (j > 0 && j <= DSIZE) params.levels = j;
        break;
 
      case 8: /* s: number of smoothing iterations */
        scanf("%d", &j);
        if (j >= 0) params.smoothing_iters = j;
        break;
 
      case 9: /* iters: number of iterations of finest level */
        scanf("%d", &j);
        if (j >= 0) params.finegrid_iters = j;
        break;
 
      case 10: /* corrs: number of coarse level corrections */
        scanf("%d", &j);
        if (j >= 0) params.coarsegrid_corrections = j;
        break;
 
      case 11: /* errn: error norm */
        scanf("%s", cmd);
        if ((j = kdparmid(ENMETHODS, parmname_en, cmd)) >= 0)
          params.error_norm = j;
        break;
 
      case 12: /* time: number of times to execute and time problem 
                        executions */
        scanf("%d", &j);
        if (j > 0) params.timings = j;
        break;
 
      case 13: /* ssize: size of scratch vectors */
        scanf("%d", &j);
        if (j > 0) params.s_size = j;
        if (scr  != NULL) free(scr);
        if (iscr != NULL) free(iscr);
        iscr = (INT *)malloc(params.s_size * sizeof(INT));
        scr  = (REAL *)malloc(params.s_size * sizeof(REAL));
        break;
 
      case 14: /* usize: size of factors vector for direct solver */
        scanf("%d", &j);
        if (j > 0) params.u_size = j;
        if (u != NULL) free(u);
        u = (REAL *)malloc(params.u_size * sizeof(REAL));
        break;

      } /* end of switch(i) */
    } /* end of while(1) */
  }

