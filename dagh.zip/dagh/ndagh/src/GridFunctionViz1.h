#ifndef _included_GridFunctionViz1_h
#define _included_GridFunctionViz1_h

/*
*************************************************************************
*                                                                       *
* GridFunctionViz1.h                                                    *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#define DIE(X) { cerr << X << flush; exit(-1); }
#define BUFFER_LENGTH (128)

template <class Type>
void GridFunction(1)<Type>::GF_View(const int time, const int l, 
				    const int axis, 
                                    const BBox& where,
                                    const int pserver,
                                    const int type,
                                    const char* xg,
                                    const char* dserver,
                                    const int ident)
  {
   assert (where.rank == dagh.rank);

   if (where.empty()) return;

   const int me = comm_service::proc_me();

   GridData(1)<Type> gd;
   GF_gather_one(time,l,where,where,gd,pserver,ident);
  
   if (me == pserver) {

     FILE *xgraph;
     char buffer [BUFFER_LENGTH];

     if (type == DAGHViz_XGRAPH) {
       if (!dserver)
         sprintf(buffer, "%s", xg);
       else
         sprintf(buffer, "%s -display %s", xg, dserver);

       if (!(xgraph = popen(buffer, "w")))
          DIE("GridFunction::GF_View -- Cannot start application ``" <<
                  buffer << "''\n");
     }
     else if (type == DAGHViz_FILE) {
       sprintf(buffer, "%s", xg);
       if (!(xgraph = fopen(buffer, "w")))
          DIE("GridFunction::GF_View -- Cannot write file``" <<
                  buffer << "''\n");
     }
     else {
       comm_service::log() << gd; /* For Now */
       return;
     }

     fprintf(xgraph, "TitleText: %s\n", gfname);
     fprintf(xgraph, "Markers: True\n");

     const Coords& lb = gd.bbox().lower();
     const Coords& ub = gd.bbox().upper();
     const Coords& step = gd.bbox().stepsize();

     double wlb[1], wub[1], wstep[1];
     dagh.worldCoords(lb,step,wlb);
     dagh.worldCoords(ub,step,wub);
     dagh.worldStep(step,wstep);

     const int a0 = axis;

     fprintf(xgraph, "XUnitText: X Slice\n");
     fprintf(xgraph, "YUnitText: Grid Data Values\n");

     Type data;

     int i0 = lb(a0);

     fprintf(xgraph, "\"X\n");
     fprintf(xgraph, "move %18.10e %18.10e\n", wlb[0], gd(i0));

     i0 += step(a0);
     for (int i = 1; i0 <= ub(a0); i++, i0 += step(a0)) {
       data = gd(i0);
       fprintf(xgraph, "draw %18.10e %18.10e\n", wlb[0]+i*wstep[0], data);
     }
     fprintf(xgraph, "\n");
     fflush(xgraph);

     if (type == DAGHViz_XGRAPH) {
       if (xgraph) pclose(xgraph);
     }
     else if (type == DAGHViz_FILE) {
       if (xgraph) fclose(xgraph);
     }
   }
  }

#endif
