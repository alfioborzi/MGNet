#ifndef _included_GridDataBlock2_h
#define _included_GridDataBlock2_h

/*
*************************************************************************
*                                                                       *
* GridDataBlock(2).h                                                    *
*                                                                       *
* This class adds stoarge and interaction information for a grid block	*
* at a particular level.						*
*                                                                       *
*************************************************************************
*/


#include "GridDataBlockCommon.h"

#include "GridData2.h"
#include "GDBStorage2.h"

#ifndef GridDataBlock
#define GridDataBlock(dim)      name2(GridDataBlock,dim)
#endif

template <class Type> class GridFunction(2);

template <class Type>
class GridDataBlock(2)
  {
   friend ostream& operator<<(ostream&, const GridDataBlock(2)<Type>&);
   friend ofstream& operator<<(ofstream&, const GridDataBlock(2)<Type>&);
   friend ifstream& operator>>(ifstream&, GridDataBlock(2)<Type>&);

   friend GridFunction(2)<Type>;

   const unsigned short gfid;

   /**************************************************************/
   /* level, geometry & other specs */
   /**************************************************************/
   short timenum;               /* timenum - 0 to 2*time_stencil */
   short levelnum;              /* levelnum */ 
   short sten_rad[2*2];         /* interaction radius */
   /**************************************************************/

   /**************************************************************/
   /* structure info */
   /**************************************************************/
   short ranks[2];             /* my ranks (if align != DAGH_All) */
   BBox merged_bbox;           /* merged bbox ... */
   BBox shmerged_bbox;         /* merged bbox on the shadow... */

   short bndryflags[2*2];      /* Flag where boundaries exist */
   /**************************************************************/

   /**************************************************************/
   /* Main Storage */
   /**************************************************************/
   GridDataBlockStorage(2)<Type> mstorage;
   /**************************************************************/

   /**************************************************************/
   /* Shadow Baggage */
   /**************************************************************/
   short shflag;
   GridDataBlockStorage(2)<Type> *shstorage;
   /**************************************************************/

   /**************************************************************/
   /* MG Baggage */
   /**************************************************************/
   short mgflag;
   short mglfine;
   short mglcoarse;
   short mglevels;
   GridDataBlockStorage(2)<Type> **mgstorage;
   /**************************************************************/

   /**************************************************************/
   /* Shadow MG Baggage */
   /**************************************************************/
   short shmgflag;
   short shmglfine;
   short shmglcoarse;
   short shmglevels;
   GridDataBlockStorage(2)<Type> **shmgstorage;
   /**************************************************************/

   /**************************************************************/
   /* Ghost Communication Stuff */
   /**************************************************************/
   dMapIndex baseindex;
   GridTableEntry *mygte;

   short comm_flag;
   short ghost_prolong_flag[2*2];
   short maxindex;
   GDB_Interaction ghost_prolong_info[2*2];
   GDB_Interaction*** gdb_write_info; 
   GDB_Interaction*** gdb_read_info; 
   GridTableGhostRcv *gdb_data_rcv;
   /**************************************************************/
   
   /**************************************************************/
   /* A reference to the GridTable SDDA */
   /**************************************************************/
   GridTable &gtable;
   /**************************************************************/

   /**************************************************************/
   /* And a reference to the GridHierarchy... */
   /**************************************************************/
   GridHierarchy &dagh;
   /**************************************************************/

private:
   /**************************************************************/
   /* Disable the following */
   /**************************************************************/
   GridDataBlock(2)(GridDataBlock(2)<Type> const &other);
   GridDataBlock(2)<Type> const &operator=(GridDataBlock(2)<Type> 
					   const &other);

private:
   /**************************************************************/
   /* The constructor */
   /**************************************************************/
   GridDataBlock(2)(const int gf,
                    GridHierarchy& gh,
                    GridTable& gt,
                    const GhostInteraction& gi,
                    GridUnitList& mgul,
                    const int time,
                    const int level,
                    const int bwidth,
                    const int extghwidth,
                    const short* olap,
                    const short *sten,
                    const int align,
                    const int mindex,
                    const int cflag,
                    const int sflag,
                    const GridDataBlock(2)<Type>* gdbtmpl);
	
   /**************************************************************/
   /* The destructor */
   /**************************************************************/
   ~GridDataBlock(2)();

   /**************************************************************/
   /* Set up internals */
   /**************************************************************/
   void gdbSetUpBoundaryFlags(GridUnitList& gul,
                              const GhostInteraction& gi,
                              const short* olap,
                              const short* rad);

   void gdbSetUpGhostInteractionInfo(GridUnitList& mcgul,
                                     GridUnitList& scgul,
                                     GridUnitList& mgul,
                                     const int align,
                                     const GhostInteraction& gi, 
                                     const short* olap,
                                     const BBox& dagh_merged_bbox,
                                     const BBox& dagh_shmerged_bbox,
                                     const short* dagh_rad);

   void gdbSetUpGhostInteractionInfo(
                             const GridDataBlock(2)<Type>* gdbtmpl);

   void gdbAddGhostInteractionInfo(const int axis, const int dir,
                                   const BBox& rb, const BBox& wb,
                                   const BBox& hisbb,
                                   const int owner, const int idx,
				   const dMapIndex& li);
   void gdbAddShadowGhostInteractionInfo(const int axis, const int dir,
                                         const BBox& srb, const BBox& swb,
                                         const BBox& shisbb,
                                         const int owner, const int idx,
					 const dMapIndex& li);

   /**************************************************************/
   /* Main setup */
   /**************************************************************/
   void gdbSetUpMain(const short* olap, 
		     const int bwidth, const int extghwidth);

   /**************************************************************/
   /* Shadow setup/release */
   /**************************************************************/
   void gdbSetUpShadow(const short* olap,
		       const int bwidth, const int extghwidth);
   void gdbReleaseShadow(void);

   /**************************************************************/
   /* Multigrid setup/release */
   /**************************************************************/
   void gdbSetUpMultiGrid(const int lc, const int lf, 
                          const short* olap, 
			  const int bwidth, const int extghwidth);
   void gdbSetUpMultiGrid(const int axis, 
                          const int lc, const int lf,
                          const short* olap, 
			  const int bwidth, const int extghwidth);
   void gdbReleaseMultiGrid(void);

   /**************************************************************/
   /* Shadow-Multigrid setup/release */
   /**************************************************************/
   void gdbSetUpShadowMultiGrid(const int lc, const int lf,
                                const short* olap, 
				const int bwidth, const int extghwidth);
   void gdbSetUpShadowMultiGrid(const int axis, 
                                const int lc, const int lf,
                                const short* olap,
				const int bwidth, const int extghwidth);
   void gdbReleaseShadowMultiGrid(void);

   /**************************************************************/
   /* General info */
   /**************************************************************/
public:
   inline int has_neighbor(const int dir)  const
	{ return (bndryflags[dir] == DAGHFalse); }

   inline int has_boundary(const int dir) const
	{ return (bndryflags[dir] != DAGHFalse); }

   inline int has_adaptiveboundary(const int dir) const
	{ return (bndryflags[dir] == DAGH_AdaptiveBoundary); }
   inline int has_externalboundary(const int dir) const
	{ return (bndryflags[dir] == DAGH_ExternalBoundary); }

   inline int prolong_ghost(const int dir) const
	{ return (ghost_prolong_flag[dir] == DAGHTrue); }
   /**************************************************************/
   /* Ghost communications */
   /**************************************************************/
private:
   void gdbReadGhosts(const int proc,
                      const int axis,
                      const int dir,
                      const int ident,
                      const int mgl);

   int gdbWriteGhosts(const int proc,
                      const int axis,
                      const int dir,
                      const int ident,
                      const int mgl,
                      GridDataBucket<Type>& gdb,
                      const int at);

public:
   inline GDB_Interaction** gdbReadInfo(const int proc)
   {return ( (gdb_read_info[proc]) ? gdb_read_info[proc] : 0 );}
   inline GDB_Interaction** gdbWriteInfo(const int proc)
   {return ( (gdb_write_info[proc]) ? gdb_write_info[proc] : 0 );}
   /**************************************************************/
   
   /**************************************************************/
   /* Data communications */
   /**************************************************************/
private:
   void gdbReadData(const int ident, const int mgl);

   //void gdbWriteData(const int ident, const int mgl);
   //void gdbWriteData(const int ident, const int mgl, const int where);
   void gdbWriteData(const int ident, const int mgl,
                     GridDataBucket<Type>& gdb, const int at);
   void gdbWriteData(const int ident, const int mgl,
                     const BBox& where,
                     GridDataBucket<Type>& gdb, const int at);

   //void gdbPostDataRcv(const int ident, const int mgl);
   //void gdbPostDataRcv(const int ident, const int mgl, where);
   /**************************************************************/

   /**************************************************************/
   /* Bounding box access */
   /**************************************************************/
public:
   const BBox& mergedbox(const int ident=DAGH_Main) const
   { return (
     (ident==DAGH_Main) ? merged_bbox :
     (ident==DAGH_Shadow) ? shmerged_bbox : BBox::_empty_bbox);
   }

   const BBox& boundingbox(const int ident=DAGH_Main, 
			   const int mgl=DAGHNull) const
   { return (
     (ident==DAGH_Main && (mgl==DAGHNull||mgl==mglfine)) ? mstorage.bbox :
     (ident==DAGH_Shadow && shflag!=0 && (mgl==DAGHNull||mgl==shmglfine)) ? 
     shstorage->bbox :  
     (ident==DAGH_Main && mgflag!=0 && mgl<mglfine && mgl>=mglcoarse) ? 
     mgstorage[mgl-mglcoarse]->bbox :
     (ident==DAGH_Shadow && shmgflag!=0 && mgl<shmglfine && mgl>=shmglcoarse)? 
     shmgstorage[mgl-shmglcoarse]->bbox :
     BBox::_empty_bbox);
   }

   const BBox& interiorbox(const int ident=DAGH_Main, 
			   const int mgl=DAGHNull) const
   { return (
     (ident==DAGH_Main && (mgl==DAGHNull || mgl==mglfine)) ? mstorage.ibbox :
     (ident==DAGH_Shadow && shflag!=0 && (mgl==DAGHNull || mgl==shmglfine)) ? 
     shstorage->ibbox :
     (ident==DAGH_Main && mgflag!=0 && mgl<mglfine && mgl>=mglcoarse) ? 
     mgstorage[mgl-mglcoarse]->ibbox :
     (ident==DAGH_Shadow && shmgflag!=0 && mgl<shmglfine && mgl>=shmglcoarse)? 
     shmgstorage[mgl-shmglcoarse]->ibbox :
     BBox::_empty_bbox);
   }

   const BBox& bndrybox(const int dir, 
                        const int ident=DAGH_Main, 
                        const int mgl=DAGHNull) const
   { return (
     (ident==DAGH_Main && (mgl==DAGHNull || mgl==mglfine)) ? 
     mstorage.bndrybbox[dir] :
     (ident==DAGH_Shadow && shflag!=0 && (mgl==DAGHNull || mgl==shmglfine)) ? 
     shstorage->bndrybbox[dir] :
     (ident==DAGH_Main && mgflag!=0 && mgl<mglfine && mgl>=mglcoarse) ? 
     mgstorage[mgl-mglcoarse]->bndrybbox[dir] :
     (ident==DAGH_Shadow && shmgflag!=0 && mgl<shmglfine && mgl>=shmglcoarse)? 
     shmgstorage[mgl-shmglcoarse]->bndrybbox[dir] :
     BBox::_empty_bbox);
   }

   const BBox& ghostbox(const GDB_Interaction& gdbi,
                        const int ident=DAGH_Main, 
			const int mgl=DAGHNull) const
   { return (
     (ident==DAGH_Main && (mgl==DAGHNull || mgl==mglfine)) ? gdbi.mbbox :
     (ident==DAGH_Shadow && shflag!=0 && (mgl==DAGHNull || mgl==shmglfine)) ? 
     gdbi.shbbox :  
     (ident==DAGH_Main && mgflag!=0 && mgl<mglfine && mgl>=mglcoarse) ? 
     gdbi.mmgbbox[mgl-mglcoarse] :
     (ident==DAGH_Shadow && shmgflag!=0 && mgl<shmglfine && mgl>=shmglcoarse)? 
     gdbi.shmgbbox[mgl-shmglcoarse] :
     BBox::_empty_bbox);
   }

   const BBox& prolong_ghostbox(const int dir,
                                const int ident=DAGH_Main, 
                                const int mgl=DAGHNull) const
   { return (
     (ident==DAGH_Main && (mgl==DAGHNull || mgl==mglfine)) ? 
     ghost_prolong_info[dir].mbbox :  
     (ident==DAGH_Shadow && shflag!=0 && (mgl==DAGHNull || mgl==shmglfine)) ? 
     ghost_prolong_info[dir].shbbox :  
     (ident==DAGH_Main && mgflag!=0 && mgl<mglfine && mgl>=mglcoarse) ? 
     ghost_prolong_info[dir].mmgbbox[mgl-mglcoarse] :
     (ident==DAGH_Shadow && shmgflag!=0 && mgl<shmglfine && mgl>=shmglcoarse)? 
     ghost_prolong_info[dir].shmgbbox[mgl-shmglcoarse] :
     BBox::_empty_bbox);
   }
   /**********************************************************************/

   /**************************************************************/
   /* Data access */
   /**************************************************************/
public:
   GridData(2)<Type> &griddata(const int ident=DAGH_Main, 
			       const int mgl=DAGHNull)
   { return (
     (ident==DAGH_Main && (mgl==DAGHNull || mgl==mglfine)) ? mstorage.data :
     (ident==DAGH_Shadow && shflag!=0 && (mgl==DAGHNull || mgl==shmglfine)) ? 
     shstorage->data :
     (ident==DAGH_Main && mgflag!=0 && mgl<mglfine && mgl>=mglcoarse) ? 
     mgstorage[mgl-mglcoarse]->data :
     (ident==DAGH_Shadow && shmgflag!=0 && mgl<shmglfine && mgl>=shmglcoarse)? 
     shmgstorage[mgl-shmglcoarse]->data :
     mstorage.data);
   }
   const GridData(2)<Type> &griddata(const int ident=DAGH_Main, 
			       const int mgl=DAGHNull) const
   { return (
     (ident==DAGH_Main && (mgl==DAGHNull || mgl==mglfine)) ? mstorage.data :
     (ident==DAGH_Shadow && shflag!=0 && (mgl==DAGHNull || mgl==shmglfine)) ? 
     shstorage->data :
     (ident==DAGH_Main && mgflag!=0 && mgl<mglfine && mgl>=mglcoarse) ? 
     mgstorage[mgl-mglcoarse]->data :
     (ident==DAGH_Shadow && shmgflag!=0 && mgl<shmglfine && mgl>=shmglcoarse)? 
     shmgstorage[mgl-shmglcoarse]->data :
     mstorage.data);
   }
   /**********************************************************************/
  };

#if defined(Want_c_files) || (!defined(RS6000) && !defined(SPX))
#include "GridDataBlock2.c"
#endif

#endif
