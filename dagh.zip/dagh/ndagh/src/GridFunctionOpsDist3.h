#ifndef _included_GridFunctionOpsDist3_h
#define _included_GridFunctionOpsDist3_h

/*
*************************************************************************
*                                                                       *
* GridFunctionOpsDist3.h                                                *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/***************************************************************************/
/* gather_one */
/***************************************************************************/
template <class Type>
void GridFunction(3)<Type>::GF_gather_one(const int t1, const int l1,
                                          const BBox& to, const BBox& from,
                                          GridData(3)<Type> &into, 
                                          const int at, 
                                          const int ident)
  {
   assert (to.rank == dagh.rank && from.rank == dagh.rank);
   const int tf = dagh_timeindex(t1,l1);

   const int me = comm_service::proc_me();
   const int pnum = comm_service::proc_num();
   const int myrank = 3;

   Coords const toshift = from.lower() - to.lower();
   BBox newfrom = from * shiftabs(to, toshift);
   if (newfrom.empty()) return;
   BBox newto = shiftabs(newfrom, -toshift);

   BBox alignedto = to;
   gdbAlignBBox(gfrank,alignedto,alignment);
   BBox alignedfrom = from;
   gdbAlignBBox(gfrank,alignedfrom,alignment);

   Coords step(myrank,dagh.stepsize(l1,ident));
   newto.stepsize() = step;
   newfrom.stepsize() = step;

   if (me == at) { 
     into.allocate(newto);
     into = (Type) 0;
   }

   if (comm_service::dce() && pnum > 1) { /* Distributed Stuff */

     const int lf = dagh.levelnum(l1);
     const int levid = dagh.daghindex(ident);
     const int mindex = dagh.maxindex()+1;

     GridUnitList &clist = *dagh.clist();
     GridUnitList &llist = *dagh.llist();

     GridUnitList gfgul;
     GridUnitList lfgul;
     clist.intersect(newfrom,lf,gfgul,overlap);
     llist.intersect(newfrom,lf,lfgul,overlap);

#ifdef DEBUG_PRINT_GF_DCOPY
     ( comm_service::log() << "\n************* Global From List *************\n"
                           << gfgul
                           << "\n************* ***************** *************\n"
                           ).flush();
     ( comm_service::log() << "\n************* Local From List *************\n"
                           << lfgul
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     GridTableDataRcv **recv_server = 0;
     
if (me == at) { /* Post Rcvs */

     recv_server = new GridTableDataRcv *[pnum];
     register int p;
     for (p=0;p<pnum;p++) recv_server[p] = GridTableDataRcvNULL;

     GridUnitList *fgul = &gfgul;

     BBoxList fbbl;
     fgul->bboxlist(fbbl,lf,overlap,levid);

#ifdef DEBUG_PRINT_GF_DCOPY
     ( comm_service::log() << "\n************* Post Recv From BB List *************\n"
                           << fbbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     unsigned *rcvsize = new unsigned[pnum];
     for (p=0;p<pnum;p++) rcvsize[p] = 0;
     BBox *rb = new BBox[pnum*mindex];
     register int ridx = 0;
     register int idx = 0;
    
     GridUnit *fgu = fgul->first();
     BBox *fbb = fbbl.first();
     BBox bb;
     int owner = DAGHNoBody;
     for(;fgu;fgu=gfgul.next(),fbb=fbbl.next(),idx++) {
       if ((owner = fgu->guOwner()) == me) continue;
       bb = *fbb * newfrom;
       if (bb.empty()) continue;
       gdbAlignBBox(gfrank,bb,alignment);
       idx = fgu->guIndex();
       ridx = owner*mindex + idx;
       if (rb[ridx].empty()) rb[ridx] = bb;
       else if (bb.mergable(rb[ridx], overlap)) rb[ridx] += bb;
       else {
         rcvsize[owner] += gdhdr::gdbsize(sizeof(Type)*rb[ridx].size());
         rb[ridx] = bb;
       }
     }
     for (p=0;p<pnum;p++) {
       if (p == me) continue;
       for (register int m=0;m<mindex;m++) {
         ridx = p*mindex + m;
         if (!rb[ridx].empty()) {
           rcvsize[p] += gdhdr::gdbsize(sizeof(Type)*rb[ridx].size());
           rb[ridx].setempty();
         }
       }
       if (rcvsize[p] > 0) {

#ifdef DEBUG_PRINT_GF_DCOPY
     ( comm_service::log() << "GF_gather_one: Receiving from: " 
                           << p << " " << rcvsize[p] << "\n").flush();
#endif
         recv_server[p] = new GridTableDataRcv(*gt,(DAGHServiceTag | p),rcvsize[p],p);
       }
     }
     if (rcvsize) delete [] rcvsize;
     if (rb) delete [] rb;
} /* End Post Recvs */

if (me != at && !lfgul.isempty()) { /* Send Data */
     GridUnitList *fgul = &lfgul;
     const int flen = fgul->number();

     BBoxList fbbl;
     fgul->bboxlist(fbbl,lf,overlap,levid);

#ifdef DEBUG_PRINT_GF_DCOPY
     ( comm_service::log() << "\n************* Send Data From BB List *************\n"
                           << fbbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     unsigned* sndsize = new unsigned[flen];
     BBox* sndbbox = new BBox[flen];
     short* sndindex = new short[flen];
     BBox *sb = new BBox[mindex];
     register int sndcnt = 0;
     register int idx = 0;

     GridUnit *fgu = fgul->first();
     BBox *fbb = fbbl.first();
     BBox bb;
     for(;fgu;fgu=fgul->next(),fbb=fbbl.next()) {
       bb = *fbb * newfrom;
       if (bb.empty()) continue;
       gdbAlignBBox(gfrank,bb,alignment);
       idx = fgu->guIndex();
       if (sb[idx].empty()) sb[idx] = bb; 
       else if (bb.mergable(sb[idx], overlap)) sb[idx] += bb;
       else {
         sndbbox[sndcnt] = sb[idx];
         sndsize[sndcnt] = sizeof(Type)*sb[idx].size();
         sndindex[sndcnt] = idx;
         sb[idx] = bb;
         sndcnt++;
       }
     }
     for (register int m=0;m<mindex;m++) {
       if (!sb[m].empty()) {
         sndbbox[sndcnt] = sb[m];
         sndsize[sndcnt] = sizeof(Type)*sb[m].size();
         sndindex[sndcnt] = m;
         sb[m].setempty();
         sndcnt++;
       }
     }
     GridDataBucket<Type> *gdbkt = new GridDataBucket<Type>(sndcnt,sndsize,DAGHPacked);
     register int s = 0;
     while (s<sndcnt) {
       sndbbox[s] *= gdb[tf][l1][sndindex[s]]->interiorbox(ident);

#ifdef DEBUG_PRINT_GF_DCOPY
     comm_service::log() << "\n************* Sending Data To: " << at << "*************\n"
                           << sndbbox[s] << " " << sndsize[s];
     ( comm_service::log() << "\n************* ***************** *************\n").flush();
#endif

       gdb[tf][l1][sndindex[s]]->gdbWriteData(ident,DAGHNull,sndbbox[s],*gdbkt,s);
       (gdbkt->head(s))->bbox = shiftabs((gdbkt->head(s))->bbox,-toshift);
       s++; 
     }
     gt->send((DAGHServiceTag | me),gdbkt,at);
     if (sndsize) delete [] sndsize;
     if (sndbbox) delete [] sndbbox;
     if (sndindex) delete [] sndindex;
     if (sb) delete [] sb;
} /* End Send Data */

if (me == at) { /* Do Local Updates */

     for (register int i=0; i<length; i++)
       if (gdb[tf][l1][i])
         into.copy(gdb[tf][l1][i]->griddata(ident),alignedto,alignedfrom);

} /* End Local Updates */

if (me == at) { /* Recv Data */

     GridUnitList *fgul = &gfgul;

     BBoxList fbbl;
     fgul->bboxlist(fbbl,lf,overlap,levid);

#ifdef DEBUG_PRINT_GF_DCOPY
     ( comm_service::log() << "\n************* Recv Data From BB List *************\n"
                           << fbbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     for (register int p=0;p<pnum;p++) {
       if (p == me) continue;
       if (recv_server[p]) {
	 if (!recv_server[p]->received())
	   comm_service::serve(*recv_server[p]->req());
         delete recv_server[p];
         recv_server[p] = 0;
       }
     }
     GF_ReadData(tf,into);
     gt->flushdata(tf);
     if (recv_server) delete [] recv_server;
} /* End Rcv Data */

   } /* End Distributed Stuff */

   else { /* Local Stuff */

     for (register int i=0; i<length; i++)
       if (gdb[tf][l1][i])
         into.copy(gdb[tf][l1][i]->griddata(ident),alignedto,alignedfrom);

   } /* End Local Stuff */
  }

/***************************************************************************/
/* Copy */
/***************************************************************************/
template <class Type>
void GridFunction(3)<Type>::GF_Copy(const int t1, const int l1, 
                            const GridFunction(3)<Type>& rhs, 
                            const int t2, const int l2, 
                            const BBox& to, const BBox& from, 
                            const int ident)
  {
   assert (to.rank == dagh.rank && from.rank == dagh.rank);
   const int tt = dagh_timeindex(t1,l1);
   const int tf = rhs.dagh_timeindex(t2,l2);

   const int me = comm_service::proc_me();
   const int pnum = comm_service::proc_num();

   if (comm_service::dce() && pnum > 1) { /* Distributed Stuff */

     const int lt = dagh.levelnum(l1);
     const int lf = dagh.levelnum(l2);
     const int levid = dagh.daghindex(ident);
     const int mindex = dagh.maxindex()+1;

     Coords const toshift = from.lower() - to.lower();
     BBox newfrom = from * shiftabs(to, toshift);
     if (newfrom.empty()) return;
     BBox newto = shiftabs(newfrom, -toshift);

     BBox alignedto = to;
     gdbAlignBBox(gfrank,alignedto,alignment);
     BBox alignedfrom = from;
     gdbAlignBBox(gfrank,alignedfrom,alignment);

     GridUnitList &clist = *dagh.clist();
     GridUnitList &llist = *dagh.llist();

     GridUnitList gtgul;
     GridUnitList ltgul;
     GridUnitList gfgul;
     GridUnitList lfgul;
     clist.intersect(newto,lt,gtgul,overlap);
     llist.intersect(newto,lt,ltgul,overlap);
     clist.intersect(newfrom,lf,gfgul,overlap);
     llist.intersect(newfrom,lf,lfgul,overlap);

#ifdef DEBUG_PRINT_GF_DCOPY
     ( comm_service::log() << "\n************* Global From List *************\n"
                           << gfgul
                           << "\n************* ***************** *************\n"
                           ).flush();
     ( comm_service::log() << "\n************* Local From List *************\n"
                           << lfgul
                           << "\n************* ***************** *************\n"
                           ).flush();
     ( comm_service::log() << "\n************* Global To List *************\n"
                           << gtgul
                           << "\n************* ***************** *************\n"
                           ).flush();
     ( comm_service::log() << "\n************* Local To List *************\n"
                           << ltgul
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     GridTableDataRcv **recv_server;
     recv_server = new GridTableDataRcv *[pnum];
     register int p;
     for (p=0;p<pnum;p++) recv_server[p] = GridTableDataRcvNULL;

{ /* Post Rcvs */
     GridUnitList *fgul = &gfgul;
     GridUnitList *tgul = &ltgul;

     BBoxList fbbl;
     fgul->bboxlist(fbbl,lf,overlap,levid);
     BBoxList tbbl;
     tgul->bboxlist(tbbl,lt,overlap,levid);

#ifdef DEBUG_PRINT_GF_DCOPY
     ( comm_service::log() << "\n************* Post Recv From BB List *************\n"
                           << fbbl
                           << "\n************* ***************** *************\n"
                           ).flush();
     ( comm_service::log() << "\n************* Post Recv To BB List *************\n"
                           << tbbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     unsigned *rcvsize = new unsigned[pnum];
     register int p;
     for (p=0;p<pnum;p++) rcvsize[p] = 0;
     BBox *rb = new BBox[pnum*mindex];
     short *rtoidx = new short[pnum*mindex];
     register int ridx = 0;
     register int rtidx = 0;
     register int idx = 0;

     GridUnit *fgu = fgul->first();
     GridUnit *tgu = 0;
     BBox *fbb = fbbl.first();
     BBox *tbb = 0;
     BBox bb;
     int owner = DAGHNoBody;
     for(;fgu;fgu=gfgul.next(),fbb=fbbl.next()) {
       if ((owner = fgu->guOwner()) == me) continue;
       idx = fgu->guIndex();
       ridx = owner*mindex + idx;
       for(tgu=tgul->first(),tbb=tbbl.first();tgu;tgu=tgul->next(),tbb=tbbl.next()) {
         bb = *fbb * shiftabs((*tbb*newto), toshift);
         if (!bb.empty()) {
           gdbAlignBBox(gfrank,bb,alignment);
           rtidx = tgu->guIndex();
           if (rb[ridx].empty()) { rb[ridx] = bb; rtoidx[ridx] = rtidx; }
           else if (rtoidx[ridx] == rtidx && bb.mergable(rb[ridx], overlap))
             rb[ridx] += bb;
           else {
             rcvsize[owner] += gdhdr::gdbsize(sizeof(Type)*rb[ridx].size());
             rb[ridx] = bb;
             rtoidx[ridx] = rtidx;
           }
         }
       }
     }
     for (p=0;p<pnum;p++) {
       if (p == me) continue;
       for (register int m=0;m<mindex;m++) {
         ridx = p*mindex + m;
         if (!rb[ridx].empty()) {
           rcvsize[p] += gdhdr::gdbsize(sizeof(Type)*rb[ridx].size());
           rb[ridx].setempty();
         }
       }
       if (rcvsize[p] > 0) {

#ifdef DEBUG_PRINT_GF_DCOPY
     ( comm_service::log() << "GF_Copy: Receiving from: "
                           << p << " " << rcvsize[p] << "\n").flush();
#endif
         recv_server[p] = new GridTableDataRcv(*gt,(DAGHServiceTag | p),rcvsize[p],p);
       }
     }
     if (rcvsize) delete [] rcvsize;
     if (rb) delete [] rb;
     if (rtoidx) delete [] rtoidx;
} /* End Post Recvs */

{ /* Send Data */
     GridUnitList *fgul = &lfgul;
     GridUnitList *tgul = &gtgul;

     const int flen = fgul->number();

     BBoxList fbbl;
     fgul->bboxlist(fbbl,lf,overlap,levid);
     BBoxList tbbl;
     tgul->bboxlist(tbbl,lt,overlap,levid);

#ifdef DEBUG_PRINT_GF_DCOPY
     ( comm_service::log() << "\n************* Send Data From BB List *************\n"
                           << fbbl
                           << "\n************* ***************** *************\n"
                           ).flush();
     ( comm_service::log() << "\n************* Send Data To BB List *************\n"
                           << tbbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     unsigned* sndsize = new unsigned[pnum*flen];
     BBox* sndbbox = new BBox[pnum*flen];
     short* sndindex = new short[pnum*flen];
     short* rcvindex = new short[pnum*flen];
     short* sndcnt = new short[pnum];
     register int p;
     for (p=0;p<pnum;p++) sndcnt[p] = 0;
     BBox *sb = new BBox[pnum*mindex];
     short *stoidx = new short[pnum*mindex];
     register int sidx = 0;
     register int stidx = 0;
     register int idx = 0;

     GridUnit *fgu = fgul->first();
     GridUnit *tgu = 0;
     BBox *fbb = fbbl.first();
     BBox *tbb = 0;
     BBox bb;

     int owner = DAGHNoBody;
     for(;fgu;fgu=fgul->next(),fbb=fbbl.next()) {
       idx = fgu->guIndex();
       for(tgu=tgul->first(),tbb=tbbl.first();tgu;tgu=tgul->next(),tbb=tbbl.next()) {
         if ((owner = tgu->guOwner()) == me) continue;
         stidx = tgu->guIndex();
         sidx = owner*mindex + idx;
         bb = *fbb * shiftabs((*tbb*newto), toshift);
         if (!bb.empty()) {
           gdbAlignBBox(gfrank,bb,alignment);
           if (sb[sidx].empty()) { sb[sidx] = bb; stoidx[sidx] = stidx; }
           else if (stoidx[sidx] == stidx && bb.mergable(sb[sidx], overlap))
             sb[sidx] += bb;
           else {
             const int tmpid = owner*flen + sndcnt[owner];
             sndbbox[tmpid] = sb[sidx];
             sndsize[tmpid] = sizeof(Type)*sb[sidx].size();
             sndindex[tmpid] = idx;
             rcvindex[tmpid] = stoidx[sidx];
             sb[sidx] = bb;
             stoidx[sidx] = stidx;
             sndcnt[owner]++;
	   }
	 }
       }
     }
     for (p=0;p<pnum;p++) {
       if (p == me) continue;
       register int off = p*flen;
       for (register int m=0;m<mindex;m++) {
         sidx = p*mindex + m;
         if (!sb[sidx].empty()) {
           const int tmpid = off + sndcnt[p];
           sndbbox[tmpid] = sb[sidx];
           sndsize[tmpid] = sizeof(Type)*sb[sidx].size();
           sndindex[tmpid] = m;
           rcvindex[tmpid] = stoidx[sidx];
           sb[m].setempty();
           sndcnt[p]++;
         }
       }
      
       if (sndcnt[p] == 0) continue;

       GridDataBucket<Type> *gdbkt = 
           new GridDataBucket<Type>(sndcnt[p],(sndsize + off),DAGHPacked);
       register int s = 0;
       while (s<sndcnt[p]) {
         sndbbox[off+s] *= rhs.gdb[tf][l2][sndindex[off+s]]->interiorbox(ident);

#ifdef DEBUG_PRINT_GF_DCOPY
      comm_service::log() << "\n************* Sending Data To: " << p << "*************\n"
                           << sndbbox[off+s] << " " << sndsize[off+s];
     ( comm_service::log() << "\n************* ***************** *************\n").flush();
#endif

         rhs.gdb[tf][l2][sndindex[off+s]]->gdbWriteData(ident,DAGHNull,sndbbox[off+s],*gdbkt,s);
         (gdbkt->head(s))->bbox = shiftabs((gdbkt->head(s))->bbox,-toshift);
         (gdbkt->head(s))->time = tt;
         (gdbkt->head(s))->level = lt;
         (gdbkt->head(s))->index = rcvindex[off+s];
         s++;
       }
       gt->send((DAGHServiceTag | me),gdbkt,p);
       if (sndsize) delete [] sndsize;
       if (sndbbox) delete [] sndbbox;
       if (sndindex) delete [] sndindex;
       if (rcvindex) delete [] rcvindex;
       if (sndcnt) delete [] sndcnt;
       if (sb) delete [] sb;
       if (stoidx) delete [] stoidx;
     }
} /* End Send Data */

{ /* Do Local Updates */
     GridUnitList *fgul = &lfgul;
     GridUnitList *tgul = &ltgul;

#ifdef DEBUG_PRINT_GF_DCOPY
     BBoxList fbbl;
     fgul->bboxlist(fbbl,lf,overlap,levid);
     BBoxList tbbl;
     tgul->bboxlist(tbbl,lt,overlap,levid);

     ( comm_service::log() << "\n************* Copy Data From BB List *************\n"
                           << fbbl
                           << "\n************* ***************** *************\n"
                           ).flush();
     ( comm_service::log() << "\n************* Copy Data To BB List *************\n"
                           << tbbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     GridUnit *fgu = fgul->first();
     GridUnit *tgu = 0;
     short *idxflag = new short[mindex*mindex];
     short fidx = DAGHNull, tidx = DAGHNull;
     for (int m=0;m<mindex*mindex;m++) idxflag[m] = DAGHFalse;

     for(;fgu;fgu=fgul->next()) {
       fidx = fgu->guIndex();
       for(tgu=tgul->first();tgu;tgu=tgul->next()) {
         tidx = tgu->guIndex();
         idxflag[fidx*mindex+tidx] = DAGHTrue;
       }
     }
     for (register int mf=0;mf<mindex;mf++) {
       GridData(3)<Type>& tmpgd = rhs.gdb[tf][l2][mf]->griddata(ident);
       for (register int mt=0;mt<mindex;mt++) {
         if (idxflag[mf*mindex+mt] == DAGHTrue) 
           (gdb[tt][l1][mt]->griddata(ident)).copy(tmpgd,alignedto,alignedfrom);
       }
     }
     if (idxflag) delete [] idxflag;
} /* End Local Updates */

{ /* Recv Data */
#ifdef DEBUG_PRINT_GF_DCOPY
     GridUnitList *fgul = &gfgul;
     GridUnitList *tgul = &ltgul;

     BBoxList fbbl;
     fgul->bboxlist(fbbl,lf,overlap,levid);
     BBoxList tbbl;
     tgul->bboxlist(tbbl,lt,overlap,levid);

     ( comm_service::log() << "\n************* Recv Data From BB List *************\n"
                           << fbbl
                           << "\n************* ***************** *************\n"
                           ).flush();
     ( comm_service::log() << "\n************* Recv Data To BB List *************\n"
                           << tbbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     for (register int pp=0;pp<pnum;pp++) {
       if (pp == me) continue;
       if (recv_server[pp]) {
	 if (!recv_server[pp]->received())
	   comm_service::serve(*recv_server[pp]->req());
         delete recv_server[pp];
         recv_server[pp] = 0;
       }
     }
     GF_ReadData(tt);
     gt->flushdata(tt);
} /* End Rcv Data */

     if (recv_server) delete [] recv_server;
   } /* End Distributed Stuff */

   else { /* Local Stuff */

     BBox alignedto = to;
     gdbAlignBBox(gfrank,alignedto,alignment);
     BBox alignedfrom = from;
     gdbAlignBBox(gfrank,alignedfrom,alignment);

     for (register int i=0; i<length; i++)
       if (gdb[tt][l1][i] && rhs.gdb[tf][l2][i])
         (gdb[tt][l1][i]->griddata(ident)).copy(
             rhs.gdb[tf][l2][i]->griddata(ident),alignedto,alignedfrom);

   } /* End Local Stuff */
  }

/***************************************************************************/
/* Equals */
/***************************************************************************/
/***************************************************************************/
/* plus */
/***************************************************************************/
/***************************************************************************/
/* minus */
/***************************************************************************/
/***************************************************************************/
/* multiply */
/***************************************************************************/
/***************************************************************************/
/* divide */
/***************************************************************************/
#endif
