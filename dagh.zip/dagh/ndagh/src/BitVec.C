/*
*************************************************************************
*                                                                       *
* BitVec.h                                                              *
*                                                                       *
* Class BitVec defines a bit-vector as an array of BitVecType.  	*
* Bit are numbered from O; i.e. The MSB of BitVec[0] is bit 0 and the   *
* LSB of BitVec[Dim-1] is bit NBit-1 where NBit=Sizeof(BitVecType)*Dim. *
*                                                                       *
* Operations on the bit vector include testing/setting and toggling a  	*
* set of bits corresponding to a digit and isolating the bits.          *
*                                                                       *
* This class has been modified to have a fix maxlen of the bitvector	*
* so that it does not need dynamic allocations.				*
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

#include "BitVec.h"

#ifndef __ENABLE_INLINE__
#include "BitVec.inline"
#endif

/*
*************************************************************************
*                                                                       *
* BitVec::BitVec(const int len)						*
*									*
* Constructor BitVec creates a bit vector of length "len" as an 	*
* array of BitVecType. The bit vector is initialized to 0.		*
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

BitVec::BitVec(const int len) 
  {

   slot_width = (sizeof(BitVecType)*ByteWidth);

   slots = (len%slot_width == 0) ?
           len/slot_width : len/slot_width + 1;

   assert(slots <= MaxBitVecSlots);

   length = len;

   for(register int i=0;i<slots;i++)
     bvec[i] = 0;

  }

/*
*************************************************************************
*                                                                       *
* BitVec const &BitVec::operator= (BitVec const &other);		*
*									*
* Overload the assignment operator for BitVec				* 
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

BitVec const &BitVec::operator= (BitVec const &other)
  {
   if(this != &other) 
     {
      slot_width = other.slot_width;
      slots = other.slots;
      length = other.length;

      for(int i=0;i<slots;i++)
        bvec[i] = other.bvec[i];
     }
   return(*this);
  }

/*
*************************************************************************
*                                                                       *
* int BitVec::operator== (BitVec const &other);				*
*									*
* Overload the equality operator for BitVec				* 
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

int BitVec::operator== (BitVec const &other) const
  {
   assert(length == other.length);

   if(this == &other) 
     return(1);

   for(int i=0;i<slots;i++)
     if((unsigned)bvec[i] != (unsigned)other.bvec[i])
       return 0;

   return(1);
  }

/*
*************************************************************************
*                                                                       *
* int BitVec::operator> (BitVec const &other);				*
*									*
* Overload the greater than operator for BitVec				* 
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

int BitVec::operator> (BitVec const &other) const
  {
   assert(length == other.length);

   if(this == &other) 
     return(0);

   for(int i=0;i<slots;i++) {
     if(bvec[i] > other.bvec[i])
       return 1;
     else if(bvec[i] < other.bvec[i])
       return 0;
   }

   return(0);
  }

/*
*************************************************************************
*                                                                       *
* int BitVec::operator< (BitVec const &other);				*
*									*
* Overload the less than operator for BitVec				* 
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

int BitVec::operator< (BitVec const &other) const
  {
   assert(length == other.length);

   if(this == &other) 
     return(0);

   for(int i=0;i<slots;i++) {
     if(bvec[i] < other.bvec[i])
       return 1;
     else if(bvec[i] > other.bvec[i])
       return 0;
   }

   return(0);
  }

/*
*************************************************************************
*                                                                       *
* int BitVec::operator!= (BitVec const &other);				*
*									*
* Overload the != operator for BitVec					* 
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

int BitVec::operator!= (BitVec const &other) const
  {
   assert(length == other.length);

   if(this == &other) 
     return(0);

   for(int i=0;i<slots;i++)
     if((unsigned)bvec[i] != (unsigned)other.bvec[i])
       return 1;

   return(0);
  }

/*
*************************************************************************
*                                                                       *
* int BitVec::operator>= (BitVec const &other);				*
*									*
* Overload the >= operator for BitVec					*
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

int BitVec::operator>= (BitVec const &other) const
  {
   assert(length == other.length);

   if(this == &other) 
     return(1);

   for(int i=0;i<slots;i++) {
     if(bvec[i] > other.bvec[i])
       return 1;
     else if(bvec[i] < other.bvec[i])
       return 0;
   }

   return(1);
  }

/*
*************************************************************************
*                                                                       *
* int BitVec::operator<= (BitVec const &other);				*
*									*
* Overload the <= operator for BitVec					*
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

int BitVec::operator<= (BitVec const &other) const
  {
   assert(length == other.length);

   if(this == &other) 
     return(1);

   for(int i=0;i<slots;i++) {
     if(bvec[i] < other.bvec[i])
       return 1;
     else if(bvec[i] > other.bvec[i])
       return 0;
   }

   return(1);
  }

/*
*************************************************************************
*                                                                       *
* void BitVec::IsolateBit(const int loc, const int num) const		*
*                                                                       *
* Member function IsolateBit isolates the bit at location "loc" of 	*
* bit vector and returns it as the LSB of an unsigned. 			*
* Remember that the most significant bit is numbered 0.			*
*									*
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

unsigned BitVec::IsolateBit(const int loc, const int num) const
 {
   assert(loc >= 0 && loc+num-1 < length);

   register int n;
   if((n = (slot_width - loc%slot_width)) < num) {
     register unsigned tmp = (~((~(unsigned)0)<<n)) & bvec[GetSlot(loc)];
                    /* IsolateBit(loc,n); */
     tmp = (tmp<<(num-n)) | 
           ((~((~(unsigned)0)<<num-n)) & (bvec[GetSlot(loc+n)]>>(slot_width-(num-n))));
                    /* IsolateBit(loc+n,num-n); */
     return tmp;
   }
   else {
      return ( (~((~(unsigned)0)<<num)) & (bvec[GetSlot(loc)]>>(n-num)) );
   }
 }

/*
*************************************************************************
*                                                                       *
* void BitVec::SwapBit(const int loc1, const int loc2)			*
*                                                                       *
* Member function SwapBit swaps the bits at locations "loc1" and "loc2".*
*									*
* Remember that the most significant bit is numbered 0.			*
*									*
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

void BitVec::SwapBit(const int loc1, const int loc2)
 {
   assert(loc1 >= 0 && loc2 < length &&
          loc2 >= 0 && loc2 < length);

   if (loc1 == loc2) return;
   	
   register unsigned tmp = IsolateBit(loc1);

   if (TestBit(loc2))
     SetBit(loc1);
   else
     UnsetBit(loc1);

   if (tmp)
     SetBit(loc2);
   else
     UnsetBit(loc2);
 }
