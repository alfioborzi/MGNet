/*
  MRUN          Return something for time accounting in milliseconds
                For example, the FORTRAN code fragment

                   real*8  mrun, t1, t2
                   t1 = mrun(0)
                        ...
                   t2 = mrun(0) - t1
                   
                puts the elapsed running time in t2.  No guarantees are
                made about what mrun returns other than it will be in
                the format seconds.milliseconds (assuming the machine
                supports milliseconds).
*/

#define BSD 1           /* 1 for Berkeley UNIX systems */
#define USG 0           /* 1 for AT&T System V systems */

#include <stdio.h>

#if BSD
#include <sys/time.h>
#endif

double mrun_(dummy) int dummy; {

  double  ret;

#if BSD
  struct timeval tp;
  struct timezone tzp;

  gettimeofday(&tp,&tzp);
  
  ret = tp.tv_usec / 1000;
  ret = ret * .001;
  ret = ret + tp.tv_sec;
#endif

#if USG
  long clock();

  ret = clock() / 1000;
  ret = ret * .001;
#endif

  return ret;
  }
