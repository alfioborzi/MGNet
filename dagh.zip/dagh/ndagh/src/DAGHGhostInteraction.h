#ifndef _included_DAGHGhostInteraction_h
#define _included_DAGHGhostInteraction_h

/*
*************************************************************************
*                                                                       *
* DAGHGhostInteraction.h						*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"
#include "GridDataParams.h"

#include "BBox.h"

#ifndef DAGHDefaultInteraction
#define DAGHDefaultInteraction 	(DAGHGhostInteraction)
#endif

class GhostInteraction 
  {
   friend ostream& operator << (ostream&, const GhostInteraction &);

   short Irank;   /* Dimensions 1, 2, or 3 */
   short Itype;	  /* Ghost Interactions ? */
   short Iwidth;  /* Radius of interactions */
    
   short Itotal;

   short Icounts[DAGHMaxAxis][DAGHMaxDirs];
   short *Ilists[DAGHMaxAxis][DAGHMaxDirs];

   short Iinside;
 
   short Iface_cnt;
   short *Ifaces;

   //short Iface_cnt[DAGHMaxAxis][DAGHMaxDirs];
   //short *Ifaces[DAGHMaxAxis][DAGHMaxDirs];
   //short Icorner_cnt[DAGHMaxAxis][DAGHMaxDirs];
   //short *Icorners[DAGHMaxAxis][DAGHMaxDirs];
   //short Iedge_cnt[DAGHMaxAxis][DAGHMaxDirs];
   //short *Iedges[DAGHMaxAxis][DAGHMaxDirs];

   short FaceFlag;
   short CornerFlag;
   short EdgeFlag;

public:
    
   GhostInteraction( const int rank, 
                     const int type,
                     const int width );    

   GhostInteraction( const int rank, 
                     const int face_flag, 
                     const int corner_flag, 
                     const int edge_flag, 
                     const int type,
                     const int width );    

   GhostInteraction( const GhostInteraction &other );

   ~GhostInteraction( );    

   void compute_interactions( const int face_flag,
                              const int corner_flag,
                              const int edge_flag );

   inline int total_interactions( ) const { return Itotal; }

   inline int num_interactions( const int axis, const int dir ) const
		{ return Icounts[axis][dir]; }
   inline short const *interactions( const int axis, const int dir ) const
		{ return Ilists[axis][dir]; }
    
   inline int inside() const { return Iinside; }

   inline complement(const int d) const { return Itotal-1-d; }

   //int is_forward(const int i);
   //int is_forward(const int i, const int d);

   //int is_backward(const int i);
   //int is_backward(const int i, const int d);

   inline int num_faces( const int axis, const int dir ) const
    		{ return Iface_cnt; }
   inline short const *faces( ) const
    		{ return Ifaces; }
   inline short faces( const int axis, const int dir ) const
    		{ return Ifaces[2*axis+dir]; }
    
   //inline int num_faces( const int axis, const int dir ) 
   // 		{ return Iface_cnt[axis][dir]; }
   //inline short const *faces( const int axis, const int dir ) 
   // 		{ return Ifaces[axis][dir]; }
    
   //inline int num_corners( const int axis, const int dir ) 
   //		{ return Icorner_cnt[axis][dir]; }
   //inline short const *corners( const int axis, const int dir ) 
   //		{ return Icorners[axis][dir]; }
    
   //inline int num_edges( const int axis, const int dir ) 
   //		{ return Iedge_cnt[axis][dir]; }
   //inline short const *edges( const int axis, const int dir ) 
   //		{ return Iedges[axis][dir]; }
    
   BBox Ibbox( BBox const &mybb, const int dir, short const *rad ) const ;
   BBox Ibbox( BBox const &mybb, const int axis, const int dir, 
               short const *rad ) const ;
   BBox IbboxFrom( BBox const &mybb, const int dir, short const *rad, 
                   const short* olap ) const ;

private:

   inline int is_inside( const int x, const int y, const int z )
		{ return (x==1 && y==1 && z==1); }
   inline int is_face( const int x, const int y, const int z )
		{ return ((x==1 && y==1 && z!=1) || 
 		          (x==1 && y!=1 && z==1) ||
			  (x!=1 && y==1 && z==1)); }
   inline int is_corner( const int x, const int y, const int z )
		{ return (x!=1 && y!=1 && z!=1 ); }
   inline int is_edge( const int x, const int y, const int z )
		{ return ((x==1 && y!=1 && z!=1) || 
 		          (x!=1 && y==1 && z!=1) ||
			  (x!=1 && y!=1 && z==1)); }
  };

#endif
