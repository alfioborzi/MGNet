/*
LPARX Software Distribution v2.0 --  11/9/94
--------------------------------------------

        Scott R. Kohn
        Scott B. Baden

        University of California, San Diego
        Department of Computer Science and Engineering, 0114
        9500 Gilman Drive
        La Jolla, CA 92093-0114 USA

"Copyright (c) 1994, by Scott R. Kohn, Scott B. Baden, and
The Regents of the University of California.  All rights reserved.
*/
