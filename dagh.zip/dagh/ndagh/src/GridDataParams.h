#ifndef _included_GridDataParams_h
#define _included_GridDataParams_h

/*
*************************************************************************
* GridDataParams.h                                                      *
*                                                                       *
*************************************************************************
*/

/* Face data directions for 1,2,3-D */
#define ALL     (-2)
#define CENTER  (-1)

#define NULL_FACE	(-1)
#define FACES	(0)
#define WEST    (0)
#define EAST    (1)
#define SOUTH   (2)
#define NORTH   (3)
#define FRONT   (4)
#define BACK    (5)
#define INSIDE  (6)

/* Corner data directions for 2,3-D */
/* West = W, East = W, South = S, North = N
   Front = F, Back = B */ 
#define NULL_CORNER	(-1)
#define CORNERS	(10)
/* 3-D */
#define WSF	(10)
#define WSB	(11)
#define WNF	(12)
#define WNB	(13)
#define ESF	(14)
#define ESB	(15)
#define ENF	(16)
#define ENB	(17)
/* 2-D */
#define WS	(10)
#define WN	(11)
#define ES	(12)
#define EN	(13)

/* Edge data directions for 3-D */
/* West = W, East = W, South = S, North = N
   Front = F, Back = B, Center C */ 
#define NULL_EDGE	(-1)
#define EDGES	(20)
#define WSC	(20)
#define WNC	(21)
#define WCF	(22)
#define WCB	(23)
#define CSF	(24)
#define CSB	(25)
#define CNF	(26)
#define CNB	(27)
#define ENC	(28)
#define ESC	(29)
#define ECB	(30)
#define ECF	(31)

const int DirCorners2[6][3] = {
                             {WS,WN,NULL_CORNER},{ES,EN,NULL_CORNER}, // X-B,X-F
                             {WS,ES,NULL_CORNER},{WN,EN,NULL_CORNER}, // Y-B,Y-F
                             {WS,WN,ES},         {ES,EN,WN}           // All-B,All-F
                            };

const int DirCorners3[8][7] = {
          {WSF,WSB,WNF,WNB,NULL_CORNER,NULL_CORNER,NULL_CORNER},
          {ESF,ESB,ENF,ENB,NULL_CORNER,NULL_CORNER,NULL_CORNER}, // X-B,X-F
          {WSF,WSB,ESF,ESB,NULL_CORNER,NULL_CORNER,NULL_CORNER},
          {WNF,WNB,ENF,ENB,NULL_CORNER,NULL_CORNER,NULL_CORNER}, // Y-B,Y-F
          {WSF,WNF,ESF,ENF,NULL_CORNER,NULL_CORNER,NULL_CORNER},
          {WSB,WNB,ESB,ENB,NULL_CORNER,NULL_CORNER,NULL_CORNER}, // Z-B,Z-F
          {WSF,WSB,WNF,WNB,ESF,ESB,ENF},
          {ESF,ESB,ENF,ENB,WNF,WNB,WSB}                          // All-B,All-F
                            };
const int DirEdges3[8][9] = {
          {WSC,WNC,WCF,WCB,NULL_EDGE,NULL_EDGE,NULL_EDGE,NULL_EDGE,NULL_EDGE},
          {ENC,ESC,ECB,ECF,NULL_EDGE,NULL_EDGE,NULL_EDGE,NULL_EDGE,NULL_EDGE}, // X-B,X-F
          {WSC,CSF,CSB,ESC,NULL_EDGE,NULL_EDGE,NULL_EDGE,NULL_EDGE,NULL_EDGE},
          {WNC,CNF,CNB,ENC,NULL_EDGE,NULL_EDGE,NULL_EDGE,NULL_EDGE,NULL_EDGE}, // Y-B,Y-F
          {WCF,CSF,CNF,ECF,NULL_EDGE,NULL_EDGE,NULL_EDGE,NULL_EDGE,NULL_EDGE},
          {WCB,CSB,CNB,ECB,NULL_EDGE,NULL_EDGE,NULL_EDGE,NULL_EDGE,NULL_EDGE}, // Z-B,Z-F
          {WSC,WNC,WCF,WCB,CSF,CSB,ESC,CNF,ECF}, 
          {ENC,ESC,ECB,ECF,WNC,CNF,CNB,WCB,CSB}                                // All-B,All-F
                          };

#endif
