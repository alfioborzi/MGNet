/***********************************************************************
*
* Subroutine KLSGSM  Symmetric Gauss Seidel with Minimum Residual
*                    acceleration iteration
*
* Key: n  integer     i  input        1  vector
*      r  real        o  output       2  matrix
*      d  real*8      s  scratch
*      c  character
*
*      Argument  Description
*      --------  -----------
* ri1  a         matrix stored in sparse form with n rows
* rs1  ap        scratch vector, size n
* rs1  az        scratch vector, size n
* ri1  b         right hand side, size n
* no   flag      error flag
*                   0  no error
*                  -1  illegal matrix type
* ni1  ija       pointers to rows of matrix followed by column indices
*                of matrix
* ni   atype      type of matrix
*                   0  symmetric
*                   1  nonsymmetric
*                  -1  nonsymmetric, solve with a transpose
* ni   iters     number of iterations
* ni   n         number of rows in matrix
* rs1  p         scratch vector, size n
* ro1  res       residual, size n
* ri1  x         initial guess and solution vector, size n
* rs1  z         scratch vector, size n
*
* Algorithm
* ---------
*   (1) r(0) = b - Ax(0)
*   (2) For i = 1 to iters
*       (a)
*       (b)
*       (c)
*       (d)
*       (e)
*       (f)
*       (g)
*       (h)
*
* Multiplies/Divides
* ------------------
*   If M = cost of computing Av (any vector v), then the cost is
*       iters*(M+9N) + M
*   which is approximately half the cost of the standard implementation.
*
* Reference
* ---------
* Randolph E. Bank and Craig C. Douglas, An efficient implementation
*   for ssor and incomplete factorization preconditionings, Applied
*   Numerical Mathematics, 1 (1985), pp. 489-492.
*
***********************************************************************/

#include "defnc.pre"

klsgsm(iters, n, ija, a, x, b, res, ap, p, az, z, atype, flag)

        INT     *atype, *flag, *iters, *ija, *n;
        REAL    *a, *ap, *az, *b, *p, *res, *x, *z;
  {
  /*********************************************************************
  *----local variables */
  INT     i, itno, *ipija, j, j1, j2, jaj, lshift, niters, ushift;
  REAL    ak, azap, bk, *pa, *pap, *paz, *pp, *pres, *px, *pz, rap,
          spap, spapn, sum, zi;
  /********************************************************************/

  *flag = -1;
  if (*atype < -1 || *atype > 1) return;
  *flag = 0;

  /* determine matrix index shifts */
  ushift = 0;
  lshift = 0;
  if (*atype == 1)  lshift = ija[*n] - *ija;
  if (*atype == -1) ushift = ija[*n] - *ija;

  /* compute residual and set p = ap = 0 */
  klres(n, ija, a, x, b, res, atype, flag);
  if (*flag != 0) return;
  pp = p;
  pap = ap;
  for (i = 0; i < *n; i++) {
    *pp++ = 0.;
    *pap++ = 0.;
    }
  spap = 0.;

  /* main loop */
  niters = *iters;
  if (niters <= 0) niters = 1;
  for (itno  = 0; itno < niters; itno++) {

    /* solve Lq = res and start computing Az */
    ipija = ija;
    pa = a;
    paz = az;
    pres = res;
    pz = z;
    for (i = 0; i < *n; i++) {
      j1 = *ipija++ - 1;
      j2 = *ipija - 1;
      sum = *pres++;
      for (j = j1; j < j2; j++)
        sum -= (a[j+lshift] * z[ija[j]-1]);
      *pz++ = sum / *pa++;
      *paz++ = sum;
      }
    paz = az;
    pz = z;
    for (i = 0; i < *n; i++)
      *pz++ = *paz++;

    /* solve (D-U)z = q and complete Az */
    azap = 0.;
    for (i = *n; i--; ) {
      j1 = ija[i] - 1;
      j2 = ija[i+1] - 1;
      z[i] /= a[i];
      zi = z[i];
      for (j = j1; j < j2; j++) {
        jaj = ija[j] - 1;
        z[jaj] -= (a[j+ushift] * zi);
        }
      }
    ipija = ija;
    pap = ap;
    paz = az;
    for (i = 0; i < *n; i++) {
      j1 = *ipija++ - 1;
      j2 = *ipija - 1;
      sum = *paz;
      for (j = j1; j < j2; j++)
        sum += (a[j+lshift] * z[ija[j]-1]);
      *paz = sum;
      azap += (*paz++ * *pap++);
      }

    /* compute next direction and update p and ap */
    bk = 0.;
    if (spap > 0) bk = azap / spap;
    spapn = 0.;
    rap = 0.;
    pap = ap;
    paz = az;
    pp = p;
    pres = res;
    pz = z;
    for (i = 0; i < *n; i++) {
      *pp = *pz++ - (*pp * bk);
      pp++;
      *pap = *paz++ - (*pap * bk);
      spapn = spapn + (*pap * *pap);
      rap = rap + (*pres++ * *pap++);
      }

    /* update x and res */
    if (spapn <= 0.) break;
    ak = rap / spapn;
    pap = ap;
    pp = p;
    pres = res;
    px = x;
    for (i = 0; i < *n; i++) {
      *px++ += (ak * *pp++);
      *pres++ -= (ak * *pap++);
      }
    ak = 0.;
    if (spap != 0.) ak = spapn / spap;
    spap = spapn;
    }

  }
