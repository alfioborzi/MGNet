#ifndef _included_BBox_h
#define _included_BBox_h

/*
*************************************************************************
*									*
* BBox.h								*
*									*
* BBox class implements a region in the computational domain		*
* This class is sort of an adaptation and extension of the from Class 	*
* RegionX of LPARX developed by Scott Kohn (skohn-at-cs.ucsd.edu	*
*									*
* Author:  Manish Parashar <parashar@cs.utexas.edu>			*
*									*
*************************************************************************
*/

#include "lparx_copyright.h"
#include "Coords.h"

#include <iostream.h>
#include <fstream.h>
#include <stdlib.h>

#ifndef LOWERBOUND
#define LOWERBOUND (-1000000000)
#endif
#ifndef UPPERBOUND
#define UPPERBOUND ( 1000000000)
#endif

#define BBoxNULL	((BBox *) NULL)

class BBox
  {
   friend istream& operator >> (istream&, BBox &);
   friend ostream& operator << (ostream&, BBox const &);
   friend ifstream& operator >> (ifstream&, BBox&);
   friend ofstream& operator << (ofstream&, const BBox&);

   Coords lb, ub;
   Coords step;

public:
   int rank;
   static class BBox _empty_bbox;

public:
   inline BBox(void)
        : rank(-1), lb(0,UPPERBOUND), ub(0,LOWERBOUND) {}
   inline BBox(const int r, const int s)
        : step(r,s), rank(r), lb(r,UPPERBOUND), ub(r,LOWERBOUND) {}
   inline BBox(const int r, Coords const &s)
        : step(s), rank(r), lb(r,UPPERBOUND), ub(r,LOWERBOUND) {}
   inline BBox(Coords const &l, Coords const &u, const int s)
        : step(l.rank,s), rank(l.rank), lb(l), ub(u) {}
   inline BBox(const int r, const int *l, const int *u, const int s)
        : step(r,s), rank(r), lb(r,l), ub(r,u) {}
   inline BBox(Coords const &l, Coords const &u, Coords const &s)
        : step(s), rank(l.rank), lb(l), ub(u) {}
   inline BBox(const int r, const int *l, const int *u, const int *s)
        : step(r,s), rank(r), lb(r,l), ub(r,u) {}
   inline BBox(BBox const &other)
        : step(other.step), rank(other.rank), lb(other.lb), ub(other.ub) {}

   /* Special constructors for 1, 2 & 3 D */
   inline BBox(const int r, const int i, 
		     const int ii, const int s)
        : step(r,s), rank(r), lb(r,i), ub(r,ii) {}
   inline BBox(const int r, const int i, const int j, 
   		     const int ii, const int jj, const int s)
        : step(r,s), rank(r), lb(r,i,j), ub(r,ii,jj) {}
   inline BBox(const int r, const int i, const int j, const int k,
		     const int ii, const int jj, const int kk, const int s)
        : step(r,s), rank(r), lb(r,i,j,k), ub(r,ii,jj,kk) {}
   inline BBox(const int r, const int i, const int j, 
   		     const int ii, const int jj, 
                     const int s, const int ss)
        : step(r,s,ss), rank(r), lb(r,i,j), ub(r,ii,jj) {}
   inline BBox(const int r, const int i, const int j, const int k,
		     const int ii, const int jj, const int kk, 
                     const int s, const int ss, const int sss)
        : step(r,s,ss,sss), rank(r), lb(r,i,j,k), ub(r,ii,jj,kk) {}

   inline BBox& operator = (const BBox& other)
	{ 
	 step = other.step; rank = other.rank; 
	 lb = other.lb; ub = other.ub; 
	 return(*this); 
        }

   inline ~BBox() {}
   
   /* Functions which modify the bounding box -- lower and upper bounds */
   inline void setempty()
     { lb.setval(UPPERBOUND); ub.setval(LOWERBOUND); }

   inline void setlower(Coords const &l) { lb = l; }
   inline void setlower(const int *l)
     { register int i; for (i=0;i<rank; i++) lb(i) = l[i]; }

   inline void setupper(Coords const &u) { ub = u; }
   inline void setupper(const int *u)
     { register int i; for (i=0;i<rank; i++) ub(i) = u[i]; }

   inline void setbbox(const int *l, const int *u)
     { setlower(l); setupper(u); }
   inline void setbbox(Coords const &l, Coords const &u) 
     { lb = l; ub = u; }
   inline void setbbox(BBox const &other) 
     { step = other.step; rank = other.rank; lb = other.lb; ub = other.ub; }

   /* Some simple inline access functions for class BBox */
   inline Coords const &lower() const { return(lb); }
   inline Coords const &upper() const { return(ub); }
   inline int lower(const int i) const { return(lb(i)); }
   inline int upper(const int i) const { return(ub(i)); }

   inline Coords &lower() { return(lb); }
   inline Coords &upper() { return(ub); }
   inline int &lower(const int i) { return(lb(i)); }
   inline int &upper(const int i) { return(ub(i)); }

   inline Coords const &stepsize(void) const { return (step); }
   inline Coords &stepsize(void) { return (step); }
   inline const int stepsize(const int i) const { return (step(i)); }
   inline int &stepsize(const int i) { return (step(i)); }

   inline void setstepsize(const int i, const int s) { step(i) = s; }
   inline void setstepsize(Coords const &s) { step = s; }
   inline void setstepsize(const int s) { step.setval(s); }

   inline int extents(const int i) const 
     { return((ub(i)-lb(i)+step(i))/step(i)); }
   inline Coords extents() const 
     { return((ub-lb+step)/step); }

   inline int empty() const
     { return ( (rank < 0) ||
               ((rank > 0) && (ub(0) < lb(0))) ||
               ((rank > 1) && (ub(1) < lb(1))) ||
               ((rank > 2) && (ub(2) < lb(2)))
             ) ; }

   inline int bottom(void) const
     {
       register int b = (rank > 0) ? lb(0)/step(0) : 0;
       register int e = (rank > 1) ? (ub(0)-lb(0)+step(0))/step(0) : 1;
       b += (rank > 1) ? e*lb(1)/step(1) : 0; 
       e *= (rank > 2) ? (ub(1)-lb(1)+step(1))/step(1) : 1;
       b += (rank > 2) ? e*lb(2)/step(2) : 0; 
       return (-b);
     }

   inline int size() const
     {
       if (empty()) return 0;
       register int s = (rank > 0) ? (ub(0)-lb(0)+step(0))/step(0) : 0;
       s *= (rank > 1) ? ((ub(1)-lb(1)+step(1))/step(1)) : 1;
       s *= (rank > 2) ? ((ub(2)-lb(2)+step(2))/step(2)) : 1;
       return s;
     }

   /* by compatible in dimension d I mean lb1(d) == lb2(d) && ub1(d) == ub2(d) */
   inline int compatible(BBox const &rhs, const int d) const
     { return( lb(d) == rhs.lb(d) && ub(d) == rhs.ub(d) ); }

   /* can the boxes be merged !! */
   //int mergable(BBox const &rhs, const int d, const int olap) const;
   inline int mergable(BBox const &rhs, const int d, const int olap) const
     {
       return (
       (rank == 1) ? (abs(lb(d) - rhs.ub(d)) == (1-olap)*step(d)) || 
	             (abs(ub(d) - rhs.lb(d)) == (1-olap)*step(d)) :
       (rank == 2) ? compatible(rhs,(d+1)%2) &&
                     ((abs(lb(d) - rhs.ub(d)) == (1-olap)*step(d)) || 
    	              (abs(ub(d) - rhs.lb(d)) == (1-olap)*step(d))) :
       (rank == 3) ? compatible(rhs,(d+1)%3) &&
	             compatible(rhs,(d+2)%3) &&
                     ((abs(lb(d) - rhs.ub(d)) == (1-olap)*step(d)) || 
                      (abs(ub(d) - rhs.lb(d)) == (1-olap)*step(d))): 0
       );
     }

   //int BBox::mergable(BBox const &rhs, const short* olap) const;
   inline int mergable(BBox const &rhs, const short* olap) const
     {
       int flag = 0;
       flag = (rank == 3) ? flag || mergable(rhs, 2, olap[2]) : flag; 
       flag = (rank >= 2) ? flag || mergable(rhs, 1, olap[1]) : flag; 
       flag = (rank >= 1) ? flag || mergable(rhs, 0, olap[0]) : flag; 
       return flag;
     }

   /* Define the bounding box operators + and += (bounding box union) */
   inline BBox &operator += (Coords const &rhs)
     {
       if (empty()) { lb = rhs; ub = rhs; return(*this); }
       lb.min(rhs); ub.max(rhs); return(*this);
     }
   inline BBox operator + (Coords const &rhs) const
     { BBox bbox(*this); bbox += rhs; return(bbox); }

   inline BBox &operator += (BBox const &rhs)
     {
       if (empty()) return(*this = rhs);
       if (rhs.empty()) return(*this);
       lb.min(rhs.lb); ub.max(rhs.ub); return(*this);
     }
   inline BBox operator + (BBox const &rhs) const
     { BBox bbox(*this); bbox += rhs; return(bbox); }

   /* Define the intersection operators * and *= */
   inline BBox &operator *= (BBox const &rhs)
     { lb.max(rhs.lb); ub.min(rhs.ub); return(*this); }
   inline BBox operator * (BBox const &rhs) const
     { BBox both(*this); both.lb.max(rhs.lb); both.ub.min(rhs.ub); 
       return(both); }

   /* Define the comparison operators == and != */ 
   inline int operator == (BBox const &rhs) const
     { return(((ub == rhs.ub) && (lb == rhs.lb)) || 
	      (empty() && rhs.empty())); }
   inline int operator != (BBox const &rhs) const 
     { return(!(*this == rhs)); } 

   /* Member functions inside() return whether a Coords 
      is inside the region */
   inline int inside(const int i) const
     { return ( (i >= lb(0)) && (i <= ub(0)) ); }

   inline int inside(const int i, const int j) const
     { return ( ((i >= lb(0)) && (i <= ub(0)))
	       && ((j >= lb(1)) && (j <= ub(1)))); }

   inline int inside(const int i, const int j, const int k) const
     { return ( ((i >= lb(0)) && (i <= ub(0)))
	       && ((j >= lb(1)) && (j <= ub(1)))
               && ((k >= lb(2)) && (k <= ub(2)))); }

   inline int inside(const int *c) const
     { return ( !((rank <= 0) ||
               ((rank > 0) && (c[0] < lb(0) || c[0] > ub(0))) ||
               ((rank > 1) && (c[1] < lb(1) || c[1] > ub(1))) ||     
	       ((rank > 2) && (c[2] < lb(2) || c[2] > ub(2)))
		)) ; }

   inline int inside(Coords const &c) const
     { return (BBox::inside(c())); }

   /* Member functions interior() return whether a 
      Coords is interior (not on the edge) to the region */
   inline int interior(const int i) const
     { return ( (i > lb(0)) && (i < ub(0)) ); }

   inline int interior(const int i, const int j) const
     { return ( ((i > lb(0)) && (i < ub(0)))
	       && ((j > lb(1)) && (j < ub(1)))); }

   inline int interior(const int i, const int j, const int k) const
     { return ( ((i > lb(0)) && (i < ub(0)))
	       && ((j > lb(1)) && (j < ub(1)))
               && ((k > lb(2)) && (k < ub(2)))); }

   inline int interior(const int *c) const
     { return ( !((rank <= 0) ||
               ((rank > 0) && (c[0] <= lb(0) || c[0] >= ub(0))) ||
               ((rank > 1) && (c[1] <= lb(1) || c[1] >= ub(1))) ||     
	       ((rank > 2) && (c[2] <= lb(2) || c[2] >= ub(2)))
		)) ; }
   inline int interior(Coords const &c) const
     { return (BBox::interior(c())); }

   /* Get linear index for a point */
   /*$inline int index(const int i) const 
     { return (i/step(0)); }
   inline int index(const int i, const int j) const 
     { return(i/step(0)+((ub(0)-lb(0)+step(0))/step(0))*(j/step(1))); }
   inline int index(const int i, const int j, const int k) const
     { return(i/step(0)+((ub(0)-lb(0)+step(0))/step(0))*
	      (j/step(1)+((ub(1)-lb(1)+step(1))/step(1))*k/step(2))); }$*/

   /* BBox comparision operators */
   inline int operator > (BBox const &rhs) const 
     { return( inside(rhs.upper()) && inside(rhs.lower()) ); } 
   inline int operator >= (BBox const &rhs) const 
     { return( (*this == rhs) || 
               (inside(rhs.upper()) && inside(rhs.lower())) ); } 

   inline int operator < (BBox const &rhs) const 
     { return( rhs.inside(ub) && rhs.inside(lb) ); } 
   inline int operator <= (BBox const &rhs) const 
     { return( (rhs == *this) || 
   	       (rhs.inside(ub) && rhs.inside(lb)) ); } 

   /* Member function accrete() (also grow()) which grows a region */
   inline void accrete(const int i)
     { if (!empty()) { lb -= step*i; ub += step*i; } }
   inline void grow(const int i)
     { if (!empty()) { lb -= step*i; ub += step*i; } }

   inline void accrete(Coords const &c)
     { if (!empty()) { lb -= c*step; ub += c*step; } }
   inline void grow(Coords const &c)
     { if (!empty()) { lb -= c*step; ub += c*step; } }

   inline void growbydim(const short* c)
     {
      if (empty()) return;
      if (rank > 0) { lb(0) -= (step(0)*c[0]); ub(0) += (step(0)*c[1]); }
      if (rank > 1) { lb(1) -= (step(1)*c[2]); ub(1) += (step(1)*c[3]); }
      if (rank > 2) { lb(2) -= (step(2)*c[4]); ub(2) += (step(2)*c[5]); }
     }

   inline void shrinkbydim(const short* c)
     {
      if (empty()) return;
      if (rank > 0) { lb(0) += (step(0)*c[0]); ub(0) -= (step(0)*c[1]); }
      if (rank > 1) { lb(1) += (step(1)*c[2]); ub(1) -= (step(1)*c[3]); }
      if (rank > 2) { lb(2) += (step(2)*c[4]); ub(2) -= (step(2)*c[5]); }
     }

   inline void growupper(const int i)
     { if (!empty()) { ub += step*i; } }
   inline void growlower(const int i)
     { if (!empty()) { lb += step*i; } }

   inline void growupper(Coords const &c)
     { if (!empty()) { ub += step*c; } }
   inline void growlower(Coords const &c)
     { if (!empty()) { lb += step*c; } }

   inline void growupper(const int d, const int i)
     { if (!empty()) { ub(d) += i*step(d); } }
   inline void growlower(const int d, const int i)
     { if (!empty()) { lb(d) += i*step(d); } }

   inline void growupperbydim(const short* c)
     {
      if (empty()) return;
      if (rank > 0) { ub(0) += (step(0)*c[0]); }
      if (rank > 1) { ub(1) += (step(1)*c[1]); }
      if (rank > 2) { ub(2) += (step(2)*c[2]); }
     }
   inline void growlowerbydim(const short* c)
     {
      if (empty()) return;
      if (rank > 0) { lb(0) += (step(0)*c[0]); }
      if (rank > 1) { lb(1) += (step(1)*c[1]); }
      if (rank > 2) { lb(2) += (step(2)*c[2]); }
     }

   inline void shrinkupperbydim(const short* c)
     {
      if (empty()) return;
      if (rank > 0) { lb(0) -= (step(0)*c[0]); }
      if (rank > 1) { lb(1) -= (step(1)*c[1]); }
      if (rank > 2) { lb(2) -= (step(2)*c[2]); }
     }
   inline void shrinklowerbydim(const short* c)
     {
      if (empty()) return;
      if (rank > 0) { lb(0) -= (step(0)*c[0]); }
      if (rank > 1) { lb(1) -= (step(1)*c[1]); }
      if (rank > 2) { lb(2) -= (step(2)*c[2]); }
     }

   inline void shift(const int c)
     { if (!empty()) { lb+=step*c ; ub+=step*c; } }
   inline void shift(Coords const &c)
     { if (!empty()) { lb+=step*c ; ub+=step*c; } }
   inline void shift(const int d, const int c)
     { if (!empty()) { lb(d)+=step(d)*c ; ub(d)+=step(d)*c; } }
    
   /* Coarsen a bbox */
   inline void coarsen(const int by)
     { if (!empty()) 
         { step *= by; lb = (lb/step)*step; ub = (ub/step)*step; } }
   inline void coarsen(Coords const &by)
     { if (!empty()) 
         { step *= by; lb = (lb/step)*step; ub = (ub/step)*step; } }
   inline void coarsen(const int d, const int by)
     { if (!empty()) { 
         step(d) *= by;
         lb(d) = (lb(d)/step(d))*step(d);
         ub(d) = (ub(d)/step(d))*step(d); } }
  };

#ifdef __ENABLE_INLINE__
#include "BBox.inline"
#endif

  inline Coords &upper(BBox &bb)
	{ return (bb.upper()); }
  inline int upper(BBox &bb, const int i)
	{ return (bb.upper(i)); }

  inline Coords &lower(BBox &bb)
	{ return (bb.lower()); }
  inline int lower(BBox &bb, const int i)
	{ return (bb.lower(i)); }

  inline Coords &stepsize(BBox &bb)
	{ return (bb.stepsize()); }
  inline int stepsize(BBox &bb, const int i)
	{ return (bb.stepsize(i)); }

  inline Coords extents(BBox &bb)
	{ return (bb.extents()); }
  inline int extents(BBox &bb, const int i)
	{ return (bb.extents(i)); }

  inline int size(BBox &bb)
	{ return (bb.size()); }
  inline int inside(BBox &bb, Coords const &c)
	{ return (bb.inside(c)); }

istream& operator >> (istream& s, BBox & bb);
ostream& operator << (ostream& s, const BBox &bb);
ifstream& operator >> (ifstream& s, BBox& bb);
ofstream& operator << (ofstream& s, const BBox& bb);

/* Function accrete() increases or decreases the size of the region */
inline BBox accrete(BBox const &bbox, Coords const &c)
  { const Coords& u = bbox.upper(); const Coords& l = bbox.lower(); 
    const Coords& s = bbox.stepsize();
    return ( (bbox.empty()) ? bbox : BBox(l-c*s, u+c*s, s) ); }
inline BBox grow(BBox const &bbox, Coords const &c)
  { const Coords& u = bbox.upper(); const Coords& l = bbox.lower(); 
    const Coords& s = bbox.stepsize();
    return ( (bbox.empty()) ? bbox : BBox(l-c*s, u+c*s, s) ); }

inline BBox accrete(BBox const &bbox, const int c)
  { const Coords& u = bbox.upper(); const Coords& l = bbox.lower(); 
    const Coords& s = bbox.stepsize();
    return ( (bbox.empty()) ? bbox : BBox(l-s*c, u+s*c, s) ); }
inline BBox grow(BBox const &bbox, const int c)
  { const Coords& u = bbox.upper(); const Coords& l = bbox.lower(); 
    const Coords& s = bbox.stepsize();
    return ( (bbox.empty()) ? bbox : BBox(l-s*c, u+s*c, s) ); }

BBox* accrete(BBox const *const bbox, const int n, const int c);
BBox* grow(BBox const *const bbox, const int n, const int c);

BBox* accrete(BBox const *const bbox, const int n, Coords const &c);
BBox* grow(BBox const *const bbox, const int n, Coords const &c);

inline BBox growupper(BBox const &bbox, const int c)
  { const Coords& u = bbox.upper(); const Coords& l = bbox.lower(); 
    const Coords& s = bbox.stepsize();
    return ( (bbox.empty()) ? bbox : BBox(l, u+s*c, s) ); }
inline BBox growlower(BBox const &bbox, const int c)
  { const Coords& u = bbox.upper(); const Coords& l = bbox.lower(); 
    const Coords& s = bbox.stepsize();
    return ( (bbox.empty()) ? bbox : BBox(l+s*c, u, s) ); }

inline BBox growupper(BBox const &bbox, const int d, const int c)
  {
   if (bbox.empty()) return(bbox);
   const Coords& l = bbox.lower(); const Coords& s = bbox.stepsize();
   Coords u = bbox.upper(); u(d) += c*s(d);
   return(BBox(l, u, s));
  }
inline BBox growlower(BBox const &bbox, const int d, const int c)
  {
   if (bbox.empty()) return(bbox);
   const Coords& u = bbox.upper(); const Coords& s = bbox.stepsize();
   Coords l = bbox.lower(); l(d) += c*s(d);
   return(BBox(l, u, s));
  }

inline BBox growbydim(BBox const &bbox, const short* c)      /* short c[2*rank] */
  {
   BBox bb(bbox);
   if (bb.empty()) return(bb);
   if (bb.rank > 0)
     {bb.lower(0) -= (bb.stepsize(0)*c[0]);bb.upper(0) += (bb.stepsize(0)*c[1]);}
   if (bb.rank > 1)
     {bb.lower(1) -= (bb.stepsize(1)*c[2]);bb.upper(1) += (bb.stepsize(1)*c[3]);}
   if (bb.rank > 2)
     {bb.lower(2) -= (bb.stepsize(2)*c[4]);bb.upper(2) += (bb.stepsize(2)*c[5]);}
   return bb;
  }
inline BBox growupperbydim(BBox const &bbox, const short* c) /* short c[rank] */
  {
   BBox bb(bbox);
   if (bb.empty()) return(bb);
   if (bb.rank > 0)
     {bb.upper(0) += (bb.stepsize(0)*c[0]);}
   if (bb.rank > 1)
     {bb.upper(1) += (bb.stepsize(1)*c[1]);}
   if (bb.rank > 2)
     {bb.upper(2) += (bb.stepsize(2)*c[2]);}
   return bb;
  }
inline BBox growlowerbydim(BBox const &bbox, const short* c) /* short c[rank] */
  {
   BBox bb(bbox);
   if (bb.empty()) return(bb);
   if (bb.rank > 0)
     {bb.lower(0) += (bb.stepsize(0)*c[0]);}
   if (bb.rank > 1)
     {bb.lower(1) += (bb.stepsize(1)*c[1]);}
   if (bb.rank > 2)
     {bb.lower(2) += (bb.stepsize(2)*c[2]);}
   return bb;
  }

inline BBox shrinkbydim(BBox const &bbox, const short* c)    /* short c[2*rank] */
  {
   BBox bb(bbox);
   if (bb.empty()) return(bb);
   if (bb.rank > 0)
     {bb.lower(0) += (bb.stepsize(0)*c[0]);bb.upper(0) -= (bb.stepsize(0)*c[1]);}
   if (bb.rank > 1)
     {bb.lower(1) += (bb.stepsize(1)*c[2]);bb.upper(1) -= (bb.stepsize(1)*c[3]);}
   if (bb.rank > 2)
     {bb.lower(2) += (bb.stepsize(2)*c[4]);bb.upper(2) -= (bb.stepsize(2)*c[5]);}
   return bb;
  }
inline BBox shrinkupperbydim(BBox const &bbox, const short* c) /* short c[rank] */
  {
   BBox bb(bbox);
   if (bb.empty()) return(bb);
   if (bb.rank > 0)
     {bb.upper(0) -= (bb.stepsize(0)*c[0]);}
   if (bb.rank > 1)
     {bb.upper(1) -= (bb.stepsize(1)*c[1]);}
   if (bb.rank > 2)
     {bb.upper(2) -= (bb.stepsize(2)*c[2]);}
   return bb;
  }
inline BBox shrinklowerbydim(BBox const &bbox, const short* c) /* short c[rank] */
  {
   BBox bb(bbox);
   if (bb.empty()) return(bb);
   if (bb.rank > 0)
     {bb.lower(0) -= (bb.stepsize(0)*c[0]);}
   if (bb.rank > 1)
     {bb.lower(1) -= (bb.stepsize(1)*c[1]);}
   if (bb.rank > 2)
     {bb.lower(2) -= (bb.stepsize(2)*c[2]);}
   return bb;
  }

/* Function shift() shifts the  space of the region */
inline BBox shiftabs(BBox const &bb, const int c)
  { return(BBox(bb.lower()+c, bb.upper()+c, bb.stepsize())); }
inline BBox shiftabs(BBox const &bb, Coords const &c)
  { return(BBox(bb.lower()+c, bb.upper()+c, bb.stepsize())); }

inline BBox shift(BBox const &bb, const int c)
  { return(BBox(bb.lower()+bb.stepsize()*c, 
                bb.upper()+bb.stepsize()*c,bb.stepsize())); }
inline BBox shift(BBox const &bb, Coords const &c)
  { return(BBox(bb.lower()+c*bb.stepsize(), 
                bb.upper()+c*bb.stepsize(),bb.stepsize())); }

inline BBox shiftabs(BBox const &bbox, const int d, const int c)
  {
   if (bbox.empty()) return(bbox);
   Coords u = bbox.upper(); u(d) += c;
   Coords l = bbox.lower(); l(d) += c;
   return(BBox(l, u, bbox.stepsize()));
  }
inline BBox shift(BBox const &bbox, const int d, const int c)
  {
   if (bbox.empty()) return(bbox);
   Coords u = bbox.upper(); u(d) += c*bbox.stepsize(d);
   Coords l = bbox.lower(); l(d) += c*bbox.stepsize(d);
   return(BBox(l, u, bbox.stepsize()));
  }

/* Function coarsen() coarsens  the BBox by a given factor */
inline BBox coarsen(BBox const &bbox, const int by)
  { Coords s = bbox.stepsize() * by;
    const Coords& u = bbox.upper(); const Coords& l = bbox.lower();
    return ((bbox.empty()) ? bbox : BBox((l/s)*s,(u/s)*s,s)); }
inline BBox coarsen(BBox const &bbox, Coords const by)
  { Coords s = bbox.stepsize() * by;
    const Coords& u = bbox.upper(); const Coords& l = bbox.lower();
    return ((bbox.empty()) ? bbox : BBox((l/s)*s,(u/s)*s,s)); }
inline BBox coarsen(BBox const &bbox, const int d, const int by)
  { Coords s = bbox.stepsize(); s(d) *= by;
    const Coords& u = bbox.upper(); const Coords& l = bbox.lower();
    return ((bbox.empty()) ? bbox : BBox((l/s)*s,(u/s)*s,s)); }

#include "CoordsIterator.h"
#endif
