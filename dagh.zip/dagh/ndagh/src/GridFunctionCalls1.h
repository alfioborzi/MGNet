#ifndef _included_GridFunctionCalls1_h
#define _included_GridFunctionCalls1_h

/*
*************************************************************************
*                                                                       *
* GridFunctionCalls1.h                                                  *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/*********************************************************************/
/*** set/get times ***/
/*********************************************************************/
template <class Type>
inline void CurrentTime(GridFunction(1)<Type>& GF, const int l,
                        const int ident)
   { GF.GF_CurrentTime(l, ident); }

template <class Type>
inline void IncrCurrentTime(GridFunction(1)<Type>& GF, const int l,
                            const int ident)
   { GF.GF_IncrCurrentTime(l, ident); }

template <class Type>
inline void SetCurrentTime(GridFunction(1)<Type>& GF, 
                           const int t, const int l,
                           const int ident)
   { GF.GF_SetCurrentTime(t, l, ident); }

template <class Type>
inline void PreviousTime(GridFunction(1)<Type>& GF, const int l,
                        const int ident)
   { GF.GF_PreviousTime(l, ident); }

template <class Type>
inline void NextTime(GridFunction(1)<Type>& GF, const int l,
                     const int ident)
   { GF.GF_NextTime(l, ident); }
/*********************************************************************/

/*********************************************************************/
/*** Set predefined functions ***/
/*********************************************************************/
template <class Type>
inline void SetInitFunction(GridFunction(1)<Type>& GF, void* initf)
   { GF.GF_SetInitFunc(initf); }

template <class Type>
inline void SetUpdateFunction(GridFunction(1)<Type>& GF, void* uf)
   { GF.GF_SetUpdateFunc(uf); }

template <class Type>
inline void SetBndryUpdateFunction(GridFunction(1)<Type>& GF, void* buf)
   { GF.GF_SetBndryUpdateFunc(buf); }

template <class Type>
inline void SetAdaptiveBndryUpdateFunction(GridFunction(1)<Type>& GF, 
					   void* abuf)
   { GF.GF_SetAdaptiveBndryUpdateFunc(abuf); }

template <class Type>
inline void SetProlongFunction(GridFunction(1)<Type>& GF, void* pf)
   { GF.GF_SetProlongFunc(pf); }

template <class Type>
inline void SetRestrictFunction(GridFunction(1)<Type>& GF, void* rf)
   { GF.GF_SetRestrictFunc(rf); }

template <class Type>
inline void SetIOFunction(GridFunction(1)<Type>& GF, void* iof)
   { GF.GF_SetIOFunc(iof); }
/*********************************************************************/

/*********************************************************************/
/*** Set boundary value ***/
/*********************************************************************/
template <class Type>
inline void SetBoundaryValue(GridFunction(1)<Type>& GF, const Type v)
   { GF.GF_SetBoundaryValue(v); }
/*********************************************************************/

/*********************************************************************/
/*** Cycle Times ***/
/*********************************************************************/
template <class Type>
inline void SwapTimeLevels(GridFunction(1)<Type> &GF,
                           const int l, const int t1, const int t2)
   { GF.GF_SwapTimeLevels(l, t1, t2); }

template <class Type>
inline void CycleTimeLevels(GridFunction(1)<Type> &GF, const int l)
   { GF.GF_CycleTimeLevels(l); }
/*********************************************************************/

/*********************************************************************/
/*** Sync Ghost Regions ***/
/*********************************************************************/
template <class Type>
inline void Sync(GridFunction(1)<Type> &GF, const int t, const int l,
                 const int ident)
   { GF.GF_Sync(t,l,ident); }

template <class Type>
inline void Sync(GridFunction(1)<Type> &GF, const int t, const int l,
                 const int mgl,
                 const int ident)
   { GF.GF_Sync(t,l,mgl,ident); }

template <class Type>
inline void Sync(GridFunction(1)<Type> &GF, const int t, const int l,
                 const int axis, const int dir,
                 const int ident)
   { GF.GF_Sync(t,l,axis,dir,ident); }

template <class Type>
inline void Sync(GridFunction(1)<Type> &GF, const int t, const int l,
                 const int mgl,
                 const int axis, const int dir,
                 const int ident)
   { GF.GF_Sync(t,l,mgl,axis,dir,ident); }
/*********************************************************************/

/*********************************************************************/
/*** Fill ***/
/*********************************************************************/
template <class Type>
inline void Initialize(GridFunction(1)<Type> &GF, 
                       const int t, const int l, 
                       const Type& val,
                       const int ident)
    { GF.GF_Fill(val, t, l, ident); }
template <class Type>
inline void Initialize(GridFunction(1)<Type> &GF, 
                       const int t, const int l, 
                       const int mgl,
                       const Type& val,
                       const int ident)
    { GF.GF_Fill(val, t, l, mgl, ident); }
/*********************************************************************/

/*********************************************************************/
/*** Use predefined functions ***/
/*********************************************************************/
template <class Type>
inline void Initialize(GridFunction(1)<Type> &GF, 
                       const int t, const int l, 
                       Type *args, const int cnt,
                       const int ident)
    { GF.GF_Init(t, l, args, cnt, ident); }
template <class Type>
inline void Initialize(GridFunction(1)<Type> &GF, 
                       const int t, const int l, 
                       const BBox& bb,
                       Type *args, const int cnt,
                       const int ident)
    { GF.GF_Init(t, l, bb, args, cnt, ident); }

template <class Type>
inline void Update(GridFunction(1)<Type> &GF, 
                   const int tf, const int tt, const int l,
                   Type *args, const int cnt,
                   const int ident)
    { GF.GF_Update(tf, tt, l, args, cnt, ident); }
template <class Type>
inline void Update(GridFunction(1)<Type> &GF, 
                   const int tf, const int tt, const int l,
                   const BBox& bb,
                   Type *args, const int cnt,
                   const int ident)
    { GF.GF_Update(tf, tt, l, bb, args, cnt, ident); }

template <class Type>
inline void Prolong(GridFunction(1)<Type> &GF, 
                    const int tf, const int lf,
                    const int tt, const int lt,
                    Type *args, const int cnt,
                    const int ident)
    { GF.GF_Prolong(tf, lf, tt, lt, args, cnt, ident); }
template <class Type>
inline void Prolong(GridFunction(1)<Type> &GF, 
                    const int tf, const int lf,
                    const int tt, const int lt,
                    const BBox& bb,
                    Type *args, const int cnt,
                    const int ident)
    { GF.GF_Prolong(tf, lf, tt, lt, bb, args, cnt, ident); }

template <class Type>
inline void Restrict(GridFunction(1)<Type> &GF, 
                     const int tf, const int lf,
                     const int tt, const int lt,
                     Type *args, const int cnt,
                     const int ident)
    { GF.GF_Restrict(tf, lf, tt, lt, args, cnt, ident); }
template <class Type>
inline void Restrict(GridFunction(1)<Type> &GF, 
                     const int tf, const int lf,
                     const int tt, const int lt,
                     const BBox& bb,
                     Type *args, const int cnt,
                     const int ident)
    { GF.GF_Restrict(tf, lf, tt, lt, bb, args, cnt, ident); }

template <class Type>
inline void IO(GridFunction(1)<Type> &GF,
               const int t, const int l,
               Type *args, const int cnt,
               const int ident)
    { GF.GF_IO(t, l, args, cnt, ident); }
template <class Type>
inline void IO(GridFunction(1)<Type> &GF,
               const int t, const int l,
               const BBox& bb,
               Type *args, const int cnt,
               const int ident)
    { GF.GF_IO(t, l, bb, args, cnt, ident); }
/*********************************************************************/

/*********************************************************************/
/*** Update Boundaries ***/
/*********************************************************************/
template <class Type>
inline void BoundaryUpdate(GridFunction(1)<Type> &GF,
                           const int t, const int l,
                           const int ident)
    { GF.GF_BndryUpdate(t, l, ident); }
template <class Type>
inline void BoundaryUpdate(GridFunction(1)<Type> &GF,
                           const int t, const int l,
                           const int mgl,
                           const int ident)
    { GF.GF_BndryUpdate(t, l, mgl, ident); }
/*********************************************************************/

/*********************************************************************/
/*** Reduction Ops ***/
/*********************************************************************/
template <class Type>
inline Type MaxVal(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const int ident)
   { return (GF.GF_maxval(t, l, ident)); }
template <class Type>
inline Type MaxVal(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const BBox& where,
                   const int ident)
   { return (GF.GF_maxval(t, l, where, ident)); }
template <class Type>
inline Type MaxVal(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const int mgl,
                   const int ident)
   { return (GF.GF_maxval(t, l, mgl, ident)); }
template <class Type>
inline Type MaxVal(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const int mgl,
                   const BBox& where,
                   const int ident)
   { return (GF.GF_maxval(t, l, mgl, where, ident)); }

template <class Type>
inline Type MinVal(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const int ident)
   { return (GF.GF_minval(t, l, ident)); }
template <class Type>
inline Type MinVal(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const BBox& where,
                   const int ident)
   { return (GF.GF_minval(t, l, where, ident)); }
template <class Type>
inline Type MinVal(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const int mgl,
                   const int ident)
   { return (GF.GF_minval(t, l, mgl, ident)); }
template <class Type>
inline Type MinVal(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const int mgl,
                   const BBox& where,
                   const int ident)
   { return (GF.GF_minval(t, l, mgl, where, ident)); }

template <class Type>
inline Type Sum(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const int ident)
   { return (GF.GF_sum(t, l, ident)); }
template <class Type>
inline Type Sum(GridFunction(1)<Type>& GF,
                   const int t, const int l,
                   const BBox& where,
                   const int ident)
   { return (GF.GF_sum(t, l, where, ident)); }
template <class Type>
inline Type Sum(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const int mgl,
                   const int ident)
   { return (GF.GF_sum(t, l, mgl, ident)); }
template <class Type>
inline Type Sum(GridFunction(1)<Type>& GF,
                   const int t, const int l,
                   const int mgl,
                   const BBox& where,
                   const int ident)
   { return (GF.GF_sum(t, l, mgl, where, ident)); }

template <class Type>
inline Type Product(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const int ident)
   { return (GF.GF_product(t, l, ident)); }
template <class Type>
inline Type Product(GridFunction(1)<Type>& GF,
                   const int t, const int l,
                   const BBox& where,
                   const int ident)
   { return (GF.GF_product(t, l, where, ident)); }
template <class Type>
inline Type Product(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const int mgl,
                   const int ident)
   { return (GF.GF_product(t, l, mgl, ident)); }
template <class Type>
inline Type Product(GridFunction(1)<Type>& GF,
                   const int t, const int l,
                   const int mgl,
                   const BBox& where,
                   const int ident)
   { return (GF.GF_product(t, l, mgl, where, ident)); }

template <class Type>
inline Type Norm2(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const int ident)
   { return (GF.GF_norm2(t, l, ident)); }
template <class Type>
inline Type Norm2(GridFunction(1)<Type>& GF,
                   const int t, const int l,
                   const BBox& where,
                   const int ident)
   { return (GF.GF_norm2(t, l, where, ident)); }
template <class Type>
inline Type Norm2(GridFunction(1)<Type>& GF, 
                   const int t, const int l,
                   const int mgl,
                   const int ident)
   { return (GF.GF_norm2(t, l, mgl, ident)); }
template <class Type>
inline Type Norm2(GridFunction(1)<Type>& GF,
                   const int t, const int l,
                   const int mgl,
                   const BBox& where,
                   const int ident)
   { return (GF.GF_norm2(t, l, mgl, where, ident)); }
/*********************************************************************/

/*********************************************************************/
/**** Shadow Hierarchy Methods ****/
/*********************************************************************/
template <class Type>
inline void SetupShadow(GridFunction(1)<Type>& GF, const int t, const int l)
   { GF.GF_SetupShadow(t,l); }

template <class Type>
inline void ReleaseShadow(GridFunction(1)<Type>& GF, const int t, const int l)
   	{ GF.GF_ReleaseShadow(t,l); }
/*********************************************************************/

/*********************************************************************/
/**** Multigrid Methods ****/
/*********************************************************************/
template <class Type>
inline void SetupMultiGrid(GridFunction(1)<Type>& GF, 
                           const int t, const int l, 
                           const int mglc, const int mglf,
                           const int ident)
   { GF.GF_SetupMultiGrid(t, l, mglc, mglf, ident); }
template <class Type>
inline void SetupMultiGrid(GridFunction(1)<Type>& GF, 
                           const int t, const int l, 
                           const int axis,
                           const int mglc, const int mglf,
                           const int ident)
   { GF.GF_SetupMultiGrid(t, l, axis, mglc, mglf, ident); }

template <class Type>
inline void ReleaseMultiGrid(GridFunction(1)<Type>& GF, 
                             const int t, const int l, 
                             const int ident)
   { GF.GF_ReleaseMultiGrid(t, l, ident); }
/*********************************************************************/

/*********************************************************************/
/* Distributed Operators (MAIN Only) */
/*********************************************************************/
template <class Type>
inline void Copy(GridFunction(1)<Type>& gff, const int tf, const int lf,
                 BBox const &from, 
                 GridFunction(1)<Type>& gft, const int tt, const int lt,
                 BBox const &to,
                 const int ident)
   { gft.GF_Copy(tt,lt,gff,tf,lf,to,from); }
/*********************************************************************/

/*********************************************************************/
/* IO Support */
/*********************************************************************/
template <class Type>
inline void Write(GridFunction(1)<Type> &GF,
                  int const t, int const l,
                  int const gfdtype)
  { GF.GF_Write(t,l,gfdtype); }
template <class Type>
inline void Write(GridFunction(1)<Type> &GF,
                  int const t, int const l,
                  int const mgl,
                  int const gfdtype)
  { GF.GF_Write(t,l,mgl,gfdtype); }
template <class Type>
inline void Write(GridFunction(1)<Type> &GF,
                  int const t, int const l,
                  int const mgl, int const ident,
                  int const gfdtype)
  { GF.GF_Write(t,l,mgl,ident,gfdtype); }

template <class Type>
inline void Write(GridFunction(1)<Type> &GF,
                  int const t, int const l,
                  BBox const &where,
                  int const gfdtype)
  { GF.GF_Write(t,l,where,gfdtype); }
template <class Type>
inline void Write(GridFunction(1)<Type> &GF,
                  int const t, int const l,
                  int const mgl,
                  BBox const &where,
                  int const gfdtype)
  { GF.GF_Write(t,l,mgl,where,gfdtype); }
template <class Type>
inline void Write(GridFunction(1)<Type> &GF,
                  int const t, int const l,
                  int const mgl, int const ident,
                  BBox const &where,
                  int const gfdtype)
  { GF.GF_Write(t,l,mgl,ident,where,gfdtype); }

template <class Type>
inline void Read(GridFunction(1)<Type> &GF,
                 int const t, int const l,
                 int const gfdtype)
  { GF.GF_Read(t,l,gfdtype); }
template <class Type>
inline void Read(GridFunction(1)<Type> &GF,
                 int const t, int const l,
                 int const mgl,
                 int const gfdtype)
  { GF.GF_Read(t,l,mgl,gfdtype); }
template <class Type>
inline void Read(GridFunction(1)<Type> &GF,
                 int const t, int const l,
                 int const mgl, int const ident,
                 int const gfdtype)
  { GF.GF_Read(t,l,mgl,ident,gfdtype); }

template <class Type>
inline void Read(GridFunction(1)<Type> &GF,
                 int const t, int const l,
                 BBox const &where,
                 int const gfdtype)
  { GF.GF_Read(t,l,where,gfdtype); }
template <class Type>
inline void Read(GridFunction(1)<Type> &GF,
                 int const t, int const l,
                 int const mgl,
                 BBox const &where,
                 int const gfdtype)
  { GF.GF_Read(t,l,mgl,where,gfdtype); }
template <class Type>
inline void Read(GridFunction(1)<Type> &GF,
                 int const t, int const l,
                 int const mgl, int const ident,
                 BBox const &where,
                 int const gfdtype)
  { GF.GF_Read(t,l,mgl,ident,where,gfdtype); }
/*********************************************************************/

/*********************************************************************/
/* Generate UCD Data */
/*********************************************************************/
template <class Type>
inline void GetUCDData(GridFunction(1)<Type> &GF,
			  const DAGHUCD(1)& daghucd, 
			  const int t,
			  Type*& ucddata,
			  const int ucdserver)
{ GF.GF_GetUCDData(daghucd,t,ucddata,ucdserver); }
/*********************************************************************/

/*********************************************************************/
/* Viz Support */
/*********************************************************************/
template <class Type>
inline void View(GridFunction(1)<Type> &GF,
                 int const t, int const l,
                 int const axis,
                 BBox const &where,
                 int const pserver,
                 int const type,
                 char const *xg,
                 char const *dserver,
                 int const ident)
  { GF.GF_View(t,l,axis,where,pserver,type,xg,dserver,ident); }
/*********************************************************************/

#endif
