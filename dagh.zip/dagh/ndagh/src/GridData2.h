#ifndef _included_GridData_2_h
#define _included_GridData_2_h

/*
*************************************************************************
*                                                                       *
* GridData(2).h                                                         *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"

#include "GridDataParams.h"

#ifdef DEBUG_PRINT_GD_MEMORY
#include "DAGHMemoryTrace.h"
#endif

#include "BBox.h"
#include "Coords.h"
#include "PackedGridDataBucket.h"

#ifdef DEBUG_PRINT
#include "CommServer.h"
#endif

#include "IndexGridData2.h"

#ifndef GridData
#define GridData(dim)           name2(GridData,dim)
#endif

#ifndef gd_OperateRegion
#define gd_OperateRegion(op)    name2(gd_OperateRegion,op)
#endif

#include "GDIterator.h"

template <class Type> class GridData(2)
  {
   friend ostream& operator<<(ostream&, const GridData(2)<Type>&);
   friend ofstream& operator<<(ofstream&, const GridData(2)<Type>&);
   friend ifstream& operator>>(ifstream&, GridData(2)<Type>&);

   BBox _bbox;
   Coords _extents;
   Coords _step;
   int _size;
   int _bottom;
   Type *_data;

private:

public:
   GridData(2)(void);
   GridData(2)(BBox const &bbox);
   GridData(2)(int const i, int const j,
               int const ii, int const jj);
   GridData(2)(int const i, int const j,
               int const ii, int const jj, int const s);
   GridData(2)(int const i, int const j,
               int const ii, int const jj, 
               int const s, int const ss);
   GridData(2)(BBox const &bbox, Type *databuf);
   GridData(2)(GridDataBucket<Type> &gdbkt);
   GridData(2)(GridDataBucket<Type> &gdbkt, int const n);
   /* A "psuedo" copy-constructor */
   GridData(2) (GridData(2)<Type> const &other);

   inline ~GridData(2)(void)
        { 
#ifdef DEBUG_PRINT_GD_MEMORY
         DAGHMemoryTrace::free(sizeof(Type)*_size);
#endif
         if (_data) delete [] _data; 
        }

   void allocate(BBox const &bbox);
   void allocate(BBox const &bbox, Type *databuf);

   inline void allocate(Type *databuf)
        {
         if (_data) {
           delete [] _data; _data = (Type*)0;
#ifdef DEBUG_PRINT_GD_MEMORY
         DAGHMemoryTrace::free(sizeof(Type)*_size);
#endif
         }
         _data = databuf;
        }

   inline void deallocate()
        {
#ifdef DEBUG_PRINT_GD_MEMORY
         DAGHMemoryTrace::free(sizeof(Type)*_size);
#endif
         if (_data) delete [] _data; _data = (Type*)0;
        }
   inline void deallocate(Type*& databuf)
        { databuf = _data; _data = (Type*) 0; }
  
   void* databuffer() { return ((void*) _data); }

   /* Query funtions */
   /* Define some inline functions for getting at region extents */

   inline const Coords& lower() const { return(_bbox.lower()); }
   inline const Coords& upper() const { return(_bbox.upper()); }
   inline const Coords& extents() const { return(_extents); }
   inline const Coords& stepsize() const { return(_step); }
   inline Coords lower() { return(_bbox.lower()); }
   inline Coords upper() { return(_bbox.upper()); }
   inline Coords extents() { return(_extents); }
   inline Coords stepsize() { return(_step); }
   inline int bottom() const { return(_bottom); }
   inline int lower(const int i) const { return(_bbox.lower(i)); }
   inline int upper(const int i) const { return(_bbox.upper(i)); }
   inline int extents(const int i) const { return(_extents(i)); }
   inline int stepsize(int const i) const { return(_step(i)); }
   inline const BBox& bbox() const { return(_bbox); }

   inline int ok_to_index() { return(_data != (Type *) NULL); }
   inline int size() const { return(_size); }

   inline int idx(const int i, const int j) const
   { return( _bottom+(i/_step(0)+_extents(0)*(j/_step(1))) ); }

   inline const Type& operator () (const int i, const int j) const
   { assert(idx(i,j) >= 0 && idx(i,j) < _size); return(_data[idx(i,j)]); }
   inline Type& operator () (const int i,  const int j)
   { assert(idx(i,j) >= 0 && idx(i,j) < _size); return(_data[idx(i,j)]); }

   inline const Type& operator () (const Coords& c) const
   { assert(idx(c(0),c(1)) >= 0 && idx(c(0),c(1)) < _size); return(_data[idx(c(0),c(1))]); }
   inline Type& operator () (const Coords& c)
   { assert(idx(c(0),c(1)) >= 0 && idx(c(0),c(1)) < _size); return(_data[idx(c(0),c(1))]); }

   inline const Type *ptr(const int i,  const int j) const
   { assert(idx(i,j) >= 0 && idx(i,j) < _size); return(_data + idx(i,j)); }
   inline Type *ptr(const int i,  const int j)
   { assert(idx(i,j) >= 0 && idx(i,j) < _size); return(_data + idx(i,j)); }

   inline const Type *ptr(const Coords& c) const
   { assert(idx(c(0),c(1)) >= 0 && idx(c(0),c(1)) < _size); return(_data + idx(c(0),c(1))); }
   inline Type *ptr(const Coords& c)
   { assert(idx(c(0),c(1)) >= 0 && idx(c(0),c(1)) < _size); return(_data + idx(c(0),c(1))); }

   inline const Type *data() const { return(_data); }
   inline Type *data() { return(_data); }

   void fill(Type const &val);

   /* Define the copy functions for communication between objects */
   void copy(GridData(2)<Type> const &gd);
   void copy(GridData(2)<Type> const &gd, BBox const &where);
   void copy(GridData(2)<Type> const &gd, BBox const &to, BBox const &from);

   void copy(GridDataBucket<Type> const &gdbkt);
   void copy(GridDataBucket<Type> const &gdbkt, BBox const &where);
   void copy(GridDataBucket<Type> const &gdbkt, BBox const &to, 
						BBox const &from);

   void copy(GridDataBucket<Type> const &gdbkt, int const n);
   void copy(GridDataBucket<Type> const &gdbkt, int const n, BBox const &where);
   void copy(GridDataBucket<Type> const &gdbkt, int const n, BBox const &to, 
							     BBox const &from);

   /* Linear interpolation */
   void lin_interp(GridData(2)<Type> const &gd1, double const frac1,
		   GridData(2)<Type> const &gd2, double const frac2,
	           BBox const &where);
   inline void lin_interp(GridData(2)<Type> const &gd1, double const frac1,
		          GridData(2)<Type> const &gd2, double const frac2)
   	{ GridData(2)<Type>::lin_interp(gd1,frac1,gd2,frac2,_bbox); }

  /* first moment (i think) sum(q(i,j)*i) */
  Type moment1(int const axis, BBox const &where);
  inline Type moment1(int const axis)
        { return (GridData(2)<Type>::moment1(axis,_bbox)); }

  /* sum of squares - for calculating a norm */
  void sumsqrd(BBox const &where, Type &s, int &c);
  inline void sumsqrd(Type &s, int &c)
        { GridData(2)<Type>::sumsqrd(_bbox,s,c); }

   /* operator == */
   BBox is_eq(Type const &val, BBox const &where);
   inline BBox is_eq(Type const &val) 
	{ return (GridData(2)<Type>::is_eq(val, _bbox)); }

   BBox is_eq(GridData(2)<Type> const &gd, BBox const &to, BBox const &from);
   inline BBox is_eq(GridData(2)<Type> const &gd)
	{ return (GridData(2)<Type>::is_eq(gd, gd._bbox, gd._bbox)); }
   inline BBox is_eq(GridData(2)<Type> const &gd, BBox const &where)
	{ return (GridData(2)<Type>::is_eq(gd, where, where)); }

   /* operator != */
   BBox is_neq(Type const &val, BBox const &where);
   inline BBox is_neq(Type const &val) 
	{ return (GridData(2)<Type>::is_neq(val, _bbox)); }

   BBox is_neq(GridData(2)<Type> const &gd, BBox const &to, BBox const &from);
   inline BBox is_neq(GridData(2)<Type> const &gd)
	{ return (GridData(2)<Type>::is_neq(gd, gd._bbox, gd._bbox)); }
   inline BBox is_neq(GridData(2)<Type> const &gd, BBox const &where)
	{ return (GridData(2)<Type>::is_neq(gd, where, where)); }

   /* operator > */
    BBox is_gt(Type const &val, BBox const &where);
   inline BBox is_gt(Type const &val) 
	{ return (GridData(2)<Type>::is_gt(val, _bbox)); }

   BBox is_gt(GridData(2)<Type> const &gd, BBox const &to, BBox const &from);
   inline BBox is_gt(GridData(2)<Type> const &gd)
	{ return (GridData(2)<Type>::is_gt(gd, gd._bbox, gd._bbox)); }
   inline BBox is_gt(GridData(2)<Type> const &gd, BBox const &where)
	{ return (GridData(2)<Type>::is_gt(gd, where, where)); }

   /* operator >= */
    BBox is_ge(Type const &val, BBox const &where);
   inline BBox is_ge(Type const &val) 
	{ return (GridData(2)<Type>::is_ge(val, _bbox)); }

   BBox is_ge(GridData(2)<Type> const &gd, BBox const &to, BBox const &from);
   inline BBox is_ge(GridData(2)<Type> const &gd)
	{ return (GridData(2)<Type>::is_ge(gd, gd._bbox, gd._bbox)); }
   inline BBox is_ge(GridData(2)<Type> const &gd, BBox const &where)
	{ return (GridData(2)<Type>::is_ge(gd, where, where)); }

   /* operator < */
    BBox is_lt(Type const &val, BBox const &where);
   inline BBox is_lt(Type const &val) 
	{ return (GridData(2)<Type>::is_lt(val, _bbox)); }

   BBox is_lt(GridData(2)<Type> const &gd, BBox const &to, BBox const &from);
   inline BBox is_lt(GridData(2)<Type> const &gd)
	{ return (GridData(2)<Type>::is_lt(gd, gd._bbox, gd._bbox)); }
   inline BBox is_lt(GridData(2)<Type> const &gd, BBox const &where)
	{ return (GridData(2)<Type>::is_lt(gd, where, where)); }

   /* operator <= */
    BBox is_le(Type const &val, BBox const &where);
   inline BBox is_le(Type const &val) 
	{ return (GridData(2)<Type>::is_le(val, _bbox)); }

   BBox is_le(GridData(2)<Type> const &gd, BBox const &to, BBox const &from);
   inline BBox is_le(GridData(2)<Type> const &gd)
	{ return (GridData(2)<Type>::is_le(gd, gd._bbox, gd._bbox)); }
   inline BBox is_le(GridData(2)<Type> const &gd, BBox const &where)
	{ return (GridData(2)<Type>::is_le(gd, where, where)); }

   /* operator = */
   void equals(Type const &val, BBox const &where);
   inline void equals(Type const &val) 
	{ GridData(2)<Type>::equals(val, _bbox); }

   void equals(GridData(2)<Type> const &gd, BBox const &to, BBox const &from);
   inline void equals(GridData(2)<Type> const &gd)
	{ GridData(2)<Type>::equals(gd, gd._bbox, gd._bbox); }
   inline void equals(GridData(2)<Type> const &gd, BBox const &where)
	{ GridData(2)<Type>::equals(gd, where, where); }

   /* operator += */
   void plus (Type const &val, BBox const &where);
   inline void plus (Type const &val) 
	{ GridData(2)<Type>::plus(val, _bbox); }

   void plus (GridData(2)<Type> const &gd, BBox const &to, BBox const &from);
   inline void plus (GridData(2)<Type> const &gd)
	{ GridData(2)<Type>::plus(gd, gd._bbox, gd._bbox); }
   inline void plus (GridData(2)<Type> const &gd, BBox const &where)
	{ GridData(2)<Type>::plus(gd, where, where); }

   /* operator -= */
   void minus (Type const &val, BBox const &where);
   inline void minus (Type const &val) 
	{ GridData(2)<Type>::minus(val, _bbox); }

   void minus (GridData(2)<Type> const &gd, BBox const &to, BBox const &from);
   inline void minus (GridData(2)<Type> const &gd)
	{ GridData(2)<Type>::minus(gd, gd._bbox, gd._bbox); }
   inline void minus (GridData(2)<Type> const &gd, BBox const &where)
	{ GridData(2)<Type>::minus(gd, where, where); }

   /* operator *= */
   void multiply(Type const &val, BBox const &where);
   inline void multiply(Type const &val) 
	{ GridData(2)<Type>::multiply(val, _bbox); }

   void multiply (GridData(2)<Type> const &gd, BBox const &to, BBox const &from);
   inline void multiply (GridData(2)<Type> const &gd)
	{ GridData(2)<Type>::multiply(gd, gd._bbox, gd._bbox); }
   inline void multiply (GridData(2)<Type> const &gd, BBox const &where)
	{ GridData(2)<Type>::multiply(gd, where, where); }

   /* operator /= */
   void divide (Type const &val, BBox const &where);
   inline void divide (Type const &val) 
	{ GridData(2)<Type>::divide(val, _bbox); }

   void divide (GridData(2)<Type> const &gd, BBox const &to, BBox const &from);
   inline void divide (GridData(2)<Type> const &gd)
	{ GridData(2)<Type>::divide(gd, gd._bbox, gd._bbox); }
   inline void divide (GridData(2)<Type> const &gd, BBox const &where)
	{ GridData(2)<Type>::divide(gd, where, where); }

   /**********************************************************************/
   inline BBox operator == (Type const &val)
	{ return (GridData(2)<Type>::is_eq(val, _bbox)); }
   inline BBox operator == (GridData(2)<Type> const &gd)
	{ return (GridData(2)<Type>::is_eq(gd, gd._bbox, gd._bbox)); }

   inline BBox operator != (Type const &val)
	{ return (GridData(2)<Type>::is_neq(val, _bbox)); }
   inline BBox operator != (GridData(2)<Type> const &gd)
	{ return (GridData(2)<Type>::is_neq(gd, gd._bbox, gd._bbox)); }

   inline BBox operator > (Type const &val)
	{ return (GridData(2)<Type>::is_gt(val, _bbox)); }
   inline BBox operator > (GridData(2)<Type> const &gd)
	{ return (GridData(2)<Type>::is_gt(gd, gd._bbox, gd._bbox)); }

   inline BBox operator >= (Type const &val)
	{ return (GridData(2)<Type>::is_ge(val, _bbox)); }
   inline BBox operator >= (GridData(2)<Type> const &gd)
	{ return (GridData(2)<Type>::is_ge(gd, gd._bbox, gd._bbox)); }

   inline BBox operator < (Type const &val)
	{ return (GridData(2)<Type>::is_lt(val, _bbox)); }
   inline BBox operator < (GridData(2)<Type> const &gd)
	{ return (GridData(2)<Type>::is_lt(gd, gd._bbox, gd._bbox)); }

   inline BBox operator <= (Type const &val)
	{ return (GridData(2)<Type>::is_le(val, _bbox)); }
   inline BBox operator <= (GridData(2)<Type> const &gd)
	{ return (GridData(2)<Type>::is_le(gd, gd._bbox, gd._bbox)); }

   inline void operator = (Type const &val)
	{ GridData(2)<Type>::equals(val, _bbox); }
   inline void operator = (GridData(2)<Type> const &gd)
	{ GridData(2)<Type>::equals(gd, gd._bbox, gd._bbox); }

   inline void operator += (Type const &val)
	{ GridData(2)<Type>::plus(val, _bbox); }
   inline void operator += (GridData(2)<Type> const &gd)
	{ GridData(2)<Type>::plus(gd, gd._bbox, gd._bbox); }

   inline void operator -= (Type const &val)
	{ GridData(2)<Type>::minus(val, _bbox); }
   inline void operator -= (GridData(2)<Type> const &gd)
	{ GridData(2)<Type>::minus(gd, gd._bbox, gd._bbox); }

   inline void operator *= (Type const &val)
	{ GridData(2)<Type>::multiply(val, _bbox); }
   inline void operator *= (GridData(2)<Type> const &gd)
	{ GridData(2)<Type>::multiply(gd, gd._bbox, gd._bbox); }

   inline void operator /= (Type const &val)
	{ GridData(2)<Type>::divide(val, _bbox); }
   inline void operator /= (GridData(2)<Type> const &gd)
	{ GridData(2)<Type>::divide(gd, gd._bbox, gd._bbox); }
   /**********************************************************************/

   /**********************************************************************/
   // Reduction Operations
   /**********************************************************************/
   Type maxval (BBox const &where);
   inline Type maxval (void)
        { return (GridData(2)<Type>::maxval(_bbox)); }

   Type minval (BBox const &where);
   inline Type minval (void)
        { return (GridData(2)<Type>::minval(_bbox)); }

   Type sum (BBox const &where);
   inline Type sum (void)
        { return (GridData(2)<Type>::sum(_bbox)); }

   Type product (BBox const &where);
   inline Type product (void)
        { return (GridData(2)<Type>::product(_bbox)); }
   /**********************************************************************/

private:
   void gd_CopyRegion(GridData(2)<Type> const &gd, BBox const &to,
                                          BBox const &from, Coords const &step);
   void gdb_CopyRegion(GridDataBucket<Type> const &gdbkt, BBox const &to,
                                          BBox const &from, Coords const &step);
   void gdb_CopyRegion(GridDataBucket<Type> const &gdbkt, int const n, BBox const &to,
                                          BBox const &from, Coords const &step);

   void gd_OperateRegion(is_eq)(Type const &val, BBox const &to,
                                          BBox const &from, Coords const &step, BBox &bb);
   void gd_OperateRegion(is_eq)(GridData(2)<Type> const &gd, BBox const &to,
                                          BBox const &from, Coords const &step, BBox &bb);

   void gd_OperateRegion(is_neq)(Type const &val, BBox const &to,
                                          BBox const &from, Coords const &step, BBox &bb);
   void gd_OperateRegion(is_neq)(GridData(2)<Type> const &gd, BBox const &to,
                                          BBox const &from, Coords const &step, BBox &bb);

   void gd_OperateRegion(is_gt)(Type const &val, BBox const &to,
                                          BBox const &from, Coords const &step, BBox &bb);
   void gd_OperateRegion(is_gt)(GridData(2)<Type> const &gd, BBox const &to,
                                          BBox const &from, Coords const &step, BBox &bb);

   void gd_OperateRegion(is_ge)(Type const &val, BBox const &to,
                                          BBox const &from, Coords const &step, BBox &bb);
   void gd_OperateRegion(is_ge)(GridData(2)<Type> const &gd, BBox const &to,
                                          BBox const &from, Coords const &step, BBox &bb);

   void gd_OperateRegion(is_lt)(Type const &val, BBox const &to,
                                          BBox const &from, Coords const &step, BBox &bb);
   void gd_OperateRegion(is_lt)(GridData(2)<Type> const &gd, BBox const &to,
                                          BBox const &from, Coords const &step, BBox &bb);

   void gd_OperateRegion(is_le)(Type const &val, BBox const &to,
                                          BBox const &from, Coords const &step, BBox &bb);
   void gd_OperateRegion(is_le)(GridData(2)<Type> const &gd, BBox const &to,
                                          BBox const &from, Coords const &step, BBox &bb);

   void gd_OperateRegion(equal)(Type const &val, BBox const &to,
                                          BBox const &from, Coords const &step);
   void gd_OperateRegion(equal)(GridData(2)<Type> const &gd, BBox const &to,
                                          BBox const &from, Coords const &step);

   void gd_OperateRegion(plus)(Type const &val, BBox const &to,
                                          BBox const &from, Coords const &step);
   void gd_OperateRegion(plus)(GridData(2)<Type> const &gd, BBox const &to,
                                          BBox const &from, Coords const &step);

   void gd_OperateRegion(minus)(Type const &val, BBox const &to,
                                          BBox const &from, Coords const &step);
   void gd_OperateRegion(minus)(GridData(2)<Type> const &gd, BBox const &to,
                                          BBox const &from, Coords const &step);

   void gd_OperateRegion(mult)(Type const &val, BBox const &to,
                                          BBox const &from, Coords const &step);
   void gd_OperateRegion(mult)(GridData(2)<Type> const &gd, BBox const &to,
                                          BBox const &from, Coords const &step);

   void gd_OperateRegion(div)(Type const &val, BBox const &to,
                                          BBox const &from, Coords const &step);
   void gd_OperateRegion(div)(GridData(2)<Type> const &gd, BBox const &to,
                                          BBox const &from, Coords const &step);

public:
   /* Perform efficient buffer packing/unpacking and data movement */
   void PackRegion(Type *sendbuf, BBox const &from) const;
   void UnPackRegion(Type const *recvbuf, BBox const &to);
  };

#if defined(Want_c_files) || (!defined(RS6000) && !defined(SPX))
  #include "GridData2.c"
#endif

 /*********************************************************************/
 template <class Type>
 inline Coords lower(GridData(2)<Type> &gd) { return(gd.lower()); }
 template <class Type>
 inline Coords upper(GridData(2)<Type> &gd) { return(gd.upper()); }
 template <class Type>
 inline Coords extents(GridData(2)<Type> &gd) { return(gd.extents()); }
 template <class Type>
 inline int lower(GridData(2)<Type> &gd, const int i) { return(gd.lower(i)); }
 template <class Type>
 inline int upper(GridData(2)<Type> &gd, const int i) { return(gd.upper(i)); }
 template <class Type>
 inline int extents(GridData(2)<Type> &gd, const int i) { return(gd.extents(i)); }
 template <class Type>
 inline BBox bbox(GridData(2)<Type> &gd) { return(gd.bbox()); }
 template <class Type>
 inline int size(GridData(2)<Type> &gd) { return(gd.size()); }
 template <class Type>
 inline Coords stepsize(GridData(2)<Type> &gd) { return(gd.stepsize()); }
  
#endif
