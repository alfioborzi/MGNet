#ifndef _included_GridFunctionIO1_h
#define _included_GridFunctionIO1_h

/*
*************************************************************************
*                                                                       *
* GridFunctionIO1.h                                                    *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGHIOParams.h"

/************************************************************************************/
/* Writes */
/************************************************************************************/
template <class Type>
void GridFunction(1)<Type>::GF_Write(const int time, const int l, 
                                     const int mgl, const int ident, 
                                     const int gfdtype)
  {
   if (!io()) return;

   const int t = dagh_timeindex(time,l);
   const int level = dagh.levelnum(l);

   if (comm_service::io_enabled()) {
     const int dest = comm_service::proc_io();
     const int me = comm_service::proc_me();
     const MPI_Comm &comm = comm_service::comm_io();

     int cnt = 0;
     unsigned *bktsize = new unsigned [length];
     unsigned size = 0;

     register int i;
     for (i=0; i<length; i++) if (gdb[t][l][i]) {
       BBox bb = gdb[t][l][i]->interiorbox(ident,mgl);
       bktsize[cnt] = sizeof(Type)*bb.size();
       size += gdhdr::gdbsize(bktsize[cnt]);
       cnt++;
     }

     /* If I dont have message to sent return */
     if (size == 0) return;

#ifdef DAGH_NO_MPI
#else  
     if (comm_service::proc_world() > 1) {
#ifdef DEBUG_PRINT_COMM_IO
     ( comm_service::log() << "GridFunction::GF_Write: " << me << " "
                           << "MPI_Isend: " << " "
                           <<  (DAGHIOTag|DAGHIOWriteReqTag) << " "
                           << "Size: " << 1 << " "
                           << "Dest: " << dest << " "
                           << endl ).flush();
#endif

       MPI_Request req ;
       int sndsize = size;
       int R = MPI_Isend(&sndsize, 1 , MPI_INT , dest,
                         (DAGHIOTag|DAGHIOWriteReqTag), 
                         comm , &req );
       if ( MPI_SUCCESS != R )
          comm_service::error_die("GridFunction::GF_Write","MPI_Isend",R);
  
       R = comm_service::serve( req );
       if ( MPI_SUCCESS != R )
          comm_service::error_die( "GridFunction::GF_Write" , 
                                   "comm_service::serve" , R );
     }
#endif

     GridDataBucket<Type>* gdbkt = 
             new GridDataBucket<Type>(cnt,bktsize,DAGHPacked);
     cnt = 0;
     for (i=0; i<length; i++) if (gdb[t][l][i]) {
       gdb[t][l][i]->gdbWriteData(ident,mgl,
                     gdb[t][l][i]->interiorbox(ident,mgl),*gdbkt,cnt);
       gdbkt->setgfname(gfname,cnt);
       (gdbkt->head(cnt))->gfdatatype = gfdtype;
       (gdbkt->head(cnt))->gfstaggertype = gftype;
       (gdbkt->head(cnt))->time = time;
       (gdbkt->head(cnt))->level = l;
       cnt++;
     }
     if (bktsize) delete [] bktsize;
     void *package = 0;
     gdbkt->pack(package,size);

     if (comm_service::proc_world() > 1) {
#ifdef DAGH_NO_MPI
#else
#ifdef DEBUG_PRINT_COMM_IO
     ( comm_service::log() << "GridFunction::GF_Write: " << me << " "
                           << "MPI_Isend: " << " "
                           <<  (DAGHIOTag|DAGHIOWriteDataTag) << " "
                           << "Size: " << size << " "
                           << "Dest: " << dest << " "
                           << endl ).flush();
#endif

       MPI_Request req ;
       int R = MPI_Isend(package, size, MPI_BYTE, dest,
                        (DAGHIOTag|DAGHIOWriteDataTag), comm, &req );
       if ( MPI_SUCCESS != R )
         comm_service::error_die("GridFunction::GF_Write","MPI_Isend",R);

       R = comm_service::serve( req );
       if ( MPI_SUCCESS != R )
         comm_service::error_die("GridFunction::GF_Write","comm_service::serve",R);
#endif
     }
     else {
       DAGHIO_WriteFunc wf = DAGHIO_Write[dagh.io_type];
       if (wf) {
        if (gdbkt->type() == DAGHPacked) {
          int num = gdbkt->num();
          for (int ii=0;ii<num;ii++) {
            (wf)(dagh, gdbkt->head(ii), gdbkt->data(ii));
          }
        }
        else {
          (wf)(dagh, gdbkt->head(),gdbkt->data());
        }
       }
       else {
         cerr << "GridFunctionIO::GF_Write: WriteFunc not set" << "\n";
       }
     }
     if (gdbkt) delete gdbkt;
   }
   else {
      cerr << "GridFunction::GF_Write: I/O Not Enabled" << "\n";
   }
  }

template <class Type>
void GridFunction(1)<Type>::GF_Write(const int time, const int l, 
                                     const int mgl, const int ident, 
                                     const BBox& where, const int gfdtype)
  {
   if (!io()) return;

   assert (where.rank == dagh.rank);
   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   const int t = dagh_timeindex(time,l);
   const int level = dagh.levelnum(l);

   if (comm_service::io_enabled()) {
     const int dest = comm_service::proc_io();
     const int me = comm_service::proc_me();
     const MPI_Comm &comm = comm_service::comm_io();

     int cnt = 0;
     unsigned *bktsize = new unsigned [length];
     unsigned size = 0;

     register int i;
     for (i=0; i<length; i++) if (gdb[t][l][i]) {
       BBox bb = gdb[t][l][i]->interiorbox(ident,mgl) * alignedwhere;
       bktsize[cnt] = sizeof(Type)*bb.size();
       size += gdhdr::gdbsize(bktsize[cnt]);
       cnt++;
     }

     /* If I dont have message to sent return */
     if (size == 0) return;

#ifdef DAGH_NO_MPI
#else
     if (comm_service::proc_world() > 1) {
#ifdef DEBUG_PRINT_COMM_IO
     ( comm_service::log() << "GridFunction::GF_Write: " << me << " "
                           << "MPI_Isend: " << " "
                           <<  (DAGHIOTag|DAGHIOWriteReqTag) << " "
                           << "Size: " << 1 << " "
                           << "Dest: " << dest << " "
                           << endl ).flush();
#endif

       MPI_Request req ;
       int sndsize = size;
       int R = MPI_Isend(&sndsize, 1 , MPI_INT , dest,
                         (DAGHIOTag|DAGHIOWriteReqTag), 
                         comm , &req );
       if ( MPI_SUCCESS != R )
          comm_service::error_die("GridFunction::GF_Write","MPI_Isend",R);
  
       R = comm_service::serve( req );
       if ( MPI_SUCCESS != R )
          comm_service::error_die( "GridFunction::GF_Write" , 
                                   "comm_service::serve" , R );
     }
#endif

     GridDataBucket<Type> *gdbkt = 
             new GridDataBucket<Type>(cnt,bktsize,DAGHPacked);
     cnt = 0;
     for (i=0; i<length; i++) if (gdb[t][l][i]) {
       gdb[t][l][i]->gdbWriteData(ident,mgl,
                     alignedwhere*gdb[t][l][i]->interiorbox(ident,mgl),*gdbkt,cnt);
       gdbkt->setgfname(gfname,cnt);
       (gdbkt->head(cnt))->gfdatatype = gfdtype;
       (gdbkt->head(cnt))->gfstaggertype = gftype;
       (gdbkt->head(cnt))->time = time;
       (gdbkt->head(cnt))->level = l;
       cnt++;
     }
     if (bktsize) delete [] bktsize;
     void *package = 0;
     gdbkt->pack(package,size);

     if (comm_service::proc_world() > 1) {
#ifdef DAGH_NO_MPI
#else
#ifdef DEBUG_PRINT_COMM_IO
     ( comm_service::log() << "GridFunction::GF_Write: " << me << " "
                           << "MPI_Isend: " << " "
                           <<  (DAGHIOTag|DAGHIOWriteDataTag) << " "
                           << "Size: " << size << " "
                           << "Dest: " << dest << " "
                           << endl ).flush();
#endif

       MPI_Request req ;
       int R = MPI_Isend(package, size, MPI_BYTE, dest,
                        (DAGHIOTag|DAGHIOWriteDataTag), comm , &req );
       if ( MPI_SUCCESS != R )
          comm_service::error_die("GridFunction::GF_Write","MPI_Isend",R);

       R = comm_service::serve( req );
       if ( MPI_SUCCESS != R )
         comm_service::error_die( "GridFunction::GF_Write" , 
                                  "comm_service::serve" , R );
#endif
     }
     else {
       DAGHIO_WriteFunc wf = DAGHIO_Write[dagh.io_type];
       if (wf) {
        if (gdbkt->type() == DAGHPacked) {
          int num = gdbkt->num();
          for (int ii=0;ii<num;ii++) {
            (wf)(dagh, gdbkt->head(ii), gdbkt->data(ii));
          }
        }
        else {
          (wf)(dagh, gdbkt->head(),gdbkt->data());
        }
       }
       else {
         cerr << "GridFunctionIO::GF_Write: WriteFunc not set" << "\n";

       }
     }
     if (gdbkt) delete gdbkt;
   }
   else {
      cerr << "GridFunction::GF_Write: I/O Not Enabled" << "\n";
   }
  }

/************************************************************************************/
/* Reads */
/************************************************************************************/
template <class Type>
void GridFunction(1)<Type>::GF_Read(const int time, const int l, 
                                    const int mgl, const int ident, 
                                    const int gfdtype)
  {
   if (!io()) return;

   const int t = dagh_timeindex(time,l);
   const int level = dagh.levelnum(l);
   const int inside = gt->gtinside;

  GridTableDataRcv** read_server = new GridTableDataRcv*[length];

   if (comm_service::io_enabled()) {
     const int dest = comm_service::proc_io();
     const int me = comm_service::proc_me();
     const int pworld = comm_service::proc_world();
     const MPI_Comm &comm = comm_service::comm_io();

     register int i;
     /* Send Read Requests */
     for (i=0; i<length; i++) if (gdb[t][l][i]) {
       read_server[i] = GridTableDataRcvNULL;
       BBox bb = gdb[t][l][i]->interiorbox(ident,mgl);
       if (bb.empty()) continue;
       unsigned size = gdhdr::gdbsize(sizeof(Type)*bb.size());
       struct gdhdr* reqhdr = 
         new struct gdhdr(bb, gfid, gfdtype, gftype, gfname, t, level, inside+i, 
                          me, gdb[t][l][i]->baseindex, ident, DAGHSingle);

       if (pworld > 1) {
#ifdef DAGH_NO_MPI
#else
         /* Post receive */
         read_server[i] = 
         new GridTableDataRcv(*gt,(DAGHIOTag|DAGHIOReadDataTag|inside+i),size,dest);

         /* Send Read Request */
#ifdef DEBUG_PRINT_COMM_IO
         ( comm_service::log() << "GridFunction::GF_Read: " << me << " "
                               << "MPI_Isend: " << " "
                               << (DAGHIOTag|DAGHIOReadReqTag) << " "
                               << "Dest: " << dest << " "
                               << "( " << *reqhdr << ") "
                               << endl ).flush();
#endif
         MPI_Request req ;
         int R = MPI_Isend((void *)reqhdr, sizeof(struct gdhdr), MPI_BYTE, dest,
                           (DAGHIOTag|DAGHIOReadReqTag), comm, &req);
         if ( MPI_SUCCESS != R )
           comm_service::error_die( "GridFunction::GF_Read" , "MPI_Isend" , R );

         R = comm_service::serve( req );
         if ( MPI_SUCCESS != R )
           comm_service::error_die("GridFunction::GF_Read","comm_service::serve",R);
#endif
       }
       else {
         GridDataBucket<Type> *gdbkt = new GridDataBucket<Type>(reqhdr,sizeof(Type));
         DAGHIO_ReadFunc rf = DAGHIO_Read[dagh.io_type];
         if (rf) {
           (rf)(dagh,gdbkt->head(),gdbkt->data());
           (gdb[t][l][i]->griddata(ident,mgl)).copy(*gdbkt);
         }
         else {
           cerr << "GridFunctionIO::GF_Read: ReadFunc not set" << "\n";
         }
         if (gdbkt) delete gdbkt; 
         gdbkt = 0;
       }
       if (reqhdr) delete reqhdr;
     }
#ifdef DAGH_NON_MPI
#else
     if (pworld > 1) { /* Serve till I get the data */
       for (i=0; i<length; i++) if (gdb[t][l][i]) {
         if (read_server[i] && !read_server[i]->received()) {
           comm_service::serve(*read_server[i]->req());
           delete read_server[i];
           read_server[i] = 0;
         }
       }
       if (read_server) delete [] read_server;  
       GF_ReadData(t);
       gt->flushdata(t);
     }
#endif
   }
   else {
      cerr << "GridFunction::GF_Read: I/O Not Enabled" << "\n";
   }
  }

template <class Type>
void GridFunction(1)<Type>::GF_Read(const int time, const int l, 
                                    const int mgl, const int ident, 
                                    const BBox& where, const int gfdtype)
  {
   if (!io()) return;

   assert (where.rank == dagh.rank);
   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   const int t = dagh_timeindex(time,l);
   const int level = dagh.levelnum(l);
   const int inside = gt->gtinside;

  GridTableDataRcv** read_server = new GridTableDataRcv*[length];

   if (comm_service::io_enabled()) {
     const int dest = comm_service::proc_io();
     const int me = comm_service::proc_me();
     const int pworld = comm_service::proc_world();
     const MPI_Comm &comm = comm_service::comm_io();

     register int i;
     /* Send Read Requests */
     for (i=0; i<length; i++) if (gdb[t][l][i]) {
       read_server[i] = GridTableDataRcvNULL;
       BBox bb = gdb[t][l][i]->interiorbox(ident,mgl) * alignedwhere;
       if (bb.empty()) continue;
       unsigned size = gdhdr::gdbsize(sizeof(Type)*bb.size());
       struct gdhdr* reqhdr = 
         new struct gdhdr(bb, gfid, gfdtype, gftype, gfname, t, level, inside+i, 
                          me, gdb[t][l][i]->baseindex, ident, DAGHSingle);

       if (pworld > 1) {
#ifdef DAGH_NO_MPI
#else
         /* Post receive */
         read_server[i] = 
         new GridTableDataRcv(*gt,(DAGHIOTag|DAGHIOReadDataTag|inside+i),size,dest);

         /* Send Read Request */
#ifdef DEBUG_PRINT_COMM_IO
         ( comm_service::log() << "GridFunction::GF_Read: " << me << " "
                               << "MPI_Isend: " << " "
                               << (DAGHIOTag|DAGHIOReadReqTag) << " "
                               << "Dest: " << dest << " "
                               << "( " << *reqhdr << ") "
                               << endl ).flush();
#endif
         MPI_Request req ;
         int R = MPI_Isend((void *)reqhdr, sizeof(struct gdhdr), MPI_BYTE, dest,
                           (DAGHIOTag|DAGHIOReadReqTag), comm, &req);
         if ( MPI_SUCCESS != R )
           comm_service::error_die( "GridFunction::GF_Read" , "MPI_Isend" , R );

         R = comm_service::serve( req );
         if ( MPI_SUCCESS != R )
           comm_service::error_die("GridFunction::GF_Read","comm_service::serve",R);
#endif     
       }
       else {
         GridDataBucket<Type> *gdbkt = new GridDataBucket<Type>(reqhdr,sizeof(Type));
         DAGHIO_ReadFunc rf = DAGHIO_Read[dagh.io_type];
         if (rf) {
           (rf)(dagh,gdbkt->head(),gdbkt->data());
           (gdb[t][l][i]->griddata(ident,mgl)).copy(*gdbkt);
         }
         else {
           cerr << "GridFunctionIO::GF_Read: ReadFunc not set" << "\n";
         }
         if (gdbkt) delete gdbkt; 
         gdbkt = 0;
       }
       if (reqhdr) delete reqhdr;
     }
#ifdef DAGH_NO_MPI
#else
     if (pworld > 1) { /* Serve till I get the data */
       for (i=0; i<length; i++) if (gdb[t][l][i]) {
         if (read_server[i] && !read_server[i]->received()) {
           comm_service::serve(*read_server[i]->req());
           delete read_server[i];
           read_server[i] = 0;
         }
       }
       if (read_server) delete [] read_server; 
     
       GF_ReadData(t);
       gt->flushdata(t);
     }
#endif
   }
   else {
      cerr << "GridFunction::GF_Read: I/O Not Enabled" << "\n";
   }
  }

#endif








