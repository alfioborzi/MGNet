#ifndef _included_DAGHIO_h
#define _included_DAGHIO_h

/*
*************************************************************************
* DAGHIO.h                                                              *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/* DAGH IO Types */
#define DAGHIO_TYPES            (5)

/* Add new types here */
#define DAGHIO_NONE             (0)
#define DAGHIO_HDF_RNPL         (1)
#define DAGHIO_HDF_NCSA         (2)

#include "DAGHIOParams.h"

/* IO a la Matt & Robert */
extern void DAGHIO_HDF_RNPL_Write(class GridHierarchy &, struct gdhdr *, void *);
extern void DAGHIO_HDF_RNPL_Read(class GridHierarchy &, struct gdhdr *, void *);

/* IO a la NCSA */
extern void DAGHIO_HDF_NCSA_Finalize();
extern void DAGHIO_HDF_NCSA_Write(class GridHierarchy &, struct gdhdr *, void *);
extern void DAGHIO_HDF_NCSA_Read(class GridHierarchy &, struct gdhdr *, void *);

inline void DAGHIOInit(void)
 {
   comm_service::set_io_enable();

   DAGHIO_Write[DAGHIO_NONE] = 0;
   DAGHIO_Read[DAGHIO_NONE] = 0;

   DAGHIO_Write[DAGHIO_HDF_RNPL] = &DAGHIO_HDF_RNPL_Write;
   DAGHIO_Read[DAGHIO_HDF_RNPL] = &DAGHIO_HDF_RNPL_Read;

   DAGHIO_Write[DAGHIO_HDF_NCSA] = &DAGHIO_HDF_NCSA_Write;
   DAGHIO_Read[DAGHIO_HDF_NCSA] = &DAGHIO_HDF_NCSA_Read;
 }

//*********************************************************
// Definition of structure "struct gdhdr"
//*********************************************************
//struct gdhdr
//  {
//   friend ostream&  operator << (ostream& os, const struct gdhdr& hdr);
//
//   short int type;                      // Bucket type - DAGHSingle or DAGHPacked
//   short int owner;                     // Who owns the associated Grid function
//   short unsigned gfid;                 // Grid function id
//   short gfdatatype;                    // Grid function data type
//   short gfstaggertype;                 // Grid function staggering (DAGHCellCentered.. etc)
//   char gfname[DAGHBktGFNameWidth];     // Grid function name
//   BBox bbox;                           // Region
//   short int time;                      // Time
//   short int level;                     // Level
//   short int index;                     // Storage index
//   short int ident;                     // DAGH_Main or DAGH_Shadow
//   dMapIndex baseindex;                 // SFC index
//
//   inline gdhdr() {};
//   gdhdr(struct gdhdr& other);
//
//   gdhdr(const BBox& bb,
//         const unsigned gf, const int gft, const int gfs, const char* gfn,
//         const int t, const int l, const int index,
//         const int who, const dMapIndex& bindex,
//         const int which, const int type);
//
//   static unsigned gdbsize(const unsigned dsize);
//  };
//*********************************************************

#endif
