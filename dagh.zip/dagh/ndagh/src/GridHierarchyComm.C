/*
*************************************************************************
*                                                                       *
* "GridHierarchyComm.C"							*
*                                                                       *
*************************************************************************
*/

#include "GridHierarchy.h"

#ifndef OnlyProc
#define OnlyProc (n)    if (comm_service::proc_me() == (n)) {
#endif

#ifndef EndOnlyProc
#define EndOnlyProc     }
#endif

int GridHierarchy::DAGH_CommInit(MPI_Comm c)
  {
    //if ( 0 == c ) c = MPI_COMM_WORLD ;
    int R = comm_service::init(c);
    return R ;
  }

void GridHierarchy::DAGH_CommKill(void)
  {
#ifdef DAGH_NO_MPI
#else 
   /*$if (comm_service::dec() && comm_service::proc_world() > 1) 
     MPI_Barrier(comm_service::comm_world());$*/
#endif
   comm_service::kill(); 
  }

void GridHierarchy::DAGH_IOEnd(void)
  {
#ifdef DAGH_NO_MPI
#else
   if (comm_service::io_enabled() &&
       comm_service::proc_world() > 1 && 
       comm_service::proc_me() != comm_service::proc_io()) {
     comm_service::barrier(comm_service_comp);

     const int dest = comm_service::proc_io();
     const int me = comm_service::proc_me();
     const MPI_Comm &comm = comm_service::comm_io();
     MPI_Request req ;

     /* End IO Recvs... */
     int size = DAGHNull;
     int R = MPI_Isend(&size, 1 , MPI_INT , dest,
		       (DAGHIOTag|DAGHIOWriteReqTag), 
		       comm , &req );
     if ( MPI_SUCCESS != R )
       comm_service::error_die("GridHierarchy::DAGH_IOEnd","MPI_Isend",R);
     
     R = comm_service::serve( req );
     if ( MPI_SUCCESS != R )
       comm_service::error_die( "GridHirarchy::DAGH_IOEnd" , 
				  "comm_service::serve" , R );

     /* End IO Sends... */
     struct gdhdr reqhdr;
     reqhdr.type = DAGHNull; reqhdr.owner = me;

     R = MPI_Isend((void *)&reqhdr, sizeof(struct gdhdr), MPI_BYTE, dest,
		       (DAGHIOTag|DAGHIOReadReqTag), comm, &req);
     if ( MPI_SUCCESS != R )
       comm_service::error_die( "GridHierarchy::DAGH_IOEnd" , "MPI_Isend" , R );

     R = comm_service::serve( req );
     if ( MPI_SUCCESS != R )
       comm_service::error_die( "GridHirarchy::DAGH_IOEnd" , 
				  "comm_service::serve" , R );

     /* Close down GlbConcat Ping Server */
     DAGH_PingIONode(DAGHIOTag|DAGHIOComplistReqTag,DAGHFalse);
     /*$int flag = DAGHFalse;
     R = MPI_Isend(&flag, 1, MPI_INT, dest, 
		   (DAGHIOTag|DAGHIOComplistReqTag), comm ,&req );
     if ( MPI_SUCCESS != R ) 
       comm_service::error_die("GridHierarchy::DAGH_EndIO","MPI_Isend",R);

     R = comm_service::serve( req );
     if ( MPI_SUCCESS != R ) 
       comm_service::error_die("GridHierarchy::DAGH_EndIO",
			       "comm_service::serve",R);$*/

     /* End IO */
     DAGH_PingIONode(DAGHIOTag|DAGHIOEndReqTag,DAGHFalse);
     comm_service::reset_io_enable();

     /* And a barrier.. */
     //comm_service::barrier(comm_service_world);
   }
#endif
  }

void GridHierarchy::DAGH_PingIONode(const int tag, int flg)
  {
#ifdef DAGH_NO_MPI
#else
   if (!comm_service::dce() || 
       !comm_service::io_enabled() ||
       comm_service::proc_me() == comm_service::proc_io()) return;

   int ionode = comm_service::proc_io();
   MPI_Request req ;

#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "GridHierarchy::DAGH_PingIONode "
                         << comm_service::proc_me() << " "
                         << " MPI_Isend: "
                         << "Tag: " << tag << " "
                         << "Size: " << 1 << " "
                         << "Flag: " << flg << " "
                         << endl ).flush();
#endif

   //int flg = DAGHTrue;
   int R = MPI_Isend(&flg, 1, MPI_INT, ionode, tag, 
                     comm_service::comm_io() , &req );
   if ( MPI_SUCCESS != R ) 
     comm_service::error_die("GridHierarchy::DAGH_PingIONode","MPI_Isend",R);

   R = comm_service::serve( req );
   if ( MPI_SUCCESS != R ) 
     comm_service::error_die("GridHierarchy::DAGH_PingIONode",
                             "comm_service::serve",R);
#endif
  }

void GridHierarchy::DAGH_GlbConcat(void *snddata, int sndsize,
				   void *&rcvdata, int &rcvsize)
  {
    if (!comm_service::dce() || comm_service::proc_world() == 1) 
      { rcvsize = sndsize; rcvdata = snddata; return; }

#ifdef DAGH_NO_MPI
#else
    int me = comm_service::proc_me();
    int num = comm_service::proc_world();

    int R;
    /* get the size of the biggest bkt */
    R = MPI_Allreduce(&sndsize, &rcvsize, 1, MPI_INT, MPI_MAX, 
                      comm_service::comm_world());
    if ( MPI_SUCCESS != R ) 
      comm_service::error_die("DAGH::DAGH_GlbConcat","MPI_Allreduce",R);

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "DAGH::DAGH_GlbConcat " 
                         << comm_service::proc_me() << " "
                         << "MPI_Allreduce (MPI_MAX) { "
                         << rcvsize
                         << " }"
                         << endl ).flush();
#endif

    /* alloc rcv buffer */
    if (rcvdata) delete [] rcvdata;
    rcvdata = (void *) new char[rcvsize*num]; 

    void* tmpsnddata = 0;
    int tmpsndsize = 0;

#ifndef MPICH
    if (sndsize < rcvsize) {
      tmpsnddata = (void *) new char[rcvsize]; 
      memcpy (tmpsnddata,snddata,sndsize);
    }
    else {
      tmpsnddata = snddata;
    }
    tmpsndsize = rcvsize;
#else
    tmpsnddata = snddata;
    tmpsndsize = sndsize;
#endif

    R = MPI_Allgather(tmpsnddata, tmpsndsize, MPI_BYTE, rcvdata, rcvsize, MPI_BYTE,
	comm_service::comm_world()); 
    if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "DAGH::DAGH_GlbConcat", "MPI_Allgather", R );
	
#ifndef MPICH
    if (sndsize < rcvsize) {
      delete [] tmpsnddata;
    }
#endif

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "DAGH::DAGH_GlbConcat " 
                         << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << rcvsize
                         << " }"
                         << endl ).flush();
#endif
#endif
  }

void GridHierarchy::DAGH_GlbConcat(void *snddata, int const size, void *&rcvdata)
  {
    if (!comm_service::dce() || comm_service::proc_world() == 1) 
      { rcvdata = snddata; return; }

#ifdef DAGH_NO_MPI
#else
    int me = comm_service::proc_me();
    int num = comm_service::proc_world();

    int R;
    /* alloc rcv buffer */
    if (rcvdata) delete [] rcvdata;
    rcvdata = (void *) new char[size*num]; 
    R = MPI_Allgather(snddata, size, MPI_BYTE, rcvdata, size, MPI_BYTE,
	comm_service::comm_world()); 
    if ( MPI_SUCCESS != R ) 
      comm_service::error_die("GridHierarchy::DAGH_GlbConcat","MPI_Allgather",R);

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridHierarchy::DAGH_GlbConcat " 
                         << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif
#endif
  }


