format long e;
amg_globals;
amg_defaults;
AMGLab_GUI;