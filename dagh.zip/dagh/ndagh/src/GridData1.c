#ifndef _included_GridData_1_c
#define _included_GridData_1_c

/*
*************************************************************************
*                                                                       *
* GridData(1).c                                                         *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

template <class Type>
GridData(1)<Type>::GridData(1)()
  : _bbox(),
    _extents(0,0),
    _step(1,1),
    _size(0),
    _bottom(0),
    _data((Type *) NULL) {}

template <class Type>
GridData(1)<Type>::GridData (1) (BBox const &bb)
  : _bbox(bb),
    _extents(bb.extents()),
    _step(bb.stepsize()),
    _size(bb.size()),
    _bottom(bb.bottom()),
    _data(_size ? new Type[_size] : ((Type *) NULL)) 
    {
#ifdef DEBUG_PRINT_GD
    assert (_data);
    fill(9999);
    ( comm_service::log() << "Data Check"
			  << _bbox 
			  << ": " << _data[_size-1]
                          << endl ).flush();
#endif
#ifdef DEBUG_PRINT_GD_MEMORY
    DAGHMemoryTrace::alloc(sizeof(Type)*_size); 
#endif
    }

template <class Type>
GridData(1)<Type>::GridData (1) (int const i, int const ii)
  : _bbox(1,i,ii,1),
    _extents(_bbox.extents()),
    _step(_bbox.stepsize()),
    _size(_bbox.size()),
    _bottom(_bbox.bottom()),
    _data(_size ? new Type[_size] : ((Type *) NULL)) 
    {
#ifdef DEBUG_PRINT_GD
    assert (_data);
    fill(9999);
    ( comm_service::log() << "Data Check"
			  << _bbox 
			  << ": " << _data[_size-1]
                          << endl ).flush();
#endif
#ifdef DEBUG_PRINT_GD_MEMORY
    DAGHMemoryTrace::alloc(sizeof(Type)*_size); 
#endif
    }

template <class Type>
GridData(1)<Type>::GridData (1) (int const i, int const ii, int const s)
  : _bbox(1,i,ii,s),
    _extents(_bbox.extents()),
    _step(_bbox.stepsize()),
    _size(_bbox.size()),
    _bottom(_bbox.bottom()),
    _data(_size ? new Type[_size] : ((Type *) NULL)) 
    {
#ifdef DEBUG_PRINT_GD
    assert (_data);
    fill(9999);
    ( comm_service::log() << "Data Check"
			  << _bbox 
			  << ": " << _data[_size-1]
                          << endl ).flush();
#endif
#ifdef DEBUG_PRINT_GD_MEMORY
    DAGHMemoryTrace::alloc(sizeof(Type)*_size); 
#endif
    }

template <class Type>
GridData(1)<Type>::GridData(1)(BBox const &bb, Type *databuf)
  : _bbox(bb),
    _extents(bb.extents()),
    _step(bb.stepsize()),
    _size(bb.size()),
    _bottom(bb.bottom()),
    _data(databuf)
    {
#ifdef DEBUG_PRINT_GD
    assert (_data);
    fill(9999);
    ( comm_service::log() << "Data Check"
			  << _bbox 
			  << ": " << _data[_size-1]
                          << endl ).flush();
#endif
#ifdef DEBUG_PRINT_GD_MEMORY
    DAGHMemoryTrace::alloc(sizeof(Type)*_size); 
#endif
    }

template <class Type>
GridData(1)<Type>::GridData(1)(GridDataBucket<Type> &gdbkt)
  : _bbox(gdbkt.bbox()),
    _extents((gdbkt.bbox()).extents()),
    _step((gdbkt.bbox()).stepsize()),
    _size((gdbkt.bbox()).size()),
    _bottom((gdbkt.bbox()).bottom()),
    _data(gdbkt.data())
    {
#ifdef DEBUG_PRINT_GD
    assert (_data);
    fill(9999);
    ( comm_service::log() << "Data Check"
			  << _bbox 
			  << ": " << _data[_size-1]
                          << endl ).flush();
#endif
#ifdef DEBUG_PRINT_GD_MEMORY
    DAGHMemoryTrace::alloc(sizeof(Type)*_size); 
#endif
    }

template <class Type>
GridData(1)<Type>::GridData(1)(GridDataBucket<Type> &gdbkt, int const n)
  : _bbox(gdbkt.bbox(n)),
    _extents((gdbkt.bbox(n)).extents()),
    _step((gdbkt.bbox(n)).stepsize()),
    _size((gdbkt.bbox(n)).size()),
    _bottom((gdbkt.bbox(n)).bottom()),
    _data(gdbkt.data(n))
    {
#ifdef DEBUG_PRINT_GD
    assert (_data);
    fill(9999);
    ( comm_service::log() << "Data Check"
			  << _bbox 
			  << ": " << _data[_size-1]
                          << endl ).flush();
#endif
#ifdef DEBUG_PRINT_GD_MEMORY
    DAGHMemoryTrace::alloc(sizeof(Type)*_size); 
#endif
    }

template <class Type>
GridData(1)<Type>::GridData(1)(GridData(1)<Type> const &other)
  : _bbox(other._bbox),
    _extents(other._extents),
    _step(other._step),
    _size(other._size),
    _bottom(other._bottom),
    _data(_size ? new Type[_size] : ((Type *) NULL)) 
    {
#ifdef DEBUG_PRINT_GD
    assert (_data);
    fill(9999);
    ( comm_service::log() << "Data Check"
			  << _bbox 
			  << ": " << _data[_size-1]
                          << endl ).flush();
#endif
#ifdef DEBUG_PRINT_GD_MEMORY
    DAGHMemoryTrace::alloc(sizeof(Type)*_size); 
#endif
    }

template <class Type>
void GridData(1)<Type>::allocate(BBox const &bb)
  {
   _bbox = bb;
   _extents = _bbox.extents();
   _step = _bbox.stepsize();
   _size = _bbox.size();
   _bottom = _bbox.bottom();
   _data = _size ? new Type[_size] : (Type *) NULL;
#ifdef DEBUG_PRINT_GD
    assert (_data);
    fill(9999);
    ( comm_service::log() << "Data Check"
			  << _bbox 
			  << ": " << _data[_size-1]
                          << endl ).flush();
#endif
#ifdef DEBUG_PRINT_GD_MEMORY
    DAGHMemoryTrace::alloc(sizeof(Type)*_size); 
#endif
  }

template <class Type>
void GridData(1)<Type>::allocate(BBox const &bb, Type *databuf)
  {
   _bbox = bb;
   _extents = _bbox.extents();
   _step = _bbox.stepsize();
   _size = _bbox.size();
   _bottom = _bbox.bottom();
#ifdef DEBUG_PRINT_GD
   assert(!_data);
#endif
   _data = databuf;
#ifdef DEBUG_PRINT_GD
    assert (_data);
    fill(9999);
    ( comm_service::log() << "Data Check"
			  << _bbox 
			  << ": " << _data[_size-1]
                          << endl ).flush();
#endif
  }

template <class Type>
void GridData(1)<Type>::fill(Type const &val)
  { register int i; for (i = 0; i < _size; i++) _data[i] = val; }

template <class Type>
void GridData(1)<Type>::copy(GridData(1)<Type> const &gd)
  {
   if (&gd != this)
     {
      BBox intersection = _bbox * gd._bbox;
      if (!intersection.empty())
        { 
         Coords max_step = max(_step, gd._step);
         BBox to(intersection); to.setstepsize(_step); 
         BBox from(intersection); from.setstepsize(gd._step);
         gd_CopyRegion(gd, to, from, max_step); 
        }
     }
  }

template <class Type>
void GridData(1)<Type>::copy(GridData(1)<Type> const &gd, BBox const &where)
  {
   if (&gd != this)
     {
      BBox intersection = _bbox * gd._bbox * where;
      if (!intersection.empty())
        { 
         Coords max_step = max(_step, gd._step);
         BBox to(intersection); to.setstepsize(_step); 
         BBox from(intersection); from.setstepsize(gd._step);
         gd_CopyRegion(gd, to, from, max_step); 
        }
     }
  }

template <class Type>
void GridData(1)<Type>::copy(GridData(1)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_CopyRegion(gd, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(1)<Type>::copy(GridDataBucket<Type> const &gdbkt)
  {
   BBox const &gdbktbb = gdbkt.bbox();
   BBox intersection = _bbox * gdbktbb;
   if (!intersection.empty())
     { 
      Coords max_step = max(_step, gdbktbb.stepsize());
      BBox to(intersection); to.setstepsize(_step); 
      BBox from(intersection); from.setstepsize(gdbktbb.stepsize());
      gdb_CopyRegion(gdbkt, to, from, max_step); 
     }
  }

template <class Type>
void GridData(1)<Type>::copy(GridDataBucket<Type> const &gdbkt, 
						BBox const &where)
  {
   BBox const &gdbktbb = gdbkt.bbox();
   BBox intersection = _bbox * gdbktbb * where;
   if (!intersection.empty())
    { 
     Coords max_step = max(_step, gdbktbb.stepsize());
     BBox to(intersection); to.setstepsize(_step); 
     BBox from(intersection); from.setstepsize(gdbktbb.stepsize());
     gdb_CopyRegion(gdbkt, to, from, max_step); 
    }
  }

template <class Type>
void GridData(1)<Type>::copy(GridDataBucket<Type> const &gdbkt, 
				BBox const &to, BBox const &from)
  {
   BBox const &gdbktbb = gdbkt.bbox();
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gdbktbb * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gdbktbb.stepsize());
      newto.setstepsize(_step);
      newfrom.setstepsize(gdbktbb.stepsize());
      gdb_CopyRegion(gdbkt, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(1)<Type>::copy(GridDataBucket<Type> const &gdbkt, int const n)
  {
   BBox const &gdbktbb = gdbkt.bbox(n);
   BBox intersection = _bbox * gdbktbb;
   if (!intersection.empty())
     { 
      Coords max_step = max(_step, gdbktbb.stepsize());
      BBox to(intersection); to.setstepsize(_step); 
      BBox from(intersection); from.setstepsize(gdbktbb.stepsize());
      gdb_CopyRegion(gdbkt, n, to, from, max_step); 
     }
  }

template <class Type>
void GridData(1)<Type>::copy(GridDataBucket<Type> const &gdbkt, int const n,
						BBox const &where)
  {
   BBox const &gdbktbb = gdbkt.bbox(n);
   BBox intersection = _bbox * gdbktbb * where;
   if (!intersection.empty())
    { 
     Coords max_step = max(_step, gdbktbb.stepsize());
     BBox to(intersection); to.setstepsize(_step); 
     BBox from(intersection); from.setstepsize(gdbktbb.stepsize());
     gdb_CopyRegion(gdbkt, n, to, from, max_step); 
    }
  }

template <class Type>
void GridData(1)<Type>::copy(GridDataBucket<Type> const &gdbkt, int const n,
				BBox const &to, BBox const &from)
  {
   BBox const &gdbktbb = gdbkt.bbox(n);
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gdbktbb * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gdbktbb.stepsize());
      newto.setstepsize(_step);
      newfrom.setstepsize(gdbktbb.stepsize());
      gdb_CopyRegion(gdbkt, n, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(1)<Type>::gd_CopyRegion(GridData(1)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(1)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);

   BeginFastIndex1(src, src._bbox, src._data, const Type);
   BeginFastIndex1(dst, dst._bbox, dst._data, Type);

   for_1(i, to, step)
      FastIndex1(dst,i) = FastIndex1(src,i+di);
   end_for

   EndFastIndex1(dst);
   EndFastIndex1(src);
  }

template <class Type>
void GridData(1)<Type>::gdb_CopyRegion(GridDataBucket<Type> const &gdbkt, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(1)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);

   BeginFastIndex1(src, gdbkt.bbox(), gdbkt.data(), const Type);
   BeginFastIndex1(dst, dst.bbox(), dst.data(), Type);
   for_1(i, to, step)
      FastIndex1(dst,i) = FastIndex1(src,i+di);
   end_for
   EndFastIndex1(dst);
   EndFastIndex1(src);
  }

template <class Type>
void GridData(1)<Type>::gdb_CopyRegion(GridDataBucket<Type> const &gdbkt, int const n,
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(1)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);

   BeginFastIndex1(src, gdbkt.bbox(n), gdbkt.data(n), const Type);
   BeginFastIndex1(dst, dst.bbox(), dst.data(), Type);
   for_1(i, to, step)
      FastIndex1(dst,i) = FastIndex1(src,i+di);
   end_for
   EndFastIndex1(dst);
   EndFastIndex1(src);
  }

template <class Type>
void GridData(1)<Type>::PackRegion(Type *sendbuf, BBox const &from) const
  {
   GridData(1)<Type> const &src = *this;
   register int p = 0;

   BeginFastIndex1(src, src._bbox, src._data, const Type);

   for_1(i, from, _step)
      sendbuf[p++] = FastIndex1(src,i);
   end_for

   EndFastIndex1(src);
  }

template <class Type>
void GridData(1)<Type>::UnPackRegion(Type const *recvbuf, BBox const &to)
  {
   GridData(1)<Type> &dst = *this;

   register int p = 0;

   BeginFastIndex1(dst, dst._bbox, dst._data, Type);

   for_1(i, to, _step)
      FastIndex1(dst,i) = recvbuf[p++];
   end_for

   EndFastIndex1(dst);
  }

template <class Type>
ostream&  operator << (ostream& os, const GridData(1)<Type> &gd)
  {
   if (&gd == (const GridData(1)<Type> *)NULL) return os;

   os << "BBox: " << gd._bbox << " " << "Extents: " << gd._extents << " ";
   os << "Step: " << gd._step << " ";
   os << "Size: " << gd._size << " " << "Bottom: " << gd._bottom << " ";

   os << "\n";
  
   if (gd._bbox.empty()) return os;

   const Coords &l = gd._bbox.lower();
   const Coords &u = gd._bbox.upper();
   const Coords &step = gd._bbox.stepsize();
   for (register int i=l(0);i<=u(0);i+=step(0)) 
     { os << "[" << i << "]=" << gd(i) << " "; }
   os << "\n";

   return os;
  }

template <class Type>
ofstream&  operator << (ofstream& ofs, const GridData(1)<Type> &gd)
  {
   if (&gd == (GridData(1)<Type> *)NULL) return ofs;

   ofs.write((char*)&gd._bbox,sizeof(BBox));
   ofs.write((char*)gd._data,gd._size*sizeof(Type));

   return ofs;
  }

template <class Type>
ifstream&  operator >> (ifstream& ifs, GridData(1)<Type> &gd)
  {
   if (&gd == (GridData(1)<Type> *)NULL) return ifs;

   BBox bb;
   ifs.read((char*)&bb,sizeof(BBox));

   if (!gd.ok_to_index())
     { gd.allocate(bb); }

   if (bb == gd._bbox) {
     ifs.read((char*)gd._data,gd._size*sizeof(Type));
   }
   else {
     GridData(1)<Type> tmpgd(bb);
     ifs.read((char*)tmpgd._data,tmpgd._size*sizeof(Type));
     gd.copy(tmpgd);  
   } 

   return ifs;
  }

  #include "GridDataOps1.h"
  #include "GridDataOpsRel1.h"
  #include "GridDataOpsRed1.h"

#endif
