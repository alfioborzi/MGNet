#ifndef _included_List_c
#define _included_List_c

/*
*************************************************************************
*									*
* List.c								*
* A generic linked list...						*
*									*
*************************************************************************
*/

template <class Type>
List<Type>::~List()
  {
   while (head != (ListItem<Type> *) 0)
     {
      ListItem<Type> *tmpitem = head;
      head = head->next;
      //delete tmpitem->item;
      block.free(tmpitem);
     }
  }

template <class Type>
void List<Type>::empty()
  {
   while (head != (ListItem<Type> *) 0)
     {
      ListItem<Type> *tmpitem = head;
      head = head->next;
      //delete tmpitem->item;
      block.free(tmpitem);
     }
   n = 0;
   head = 0;
   tail = 0;
  }

template <class Type>
void List<Type>::add(const Type& t)
  {
   ListItem<Type> *item = new (block.alloc()) ListItem<Type>(t);
   if (!head) head = item;
   if (tail) tail->next = item;
   tail = item;
   n++;
  }

template <class Type>
void List<Type>::add(const List<Type>& other)
  {
   for (ListItem<Type> *p = other.head; p; p = p->next)
     {
      ListItem<Type> *item = new (block.alloc()) ListItem<Type>(p->item);
      if (!head) head = item;
      if (tail) tail->next = item;
      tail = item;
      n++;
     }
  }

template <class Type>
void List<Type>::pop( )
  {
   if (n > 0)
     {
      ListItem<Type> *byebye = head;
      head = head->next;
      if (!head) tail = 0;
      //delete byebye->item;
      block.free(byebye);
      n--;
     }
  }

template <class Type>
void List<Type>::combine(List<Type>& other)
  {
   if (other.n > 0)
     {
      if (n == 0)
        {
         head = other.head;
         tail = other.tail;
         n    = other.n;
        }
      else
        {
         tail->next = other.head;
         tail = other.tail;
         n += other.n;
        }
      other.n    = 0;
      other.head = 0;
      other.tail = 0;
     }
  }

template <class Type>
void List<Type>::array(Type **& array, int &cnt) const
  {
   assert(!array);
   cnt = n;
   if (cnt > 0) {
     array = new Type *[cnt];
     int i = 0;
     ListItem<Type> *p = head;
     for (;i<cnt;p=p->next,i++) {
       array[i] = new Type(p->item);
     }
   }
  }

template <class Type>
void List<Type>::array(Type *& array, int &cnt) const
  {
   assert(!array);
   cnt = n;
   if (cnt > 0) {
     array = new Type [cnt];
     int i = 0;
     ListItem<Type> *p = head;
     for (;i<cnt;p=p->next,i++) {
       array[i] = p->item;
     }
   }
  }

#endif
