#ifndef _included_GridHierarchyIndex_h
#define _included_GridHierarchyIndex_h

/*
*************************************************************************
*									*
* GridHierarchyIndex.h							*
*									*
*************************************************************************
*/

#include <generic.h>

#ifndef foreachGF
#define foreachGF(gh,gf,DIM,Type) {					\
   const int name2(faGF,_GFNUM) = (gh).gfnum;				\
   for (int gfid = 0; gfid < name2(faGF,_GFNUM); gfid++) {		\
     if(!(gh).gflist[gfid]) ; else {					\
     GridFunction(DIM)<Type> & gf = 					\
     *((GridFunction(DIM)<Type> *) gh.gflist[gfid]);
#endif

#ifndef end_foreachGF_sync
#define end_foreachGF_sync } } comm_service::barrier(); }
#endif

#ifndef end_foreachGF
#define end_foreachGF } } }
#endif

#endif
