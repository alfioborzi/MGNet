/*
*************************************************************************
*                                                                       *
* GridFunctionInterface.h                                               *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#ifndef FORTRAN_INTERFACE
#define FORTRAN_INTERFACE(T)     T *, const int *, const int *, \
                                 const int *
#endif

#ifndef BBOX_INTERFACE
#define BBOX_INTERFACE     	 const int *, const int *, const int *
#endif

#ifndef GF_TYPE
#define GF_TYPE double
#endif

/* Initialization Function Interface */
typedef void (*InitFunc) (
            FORTRAN_INTERFACE(GF_TYPE),
	    BBOX_INTERFACE,
	    GF_TYPE *, const int *);

/* Update Function Interface */
typedef void (*UpdateFunc) (
            FORTRAN_INTERFACE(GF_TYPE), FORTRAN_INTERFACE(GF_TYPE),
	    BBOX_INTERFACE,
	    GF_TYPE *, const int *);

/* Boundary Update Function Interface */
typedef void (*BndryUpdateFunc) (
            FORTRAN_INTERFACE(GF_TYPE), 
	    BBOX_INTERFACE,
	    GF_TYPE *, const int *);

/* Adaptive Boundary Update Function Interface */
typedef void (*AdptBndryUpdateFunc) (
            FORTRAN_INTERFACE(GF_TYPE), 
            FORTRAN_INTERFACE(GF_TYPE), const double *,
            FORTRAN_INTERFACE(GF_TYPE), const double *,
	    BBOX_INTERFACE,
	    GF_TYPE *, const int *);

/* Prolongation Function Interface */
typedef void (*ProlongFunc) (
            FORTRAN_INTERFACE(GF_TYPE), FORTRAN_INTERFACE(GF_TYPE),
	    BBOX_INTERFACE,
	    GF_TYPE *, const int *);

/* Restriction Function Interface */
typedef void (*RestrictFunc) (
            FORTRAN_INTERFACE(GF_TYPE), FORTRAN_INTERFACE(GF_TYPE),
	    BBOX_INTERFACE,
	    GF_TYPE *, const int *);

/* I/O Function Interface */
typedef void (*IOFunc) (
            FORTRAN_INTERFACE(GF_TYPE),
	    BBOX_INTERFACE,
	    GF_TYPE *, const int *);
