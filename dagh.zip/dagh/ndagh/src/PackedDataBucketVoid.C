/*
*************************************************************************
* PackedDataBucketVoid.C                           			*
*                              						*
*************************************************************************
*/

#include "PackedDataBucketVoid.h"

#ifdef DEBUG_PRINT_DBKT
#include "CommServer.h"
#endif

DataBucketVoid::DataBucketVoid(unsigned const hsize, unsigned const dsize)
        : headsize(0), datasize(0), cnt(1), hs(0), ds(0), bkt(0)
  {
   hs = new unsigned[1];
   ds = new unsigned[1];

#ifdef DEBUG_PRINT_DBKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(unsigned)*1); // hs
   DAGHMemoryTrace::alloc(sizeof(unsigned)*1); // ds
#endif

   headsize = hsize + sizeof(struct dbkthdr);
   unsigned int align = ((headsize > 8) ? 16 : ((headsize > 4) ? 8 : 4));
   headsize = (headsize+align-1) & (~(align-1));
   hs[0] = 0;

   align = ((dsize > 8) ? 16 : ((dsize > 4) ? 8 : 4));
   datasize = (dsize+align-1) & (~(align-1));
   ds[0] = headsize;

   char *chunk;
   assert ((chunk = new char[headsize+datasize]) != (char *) 0);

#ifdef DEBUG_PRINT_DBKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(char)*(headsize+datasize));
#endif

   bkt = (union drecord *) chunk;
   bkt->head.headsize = headsize;
   bkt->head.datasize = datasize;
   bkt->head.cnt = cnt;

#ifdef DEBUG_PRINT_DBKT
     ( comm_service::log() << "\n************* Grid Data Bucket *************\n"
                           << "Cnt: " << cnt << " "
                           << "HSize: " << headsize << " "
                           << "DSize: " << datasize << " "
                           << "\n" ).flush();
     for (int db_i=0;db_i<cnt;db_i++) {
      ( comm_service::log() << "[" << hs[db_i] << " , " << ds[db_i] << "]\n");
     }
     ( comm_service::log() << "\n************* ***************** *************\n"
                           ).flush();
#endif
  }

DataBucketVoid::DataBucketVoid(unsigned *hsize, unsigned *dsize, int const n)
        : headsize(0), datasize(0), cnt(n), hs(0), ds(0), bkt(0)
  {
   hs = new unsigned[cnt];
   ds = new unsigned[cnt];

#ifdef DEBUG_PRINT_DBKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(unsigned)*cnt); // hs
   DAGHMemoryTrace::alloc(sizeof(unsigned)*cnt); // ds
#endif

   unsigned h = 0, d = 0;
   unsigned s = sizeof(struct dbkthdr);
   unsigned a = 0;
   int i;
   for (i=0;i<cnt;i++) {
     hs[i] = headsize + datasize;

     h = hsize[i] + s;
     a = ((h > 8) ? 16 : ((h > 4) ? 8 : 4));
     h = (h+a-1) & (~(a-1));
     headsize += h;

     ds[i] = headsize + datasize;

     a = ((dsize[i] > 8) ? 16 : ((dsize[i] > 4) ? 8 : 4));
     d = (dsize[i]+a-1) & (~(a-1));
     datasize += d;

     hsize[i] = h;
     dsize[i] = d;
   }

   char *chunk;
   assert ((chunk = new char[headsize+datasize]) != (char *) 0);

#ifdef DEBUG_PRINT_DBKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(char)*(headsize+datasize));
#endif

   bkt = (union drecord *) chunk;

   for (i=0;i<cnt;i++) {
     ((union drecord *)((char *)(bkt)+hs[i]))->head.headsize = hsize[i];
     ((union drecord *)((char *)(bkt)+hs[i]))->head.datasize = dsize[i];
     ((union drecord *)((char *)(bkt)+hs[i]))->head.cnt = cnt;
   }
#ifdef DEBUG_PRINT_DBKT
     ( comm_service::log() << "\n************* Grid Data Bucket *************\n"
                           << "Cnt: " << cnt << " "
                           << "HSize: " << headsize << " "
                           << "DSize: " << datasize << " "
                           << "\n" ).flush();
     for (int db_i=0;db_i<cnt;db_i++) {
      ( comm_service::log() << "[" << hs[db_i] << " , " << ds[db_i] << "]\n");
     }
     ( comm_service::log() << "\n************* ***************** *************\n"
                           ).flush();
#endif
  }

DataBucketVoid::DataBucketVoid(unsigned hsize, unsigned *dsize, int const n)
        : headsize(0), datasize(0), cnt(n), hs(0), ds(0), bkt(0)
  {
   hs = new unsigned[cnt];
   ds = new unsigned[cnt];

#ifdef DEBUG_PRINT_DBKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(unsigned)*cnt); // hs
   DAGHMemoryTrace::alloc(sizeof(unsigned)*cnt); // ds
#endif

   unsigned h = 0, d = 0;
   unsigned s = sizeof(struct dbkthdr);
   unsigned a = 0;

   h = hsize + s;
   a = ((h > 8) ? 16 : ((h > 4) ? 8 : 4));
   h = (h+a-1) & (~(a-1));
   hsize = h;

   int i;
   for (i=0;i<cnt;i++) {
     hs[i] = headsize + datasize;

     headsize += h;

     ds[i] = headsize + datasize;

     a = ((dsize[i] > 8) ? 16 : ((dsize[i] > 4) ? 8 : 4));
     d = (dsize[i]+a-1) & (~(a-1));
     datasize += d;

     dsize[i] = d;
   }

   char *chunk;
   assert ((chunk = new char[headsize+datasize]) != (char *) 0);

#ifdef DEBUG_PRINT_DBKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(char)*(headsize+datasize));
#endif

   bkt = (union drecord *) chunk;

   for (i=0;i<cnt;i++) {
     ((union drecord *)((char *)(bkt)+hs[i]))->head.headsize = hsize;
     ((union drecord *)((char *)(bkt)+hs[i]))->head.datasize = dsize[i];
     ((union drecord *)((char *)(bkt)+hs[i]))->head.cnt = cnt;
   }
#ifdef DEBUG_PRINT_DBKT
     ( comm_service::log() << "\n************* Grid Data Bucket *************\n"
                           << "Cnt: " << cnt << " "
                           << "HSize: " << headsize << " "
                           << "DSize: " << datasize << " "
                           << "\n" ).flush();
     for (int db_i=0;db_i<cnt;db_i++) {
      ( comm_service::log() << "[" << hs[db_i] << " , " << ds[db_i] << "]\n");
     }
     ( comm_service::log() << "\n************* ***************** *************\n"
                           ).flush();
#endif
  }

DataBucketVoid::DataBucketVoid(union drecord const *package)
        : headsize(0), datasize(0), cnt(0), hs(0), ds(0), bkt(0)
  {
   cnt = package->head.cnt;
   hs = new unsigned[cnt];
   ds = new unsigned[cnt];

#ifdef DEBUG_PRINT_DBKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(unsigned)*cnt); // hs
   DAGHMemoryTrace::alloc(sizeof(unsigned)*cnt); // ds
#endif

   int i;
   for (i=0;i<cnt;i++) {
     hs[i] = headsize + datasize;
     headsize += ((union drecord *)((char *)(package)+hs[i]))->head.headsize;
     ds[i] = headsize + datasize;
     datasize += ((union drecord *)((char *)(package)+hs[i]))->head.datasize;
   }

   char *nchunk, *ochunk;
   ochunk = (char *) package;
   assert ((nchunk = new char[headsize+datasize]) != (char *) 0);

#ifdef DEBUG_PRINT_DBKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(char)*(headsize+datasize));
#endif


   //for (register int i=0;i<headsize+datasize;i++)
   //	nchunk[i] = ochunk[i];
   memcpy((void *)nchunk, (void *)ochunk, headsize+datasize);

   bkt = (union drecord *) nchunk;
#ifdef DEBUG_PRINT_DBKT
     ( comm_service::log() << "\n************* Grid Data Bucket *************\n"
                           << "Cnt: " << cnt << " "
                           << "HSize: " << headsize << " "
                           << "DSize: " << datasize << " "
                           << "\n" ).flush();
     for (int db_i=0;db_i<cnt;db_i++) {
      ( comm_service::log() << "[" << hs[db_i] << " , " << ds[db_i] << "]\n");
     }
     ( comm_service::log() << "\n************* ***************** *************\n"
                           ).flush();
#endif
  }

DataBucketVoid::DataBucketVoid(union drecord *package)
        : headsize(0), datasize(0), cnt(0), hs(0), ds(0), bkt(0)
  {
   cnt = package->head.cnt;
   hs = new unsigned[cnt];
   ds = new unsigned[cnt];

#ifdef DEBUG_PRINT_DBKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(unsigned)*cnt); // hs
   DAGHMemoryTrace::alloc(sizeof(unsigned)*cnt); // ds
#endif

   for (int i=0;i<cnt;i++) {
     hs[i] = headsize + datasize;
     headsize += ((union drecord *)((char *)(package)+hs[i]))->head.headsize;
     ds[i] = headsize + datasize;
     datasize += ((union drecord *)((char *)(package)+hs[i]))->head.datasize;
   }

#ifdef DEBUG_PRINT_DBKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(char)*(headsize+datasize));
#endif

   bkt = package;
#ifdef DEBUG_PRINT_DBKT
     ( comm_service::log() << "\n************* Grid Data Bucket *************\n"
                           << "Cnt: " << cnt << " "
                           << "HSize: " << headsize << " "
                           << "DSize: " << datasize << " "
                           << "\n" ).flush();
     for (int db_i=0;db_i<cnt;db_i++) {
      ( comm_service::log() << "[" << hs[db_i] << " , " << ds[db_i] << "]\n");
     }
     ( comm_service::log() << "\n************* ***************** *************\n"
                           ).flush();
#endif
  }

DataBucketVoid::DataBucketVoid(union drecord const *package, int const n)
        : headsize(0), datasize(0), cnt(0), hs(0), ds(0), bkt(0)
  { 
   assert (n < package->head.cnt);

   cnt = 1;
   hs = new unsigned[1];
   ds = new unsigned[1];

#ifdef DEBUG_PRINT_DBKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(unsigned)*1); // hs
   DAGHMemoryTrace::alloc(sizeof(unsigned)*1); // ds
#endif

   unsigned hoff = 0;
   int i;
   for (i=0;i<n;i++) {
     headsize = ((union drecord *)((char *)(package)+hoff))->head.headsize;
     datasize = ((union drecord *)((char *)(package)+hoff))->head.datasize;
     hoff += (headsize + datasize);
   }
   headsize = ((union drecord *)((char *)(package)+hoff))->head.headsize;
   datasize = ((union drecord *)((char *)(package)+hoff))->head.datasize;

   hs[0] = 0;
   ds[0] = headsize;

   char *nchunk, *ochunk;
   ochunk = (char *) ((char *)(package)+hoff);
   assert ((nchunk = new char[headsize+datasize]) != (char *) 0);

#ifdef DEBUG_PRINT_DBKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(char)*(headsize+datasize));
#endif

   //for (register int i=0;i<headsize+datasize;i++)
   //	nchunk[i] = ochunk[i];
   memcpy((void *)nchunk, (void *)ochunk, headsize+datasize);

   bkt = (union drecord *) nchunk;
   bkt->head.cnt = cnt;

#ifdef DEBUG_PRINT_DBKT
     ( comm_service::log() << "\n************* Grid Data Bucket *************\n"
                           << "Cnt: " << cnt << " "
                           << "HSize: " << headsize << " "
                           << "DSize: " << datasize << " "
                           << "\n" ).flush();
     for (int db_i=0;db_i<cnt;db_i++) {
      ( comm_service::log() << "[" << hs[db_i] << " , " << ds[db_i] << "]\n");
     }
     ( comm_service::log() << "\n************* ***************** *************\n"
                           ).flush();
#endif
  }
