#include <DAGH.h>
#include <DAGHIO.h>
#include <bbhutil.h>
#include <time.h>
#include <stdio.h>

#define MAXSTEP 50
#define IN(A,i,j) *(A + (i) + Nx*(j))

double calc_resid(double *phinp1, double *phin, double *phinm1, 
                  const int *size, double dt, double dx, double dy);
void initialize(double *phinp1, double *phin, double *phinm1, 
                const double *lb, const double *ub, const double *stp,
                const int *size, double *bb,
                double dt, double dx, double dy, double amp,
                double cx, double cy, double sx, double sy, double epsiter);
void update(double *phinp1, double *phin, double *phinm1, 
            const double *lb, const double *ub, const double *stp,
            const int *size, double *bb, double dt, double dx, double dy);
						
void wout(FILE *fp, GridFunction(2)<double> &gf, int tc, int lev);
void woutr(GridHierarchy &GH, GridFunction(2)<double> &gf, char *gfname, 
           double dt, int tc, int lev);

void writeslicehdf(const int IDENT,
                const char *fname,
                GridHierarchy &GH,
                GridFunction(2)<double> &gf,
                const int t, const int l,
                const int viz_server);
 
double calc_resid(double *phinp1, double *phin, double *phinm1, 
                  const int *size, double dt, double dx, double dy)
{
  int i,j,Nx,Ny;
  double u,v,w;
  
  Nx=size[0];
  Ny=size[1];
  
  for(u=0,i=1;i<Nx-1;i++){
    for(j=1;j<Ny-1;j++){
      w=((*(phinp1 + Nx*j + i) - 2* *(phin + Nx*j + i) + 
          *(phinm1 + Nx*j + i))/(dt*dt) -
         (*(phin + Nx*j + i+1) - 2* *(phin + Nx*j + i) + 
          *(phin + Nx*j + i-1))/(dx*dx) -
         (*(phin + Nx*(j+1) + i) - 2* *(phin + Nx*j + i) + 
          *(phin + Nx*(j-1) + i))/(dy*dy));
      w*=w;
      u+=w;
    }
  }
  u=sqrt(u/((Nx-2)*(Ny-2)));
  v=l2norm(Nx*Ny,phinp1);
  if(v!=0.0) u/=v;
  return u;
}

void initialize(double *phinp1, double *phin, double *phinm1, 
                const double *lb, const double *ub, const double *stp,
                const int *size, double *bb,
                double dt, double dx, double dy, double amp,
                double cx, double cy, double sx, double sy, double epsiter)
{
  int i,j,Nx,Ny,step;
  double u=0.0;
  
  Nx=size[0];
  Ny=size[1];

  // initialize t=n
  for(i=0;i<Nx;i++)
    for(j=0;j<Ny;j++){
      *(phin + Nx*j + i)=amp*exp(-pow((lb[0]+i*dx-cx)/sx,2))*
                             exp(-pow((lb[1]+j*dy-cy)/sy,2));
    }
  // copy n to n-1 and n+1
  rdvcpy(phinm1,phin,Nx*Ny);
  rdvcpy(phinp1,phin,Nx*Ny);
  dt/=-2;
  step=0;

  do{
    step++;
    rdvaddc(phin,.5,phinp1,.5,phinm1,Nx*Ny);
    update(phinp1,phin,phinm1,lb,ub,stp,size,bb,dt,dx,dy);
    u=calc_resid(phinp1,phin,phinm1,size,dt,dx,dy);
    cout<<"step="<<step<<", u="<<u<<endl;
  }while(u>epsiter && step<MAXSTEP);

  if(step==MAXSTEP)
    cout<<"Initialization did not converge within "<<MAXSTEP<<" iterations."<<endl;
  else cout<<"Initialization took "<<step<<" iterations."<<endl;
}

void update(double *phinp1, double *phin, double *phinm1, 
            const double *lb, const double *ub, const double *stp,
            const int *size, double *bb, double dt, double dx, double dy)
{
  int i,j,Nx,Ny;

  Nx=size[0];
  Ny=size[1];
  for(i=1;i<Nx-1;i++)
    for(j=1;j<Ny-1;j++){
      *(phinp1 + Nx*j + i)=dt*dt*((*(phin + Nx*j + i+1) - 
                                  2* *(phin + Nx*j + i) +
                                  *(phin + Nx*j + i-1))/(dx*dx) +
                                  (*(phin + Nx*(j+1) + i) - 
                                  2* *(phin + Nx*j + i) +
                                  *(phin + Nx*(j-1) + i))/(dy*dy)) +
                           2* *(phin + Nx*j + i) -
                           *(phinm1 + Nx*j + i);
    }

		
	if(lb[1]==bb[2]){
		for(i=1;i<Nx-1;i++){
			*(phinp1 + i) = *(phin + i);
		}
	}
	if(lb[0]==bb[0]){
		for(j=1;j<Ny-1;j++){
			*(phinp1 + Nx*j) = *(phin + Nx*j);
		}
	}
	if(ub[1]==bb[3]){
		for(i=1;i<Nx-1;i++){
			*(phinp1 + Nx*(Ny-1) + i) = *(phin + Nx*(Ny-1) + i);
		}
	}
	if(ub[0]==bb[1]){
		for(j=1;j<Ny-1;j++){
			*(phinp1 + Nx*j + Nx-1) = *(phin + Nx*j + Nx-1);
		}
	}

}

void wout(FILE *fp, GridFunction(2)<double> &gf, int tc, int lev)
{
  int len,ret;
	int c,*size,i;
	double *dat,time;
	
	time=tc;
	forall(gf,tc,lev,c)
	  size=gf(tc,lev,c,DAGH_Main).extents();
		len=size[0]*size[1];
		dat=gf(tc,lev,c,DAGH_Main).data();
		
		fprintf(fp,"time: %d\n",tc);
		fprintf(fp,"size: (%d,%d)\n",size[0],size[1]);
    fprintf(fp,"data: %g\n",dat[0]);
		fprintf(fp,"\n");

	end_forall
}

void woutr(GridHierarchy &GH, GridFunction(2)<double> &gf, char *gfname, 
           double dt, int tc, int lev)
{
  int len,ret,rank;
	int c,*shape,i;
	double *data,time,bbox[6];
	double *lb, *ub;
	
	forall(gf,tc,lev,c)
	  time=tc*dt;
		data=gf(tc,lev,c,DAGH_Main).data();
		shape=gf(tc,lev,c,DAGH_Main).extents();
		rank=GH.rank;
		lb=GH.worldCoordsLower(gf(tc,lev,c,DAGH_Main).lower(),
		                       gf(tc,lev,c,DAGH_Main).stepsize());
		ub=GH.worldCoordsUpper(gf(tc,lev,c,DAGH_Main).upper(),
		                       gf(tc,lev,c,DAGH_Main).stepsize());
		for(i=0;i<rank;i++){
		  bbox[2*i]=lb[i];
			bbox[2*i+1]=ub[i];
		}
    gft_out_bbox(gfname,time,shape,rank,bbox,data);
	end_forall
}

#define IVEL 4

void main(int argc, char **argv)
{
  double bb[4],iargs[9],dt,dx,dy;
  int shape[2],lev,step,ot,iac,idt,tc;
  double amp;
  double cx;
  double cy;
  int iter;
  double lambda;
  int *output;
  double sx;
  double sy;
  double xmax;
  double xmin;
  double ymax;
  double ymin;
  double epsiter;
  int Nx;
  int Ny;
  char p_file[60];
  time_t st,ed;
  int fout;
	int me;
	char fname[10];
	FILE *fp;
	int VizServer=0;
  
#ifdef HAVE_LIBMPI
   cout << "Initializing MPI"<<endl;
   MPI_Init( &argc, &argv ); // Initialize MPI
#endif
  
  if(argc!=2){
    cout<<"Enter name of parameter file: ";
    cout.flush();
    cin>>p_file;
  }else strcpy(p_file,argv[1]);

  fout=1;
  output=new int[5];
  cout<<"Parameters:"<<endl;
  get_param(p_file,"amp",0,"double",1,&amp);
  cout<<"amp="<<amp<<endl;
  get_param(p_file,"cx",0,"double",1,&cx);
  cout<<"cx="<<cx<<endl;
  get_param(p_file,"cy",0,"double",1,&cy);
  cout<<"cy="<<cy<<endl;
  get_param(p_file,"sx",0,"double",1,&sx);
  cout<<"sx="<<sx<<endl;
  get_param(p_file,"sy",0,"double",1,&sy);
  cout<<"sy="<<sy<<endl;
  get_param(p_file,"iter",0,"long",1,&iter);
  cout<<"iter="<<iter<<endl;
  get_param(p_file,"fout",0,"long",1,&fout);
  cout<<"fout="<<fout<<endl;
  get_param(p_file,"lambda",0,"double",1,&lambda);
  cout<<"lambda="<<lambda<<endl;
  get_param(p_file,"output",0,"ivec",5,&output);
  cout<<"output=<"<<output[1]<<">-<"<<output[2]<<">/<"<<output[3]<<">"<<endl;
  get_param(p_file,"Nx",0,"long",1,&Nx);
  cout<<"Nx="<<Nx<<endl;
  get_param(p_file,"Ny",0,"long",1,&Ny);
  cout<<"Ny="<<Ny<<endl;
  get_param(p_file,"xmax",1,"double",1,&xmax);
  cout<<"xmax="<<xmax<<endl;
  get_param(p_file,"xmin",1,"double",1,&xmin);
  cout<<"xmin="<<xmin<<endl;
  get_param(p_file,"ymax",1,"double",1,&ymax);
  cout<<"ymax="<<ymax<<endl;
  get_param(p_file,"ymin",1,"double",1,&ymin);
  cout<<"ymin="<<ymin<<endl;
  get_param(p_file,"epsiter",1,"double",1,&epsiter);
  cout<<"epsiter="<<epsiter<<endl;

  bb[0]=xmin;
  bb[1]=xmax;
  bb[2]=ymin;
  bb[3]=ymax;
  shape[0]=Nx;
  shape[1]=Ny;

  GridHierarchy GH(2,NON_CELL_CENTERED,1);
  GH.DAGH_SetBaseGrid(bb, shape);
  GH.DAGH_ComposeHierarchy();
  GH.DAGH_IOType(DAGHIO_HDF_RNPL);

  BEGIN_COMPUTE

  GridFunction(2)<double> phi("phi",1,1,GH,DAGHComm,DAGHNoShadow);
//  phi.GF_SetBoundaryType(DAGHBoundaryConst);
//  phi.GF_SetBoundaryType(DAGHNoBoundary);

//  phi.GF_SetUpdateFunc(update);
//  phi.GF_SetInitFunc(initialize);
  
//  if(fout)
//	  DAGHIOInit();
  
	me=MY_PROC(GH);
	 
	fixup_ivec(0,iter,0,output);
  sprintf(fname,"phi_%d",me);
	 
  // set up parameters for update and initialize
  lev=0;
  tc=CurrentTime(GH,lev,DAGH_Main);
  idt=TimeStep(GH,lev,DAGH_Main);
  dx=DeltaX(GH,0,lev,DAGH_Main);
  dy=DeltaX(GH,1,lev,DAGH_Main);
  dt=dx*lambda;
  // Compute initial data
  forall(phi,tc,lev,c)
    initialize(FDA(phi(tc+idt,lev,c,DAGH_Main)),FDA(phi(tc,lev,c,DAGH_Main)),
               FDA(phi(tc-idt,lev,c,DAGH_Main)),WBA(GH,phi(tc,lev,c,DAGH_Main)),
               bb,dt,dx,dy,amp,cx,cy,sx,sy,epsiter);
  end_forall
  phi.GF_Sync(tc-idt,lev,DAGH_Main);
  phi.GF_Sync(tc+idt,lev,DAGH_Main);
  phi.GF_Sync(tc,lev,DAGH_Main);
  phi.GF_SwapTimeLevels(lev,tc+idt,tc-idt);
  phi.GF_SwapTimeLevels(lev,tc+idt,tc);
  step=0;
  cout<<"Starting evolution..."<<endl;
  if(do_ivec(step,iter,output)){
		cout<<"processor: "<<me<<" step: "<<step<<endl;
    if(fout)
//      phi.GF_Write(tc,lev,DAGH_Double);
//      wout(fp,phi,tc,lev);
      woutr(GH,phi,fname,dt,tc,lev);
//        writeslicehdf(DAGH_Main, fname, GH, phi, tc, lev,VizServer);
  }
    
  st=time(&st);
  for(step++;step<=iter;step++){
    tc=CurrentTime(GH,lev,DAGH_Main);
    idt=TimeStep(GH,lev,DAGH_Main);
    forall(phi,tc,lev,c)
      update(FDA(phi(tc+idt,lev,c,DAGH_Main)),FDA(phi(tc,lev,c,DAGH_Main)),
             FDA(phi(tc-idt,lev,c,DAGH_Main)),WBA(GH,phi(tc,lev,c,DAGH_Main)),
             bb,dt,dx,dy);
    end_forall

    phi.GF_Sync(tc+idt,lev,DAGH_Main);

//    phi.GF_BndryUpdate(tc,lev,DAGH_Main);
		
    if(do_ivec(step,iter,output)){
      cout<<"processor: "<<me<<" step: "<<step<<endl;
			if(fout)
//        phi.GF_Write(tc+idt,lev,DAGH_Double);
//        wout(fp,phi,tc+idt,lev);
      woutr(GH,phi,fname,dt,tc,lev);
//        writeslicehdf(DAGH_Main, fname, GH, phi, tc+idt, lev,VizServer);
    }
    phi.GF_CycleTimeLevels(lev);
    GH.incrCurrentTime(lev,DAGH_Main);
  }
  ed=time(&ed);
  cout<<"processor: "<<me<<" Elapsed: "<<ed-st<<" sec"<<endl;
//  if(fout)
//    GH.DAGH_IOEnd();
		
  END_COMPUTE
#ifdef HAVE_LIBMPI
  DAGHMPI_Finalize();
#endif
  if(fout)
    gft_close_all();
//    fclose(fp);
}

