/*
*************************************************************************
* SimpleBucketVoid.C                           				*
*                              						*
*************************************************************************
*/

#include "SimpleBucketVoid.h"

#define MINALLOC (1)

static inline unsigned int max(const unsigned int a, const unsigned int b)
  { return((a > b) ? a : b); }

bkt::bkt(unsigned short const blksize, unsigned short const nblks)
	: head(0)
  {
   char *chunk, *end;
   assert ((chunk = new char[blksize*nblks]) != (char *) 0);

#ifdef DEBUG_PRINT_BKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(char)*blksize*nblks);
#endif

   end = chunk+(nblks-1)*blksize;

   char *p = chunk;
   /* Fill bkthdr */
   { 
     ((union record *) p)->bhdr.blksize = blksize;
     ((union record *) p)->bhdr.nblks = nblks;
     ((union record *) p)->bhdr.headoff = (unsigned short) 1;
     ((union record *) p)->bhdr.tailoff = NullRec;
     ((union record *) p)->bhdr.freeoff = 1;
     ((union record *) p)->bhdr.cnt = 0;
   }

   p += blksize;
   /* Set record ptrs */
   {
     register unsigned i = 1;
     for (; p < end; p += blksize,i++) {
	((union record *) p)->hdr.mysize = 0;
	((union record *) p)->hdr.myoff = (unsigned short) i;
	((union record *) p)->hdr.noff = (unsigned short) i+1;
	((union record *) p)->hdr.poff = (unsigned short) i-1;
        ((union record *) p)->hdr.head = (pointer) chunk;
        ((union record *) p)->link.next = (unsigned short) i+1;
     }
     ((union record *) end)->hdr.mysize = 0;
     ((union record *) end)->hdr.myoff = (unsigned short) i;
     ((union record *) end)->hdr.noff = NullRec;
     ((union record *) end)->hdr.poff = (unsigned short) i-1;
     ((union record *) end)->hdr.head = (pointer) chunk;
     ((union record *) end)->link.next = NullRec;
   }

   head = (union record *) chunk;
  }

bkt::bkt(struct bkt const &other)
	: head(0)
  {
   unsigned short bsize = other.head->bhdr.blksize;
   unsigned short nb = other.head->bhdr.nblks;

   char *ochunk, *nchunk, *end;
   assert ((nchunk = new char[bsize*nb]) != (char *) 0);

#ifdef DEBUG_PRINT_BKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(char)*bsize*nb);
#endif

   end = nchunk+(nb-1)*bsize;
   ochunk = (char *) other.head;

   //for (register int j=0;j<nb*bsize;j++)
   //   nchunk[j] = ochunk[j];
   memcpy ((void *)nchunk, (void *)ochunk, nb*bsize);

   char *p = (char *) (nchunk + bsize);
   /* set record headers */
   for (; p < end; p += bsize) {
     ((union record *) p)->hdr.head = (pointer) nchunk;
   }
   ((union record *) end)->hdr.head = (pointer) nchunk;

   head = (union record *) nchunk;
  }

bkt::bkt(union record const *hdr)
	: head(0)
  {
   unsigned short bsize = hdr->bhdr.blksize;
   unsigned short nb = hdr->bhdr.nblks;

   char *ochunk, *nchunk, *end;
   assert ((nchunk = new char[bsize*nb]) != (char *) 0);

#ifdef DEBUG_PRINT_BKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(char)*bsize*nb);
#endif

   end = nchunk+(nb-1)*bsize;
   ochunk = (char *) hdr;

   //for (register int j=0;j<nb*bsize;j++)
   //   nchunk[j] = ochunk[j];
   memcpy ((void *)nchunk, (void *)ochunk, nb*bsize);

   char *p = (char *) (nchunk + bsize);
   /* set record headers */
   for (; p < end; p += bsize) {
     ((union record *) p)->hdr.head = (pointer) nchunk;
   }
   ((union record *) end)->hdr.head = (pointer) nchunk;

   head = (union record *) nchunk;
  }

bkt::bkt(union record *hdr)
	: head(0)
  {
   unsigned short nb = hdr->bhdr.nblks;
   unsigned short bsize = hdr->bhdr.blksize;

   /*** This is probably redundant ***/
   char *chunk = (char *) hdr;

#ifdef DEBUG_PRINT_BKT_MEMORY
   DAGHMemoryTrace::alloc(sizeof(char)*bsize*nb);
#endif

   char *end = chunk+(nb-1)*bsize;
   char *p = (char *) (chunk + bsize);

   /* set record headers */
   for (; p < end; p += bsize) 
     { ((union record *) p)->hdr.head = (pointer) chunk; }
   ((union record *) end)->hdr.head = (pointer) chunk;
   /*** ************************* ***/

   head = (union record *) chunk;
  }

SimpleBucketVoid::SimpleBucketVoid(unsigned short const size, 
						unsigned short const num)
        : blksize(0), nblks(0), bktptr(0), freeoff(0)
  {
   assert(num < FullBkt);

   /* const unsigned int block = size + 
		max(sizeof(struct bkthdr),sizeof(struct rechdr)); */
   /* sizeof(struct rechdr) > sizeof(struct bkthdr) */
   const unsigned int block = size + sizeof(struct rechdr);

   const unsigned int align = ((size > 8) ? 16 : ((size > 4) ? 8 : 4));
   blksize = (block+align-1) & (~(align-1));

   /* number of blocks in bkt = bktheader + num */
   nblks = 1 + max(num, MINALLOC);

   bktptr = new struct bkt(blksize,nblks);
   freeoff = 1;
  }

SimpleBucketVoid::SimpleBucketVoid(SimpleBucketVoid const &other)
        : blksize(0), nblks(0), bktptr(0), freeoff(0)
  {
   bktptr = new struct bkt(*other.bktptr);   
   blksize = other.blksize;
   nblks = other.nblks;
   freeoff = other.freeoff;
  }

SimpleBucketVoid::SimpleBucketVoid(union record const *hdr)
        : blksize(0), nblks(0), bktptr(0), freeoff(0)
  {
   blksize = hdr->bhdr.blksize;
   nblks = hdr->bhdr.nblks;
   bktptr = new struct bkt(hdr);   
   freeoff = (unsigned short) bktptr->head->bhdr.freeoff;
  }

SimpleBucketVoid::SimpleBucketVoid(union record const *hdr, 
					unsigned const size, int const n)
        : blksize(0), nblks(0), bktptr(0), freeoff(0)
  {
   blksize = hdr->bhdr.blksize;
   nblks = hdr->bhdr.nblks;
   bktptr = new struct bkt(hdr);   
   freeoff = (unsigned short) bktptr->head->bhdr.freeoff;

   for (register int i=1; i<n;i++) {
     union record *nhdr = (union record *)((char const *)(hdr)+i*size);
     unsigned short bsize = nhdr->bhdr.blksize;
     register union record *rec = 
	(union record *) ((char *)(nhdr)+(bsize*nhdr->bhdr.headoff));
     for (register int j=0; j<nhdr->bhdr.cnt; j++) {
       addrec(rec);
       rec = (union record *) ((char *)(nhdr)+(bsize*rec->hdr.noff));
     }
   }
  }

SimpleBucketVoid::SimpleBucketVoid(union record *hdr)
        : blksize(0), nblks(0), bktptr(0), freeoff(0)
  {
   blksize = hdr->bhdr.blksize;
   nblks = hdr->bhdr.nblks;
   bktptr = new struct bkt(hdr);   
   freeoff = (unsigned short) bktptr->head->bhdr.freeoff;
  }

void SimpleBucketVoid::allocbkt(int const incr)
  {
   struct bkt *b = new struct bkt(blksize,nblks+incr);
   register union record *tr = bktGetHeadRec(bktptr->head);
   for (;tr;tr=nextrec(tr)) bktaddrec(b->head,tr);
   freeoff = bktGetfreeoff(b->head);
   delete bktptr;
   bktptr = b;
   nblks = nblks+incr;
  }

union record *SimpleBucketVoid::bktaddrec(union record *bhead)
  {
   assert(bktGetfreeoff(bhead) != NullRec);

   union record *rec = bktGetFreeRec(bhead);
   bktSettailoff(bhead,rec->hdr.myoff);
   bktSetfreeoff(bhead,rec->link.next);
   bktIncrcnt(bhead);
   rec->hdr.mysize = 1;
   return(rec);
  }

void SimpleBucketVoid::bktaddfree(union record *bhead, union record *rec)
  {
   if ((rec->link.noff = rec->link.next = bktGetfreeoff(bhead)) != NullRec) {
     register union record *fr = bktGetFreeRec(bhead);
     if ((rec->link.poff = fr->hdr.poff) != NullRec) 
       (recPrevRec(fr))->hdr.noff = rec->link.myoff;
     fr->hdr.poff = rec->link.myoff;
   }
   bktSetfreeoff(bhead,rec->hdr.myoff);
   rec->hdr.mysize = 0;
   bktDecrcnt(bhead);
  }

union record *SimpleBucketVoid::addrec(void)
  {
   if (freeoff == NullRec) allocbkt();

   register union record *hd = bktptr->head;
   union record *rec = bktGetFreeRec(hd);
   bktSettailoff(hd,rec->hdr.myoff);
   bktSetfreeoff(hd,rec->link.next);
   bktIncrcnt(hd);
   rec->hdr.mysize = 1;

   freeoff = rec->link.next;

   assert (rec != 0);
   return(rec);
  }

union record *SimpleBucketVoid::insertrec(union record *after)
  {

   if (after == tailrec() || count() == 0) 
	{ return ( addrec() ); }

   union record *rec = 0;

   if (freeoff == NullRec) { 
     struct bkt *b = new struct bkt(blksize,nblks+DefIncrement);
     register union record *tr = bktGetHeadRec(bktptr->head);
     if (after == 0) rec = bktaddrec(b->head);
     for (;tr;tr=nextrec(tr)) {
       bktaddrec(b->head,tr);
       if (tr == after) {
         assert (rec == 0);
         rec = bktaddrec(b->head);
       }
     }
     if (rec == 0) rec = bktaddrec(b->head);
     freeoff = bktGetfreeoff(b->head);
     delete bktptr;
     bktptr = b;
     nblks = nblks+DefIncrement;
     assert (rec != 0);
     return (rec);
   }

   rec = addrec();

   if(rec->hdr.poff != NullRec)
     (recPrevRec(rec))->hdr.noff = rec->hdr.noff;
   if(rec->hdr.noff != NullRec)
     (recNextRec(rec))->hdr.poff = rec->hdr.poff;

   bktSettailoff(bktptr->head,rec->hdr.poff);

   if( after != recordNULL) {
     rec->hdr.poff = after->hdr.myoff;
     rec->hdr.noff = after->hdr.noff;
     if(after->hdr.noff != NullRec)
       (recNextRec(after))->hdr.poff = rec->hdr.myoff;
     after->hdr.noff = rec->hdr.myoff;
   }
   else { /* Insert at head of the list */
     union record *hrec = headrec();
     rec->hdr.poff = 0;
     rec->hdr.noff = hrec->hdr.myoff;
     hrec->hdr.poff = rec->hdr.myoff;
     bktSetheadoff(bktptr->head,rec->hdr.myoff);
   }
   assert (rec != 0);
   return(rec);
  }

void SimpleBucketVoid::removerec(union record *rec)
  {
   register union record *hd = (union record *)(rec->hdr.head);

   rec->hdr.mysize = 0;

   // delete block from the list
   if (rec->hdr.poff != NullRec)
     (recPrevRec(rec))->hdr.noff = rec->hdr.noff;
   if (rec->hdr.noff != NullRec)
     (recNextRec(rec))->hdr.poff = rec->hdr.poff;

   // if I am the head of the bucket....
   if (bktGetheadoff(hd) == rec->hdr.myoff && hd->bhdr.cnt > 1) 
     bktSetheadoff(hd,rec->hdr.noff);

   // if I am the tail of the bucket....
   //if (bktGettailoff(hd) == rec->hdr.myoff && hd->bhdr.cnt > 1) 
   if (bktGettailoff(hd) == rec->hdr.myoff)
     bktSettailoff(hd,rec->hdr.poff);

   // add block to buckets local free list
   if ( (rec->link.noff = rec->link.next = bktGetfreeoff(hd)) != NullRec) {
     register union record *fr = bktGetFreeRec(hd);
     if ((rec->link.poff = fr->hdr.poff) != NullRec) 
       (recPrevRec(fr))->hdr.noff = rec->link.myoff;
     fr->hdr.poff = rec->link.myoff;
   }
   else if ( (rec->link.poff = rec->link.poff = bktGettailoff(hd)) != NullRec) {
     register union record *tr = bktGetTailRec(hd);
     tr->hdr.noff = rec->link.myoff;
   }

   bktSetfreeoff(hd,rec->hdr.myoff);
   freeoff = rec->hdr.myoff;
   bktDecrcnt(hd);
 }

void SimpleBucketVoid::pack(void *&package, int &size)
  {
    size = blksize*nblks;
    bktptr->head->rec.data[0] = (unsigned) size;
    package = (void *) bktptr->head;
  }

void *SimpleBucketVoid::pack(int &size)
  {
    union record *tmppkg = bktptr->head;
    size = blksize*nblks;
    tmppkg->rec.data[0] = (unsigned) size;
    return ( (void *)tmppkg );
  }

void SimpleBucketVoid::pack(void *&package, unsigned &size)
  {
    size = blksize*nblks;
    bktptr->head->rec.data[0] = size;
    package = (void *) bktptr->head;
  }

void *SimpleBucketVoid::pack(unsigned &size)
  {
    union record *tmppkg = bktptr->head;
    size = blksize*nblks;
    tmppkg->rec.data[0] = size;
    return ( (void *)tmppkg );
  }

void SimpleBucketVoid::emptybkt(void)
  {
    if (bktptr->head->bhdr.cnt == 0) return;

    register union record *tmprec = headrec();
    for (;tmprec;tmprec=nextrec(tmprec)) {
      tmprec->hdr.mysize = 0;
      tmprec->link.next = tmprec->link.noff;
    }
    bktptr->head->bhdr.tailoff = NullRec;
    bktptr->head->bhdr.freeoff = bktptr->head->bhdr.headoff;
    bktptr->head->bhdr.cnt = 0;
  
    freeoff = bktptr->head->bhdr.freeoff;
  }

void SimpleBucketVoid::splitbkt(SimpleBucketVoid &sbv, union record *atrec)
  {
   if (atrec == recordNULL || 
	bktGetheadoff((union record *)atrec->hdr.head) == atrec->hdr.myoff)  
     {
      sbv.blksize = blksize;
      sbv.nblks = nblks;
      sbv.freeoff = freeoff;
      if (sbv.bktptr != 0) delete sbv.bktptr;
      //sbv.bktptr = new struct bkt(*bktptr);
      sbv.bktptr = bktptr;

      struct bkt *nbkt = new struct bkt(blksize,nblks);
      //delete bktptr;
      bktptr = nbkt;
      freeoff = nbkt->head->bhdr.freeoff;
     }
   else 
     {
      struct bkt *nbkt = new struct bkt(blksize,nblks);
      register union record *nhd = (union record *)(nbkt->head);
      register union record *pr = recPrevRec(atrec);
      register union record *tmprec;
      for (tmprec=atrec;tmprec;tmprec=nextrec(pr)) {
        bktaddrec(nhd,tmprec);
        removerec(tmprec);
      }

      sbv.blksize = blksize;
      sbv.nblks = nblks;
      sbv.freeoff = nbkt->head->bhdr.freeoff;
      if (sbv.bktptr != 0) delete sbv.bktptr;
      sbv.bktptr = nbkt;
     }
  }

ostream& operator<<(ostream& os, struct bkt& b)
  {
   if (&b == bktNULL) return os;

   os << "Bucket [";
   os << b.head->bhdr.blksize << " ";
   os << b.head->bhdr.nblks << " ";
   os << b.head->bhdr.headoff << " ";
   os << b.head->bhdr.tailoff << " ";
   os << b.head->bhdr.freeoff << " ";
   os << b.head->bhdr.cnt << " ";
   os << "]";

   return os;
  }

ostream& operator<<(ostream& os, union record& r)
  {
   if (&r == recordNULL) return os;

   os << "Record [";
   os << r.hdr.mysize << " ";
   os << r.hdr.myoff << " ";
   os << r.hdr.noff << " ";
   os << r.hdr.poff << " ";
   os << r.hdr.head << " ";
   os << "]";

   return os;
  }

ostream&  operator << (ostream& os, SimpleBucketVoid& sbv)
  {
   if (&sbv == SimpleBucketVoidNULL) return os;

   os << "BlkSize:" << sbv.blksize << " ";
   os << "NumBlks:" << sbv.nblks << " ";
   os << "FreeOff:" << sbv.freeoff << " ";
   os <<  "\n";

   os << *sbv.bktptr;
   os << "\n**********************************\n";
   
   union record *r = sbv.bktGetHeadRec(sbv.bktptr->head);
   while ( r != recordNULL ) {
        os << *r;
        os << "\n**********************************\n";
        os << flush;
        r=sbv.recNextRec(r);
   }
   return os;
  }
