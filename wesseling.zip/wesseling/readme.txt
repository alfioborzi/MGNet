MGLAB.FOR is a tutorial multigrid program.
It solves elliptic boundary values in one dimension.
The user may choose various multigrid cycles, transfer operators, 
smoothing
methods, and nested iteration end defect correction. 

Cell-centered and vertex-centered discretization and 
multigrid is included.
Documentation is included in the program.
The program is written in portable FORTRAN-77, 
and has run on MS-DOS PC's 
and Unix mainframes. The methods used are fully 
described in the following book:
An Introduction to Multigrid Methods, Wiley, Chichester, 
1992 by P.Wesseling. MGLAB.FOR is the FORTRAN source of the 
tutorial multigrid program.
MGLAB.DAT is an example of an 
input file.MGLAB.RES is the corresponding output.