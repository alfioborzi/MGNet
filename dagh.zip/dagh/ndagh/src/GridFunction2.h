#ifndef _included_GridFunction2_h
#define _included_GridFunction2_h

/*
*************************************************************************
*                                                                       *
* GridFunction2.h                                                       *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "GridData2.h"
#include "GridDataBlock2.h"
#include "DAGHUCD.h"

#ifndef GridFunctionName
#define GridFunction(dim)      name2(GridFunction,dim)
#define GridFunctionName
#endif

#include "GFIterator.h"

template <class DAGH_GFType>
class GridFunction(2) : public GridFunctionVoid
  {
public:
   GridData(2)<DAGH_GFType>& operator()(GDIterator(2)<DAGH_GFType>& gfi,
	int main_or_shadow) {
	return operator()(gfi.time(),gfi.level(),gfi.component(),
		main_or_shadow);
  }
private:
   friend ostream& operator<<(ostream&, const GridFunction(2)<DAGH_GFType>&);
   friend class GridHierarchy;

   /* data storage */
   short length;
   GridDataBlock(2)<DAGH_GFType> ****gdb;

   /* Boundary Value - default is 0 */
   DAGH_GFType bvalue;

#define GF_TYPE DAGH_GFType
#include "GridFunctionInterface.h"

   /* Initialization Function */
   InitFunc ifunc;

   /* Update Functions */
   UpdateFunc ufunc;

   /* Boundary Update Functions */
   BndryUpdateFunc bfunc;
   AdptBndryUpdateFunc abfunc;

   /* Prolongation/Restriction Functions */
   ProlongFunc pfunc;
   RestrictFunc rfunc;

   /* I/O Function */
   IOFunc iofunc;

   /*****************************************************************************/
   /* Disable assignments */
   /*****************************************************************************/
private:
   GridFunction(2)(const GridFunction(2)<DAGH_GFType>&);
   const GridFunction(2)<DAGH_GFType>& operator= 
                        (const GridFunction(2)<DAGH_GFType>&);
   /*****************************************************************************/

   /*****************************************************************************/
   /* Constructors.... */
   /*****************************************************************************/
public:
   GridFunction(2)(char const name[], 
		   GridHierarchy &gh);

   /* For backward compatibility */
   GridFunction(2)(const char name[], 
                   const int t_sten, 
                   const int s_sten, 
		   GridHierarchy &gh,
                   const int cflag = DAGHComm,
                   const int sflag = DAGHNoShadow,
		   const int extghflag = DAGHNoExternalGhost);

   GridFunction(2)(const char name[], 
                   const int t_sten, 
                   const int s_sten, 
		   GridHierarchy &gh,
                   const int type, 
                   const int cflag,
                   const int sflag,
                   const int bflag,
		   const int adptbflag,
		   const int extghflag = DAGHNoExternalGhost); 

   GridFunction(2)(const char name[], 
                   const int t_sten, 
                   const int* s_sten, 
		   GridHierarchy &gh,
                   const int type, 
                   const int cflag,
                   const int sflag,
                   const int bflag,
		   const int adptbflag,
		   const int extghflag = DAGHNoExternalGhost);

   /* Add one to set the alignment when rank < dagh.rank */
   GridFunction(2)(const char name[], 
                   const int t_sten, 
                   const int s_sten, 
		   GridHierarchy &gh,
                   const int type, 
                   const int align, 
                   const int cflag,
                   const int sflag,
                   const int bflag,
		   const int adptbflag,
		   const int extghflag);

   GridFunction(2)(const char name[], 
                   const int t_sten, 
                   const int* s_sten, 
		   GridHierarchy &gh,
                   const int type, 
                   const int align, 
                   const int cflag,
                   const int sflag,
                   const int bflag,
		   const int adptbflag,
		   const int extghflag);

   /* a particular time and level */ 
   GridFunction(2)(const char name[], 
                   const int t_sten, 
                   const int s_sten, 
                   const int time,
                   const int level,
		   GridHierarchy &gh,
                   const int type,
                   const int cflag,
                   const int sflag,
                   const int bflag,
		   const int adptbflag,
		   const int extghflag = DAGHNoExternalGhost);

   GridFunction(2)(const char name[], 
                   const int t_sten, 
                   const int* s_sten, 
                   const int time,
                   const int level,
		   GridHierarchy &gh,
                   const int type,
                   const int cflag,
                   const int sflag,
                   const int bflag,
		   const int adptbflag,
		   const int extghflag = DAGHNoExternalGhost);

   /* From another GridFunction */
   GridFunction(2)(const char name[], 
                   const GridFunction(2)<DAGH_GFType>& gf,
                   const int time,
                   const int level,
                   const int cflag,
                   const int sflag,
                   const int bflag,
		   const int adptbflag,
		   const int extghflag = DAGHNoExternalGhost);
   /*****************************************************************************/

   /*****************************************************************************/
   /* Destructor */
   /*****************************************************************************/
public:
   ~GridFunction(2)();
   /*****************************************************************************/

   /*****************************************************************************/
   /* Delete Comm Info */
   /*****************************************************************************/
private:
   void GF_DeleteGDBStorage();
   void GF_DeleteGDBStorage(const int t);
   void GF_DeleteGhostCommInfo();
   void GF_DeleteDataCommInfo();
   /*****************************************************************************/

   /*****************************************************************************/
   /* Compose & Recompose */
   /*****************************************************************************/
private:
   void GF_Compose();
   void GF_Compose(const int T, const int L);
   void GF_Compose(const GridFunction(2)<DAGH_GFType>& gf, 
                   const int T, const int L);


   void GF_Recompose(const int omindex, const GridUnitList& ollist,
                     GridUnitList& rlist, GridUnitList& slist, GridUnitList& olist);
   /*****************************************************************************/

   /*****************************************************************************/
   /* For checkpointing */
   /*****************************************************************************/
   void GF_CheckpointRecompose();
   void GF_Checkpoint(ofstream& ofs);
   void GF_CheckpointRestart();

   /*****************************************************************************/

   /*****************************************************************************/
   /* Set Up Ghost Comm Servers */
   /*****************************************************************************/
private:
   void GF_SetUpGhostCommServers();
   /*****************************************************************************/

   /*****************************************************************************/
   /**** Gather Ghost Communication Info ****/
   /*****************************************************************************/
private:
   void GF_GatherGhostCommInfo();
   /*****************************************************************************/

   /*****************************************************************************/
   /* Set Functions */
   /*****************************************************************************/
public:
   inline void GF_SetInitFunc(void* initf) 
     { ifunc = (InitFunc) initf; }
   inline void GF_SetUpdateFunc(void* uf) 
     { ufunc = (UpdateFunc) uf; }
   inline void GF_SetBndryUpdateFunc(void* bf) 
     { bfunc = (BndryUpdateFunc) bf; }
   inline void GF_SetAdaptiveBndryUpdateFunc(void* abf) 
     { abfunc = (AdptBndryUpdateFunc) abf; }
   inline void GF_SetProlongFunc(void* pf) 
     { pfunc = (ProlongFunc) pf; }
   inline void GF_SetRestrictFunc(void* rf) 
     { rfunc = (RestrictFunc) rf; }
   inline void GF_SetIOFunc(void* iof) 
     { iofunc = (IOFunc) iof; }
   /*****************************************************************************/

   /*****************************************************************************/
   /* Query function status */
   /*****************************************************************************/
public:
   inline int has_initfunc()
     { return (ifunc != (InitFunc) 0); }
   inline int has_updatefunc()
     { return (ufunc != (UpdateFunc) 0); }
   inline int has_bndryupdatefunc()
     { return (bfunc != (BndryUpdateFunc) 0); }
   inline int has_adaptivebndryupdatefunc()
     { return (abfunc != (AdptBndryUpdateFunc) 0); }
   inline int has_prolongfunc()
     { return (pfunc != (ProlongFunc) 0); }
   inline int has_restrictrunc() 
     { return (rfunc != (RestrictFunc) 0); }
   inline int has_iofunc() 
     { return (iofunc != (IOFunc) 0); }
   /*****************************************************************************/

   /*****************************************************************************/
   /* Set boundary value */
   /*****************************************************************************/
public:
   inline void GF_SetBoundaryValue(const DAGH_GFType value) 
     { bvalue = value; }
   /*****************************************************************************/

   /*****************************************************************************/
   /* Swap storage for time levels */
   /*****************************************************************************/
public:
   void GF_SwapTimeLevels(const int l, const int t1, const int t2);
   void GF_CycleTimeLevels(const int l);
   /*****************************************************************************/

   /*****************************************************************************/
   /* Queries.... */
   /*****************************************************************************/
public:
   inline int len() const { return (length); }

   inline int comm() const { return (comm_flag != DAGHNoComm); }
   inline int comm(const int t, const int l) const
        { return (comm_flag!=DAGHNoComm) &&
                 (comm_flag!=DAGHCommCurrentTimeOnly ||
                  t==dagh_timeindex(dagh.getCurrentTime(l),l)); }

   inline GridDataBlock(2)<DAGH_GFType>& mygdb(const int t, 
                                               const int l, 
                                               const int c) 
        { return (*gdb[dagh_timeindex(t,l)][l][c]); }

   inline int exists(const int t, const int l, const int c) const
	{ return (gdb[dagh_timeindex(t,l)][l][c] != 
                  (GridDataBlock(2)<DAGH_GFType> *)NULL); }
   /*****************************************************************************/

   /*****************************************************************************/
   /* set/get current time */
   /*****************************************************************************/
public:
   inline int GF_CurrentTime(int const lev, 
			     const int ident=DAGH_Main) const
     { return curtime[dagh.daghindex(ident)][lev] ; }
   inline void GF_SetCurrentTime(const int ctime, const int lev, 
                                 const int ident=DAGH_Main)
     { curtime[dagh.daghindex(ident)][lev] = ctime; }
   inline void GF_IncrCurrentTime(const int lev, 
				  const int ident=DAGH_Main)
     { curtime[dagh.daghindex(ident)][lev] += dagh.timestep(lev,ident); }

   inline int GF_PreviousTime(const int lev, 
			      const int ident=DAGH_Main) const
     { return curtime[dagh.daghindex(ident)][lev] - 
	 dagh.timestep(lev,ident); }
   inline int GF_NextTime(const int lev, 
			  const int ident=DAGH_Main) const
     { return curtime[dagh.daghindex(ident)][lev] +
	 dagh.timestep(lev,ident); }

private:
   inline int gf_timevalue(const int t, const int l, 
			   const int ident=DAGH_Main) const
   { return ((t-time_sten_rad)*dagh.timestep(l,ident) +
              curtime[dagh.daghindex(ident)][l]); }

   inline int gf_timeindex(const int t, const int l, 
			   const int ident=DAGH_Main) const
   { return (time_alias[((t-curtime[dagh.daghindex(ident)][l])/dagh.timestep(l,ident))
                        + time_sten_rad]); }
   /*****************************************************************************/

   /*****************************************************************************/
   /* time queries based on DAGH current time information */
   /*****************************************************************************/
public:
   inline int dagh_timevalue(const int t, const int l, 
			     const int ident=DAGH_Main) const
   { return ((t-time_sten_rad)*dagh.timestep(l,ident) + 
	     dagh.getCurrentTime(l,ident)); }

   inline int dagh_timeindex(const int t, const int l, 
			     const int ident=DAGH_Main) const
   { return (time_alias[((t-dagh.getCurrentTime(l,ident))/dagh.timestep(l,ident))
                        + time_sten_rad]); }
   /*****************************************************************************/

   /*****************************************************************************/
   /* Data Updates */
   /*****************************************************************************/
private:
   void GF_ReadData(const int time);
   void GF_ReadData(const int time, const int level);
   void GF_ReadData(const int time, GridData(2)<DAGH_GFType>& into);
   /*****************************************************************************/
    
   /*****************************************************************************/
   /* Ghost Region Updates */
   /*****************************************************************************/
private:
   void GF_InterpGhosts(const int time, const int level,
                        const int mgl,
                        const int ident);
   void GF_InterpGhosts(const int time, const int level,
                        const int mgl,
                        const int axis, const int dir,
                        const int ident);

public:
   void GF_WriteGhosts(const int time, const int level, 
                       const int ident);
   void GF_WriteGhosts(const int time, const int level, 
                       const int mgl,
                       const int ident);
   void GF_WriteGhosts(const int time, const int level, 
                       const int axis, const int dir,
                       const int ident);
   void GF_WriteGhosts(const int time, const int level, 
                       const int mgl,
                       const int axis, const int dir,
                       const int ident);
   inline void GF_WriteGhosts(const int time, const int level)
     { GF_WriteGhosts(time, level, DAGH_Main); }

   void GF_ReadGhosts(const int time, const int level, 
                      const int ident);
   void GF_ReadGhosts(const int time, const int level, 
                      const int mgl,
                      const int ident);
   void GF_ReadGhosts(const int time, const int level, 
                      const int axis, const int dir,
                      const int ident);
   void GF_ReadGhosts(const int time, const int level, 
                      const int mgl,
                      const int axis, const int dir,
                      const int ident);
   inline void GF_ReadGhosts(const int time, const int level)
     { GF_ReadGhosts(time, level, DAGH_Main); }

public:
   inline void GF_Sync(const int time, const int level)
   { 
     GF_WriteGhosts(time,level); 
     GF_ReadGhosts(time,level); 
   }

   inline void GF_Sync(const int time, const int level, 
                       const int ident)
   { 
     GF_WriteGhosts(time,level,ident); 
     GF_ReadGhosts(time,level,ident); 
   }

   inline void GF_Sync(const int time, const int level, 
                       const int mgl, const int ident)
   { 
     GF_WriteGhosts(time,level,mgl,ident); 
     GF_ReadGhosts(time,level,mgl,ident); 
   }

   inline void GF_Sync(const int time, const int level, 
                       const int axis, const int dir,
                       const int ident)
   { 
     GF_WriteGhosts(time,level,axis,dir,ident); 
     GF_ReadGhosts(time,level,axis,dir,ident); 
   }

   inline void GF_Sync(const int time, const int level, 
                       const int mgl,
                       const int axis, const int dir,
                       const int ident)
   { 
     GF_WriteGhosts(time,level,mgl,axis,dir,ident); 
     GF_ReadGhosts(time,level,mgl,axis,dir,ident); 
   }
   /*****************************************************************************/

   /*****************************************************************************/
   /* Use predefined functions */
   /*****************************************************************************/
public:
   void GF_Init(const int time, const int level, 
		GF_TYPE *args, const int cnt, const int ident=DAGH_Main);
   void GF_Init(const int time, const int level, 
		const BBox &bb,
		GF_TYPE *args, const int cnt, const int ident=DAGH_Main);

   void GF_Update(const int time_from, const int time_to, const int level, 
		GF_TYPE *args, const int cnt, const int ident=DAGH_Main);
   void GF_Update(const int time_from, const int time_to, const int level, 
                const BBox &bb,
		GF_TYPE *args, const int cnt, const int ident=DAGH_Main);

   void GF_Prolong(const int tf, const int lf, const int tt, const int lt, 
		GF_TYPE *args, const int cnt, const int ident=DAGH_Main);
   void GF_Prolong(const int tf, const int lf, const int tt, const int lt, 
                const BBox &bb,
		GF_TYPE *args, const int cnt, const int ident=DAGH_Main);

   void GF_Restrict(const int tf, const int lf, const int tt, const int lt, 
		GF_TYPE *args, const int cnt, const int ident=DAGH_Main);
   void GF_Restrict(const int tf, const int lf, const int tt, const int lt, 
                const BBox &bb,
		GF_TYPE *args, const int cnt, const int ident=DAGH_Main);

   void GF_IO(const int time, const int level, 
		GF_TYPE *args, const int cnt, const int ident=DAGH_Main);
   void GF_IO(const int time, const int level, 
		const BBox &bb,
		GF_TYPE *args, const int cnt, const int ident=DAGH_Main);
   /*****************************************************************************/

   /*****************************************************************************/
   /* Boundary updates */
   /*****************************************************************************/
   void GF_BndryUpdate(const int t, const int l, const int ident=DAGH_Main);
   void GF_BndryUpdate(const int t, const int l, const int mgl, 
                       const int ident);

   void GF_DoAdaptBndryUpdate(GridDataBlock(2)<DAGH_GFType> &,
			      GridDataBlock(2)<DAGH_GFType> &,
			      GridDataBlock(2)<DAGH_GFType> &,
			      const double,
			      const int);

   void GF_DoAdaptBndryUpdate(GridDataBlock(2)<DAGH_GFType> &,
			      GridDataBlock(2)<DAGH_GFType> &,
			      GridDataBlock(2)<DAGH_GFType> &,
			      const double,
			      const int,
			      const int);
   /*****************************************************************************/

   /*****************************************************************************/
   /* Query boundary info */
   /*****************************************************************************/
   short boundary_flag(const int t, const int l, const int c, 
			   const int dir) const
	{ return (gdb[dagh_timeindex(t,l)][l][c]->bndryflags[dir]); }

   const short* boundary_flag(const int t, const int l, const int c) const
	{ return (gdb[dagh_timeindex(t,l)][l][c]->bndryflags); }
   /*****************************************************************************/

   /*****************************************************************************/
   /* Queries */
   /*****************************************************************************/
   inline const BBox& databbox(const int t, const int l, const int c, 
			const int ident=DAGH_Main) const
	{ return (gdb[dagh_timeindex(t,l)][l][c]->boundingbox(ident)); }
   inline BBox databbox(const int t, const int l, const int c,
			const int ident=DAGH_Main)
	{ return (gdb[dagh_timeindex(t,l)][l][c]->boundingbox(ident)); }

   inline const BBox& databbox(const int t, const int l, const int c, 
			const int mgl, const int ident) const
        { return (gdb[dagh_timeindex(t,l)][l][c]->boundingbox(ident,mgl)); }
   inline BBox databbox(const int t, const int l, const int c, 
			const int mgl, const int ident)
        { return (gdb[dagh_timeindex(t,l)][l][c]->boundingbox(ident,mgl)); }

   inline const BBox& interiorbbox(const int t, const int l, const int c, 
			const int ident=DAGH_Main) const
	{ return (gdb[dagh_timeindex(t,l)][l][c]->interiorbox(ident)); }
   inline BBox interiorbbox(const int t, const int l, const int c,
			const int ident=DAGH_Main)
	{ return (gdb[dagh_timeindex(t,l)][l][c]->interiorbox(ident)); }

   inline const BBox& interiorbbox(const int t, const int l, const int c, 
			const int mgl, const int ident) const
        { return (gdb[dagh_timeindex(t,l)][l][c]->interiorbox(ident,mgl)); }
   inline BBox interiorbbox(const int t, const int l, const int c, 
			const int mgl, const int ident)
        { return (gdb[dagh_timeindex(t,l)][l][c]->interiorbox(ident,mgl)); }

   inline const BBox& bndrybbox(const int t, const int l, const int c, 
			const int dir, const int ident=DAGH_Main) const
	{ return (gdb[dagh_timeindex(t,l)][l][c]->bndrybox(dir,ident)); }
   inline BBox bndrybbox(const int t, const int l, const int c,
			 const int dir, const int ident=DAGH_Main)
	{ return (gdb[dagh_timeindex(t,l)][l][c]->bndrybox(dir,ident)); }

   inline const BBox& bndrybbox(const int t, const int l, const int c, 
		const int dir, const int mgl, const int ident) const
	{ return (gdb[dagh_timeindex(t,l)][l][c]->bndrybox(dir,ident,mgl)); }
   inline BBox bndrybbox(const int t, const int l, const int c,
	        const int dir, const int mgl, const int ident)
	{ return (gdb[dagh_timeindex(t,l)][l][c]->bndrybox(dir,ident,mgl)); }

   inline const BBox& mergedbbox(const int t, const int l, const int c, 
			const int ident=DAGH_Main) const
	{ return (gdb[dagh_timeindex(t,l)][l][c]->mergedbox(ident)); }
   inline BBox mergedbbox(const int t, const int l, const int c,
			const int ident=DAGH_Main)
	{ return (gdb[dagh_timeindex(t,l)][l][c]->mergedbox(ident)); }

   void intbboxlist(BBoxList& bbl, const int l, const int ident=DAGH_Main);
   void intbboxlist(BBoxList& bbl, const int l, const int mgl, 
		    const int ident);

   void databboxlist(BBoxList& bbl, const int l, const int ident=DAGH_Main);
   void databboxlist(BBoxList& bbl, const int l, const int mgl, 
		     const int ident);

   void mergedbboxlist(BBoxList& bbl, const int l, const int ident=DAGH_Main);
   /*****************************************************************************/

   /*****************************************************************************/
   /**** Main, Shadow & Mutigrid Operators ****/
   /*****************************************************************************/
   inline GridData(2)<DAGH_GFType> const &operator () (const int t, 
						       const int l, 
                                     const int c, const int ident) const 
	{ return (gdb[dagh_timeindex(t,l)][l][c]->griddata(ident)); }

   inline GridData(2)<DAGH_GFType> &operator () (const int t, const int l,
                                           const int c, const int ident) 
	{ return (gdb[dagh_timeindex(t,l)][l][c]->griddata(ident)); }

   inline GridData(2)<DAGH_GFType> const &operator () (const int t, 
		            const int l, const int c, const int mgl, 
			    const int ident) const
	{ return (gdb[dagh_timeindex(t,l)][l][c]->griddata(ident, mgl)); }

   inline GridData(2)<DAGH_GFType> &operator () (const int t, const int l, 
                                     const int c, const int mgl, 
                                     const int ident)
	{ return (gdb[dagh_timeindex(t,l)][l][c]->griddata(ident, mgl)); }
   /*****************************************************************************/

   /*****************************************************************************/
   /**** Shadow Hierarchy Methods ****/
   /*****************************************************************************/
   void GF_SetupShadow(const int time, const int level);
   void GF_ReleaseShadow(const int time, const int level);
   /*****************************************************************************/

   /*****************************************************************************/
   /**** Multigrid Methods ****/
   /*****************************************************************************/
   void GF_SetupMultiGrid(const int time, const int level, const int mglc, 
			  const int mglf, const int ident);
   void GF_SetupMultiGrid(const int time, const int level, const int axis, 
                       const int mglc, const int mglf, const int ident);
   void GF_ReleaseMultiGrid(const int time, const int level, 
                       const int ident);
   /*****************************************************************************/

   /*********************************************************************/
   /* Operators (DAGH_Main & DAGH_Shadow only) */
   /*********************************************************************/
   void GF_Fill(const DAGH_GFType& val, const int time, const int level, 
                const int ident=DAGH_Main);
   void GF_Fill(const DAGH_GFType& val, const int time, const int level, 
                const int mgl, const int ident);

   void GF_Copy(const int t1, const int l1, 
                const GridFunction(2)<DAGH_GFType>& rhs, 
		const int t2, const int l2, const BBox& where,
                const int ident=DAGH_Main);
   void GF_Copy(const int t1, const int l1, 
                const GridFunction(2)<DAGH_GFType>& rhs, 
		const int t2, const int l2,
                const int ident=DAGH_Main);

   void GF_equals(const int t, const int l, const BBox& where, 
                  const DAGH_GFType& val,
                  const int ident=DAGH_Main);
   void GF_equals(const int t, const int l, 
                  const DAGH_GFType& val,
                  const int ident=DAGH_Main);
   void GF_equals(const int t1, const int l1, 
                  const GridFunction(2)<DAGH_GFType>& rhs, 
		  const int t2, const int l2, const BBox& where,
                  const int ident=DAGH_Main);
   void GF_equals(const int t1, const int l1, 
                  const GridFunction(2)<DAGH_GFType>& rhs, 
		  const int t2, const int l2,
                  const int ident=DAGH_Main);

   void GF_plus(const int t, const int l, const BBox& where, 
                const DAGH_GFType& val,
                const int ident=DAGH_Main);
   void GF_plus(const int t, const int l, const DAGH_GFType& val,
                const int ident=DAGH_Main);
   void GF_plus(const int t1, const int l1, 
                const GridFunction(2)<DAGH_GFType>& rhs, 
		const int t2, const int l2, const BBox& where,
                const int ident=DAGH_Main);
   void GF_plus(const int t1, const int l1, 
                const GridFunction(2)<DAGH_GFType>& rhs, 
		const int t2, const int l2,
                const int ident=DAGH_Main);

   void GF_minus(const int t, const int l, const BBox& where, 
                 const DAGH_GFType& val,
                 const int ident=DAGH_Main);
   void GF_minus(const int t, const int l, const DAGH_GFType& val,
                 const int ident=DAGH_Main);
   void GF_minus(const int t1, const int l1, 
                 const GridFunction(2)<DAGH_GFType>& rhs, 
		 const int t2, const int l2, const BBox& where,
                 const int ident=DAGH_Main);
   void GF_minus(const int t1, const int l1, 
                 const GridFunction(2)<DAGH_GFType>& rhs, 
		 const int t2, const int l2,
                 const int ident=DAGH_Main);

   void GF_multiply(const int t, const int l, const BBox& where, 
                    const DAGH_GFType& val,
                    const int ident=DAGH_Main);
   void GF_multiply(const int t, const int l, const DAGH_GFType& val,
                    const int ident=DAGH_Main);
   void GF_multiply(const int t1, const int l1, 
                    const GridFunction(2)<DAGH_GFType>& rhs, 
		    const int t2, const int l2, const BBox& where,
                    const int ident=DAGH_Main);
   void GF_multiply(const int t1, const int l1, 
                    const GridFunction(2)<DAGH_GFType>& rhs, 
		    const int t2, const int l2,
                    const int ident=DAGH_Main);

   void GF_divide(const int t, const int l, const BBox& where, 
                  const DAGH_GFType& val,
                  const int ident=DAGH_Main);
   void GF_divide(const int t, const int l, const DAGH_GFType& val,
                  const int ident=DAGH_Main);
   void GF_divide(const int t1, const int l1, 
                  const GridFunction(2)<DAGH_GFType>& rhs, 
		  const int t2, const int l2, const BBox& where,
                  const int ident=DAGH_Main);
   void GF_divide(const int t1, const int l1,
                  const GridFunction(2)<DAGH_GFType>& rhs, 
		  const int t2, const int l2,
                  const int ident=DAGH_Main);
   /*********************************************************************/

   /*********************************************************************/
   /* Distributed Operators (Main & Shadow Only) */
   /*********************************************************************/
   void GF_gather_one(const int t1, const int l1,
                      const BBox& to, const BBox& from,
                      GridData(2)<DAGH_GFType>& into, const int at,
               	      const int ident=DAGH_Main);

   void GF_Copy(const int t1, const int l1,
                const GridFunction(2)<DAGH_GFType>& rhs,
                const int t2, const int l2,
                const BBox& to, const BBox& from,
                const int ident=DAGH_Main);

   // I will redefine these as soon as I have operators between
   // GridData & GridDataBucket !
   //void GF_equals(const int t1, const int l1,
   //               const GridFunction(2)<DAGH_GFType>& rhs,
   //               const int t2, const int l2,
   //               const BBox& to, const BBox& from,
   //               const int ident=DAGH_Main);
   //
   //void GF_plus(const int t1, const int l1,
   //             const GridFunction(2)<DAGH_GFType>& rhs,
   //             const int t2, const int l2,
   //             const BBox& to, const BBox& from,
   //             const int ident=DAGH_Main);
   //
   //void GF_minus(const int t1, const int l1,
   //              const GridFunction(2)<DAGH_GFType>& rhs,
   //              const int t2, const int l2,
   //              const BBox& to, const BBox& from,
   //              const int ident=DAGH_Main);
   //
   //void GF_multiply(const int t1, const int l1,
   //                 const GridFunction(2)<DAGH_GFType>& rhs,
   //                 const int t2, const int l2,
   //                 const BBox& to, const BBox& from,
   //                 const int ident=DAGH_Main);
   //
   //void GF_divide(const int t1, const int l1,
   //               const GridFunction(2)<DAGH_GFType>& rhs,
   //               const int t2, const int l2,
   //               const BBox& to, const BBox& from,
   //               const int ident=DAGH_Main);
   /*********************************************************************/

   /*********************************************************************/
   /* Reduction Ops (DAGH_Main, DAGH_Shadow & Multigrid) */
   /*********************************************************************/
   DAGH_GFType GF_maxval(const int t, const int l, 
                         const int ident=DAGH_Main);
   DAGH_GFType GF_maxval(const int t, const int l, const BBox& where, 
                         const int ident=DAGH_Main);
   DAGH_GFType GF_maxval(const int t, const int l, const int lmg, 
                         const int ident);
   DAGH_GFType GF_maxval(const int t, const int l, const int lmg, 
                         const BBox& where, 
                         const int ident);

   DAGH_GFType GF_minval(const int t, const int l, 
                         const int ident=DAGH_Main);
   DAGH_GFType GF_minval(const int t, const int l, const BBox& where, 
                         const int ident=DAGH_Main);
   DAGH_GFType GF_minval(const int t, const int l, const int lmg, 
                         const int ident);
   DAGH_GFType GF_minval(const int t, const int l, const int lmg, 
                         const BBox& where, 
                         const int ident);

   DAGH_GFType GF_sum(const int t, const int l, 
                      const int ident=DAGH_Main);
   DAGH_GFType GF_sum(const int t, const int l, const BBox& where, 
                      const int ident=DAGH_Main);
   DAGH_GFType GF_sum(const int t, const int l, const int lmg, 
                      const int ident);
   DAGH_GFType GF_sum(const int t, const int l, const int lmg, 
                      const BBox& where, 
                      const int ident);

   DAGH_GFType GF_product(const int t, const int l, 
                          const int ident=DAGH_Main);
   DAGH_GFType GF_product(const int t, const int l, const BBox& where, 
                          const int ident=DAGH_Main);
   DAGH_GFType GF_product(const int t, const int l, const int lmg, 
                          const int ident);
   DAGH_GFType GF_product(const int t, const int l, const int lmg, 
                          const BBox& where, const int ident);

   DAGH_GFType GF_norm2(const int t, const int l, 
                        const int ident=DAGH_Main);
   DAGH_GFType GF_norm2(const int t, const int l, const BBox& where, 
                        const int ident=DAGH_Main);
   DAGH_GFType GF_norm2(const int t, const int l, const int lmg, 
                        const int ident);
   DAGH_GFType GF_norm2(const int t, const int l, const int lmg, 
                        const BBox& where, 
                        const int ident);
   /*********************************************************************/

   /*********************************************************************/
   /* IO Support */
   /*********************************************************************/
   void GF_Write(const int t, const int l, 
                 const int mgl, const int ident, 
                 const int gfdtype);
   inline void GF_Write(const int t, const int l, const int gfdtype)
          { GF_Write(t,l,DAGHNull,DAGH_Main,gfdtype); }
   inline void GF_Write(const int t, const int l, 
                        const int mgl, const int gfdtype)
          {(mgl >= 0) ? GF_Write(t,l,mgl,DAGH_Main,gfdtype) : 
                        GF_Write(t,l,DAGHNull,mgl,gfdtype); }

   void GF_Write(const int t, const int l, 
                 const int mgl, const int ident,
                 const BBox& where, const int gfdtype);
   inline void GF_Write(const int t, const int l,
                        const BBox& where, const int gfdtype)
          { GF_Write(t,l,DAGHNull,DAGH_Main,where,gfdtype); }
   inline void GF_Write(const int t, const int l, const int mgl,
                        const BBox& where, const int gfdtype)
          {(mgl >= 0) ? GF_Write(t,l,mgl,DAGH_Main,where,gfdtype) : 
                        GF_Write(t,l,DAGHNull,mgl,where,gfdtype); }

   void GF_Read(const int t, const int l, 
                const int mgl, const int ident, 
                const int gfdtype);
   inline void GF_Read(const int t, const int l, const int gfdtype)
          { GF_Read(t,l,DAGHNull,DAGH_Main,gfdtype); }
   inline void GF_Read(const int t, const int l, 
                       const int mgl, const int gfdtype)
          {(mgl >= 0) ? GF_Read(t,l,mgl,DAGH_Main,gfdtype) : 
                        GF_Read(t,l,DAGHNull,mgl,gfdtype); }

   void GF_Read(const int t, const int l, 
                const int mgl, const int ident,
                const BBox& where, const int gfdtype);
   inline void GF_Read(const int t, const int l, 
                       const BBox& where, const int gfdtype)
          { GF_Read(t,l,DAGHNull,DAGH_Main,where,gfdtype); }
   inline void GF_Read(const int t, const int l, const int mgl, 
                       const BBox& where, const int gfdtype)
          {(mgl >= 0) ? GF_Read(t,l,mgl,DAGH_Main,where,gfdtype) : 
                        GF_Read(t,l,DAGHNull,mgl,where,gfdtype); }
   /*********************************************************************/

   /*********************************************************************/
   /* Generate UCD Data */
   /*********************************************************************/
   void GF_GetUCDData(const DAGHUCD(2)& daghucd, 
		      const int t,
		      DAGH_GFType*& ucddata,
		      const int ucdserver);
   /*********************************************************************/
   /* Viz Support */
   /*********************************************************************/
   void GF_View(const int t, const int l,
                const int axis,
                const BBox& where, 
                const int pserver,
                const int type,
                const char* xg,
                const char* dserver,
		const int ident=DAGH_Main);
   /*********************************************************************/

   /*****************************************************************************/
   /* Some Rudimentary debugging */
   /*****************************************************************************/
   ostream& GF_DebugPrintData(ostream& os, 
                              const int t, const int l, const int ident);
   ostream& GF_DebugPrintIntData(ostream& os, 
                                 const int t, const int l, const int ident);
   ostream& GF_DebugPrintDataBlk(ostream& os, 
                                 const int time, const int level);
   /*****************************************************************************/
  };

#if defined(Want_c_files) || (!defined(RS6000) && !defined(SPX))
  #include "GridFunction2.c"
#endif

#endif
