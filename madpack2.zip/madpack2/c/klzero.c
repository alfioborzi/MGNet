/***********************************************************************
*
* Subroutine KLZERO  Zero all n entries in x
*
* Key: n  integer     i  input        1  vector
*      r  real        o  output       2  matrix
*      d  real*8      s  scratch
*      c  character
*
* Type  Argument  Description
* ----  --------  -----------
* ni    n         length of vector
* ro1   x         vector, size n
*
***********************************************************************/

#include "defnc.pre"

klzero(n, x)

        INT     *n;
        REAL    *x;
  {
  /*********************************************************************
  *----local variables */
  INT     i;
  /********************************************************************/

  i = *n;
  while (i--)
    *x++ = 0.;

  }
