#ifndef _included_GridHierarchy_h
#define _included_GridHierarchy_h

/*
*************************************************************************
*                                                                       *
* GridHierarchy.h                                                       *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"

#include "DAGHDistribution.h"

#include "List.h"

#include "GridUnit.h"
#include "GridUnitList.h"

#include "BBoxList.h"

#include "CommServer.h"
#include "CommIOServer.h"

#include "GridFunctionVoid.h"

/*************************************************************************/
/* Space-Time Dimension Specs */
/*************************************************************************/
struct dimspec {
  double low; 
  double high; 
  double h; 
  double hfine; 
  unsigned n; 
  unsigned nfine; 
  inline dimspec():low(0),high(0),h(0),hfine(0),n(0),nfine(0) {}
};
/*************************************************************************/

/*************************************************************************/
/* Merged bbox + grid unit list combo */
/*************************************************************************/
struct MergedGridUnit { 
  BBox bb;
  GridUnitList gul;
};
/*************************************************************************/

/*************************************************************************/
/* Utility routines */
/*************************************************************************/
inline double toWorld(struct dimspec const &ds, const int lc)
	{ return (ds.low + (lc*ds.hfine)); }
inline double toWorld(struct dimspec const &ds, const int lc, 
		      const int step)
	{ return (ds.low + (lc*ds.hfine)); }

inline double toWorldLower(struct dimspec const &ds, const int lc, 
                           const int step, const int olap)
	{ return (ds.high*((1.0*lc)/(1.0*ds.nfine)) + 
	          ds.low*(1.0 - (1.0*lc)/(1.0*ds.nfine))); }
inline double toWorldUpper(struct dimspec const &ds, const int lc, 
                           const int step, const int olap)
	{ return (ds.high*((1.0*(lc+(1-olap)*step))/(1.0*ds.nfine)) + 
	          ds.low*(1.0 - (1.0*(lc+(1-olap)*step))/(1.0*ds.nfine))); }

inline int toLocal(struct dimspec const &ds, double const wc)
	{ return ((int) ((wc - ds.low)/ds.hfine)); }
/*************************************************************************/

/*************************************************************************/
/* IO ping functions */
/*************************************************************************/
/* A PingFunction for gathering the Complist on the IO processor */
void DAGHIO_ComplistPingFunction(GridHierarchy &GH);
/* A PingFunction for Ending IO */
void DAGHIO_EndIOPingFunction(GridHierarchy &GH);
/*************************************************************************/

#ifndef DAGHDefaultDistribution
#define DAGHDefaultDistribution	(DAGHCompositeDistribution)
#endif

#ifndef DAGHDefaultPartMinGUWidth
#define DAGHDefaultPartMinGUWidth	(0)
#endif
#ifndef DAGHDefaultRefineMinGUWidth
#define DAGHDefaultRefineMinGUWidth	(0)
#endif

#ifndef DAGHDefaultBoundary
#define DAGHDefaultBoundary 	(DAGHBoundaryRegular)
#endif

#ifndef DAGHDefaultAdaptBoundary
#define DAGHDefaultAdaptBoundary (DAGHAdaptBoundaryInterp)
#endif

#ifndef DAGHDefaultRefineFactor
#define DAGHDefaultRefineFactor	(2)
#endif

#ifndef DAGHDefaultRefineLevel
#define DAGHDefaultRefineLevel	(1)
#endif

#ifndef DAGHMaxIOTypes
#define DAGHMaxIOTypes		(5)
#endif 

#ifndef DAGHChkPtTagNameSize
#define DAGHChkPtTagNameSize    (16)
#endif

class GridHierarchy 
  {
   friend ostream&  operator << (ostream& os, const GridHierarchy& );
   friend ofstream& operator << (ofstream& ofs, const GridHierarchy&);
   friend ifstream& operator >> (ifstream& ifs, GridHierarchy&);

public:
   short const rank;		/* Grid rank */

private:
   /* Geometry Information */
   struct dimspec dspecs[DAGHMaxRank]; 	/* Grid Specifications */
   struct dimspec tspecs; 	        /* Time Specifications */
   BBox basebbox;	    	        /* Bounding box of the entire base grid */

   /* The default DAGH type - can be overridden by GridFunction */
   short daghtype;		   /* DAGH type..... */
   short overlap[DAGHMaxRank];     /* Store olap flags */

   /* Boundary Information */
   short bndrytype;		   /* Boundary Type */
   short adaptbndrytype;           /* Adaptive boundary type */
   short bndrywidth;          	   /* Bndry Width */
   BBox bndrybbox[2*DAGHMaxRank];  /* Bndry BBox's */

   /* External ghost information */
   short extghostwidth;            /* default width for GF's */

   /* Refinement Information */
   short maxlev;	  	   /* Level of the finest possible grid */
   short crslev;                   /* Level of the coarsest grid */
   short levels;                   /* = (maxlev - crslev)/reflev + 1 */

   short refby;			/* Refinement factor - power of two */
   short reflev;		/* what power of two is refby */

   /* Curent finest level */
   short finelev;               /* Level of finest refinement in hierarchy */

   BBox intbbox;	 	/* Bounding box of the actual base grid */

   /* Time Information */
   int *curtime[2]; 	/* DAGH_Main -> curtime[0]; DAGH_Shadow -> curtime[1] */
   int *reftime[2]; 	/* curtime at refinements */

   int updatedstep;     /* Where does the updated timestep reside ? */

public:
   /* Distribution information */
   short distribution_type;
   DAGHDistribution distribution;
   
private:
   /* Global Information */
   short mindex;
   GridUnitList *complist;	/* The COMPOSITE list */

   /* Local Information */
   GridUnitList *locallist;	/* Local grid list */
   GridUnitList **localarray;	/* Local array of GridUnits per level */
   GridUnitList *oldcomplist;   /* Old composite grid list for data-xfer */
   GridUnitList *oldlocallist;  /* Old local grid list for data-xfer */

   GridUnitList *origlocallist;     /* Original Compsite List */

   /* Merged Local Information */
   List<MergedGridUnit*>* mergedllist;	/* Merged local grid list */

   //GridUnitList **gdiffarray;	/* Temporary list used to store the */
   //GridUnitList **ldiffarray;	/* difference between the previous */

   /* Attribute Information */
   /* To Be Added */

public:
   /* GridFunction Information */
   short gfnum;
   GridFunctionVoid **gflist;

   /* IO Servers */
   short io_type;
   DAGHIOServerPing *io_complist_server;
   DAGHIOServerRcv *io_write_server;
   DAGHIOServerSnd *io_read_server;
   DAGHIOServerPing *io_end_server;

private:
   /* For checkpointing.... */
   short chkptflag;
   int chkptpnum;
   char chkptname[DAGHChkPtTagNameSize];

private:
   /*************************************************************************/
   /* Disable the following */
   /*************************************************************************/
   GridHierarchy(GridHierarchy const &other);
   GridHierarchy const &operator= (GridHierarchy const &other);

public:
   /*************************************************************************/
   /* Constructors */
   /*************************************************************************/
   GridHierarchy(const int ndim, const int type, const int max_level);

   /*************************************************************************/
   /* Destructor */
   /*************************************************************************/
   ~GridHierarchy(void);

   /*************************************************************************/
   /* Setup DAGH */
   /*************************************************************************/
public:
   void DAGH_SetBaseGrid(double const *bbox, const int *shape);
   void DAGH_SetTimeSpecs(double const starttime, 
			  double const stoptime, 
                          const int ntsteps);

   inline void DAGH_SetBoundaryType(const int type) 
     { bndrytype = type; }
   inline void DAGH_SetAdaptBoundaryType(const int type) 
     { adaptbndrytype = type; }
   inline void DAGH_SetBoundaryWidth(const int width) 
     { bndrywidth = width; }

   inline void DAGH_SetExternalGhostWidth(const int width) 
     { extghostwidth = width; }

   void DAGH_SetRefineFactor(const int rfactor);

   inline void DAGH_SetDistributionType(const int type)
	{ distribution.set_dist(type); }
   inline void DAGH_SetDistributionType(const int type, BBoxList& bbl)
	{ distribution.set_dist(type,bbl); }

   inline void DAGH_SetWorkFunction(void *wf)
	{ distribution.set_workfunc(wf); }

   /*************************************************************************/
   /* Compose the grid hierarchy */
   /*************************************************************************/
private:
   void DAGH_MergeGridUnits(void);

public:
   void DAGH_ComposeHierarchy(void);

   /*************************************************************************/
   /* Setup GridFunctions */
   /*************************************************************************/
public:
   int DAGH_AddGridFunction(GridFunctionVoid *gfv);
   inline void DAGH_DelGridFunction(const int gfid)
        { 
         gflist[gfid] = (GridFunctionVoid *) NULL; 
         if (comm_service::dce()) comm_service::delete_comm(gfid);
         gfnum--; 
        }

   inline void DAGH_ComposeGridFunctions(void)
  	{ 
         for (register int i=0; i<gfnum; i++) 
          { if (gflist[i]) gflist[i]->GF_Compose(); }
         if (chkpt_restart()) {
          for (register int i=0; i<gfnum; i++) 
           { if (gflist[i] && gflist[i]->checkpoint()) 
             gflist[i]->GF_CheckpointRestart(); }
         }
        }

   inline int DAGH_GridFunctionTemplate(GridFunctionVoid& gfv)
   	{ return (DAGHTemplateComm + gfv.gfid); }

   /*************************************************************************/
   /* Recomposition */
   /*************************************************************************/
public:
   void DAGH_RecomposeHierarchy(void);

   /*************************************************************************/
   /* Refinement methods */
   /*************************************************************************/
public:
   void DAGH_Refine(const int lev);
   void DAGH_Refine(BBoxList &bblist, const int lev);

   /*************************************************************************/
   /* Redistribution methods */
   /*************************************************************************/
public:
   inline void DAGH_RedistributeHierarchy(const int type)
        { distribution.set_dist(type); DAGH_RecomposeHierarchy(); }
   inline void DAGH_RedistributeHierarchy(const int type, BBoxList& bbl)
        { distribution.set_dist(type,bbl); DAGH_RecomposeHierarchy(); }

   /*************************************************************************/
   /* For Checkpointing.... */
   /*************************************************************************/
public:
   void DAGH_Checkpoint(const char* name);
   
   void DAGH_ComposeHierarchy(const char* name);
   void DAGH_RecomposeHierarchy(const char* name);

   void DAGH_InitChkpt(const char* name)
     { chkptflag = DAGHTrue; strncpy(chkptname,name,DAGHChkPtTagNameSize); }
   void DAGH_StopChkpt()
     { chkptflag = DAGHFalse; chkptname[0] = '\0'; chkptpnum = 0; }

   int DAGH_OpenChkptIStream(const int p,
			     ifstream& ifs);
   void DAGH_CloseChkptIStream(ifstream& ifs)
     { ifs.close(); }

   int DAGH_OpenChkptIStream(const int p,
			     streampos*& chkptdir, 
			     char*& chkptnamedir,
			     ifstream& ifs);
   void DAGH_CloseChkptIStream(streampos*& chkptdir, 
			      char*& chkptnamedir,
			      ifstream& ifs)
     { if (chkptdir) delete [] chkptdir; 
       if (chkptnamedir) delete [] chkptnamedir; 
       ifs.close(); }

   int DAGH_GetGFChkptIStream(const int p, const char* gfname, 
			      const int gfid,
			      ifstream& ifs);

   int DAGH_OpenChkptOStream(const int p,
			     ofstream& ofs);
   void DAGH_CloseChkptOStream(ofstream& ofs)
     { ofs.close(); }

   /*************************************************************************/
   /* Communications */
   /*************************************************************************/
private:
   void DAGH_GlbConcat(void *snddata, int sndsize, void *&rcvdata, 
		       int &rcvsize);
   void DAGH_GlbConcat(void *snddata, const int size, void *&rcvdata);
   //void DAGH_PingIONode(const int tag, int flg = DAGHTrue);
   void DAGH_PingIONode(const int tag, int flg);
public:
   int DAGH_CommInit(MPI_Comm c = 0);
   void DAGH_CommKill(void);

    /*************************************************************************/
    /* Initialize the overlap flag array */
    /*************************************************************************/ 
public:
   static void DAGH_InitOverlaps(const int Type, short* olap)
   { if (Type == DAGHCellCentered) 
       {olap[0] = 0; olap[1] = 0; olap[2] = 0; }
     else if (Type == DAGHVertexCentered) 
       {olap[0] = 1; olap[1] = 1; olap[2] = 1; } 
     else if (Type == DAGHFaceCentered_X) 
       {olap[0] = 1; olap[1] = 0; olap[2] = 0; }  
     else if (Type == DAGHFaceCentered_Y) 
       {olap[0] = 0; olap[1] = 1; olap[2] = 0; }  
     else if (Type == DAGHFaceCentered_Z) 
       {olap[0] = 0; olap[1] = 0; olap[2] = 1; } }
   /*************************************************************************/

   /*************************************************************************/
   /* Private query operators */
   /*************************************************************************/
private:   
   inline int daghoverlapCC_or_NCC() const 
     { return ((daghtype==DAGHCellCentered) ? 0 : 1); }

   inline const short* daghoverlap() const 
     { return (overlap); }

   inline int daghoverlap(const int dir) const 
     { return (overlap[dir]); }
   /*************************************************************************/
   /* Static Generic public query operators */
   /*************************************************************************/
public:
   static int daghindex(const int ident) 
      { return((ident==DAGH_Main) ? 0 : 1); }
   static int daghfactor(const int ident)
      { return((ident==DAGH_Main) ? 1 : 2); }

   static int daghoverlapCC_or_NCC(const int type) 
      { return((type==DAGHCellCentered) ? 0 : 1); }
   
   static int daghshadowfactor() 
      { return(2); } /* may be settable later */
   static int daghmultigridfactor()
      { return(2); } /* may be settable later */

   /*************************************************************************/
   /* Generic public query operators */
   /*************************************************************************/
public:
   inline  int levelindex(const int l) const 
     { return ((l-crslev)/reflev); }
   inline int levelnum(const int l) const 
     { return ((l*reflev+crslev)); }

   inline int default_alignment(const int r) const 
	{ return ((r == rank) ? DAGH_All : 
                  (r == 3) ? DAGH_All : 
                  (r == 2) ? DAGH_XY : DAGH_X); }
   /*************************************************************************/
   /* GridHierarchy public query operators */
   /*************************************************************************/
public:
   inline const int dagh_type(void) const { return daghtype; }

   inline int boundarywidth(void) const { return bndrywidth; }
   inline int boundarytype(void) const { return bndrytype; }
   inline int adaptboundarytype(void) const { return adaptbndrytype; }

   inline int externalghostwidth(void) const { return extghostwidth; }

   inline int totallevels(void) const { return levels; }

   inline int coarselevel(void) const { return crslev; }
   inline int finelevel(void) const { return finelev; }
   inline int maxlevel(void) const { return maxlev; }

   inline int coarselevelindex(void) const { return levelindex(crslev); }
   inline int finelevelindex(void) const { return levelindex(finelev); }
   inline int maxlevelindex(void) const { return levelindex(maxlev); }

   inline int stepsize(const int l, const int ident=DAGH_Main) const 
     { return (((unsigned)1 << (maxlev-levelnum(l)))*daghfactor(ident)); }

   inline int step2level(const int s, const int ident=DAGH_Main) const
     { return levelindex(maxlev-(int)(0.5+log2(1.0*(s/daghfactor(ident))))); }

   inline int timestep(const int l, const int ident=DAGH_Main) const 
     { return(((unsigned)1 << ((levels-1-l)*reflev))*daghfactor(ident)); }

   inline int numtsteps(const int l, const int ident=DAGH_Main) const
     { return(((unsigned)1 << (l*reflev))/daghfactor(ident)); }

   inline int stepstaken(const int t, const int l, 
			 const int ident=DAGH_Main) const
     { return (t/timestep(l,ident)); }

   inline double delta_t(const int l ,const int ident=DAGH_Main) const
     { return (tspecs.h/numtsteps(l,ident)); }

   inline double delta_x(const int dim, const int l, 
			 const int ident=DAGH_Main) const
     { return (daghfactor(ident)*dspecs[dim].h/refinedby(l)); }

   inline int refinelevel(void) const { return (reflev); }
   inline int refinefactor(void) const { return (refby); }
   inline int refinedby(const int l) const 
     { return ((unsigned)1 << (l*reflev)); }

   /*************************************************************************/
   /* Set/Query Updated Timestep Info */
   /*************************************************************************/
   inline int updatedvaluestep() const { return updatedstep; } 
   inline void setupdatedvaluestep(const int ustep) { updatedstep = ustep; } 

   /*************************************************************************/
   /* Checkpoint info... */
   /*************************************************************************/
   inline void chkpt_filename(ostrstream& obuf, const char* name, 
			      const int p)
     { obuf << name << "." << p << ".cp" << ((char)0); }
   inline int chkpt_restart(void) const 
     { return (chkptflag ==  DAGHTrue); }
   inline const char* chkpt_name(void) const 
     { return chkptname; }
   inline int chkpt_pnum(void) const
     { return chkptpnum; }
   inline void chkpt_reset(void)
     { chkptflag = DAGHFalse; chkptname[0] = '\0'; chkptpnum = 0; }

   /*************************************************************************/
   /* Set/Get current time */
   /*************************************************************************/
public:
   inline int getCurrentTime(const int lev, 
			     const int ident=DAGH_Main) const 
	{ return curtime[daghindex(ident)][lev] ; }
   inline void setCurrentTime(const int ctime, const int lev, 
			      const int ident=DAGH_Main) 
	{ curtime[daghindex(ident)][lev] = ctime; }
   inline void incrCurrentTime(const int lev, const int ident=DAGH_Main) 
	{ curtime[daghindex(ident)][lev] += timestep(lev,ident); }

   inline int getPreviousTime(const int lev, 
			      const int ident=DAGH_Main) const 
	{ return curtime[daghindex(ident)][lev] - timestep(lev,ident); }
   inline int getNextTime(const int lev, const int ident=DAGH_Main) const 
	{ return curtime[daghindex(ident)][lev] + timestep(lev,ident); }

   inline int getRefineTime(const int lev, const int ident=DAGH_Main) const 
	{ return reftime[daghindex(ident)][lev] ; }

   /*************************************************************************/
   /* DAGH structure & coordinate information */
   /*************************************************************************/
public:
   inline int maxindex() const { return mindex; }

   inline GridUnitList* clist() { return (complist); }
   inline GridUnitList* llist() { return (locallist); }
   inline GridUnitList* oldllist() { return (oldlocallist); }
   inline GridUnitList* oldclist() { return (oldcomplist);} 

   inline GridUnitList* origclist() { return (origlocallist); }

   inline const List<MergedGridUnit*>& mllist() { return (*mergedllist); }

   inline GridUnitList* larray(const int l) { return (localarray[l]); }

   inline GridUnitList** larray() { return (localarray); }
   //inline GridUnitList** ldarray() { return (ldiffarray); }
   //inline GridUnitList** gdarray() { return (gdiffarray); }

   /* Integer coords */
   void llb(int *lc) const;
   void lub(int *lc) const;

   inline Coords llb(void) const { return (basebbox.lower()); }
   inline Coords lub(void) const { return (basebbox.upper()); }

   /* World coords */
   void wlb(double *wc) const;
   void wub(double *wc) const;
  
   /* To world coords... */
   DCoords worldCoords(const int *lc, const int *ls) const;
   DCoords worldCoordsUpper(const int *lc, const int *ls) const;
   DCoords worldCoordsLower(const int *lc, const int *ls) const;
   DCoords worldStep(const int *ls) const;

   void worldCoords(const int *lc, const int *ls, double *wc) const;
   void worldStep(const int *ls, double *ws) const;

   /* To integer coords */
   Coords localCoords(double const *wc) const;
   Coords localStep(double const *ws) const;

   void localCoords(double const *wc, int *lc) const;
   void localStep(double const *ws, int *ls) const;

   /*************************************************************************/
   /* Bounding box information */
   /*************************************************************************/
public:
   /* Base bbox info */
   inline BBox bbbox(void) const { return basebbox; }
   inline BBox glbbbox(void) const { return intbbox; }
   inline BBox wholebbox(void) const 
     { return shrinkupperbydim(intbbox,daghoverlap()); }

   /* Boundary bbox info */
   //inline BBox const &boundarybbox(const int dir) const 
   //  { return bndrybbox[dir]; }

   /* Global BBox Lists */
   void glb_bboxlist(BBoxList& bbl,
		     const int l, 
		     const int type, 
                     const int ident=DAGH_Main) const;
   void glb_mergedbboxlist(BBoxList& bbl, 
			   const int l, 
			   const int type,
                           const int ident=DAGH_Main) const;

   void glb_bboxlist(BBoxList& bbl, 
 		     const int minl, 
		     const int maxl,
		     const int type, 
                     const int ident) const;
   void glb_mergedbboxlist(BBoxList& bbl, 
			   const int minl, 
			   const int maxl,
			   const int type, 
                           const int ident) const;
   
   /*************************************************************************/
   /* Multigrid Operators */
   /*************************************************************************/
public:
   int DAGH_MultiGridLevels(const int level, 
			    const int ident=DAGH_Main) const;

   /*************************************************************************/
   /* IO Support */
   /*************************************************************************/
private:
   void DAGH_IOServe(void);
public:
   inline void DAGH_IOType(const int type) { io_type = type; }
   void DAGH_IOEnd(void);
   friend void DAGHIO_ComplistPingFunction(GridHierarchy &GH);
   friend void DAGHIO_EndIOPingFunction(GridHierarchy &GH);

   /*************************************************************************/
   /* Ghost Communications */
   /*************************************************************************/
public:
   inline void DAGH_SyncGhostRegions(const int t, const int l, 
                                     const int ident=DAGH_Main)
     { 
      register int i;
      for (i=0; i<gfnum; i++)
        if (gflist[i] && gflist[i]->comm()) 
	  gflist[i]->GF_WriteGhosts(t,l,ident);
      for (i=0; i<gfnum; i++)
        if (gflist[i] && gflist[i]->comm()) 
	  gflist[i]->GF_ReadGhosts(t,l,ident);
     }
   inline void DAGH_SyncGhostRegions(const int t, const int l, 
                                     const int mgl, const int ident)
     { 
      register int i;
      for (i=0; i<gfnum; i++)
        if (gflist[i] && gflist[i]->comm()) 
	  gflist[i]->GF_WriteGhosts(t,l,mgl,ident);
      for (i=0; i<gfnum; i++)
        if (gflist[i] && gflist[i]->comm()) 
	  gflist[i]->GF_ReadGhosts(t,l,mgl,ident);
     }

   inline void DAGH_SyncGhostRegions(const int t, const int l, 
                                     const int axis, const int dir,
                                     const int ident)
     { 
      register int i;
      for (i=0; i<gfnum; i++) 
        if (gflist[i] && gflist[i]->comm()) 
	  gflist[i]->GF_WriteGhosts(t,l,axis,dir,ident);
      for (i=0; i<gfnum; i++) 
        if (gflist[i] && gflist[i]->comm()) 
	  gflist[i]->GF_ReadGhosts(t,l,axis,dir,ident);
     }

   inline void DAGH_SyncGhostRegions(const int t, const int l, 
                                     const int mgl, 
                                     const int axis, const int dir,
                                     const int ident)
     { 
      register int i;
      for (i=0; i<gfnum; i++) 
        if (gflist[i] && gflist[i]->comm()) 
	  gflist[i]->GF_WriteGhosts(t,l,mgl,axis,dir,ident);
      for (i=0; i<gfnum; i++) 
        if (gflist[i] && gflist[i]->comm()) 
	  gflist[i]->GF_ReadGhosts(t,l,mgl,axis,dir,ident);
     }

   /*************************************************************************/
   /* Compress a GUL ! */
   /*************************************************************************/
   void compress_gul(GridUnitList& gul) const;
  };

ostream&  operator << (ostream& , const GridHierarchy&);
ostream&  operator << (ostream& , const struct dimspecs&);
ostream&  operator << (ostream& , const struct MergedGridUnit&);

ofstream& operator << (ofstream& , const GridHierarchy&);
ifstream& operator >> (ifstream& , GridHierarchy&);


#endif
