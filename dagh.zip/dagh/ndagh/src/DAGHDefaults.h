#ifndef _included_DAGHDefaults_h
#define _included_DAGHDefaults_h

/*
*************************************************************************
* DAGHDefaults.h                                                        *
*                                                                       *
*************************************************************************
*/

/* File: BitVec.h */
#ifndef ByteWidth
#define ByteWidth 			(8)
#endif
#ifndef MaxBitVecSlots
#define MaxBitVecSlots 			(4)
#endif

/* File: sfcIndex.h */
#ifndef sfcBase
#define sfcBase 			(2)
#endif

/* File: SimpleBucketVoid.C */
#ifndef DefBucketSize
#define DefBucketSize 			(128)
#endif
#ifndef DefIncrement
#define DefIncrement 			(128)
#endif

/* File: PackedGridDataBucket.h */
#ifndef DAGHBktGFNameWidth
#define DAGHBktGFNameWidth    		(8)
#endif

/* File: CommServer.C */
#ifndef CommIncrement
#define CommIncrement 			(128)
#endif

/* File: Coords.h */
#ifndef CoordsMaxDim
#define CoordsMaxDim   			(3)
#endif

/* File: DCoords.h */
#ifndef DCoordsMaxDim
#define DCoordsMaxDim 			(3)
#endif

/* File: GridUnitList.h */
#ifndef DefMinimumGUExtent
#define DefMinimumGUExtent  		(0)
#endif
#ifndef DefGridUnitListSize
#define DefGridUnitListSize 		(256)
#endif

/* File: DAGHGhostInteraction.h */
#ifndef DAGHDefaultInteraction
#define DAGHDefaultInteraction   	(DAGHGhostInteraction)
#endif

/* File: GridHierarchy.C */
#ifndef GFListIncrement
#define GFListIncrement   		(64)
#endif
#ifndef DAGHDefaultDistribution
#define DAGHDefaultDistribution 	(DAGHCompositeDistribution)
#endif
#ifndef DAGHDefaultPartMinGUWidth
#define DAGHDefaultPartMinGUWidth 	(1)
#endif
#ifndef DAGHDefaultRefineMinGUWidth
#define DAGHDefaultRefineMinGUWidth 	(1)
#endif
#ifndef DAGHDefaultBoundary
#define DAGHDefaultBoundary     	(DAGHBoundaryRegular)
#endif
#ifndef DAGHDefaultAdaptBoundary
#define DAGHDefaultAdaptBoundary     	(DAGHAdaptBoundaryInterp)
#endif
#ifndef DAGHDefaultRefineFactor 
#define DAGHDefaultRefineFactor 	(2)
#endif
#ifndef DAGHDefaultRefineLevel
#define DAGHDefaultRefineLevel  	(1)
#endif
#ifndef DAGHMaxIOTypes
#define DAGHMaxIOTypes         		(5)
#endif
#ifndef DAGHMerge
#define DAGHMerge                       DAGHTrue
#endif
#ifndef DAGHMergeWithClusterer
#define DAGHMergeWithClusterer          DAGHFalse
#endif

/* GridFunctionVoid.h */
#ifndef DAGHGFVFlagType
#define DAGHGFVFlagType                 short
#endif

#ifndef DAGHGFVFlagNum
#define DAGHGFVFlagNum                  (10)
#endif

/* File: List.h */
#ifndef ListItemsAtATime
#define ListItemsAtATime 		(32)
#endif

#endif
