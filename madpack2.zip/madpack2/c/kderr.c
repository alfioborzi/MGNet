/***********************************************************************
*
* Subroutine KDERR   Compute error
*
* Key: n  integer     i  input        1  vector
*      r  real        o  output       2  matrix
*      d  real*8      s  scratch
*      c  character
*
* Type  Argument  Description
* ----  --------  -----------
* ri1   a         matrix stored in sparse form with nr rows, nc columns
* ni    atype     type of matrix
*                    0  symmetric
*                    1  nonsymmetric
*                    2  nonsymmetric (nonsymmetric zero structure)
*                    3  constant coefficient
*                 to compute with a-transpose, negate atype
* ri1   e         error vector (wrt sol)
* ro    errl2     l2 error norm
* ro    errmax    l-infinity error norm
* ni1   ija       pointers to rows of matrix followed by column indices
*                 of matrix
* ni    n         number of rows & columns in matrix
* ni    opt       vector norm (opt == 1) or A norm (opt == 2)
* rs1   scr       scratch vector, size n
* ri1   sol       solution vector
* ri1   x         input vector
*
***********************************************************************/

#include "defnc.pre"

kderr(opt, n, atype, ija, a, x, sol, e, scr, errmax, errl2)

        INT     *atype, *ija, *n, *opt;
        REAL    *a, *e, *errl2, *errmax, *scr, *sol, *x;
  {
  /*********************************************************************
  *****local variables */
  INT     flag, i, zero;
  REAL    el2, em, emax, *pe, *ps, *px;
  /********************************************************************/

  zero = 0;
  em   = 0.;
  el2  = 0.;

  pe = e;
  ps = sol;
  px = x;
  for (i = 0; i < *n; i++)
    *pe++ = *px++ - *ps++;
  if (*opt == 2) {
    klax(&zero, n, n, ija, a, e, scr, atype, &flag);
    pe = e;
    ps = scr;
    for (i = 0; i < *n; i++)
      *pe++ *= *ps++;
    }
  pe = e;
  for (i = 0; i < *n; i++) {
    el2 += (*pe * *pe);
    if ((emax = fabs(*pe)) > em) em = emax;
    pe++;
    }
  *errl2 = sqrt(el2);
  *errmax = em;
  }

