#ifndef _included_DAGHIO_hdf_ncsa_h
#define _included_DAGHIO_hdf_ncsa_h

/*
*************************************************************************
* DAGHIO_hdf_ncsa.h						
*                                                                       
* IO Interface to John Shalf / NCSA AMR HDF Files
* More info at http://bach.ncsa.uiuc.edu/IO/
*                                                                       
* Author:  Manish Parashar <parashar@cs.utexas.edu>   
*          Paul Walker <pwalker@ncsa.uiuc.edu>
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"
#include "DAGHIOParams.h"
#include "PackedGridDataBucket.h"

#ifdef IO_NCSAIO
extern "C" {
#include "sds.h"
#include "amrsds.h"
}
#endif
#ifdef IO_OLDNCSA
extern "C" {
#include "hdf.h"
#include "mfhdf.h"
void WriteChunk (char *componentname,
                 int pid,
                 int level,
                 int component,
                 int timestep,
                 int ndims,
                 int dims[3],
                 int lb[3],
                 int ub[3],
                 long totalbytes,
                 double *data);
void FinalizeIO();
}
#endif

#endif

