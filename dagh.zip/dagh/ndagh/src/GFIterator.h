#if !defined(GFIterator_h)
#define GFIterator_h
#define GFIterator(N) name2(GFIterator_,N)
#define DeclareGFIterator(N) \
template<class Type> \
class GFIterator(N) { \
	int faGF; \
	int gfid; \
	GridHierarchy *ghp; \
public: \
	GFIterator(N)() { ghp=0; } \
	void operator=(GridHierarchy& gh) { \
		faGF = gh.gfnum; \
		ghp = &gh; \
		gfid = 0; \
	} \
	void operator++() { \
		gfid++; \
	} \
	void operator++(int) { \
		gfid++; \
	} \
	operator int() { \
		return gfid < faGF; \
	} \
	GridFunction(N)<Type>& operator*() { \
		assert(ghp); \
		return *(GridFunction(N)<Type> *)ghp->gflist[gfid]; \
	} \
	GridFunction(N)<Type>* operator->() { \
		assert(ghp); \
		return (GridFunction(N)<Type> *)ghp->gflist[gfid]; \
	} \
};
DeclareGFIterator(1)
DeclareGFIterator(2)
DeclareGFIterator(3)
#endif
