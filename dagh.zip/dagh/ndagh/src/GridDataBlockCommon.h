#ifndef _included_GridDataBlockCommon_h
#define _included_GridDataBlockCommon_h

/*
*************************************************************************
*                                                                       *
* GridDataBlockCommon.h                                                 *
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"

#include "Coords.h"
#include "BBox.h"

#include "GridUnit.h"
#include "PackedGridDataBucket.h"
#include "GridTable.h"
#include "GridHierarchy.h"

#include "CommServer.h"

#include "GDBInteraction.h"

/* Utility functions */
void gdbSetRanks(const int rank, const int align, short* ranks);
void gdbAlignBBox(const int, class BBox&, const int);

#endif
