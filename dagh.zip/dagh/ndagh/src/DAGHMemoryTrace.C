/*
*************************************************************************
* DAGHMemoryTraces.C                                                    *
*                                                                       *
* Maintain memory allocation and deallocation traces 			*
*                                                                       *
*************************************************************************
*/

#include "DAGHMemoryTrace.h"

unsigned DAGHMemoryTrace::alloc_cnt = 0;
unsigned DAGHMemoryTrace::free_cnt = 0;
