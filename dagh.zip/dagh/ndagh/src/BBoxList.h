#ifndef _included_BBoxList_h
#define _included_BBoxList_h

/*
*************************************************************************
*                                                                       *
* class BBoxList							*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "BucketType.h"
#include "BBox.h"
#include "Coords.h"

#include "iostream.h"
#include "fstream.h"

#define BBoxListNULL ((BBoxList *) NULL)


#ifdef __GNUG__
template class Bucket<BBox>;
#endif

class BBoxList : public Bucket<BBox>
  {
   friend ostream& operator << (ostream& s, const BBoxList& bbl);

   friend ofstream& operator << (ofstream& s, const BBoxList& bbl);
   friend ifstream& operator >> (ifstream& s, BBoxList& bbl);

   friend class BBox;

   int num;

private:
   /*************************************************************************/
   /*** Set list statistics ***/
   /*************************************************************************/
   inline int setstats(void)
     {
      num = 0;
      for ( BBox *b=first();b!=BBoxNULL;b=next() ) num++;
      return num;
     }

public:
   /*************************************************************************/
   /*** Constructors ***/
   /*************************************************************************/
   inline BBoxList()
        : Bucket<BBox>(DefBucketSize), num(0) {}

   inline BBoxList(unsigned short const maxnum, const int dumnum) 
	: Bucket<BBox>(maxnum), num(0) {}

   inline BBoxList(void const *package, unsigned const size, const int n)
        : Bucket<BBox>(package, size, n), num(0)
	{ setstats(); }

   /*$inline BBoxList(void const *package)
        : Bucket<BBox>(package), num(0)
	{ setstats(); }

   inline BBoxList(void *package)
        : Bucket<BBox>(package), num(0)
	{ setstats(); }$*/

   inline BBoxList(BBoxList const &other)
        : Bucket<BBox>(other), num(other.num) {}

   BBoxList &operator = (const BBoxList&);

   /*************************************************************************/
   /*** Destructor ***/
   /*************************************************************************/
   inline ~BBoxList(void) {}

   /*************************************************************************/
   /*** Query functions ***/
   /*************************************************************************/
   inline int number() const { return(num); }
   inline int isempty() const { return(num == 0); }

   /*************************************************************************/
   /* Empty the list */
   /*************************************************************************/
   inline void empty(void)
	{ Bucket<BBox>::empty(); num = 0; }

   /*************************************************************************/
   /* BBoxList operators */
   /*************************************************************************/
   //void operator *= (BBoxList const &rhs); /* intersection */
   //BBoxList *operator * (BBoxList const &rhs); /* intersection */
   //void operator += (BBoxList const &rhs); /* union */
   //BBoxList *operator + (BBoxList const &rhs); /* union */

private:
   /*************************************************************************/
   /* Nest with another list - This needs work */
   /*************************************************************************/
   void nest(const BBoxList &rhs);

public:
   /*************************************************************************/
   /* Merge bounding boxes in the list is possible */
   /*************************************************************************/
   void mergeboxes(const short* olap);

   /*************************************************************************/
   /* Combine two bbl's */
   /*************************************************************************/
   void combine(const BBoxList &rhs);
   
   /*************************************************************************/
   /* Reduce the list in a single bounding box */
   /*************************************************************************/
   BBox reduce();

   /*************************************************************************/
   /* List manipulation functions */
   /*************************************************************************/
   inline BBox *add(BBox const &bb)
      { num++; return (Bucket<BBox>::add(bb)); }
   inline BBox *insert(BBox const &bb)
      { num++; return (Bucket<BBox>::insert(bb)); }
   inline void remove(void)
      { 
        BBox *bb = current();
	if (bb) { num--; Bucket<BBox>::remove(); }
      }

   /*************************************************************************/
   /* Split the list bucket */
   /*************************************************************************/
   inline void split(BBoxList &bbl)
     {
      Bucket<BBox>::split((Bucket<BBox> &) bbl);
      bbl.setstats(); num -= bbl.num;
     }
  };

ostream& operator<<(ostream&, const BBoxList&);
ofstream& operator<<(ofstream&, const BBoxList&);
ifstream& operator>>(ifstream&, BBoxList&);

  /*************************************************************************/
  /* interface routines */
  /*************************************************************************/
  inline BBox *first(BBoxList &bbl)
  	{ return (bbl.first()); }
  inline BBox *next(BBoxList &bbl)
  	{ return (bbl.next()); }
  inline BBox *prev(BBoxList &bbl)
  	{ return (bbl.prev()); }
  inline BBox *current(BBoxList &bbl)
  	{ return (bbl.current()); }
  inline BBox *last(BBoxList &bbl)
  	{ return (bbl.last()); }

  inline void add(BBoxList &bbl, BBox const &bb)
  	{ bbl.add(bb); }
  inline void insert(BBoxList &bbl, BBox const &bb)
  	{ bbl.insert(bb); }
  inline void remove(BBoxList &bbl)
  	{ bbl.remove(); }

  inline int number(BBoxList const &bbl)
	{ return (bbl.number()); }
  inline int isempty(BBoxList const &bbl)
	{ return (bbl.isempty()); }

  inline void empty(BBoxList &bbl)
	{ bbl.empty(); }
#endif
