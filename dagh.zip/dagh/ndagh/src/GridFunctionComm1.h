#ifndef _included_GridFunctionComm1_h
#define _included_GridFunctionComm1_h

/*
*************************************************************************
*                                                                       *
* GridFunctionComm1.h                                                   *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/*****************************************************************************/
/**** Data Communications: Reads ****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(1)<DAGH_GFType>::GF_ReadData(const int time) 
  {
   List<GridDataBucketVoid*>& lgdbkt = (*gt)(time);
   GridDataBucketVoid** gdbkt = 0;
   DAGHListLoop(lgdbkt, gdbkt, GridDataBucketVoid*) {
     GridDataBucket<DAGH_GFType>* rcvbkt =
                            (GridDataBucket<DAGH_GFType> *) *gdbkt;

     const int num = rcvbkt->num();
     for (register int i=0;i<num;i++) {
       struct gdhdr *gdh = rcvbkt->head(i);

#ifdef DEBUG_PRINT_GF_COMM
     ( comm_service::log() << "[GF_ReadData: Extracting"
                           << *gdh
                           << "]" << endl).flush();
#endif

       assert(gdh->time == time);

       //GridTableEntry* gte = gt->find(gdh->baseindex);
       //if (gte == GridTableEntryNULL)
       //  comm_service::error_die("GridFunction::GF_ReadData",
       //                          "No Table Entry",DAGH_FATAL);
       //const int idx = gte->myindex();

       const int t = gdh->time;
       const int l = dagh.levelindex(gdh->level);
       const int idx = gdh->index;
       const int ident = gdh->ident;
#ifdef DEBUG_PRINT
       assert (gdb[t]);
#endif
       (gdb[t][l][idx]->griddata(ident)).copy(*rcvbkt,i);
     }
   } DAGHEndLoop
  }

template <class DAGH_GFType>
void GridFunction(1)<DAGH_GFType>::GF_ReadData(const int time, const int level) 
  {
   List<GridDataBucketVoid*>& lgdbkt = (*gt)(time);
   GridDataBucketVoid** gdbkt = 0;
   DAGHListLoop(lgdbkt, gdbkt, GridDataBucketVoid*) {
     GridDataBucket<DAGH_GFType>* rcvbkt =
                            (GridDataBucket<DAGH_GFType> *) *gdbkt;

     const int num = rcvbkt->num();
     for (register int i=0;i<num;i++) {
       struct gdhdr *gdh = rcvbkt->head(i);
       if (level != dagh.levelindex(gdh->level)) continue;

#ifdef DEBUG_PRINT_GF_COMM
     ( comm_service::log() << "[GF_ReadData: Extracting"
                           << *gdh
                           << "]" << endl).flush();
#endif

       assert(gdh->time == time);

       //GridTableEntry* gte = gt->find(gdh->baseindex);
       //if (gte == GridTableEntryNULL)
       //  comm_service::error_die("GridFunction::GF_ReadData",
       //                          "No Table Entry",DAGH_FATAL);
       //const int idx = gte->myindex();

       const int t = gdh->time;
       const int idx = gdh->index;
       const int ident = gdh->ident;
#ifdef DEBUG_PRINT
       assert (gdb[t]);
#endif
       (gdb[t][level][idx]->griddata(ident)).copy(*rcvbkt,i);
     }
   } DAGHEndLoop
  }

template <class DAGH_GFType>
void GridFunction(1)<DAGH_GFType>::GF_ReadData(const int time, 
                                               GridData(1)<DAGH_GFType>& into) 
  {
   List<GridDataBucketVoid*>& lgdbkt = (*gt)(time);
   GridDataBucketVoid** gdbkt = 0;
   DAGHListLoop(lgdbkt, gdbkt, GridDataBucketVoid*) {
     GridDataBucket<DAGH_GFType>* rcvbkt =
                            (GridDataBucket<DAGH_GFType> *) *gdbkt;
     const int num = rcvbkt->num();
     for (register int i=0;i<num;i++) {

#ifdef DEBUG_PRINT_GF_COMM
     ( comm_service::log() << "[GF_ReadData: Extracting"
                           << *rcvbkt->head(i)
                           << "]" << endl).flush();
#endif

       into.copy(*rcvbkt,i);
     }
   } DAGHEndLoop
  }

/*****************************************************************************/
/**** Ghost Communications: Writes ****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(1)<DAGH_GFType>::GF_WriteGhosts(const int time, 
                                                        const int level, 
                                                        const int ident)
  {
   register const int t = dagh_timeindex(time,level);
   register const int l = level;
   if (!comm(t,l) || t > 2*time_sten_rad || !gdb[t]) return;
   const int levels = dagh.totallevels();
   const int pnum = comm_service::proc_num();
   const int me = comm_service::proc_me();
   const int cnt1 = levels * DAGHMaxAxis * DAGHMaxDirs ;
   const int idx = (l * DAGHMaxAxis * DAGHMaxDirs) + 
                   (DAGH_All * DAGHMaxDirs) + DAGH_Both;

   for (register int p=0;p<pnum;p++) {
     if (p == me) continue;
     if (ghost_send_info[p] && ghost_send_info[p][idx]) {
       GridDataBucket<DAGH_GFType> *gdbkt = 
       new GridDataBucket<DAGH_GFType>(ghost_send_info[p][idx]->cnt,
                                ghost_send_info[p][idx]->size,DAGHPacked);
       int s = 0;
       for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
         s += gdb[t][l][i]->gdbWriteGhosts(p, DAGH_All, DAGH_Both,
                                                 ident, DAGHNull, *gdbkt, s);
       gt->send((DAGHGhostTag|idx),gdbkt,p);
     }
   }
  }

template <class DAGH_GFType>
void GridFunction(1)<DAGH_GFType>::GF_WriteGhosts(const int time, 
                                                        const int level, 
                                                        const int mgl, 
                                                        const int ident)
  {
   register int const t = dagh_timeindex(time,level);
   register int const l = level;
   if (!comm(t,l) || t > 2*time_sten_rad || !gdb[t]) return;
   const int levels = dagh.totallevels();
   const int pnum = comm_service::proc_num();
   const int me = comm_service::proc_me();
   const int cnt1 = levels * DAGHMaxAxis * DAGHMaxDirs ;
   const int idx = (l * DAGHMaxAxis * DAGHMaxDirs) +
                   (DAGH_All * DAGHMaxDirs) + DAGH_Both;

   for (register int p=0;p<pnum;p++) {
     if (p == me) continue;
     if (ghost_send_info[p] && ghost_send_info[p][idx]) {
       GridDataBucket<DAGH_GFType> *gdbkt =
       new GridDataBucket<DAGH_GFType>(ghost_send_info[p][idx]->cnt,
                                ghost_send_info[p][idx]->size,DAGHPacked);
       int s = 0;
       for (register int i=0; i<length; i++) if (gdb[t][l][i])
         s += gdb[t][l][i]->gdbWriteGhosts(p, DAGH_All, DAGH_Both,
                                                 ident, mgl, *gdbkt, s);
       gt->send((DAGHGhostTag|idx),gdbkt,p);
     }
   }
  }

template <class DAGH_GFType>
void GridFunction(1)<DAGH_GFType>::GF_WriteGhosts(const int time, 
                                                        const int level,
					                const int axis, 
                                                        const int dir, 
                                                        const int ident)
  {
   assert(dir==DAGH_Forward || dir==DAGH_Backward || axis==DAGH_All);
   register int const t = dagh_timeindex(time,level);
   register int const l = level;
   if (!comm(t,l) || t > 2*time_sten_rad || !gdb[t]) return;
   const int levels = dagh.totallevels();
   const int me = comm_service::proc_me();
   const int pnum = comm_service::proc_num();
   const int cnt1 = levels * DAGHMaxAxis * DAGHMaxDirs ;
   const int idx = (l * DAGHMaxAxis * DAGHMaxDirs) +
                   (axis * DAGHMaxDirs) + dir;

   for (register int p=0;p<pnum;p++) {
     if (p == me) continue;
     if (ghost_send_info[p] && ghost_send_info[p][idx]) {
       GridDataBucket<DAGH_GFType> *gdbkt =
       new GridDataBucket<DAGH_GFType>(ghost_send_info[p][idx]->cnt,
                                ghost_send_info[p][idx]->size,DAGHPacked);
       int s = 0;
       for (register int i=0; i<length; i++) if (gdb[t][l][i])
         s += gdb[t][l][i]->gdbWriteGhosts(p, axis, dir,
                                                 ident, DAGHNull, *gdbkt, s);
       gt->send((DAGHGhostTag|idx),gdbkt,p);
     }
   }
  }

template <class DAGH_GFType>
void GridFunction(1)<DAGH_GFType>::GF_WriteGhosts(const int time, 
                                                        const int level, 
					                const int mgl,
					                const int axis, 
                                                        const int dir, 
                                                        const int ident)
  {
   assert(dir==DAGH_Forward || dir==DAGH_Backward || axis==DAGH_All);
   register int const t = dagh_timeindex(time,level);
   register int const l = level;
   if (!comm(t,l) || t > 2*time_sten_rad || !gdb[t]) return;
   const int levels = dagh.totallevels();
   const int pnum = comm_service::proc_num();
   const int me = comm_service::proc_me();
   const int cnt1 = levels * DAGHMaxAxis * DAGHMaxDirs ;
   const int idx = (l * DAGHMaxAxis * DAGHMaxDirs) +
                   (axis * DAGHMaxDirs) + dir;

   for (register int p=0;p<pnum;p++) {
     if (p == me) continue;
     if (ghost_send_info[p] && ghost_send_info[p][idx]) {
       GridDataBucket<DAGH_GFType> *gdbkt =
       new GridDataBucket<DAGH_GFType>(ghost_send_info[p][idx]->cnt,
                                ghost_send_info[p][idx]->size,DAGHPacked);
       int s = 0;
       for (register int i=0; i<length; i++) if (gdb[t][l][i])
         s += gdb[t][l][i]->gdbWriteGhosts(p, axis, dir,
                                                 ident, mgl, *gdbkt, s);
       gt->send((DAGHGhostTag|idx),gdbkt,p);
     }
   }
  }

/*****************************************************************************/
/**** Ghost Communications: Reads ****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(1)<DAGH_GFType>::GF_ReadGhosts(const int time, 
                                                 const int level,
                                                 const int ident)
  {
   register int const t = dagh_timeindex(time,level);
   register int const l = level;
   if (!comm(t,l) || t > 2*time_sten_rad || !gdb[t]) return;

   const int levels = dagh.totallevels();
   const int pnum = comm_service::proc_num();
   const int me = comm_service::proc_me();
   const int cnt1 = levels * DAGHMaxAxis * DAGHMaxDirs ;
   const int idx = (l * DAGHMaxAxis * DAGHMaxDirs) +
                   (DAGH_All * DAGHMaxDirs) + DAGH_Both;

   /* Interpolate */
   if (l > 0) GF_InterpGhosts(time,level,DAGHNull,ident);

   /* Local copies */
   const int mindex = dagh.maxindex()+1;
   const int lcindex = DAGHMaxDirs*mindex*DAGH_All + mindex*DAGH_Both;
   if (ghost_recv_info[me] && ghost_recv_info[me][idx] 
                           && ghost_recv_info[me][idx]->cnt > 0) {
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) {
       GDB_Interaction** gdbi = gdb[t][l][i]->gdbReadInfo(me);
       if (gdbi != 0) for (register int m=0; m<mindex; m++) {
         if (m != i && (gdbi[lcindex+m]))  {
#ifdef DEBUG_PRINT_GF_COMM
     ( comm_service::log() << "[GF_ReadGhosts::LocalCopy "
                           << "[" << i << "<-" << m << "]"
                           << *gdbi[lcindex+m]
                           << "]" << endl).flush();
#endif
           gdb[t][l][i]->griddata(ident).copy(gdb[t][l][m]->griddata(ident),
                            gdb[t][l][i]->ghostbox(*gdbi[lcindex+m],ident));
         }
       }
     }
   }
   
   /* Receives */
   register int p;
   for (p=0;p<pnum;p++) {
     if (p == me) continue;
     if (ghost_recv_server[p] && ghost_recv_server[p][idx]
                              && !ghost_recv_server[p][idx]->received()) 
       comm_service::serve(*ghost_recv_server[p][idx]->req());
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
       gdb[t][l][i]->gdbReadGhosts(p,DAGH_All,DAGH_Both,ident,DAGHNull);
   }
   gt->flush(t,dagh.levelnum(level),DAGH_All,DAGH_Both);
   for (p=0;p<pnum;p++) {
     if (p != me && ghost_recv_server[p] && ghost_recv_server[p][idx])
       ghost_recv_server[p][idx]->postrcv();
   }
  }

template <class DAGH_GFType>
void GridFunction(1)<DAGH_GFType>::GF_ReadGhosts(const int time, 
                                                 const int level,
                                                 const int mgl, 
                                                 const int ident)
  {
   register int const t = dagh_timeindex(time,level);
   register int const l = level;
   if (!comm(t,l) || t > 2*time_sten_rad || !gdb[t]) return;

   const int levels = dagh.totallevels();
   const int pnum = comm_service::proc_num();
   const int me = comm_service::proc_me();
   const int cnt1 = levels * DAGHMaxAxis * DAGHMaxDirs ;
   const int idx = (l * DAGHMaxAxis * DAGHMaxDirs) +
                   (DAGH_All * DAGHMaxDirs) + DAGH_Both;

   /* Interpolate */
   if (l > 0) GF_InterpGhosts(time,level,mgl,ident);

   /* Local copies */
   const int mindex = dagh.maxindex()+1;
   const int lcindex = DAGHMaxDirs*mindex*DAGH_All + mindex*DAGH_Both;
   if (ghost_recv_info[me] && ghost_recv_info[me][idx] 
                           && ghost_recv_info[me][idx]->cnt > 0) {
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) {
       GDB_Interaction** gdbi = gdb[t][l][i]->gdbReadInfo(me);
       if (gdbi != 0) for (register int m=0; m<mindex; m++) {
         if (m != i && (gdbi[lcindex+m]))  {
#ifdef DEBUG_PRINT_GF_COMM
     ( comm_service::log() << "[GF_ReadGhosts::LocalCopy "
                           << "[" << i << "<-" << m << "]"
                           << *gdbi[lcindex+m]
                           << "]" << endl).flush();
#endif
           gdb[t][l][i]->griddata(ident,mgl).copy(gdb[t][l][m]->griddata(ident,mgl),
                                gdb[t][l][i]->ghostbox(*gdbi[lcindex+m],ident,mgl));
         }
       }
     }
   }
   
   /* Receives */
   register int p;
   for (p=0;p<pnum;p++) {
     if (p == me) continue;
     if (ghost_recv_server[p] && ghost_recv_server[p][idx]
                              && !ghost_recv_server[p][idx]->received()) 
       comm_service::serve(*ghost_recv_server[p][idx]->req());
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
       gdb[t][l][i]->gdbReadGhosts(p,DAGH_All,DAGH_Both,ident,mgl);
   }

   gt->flush(t,dagh.levelnum(level),DAGH_All,DAGH_Both);
   for (p=0;p<pnum;p++) {
     if (p != me && ghost_recv_server[p] && ghost_recv_server[p][idx])
       ghost_recv_server[p][idx]->postrcv();
   }
  }

template <class DAGH_GFType>
void GridFunction(1)<DAGH_GFType>::GF_ReadGhosts(const int time, 
                                                 const int level,
					         const int axis, 
                                                 const int dir,
                                                 const int ident)
  {
   assert(dir==DAGH_Forward || dir==DAGH_Backward || axis==DAGH_All);
   register int const t = dagh_timeindex(time,level);
   register int const l = level;
   if (!comm(t,l) || t > 2*time_sten_rad || !gdb[t]) return;

   const int levels = dagh.totallevels();
   const int pnum = comm_service::proc_num();
   const int me = comm_service::proc_me();
   const int cnt1 = levels * DAGHMaxAxis * DAGHMaxDirs ;
   const int idx = (l * DAGHMaxAxis * DAGHMaxDirs) +
                    (axis * DAGHMaxDirs) + dir;

   /* Interpolate */
   if (l > 0) GF_InterpGhosts(time,level,DAGHNull,axis,dir,ident);

   /* Local copies */
   const int mindex = dagh.maxindex()+1;
   const int lcindex = DAGHMaxDirs*mindex*axis + mindex*dir;
   if (ghost_recv_info[me] && ghost_recv_info[me][idx] 
                           && ghost_recv_info[me][idx]->cnt > 0) {
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) {
       GDB_Interaction** gdbi = gdb[t][l][i]->gdbReadInfo(me);
       if (gdbi != 0) for (register int m=0; m<mindex; m++) {
         if (m != i && (gdbi[lcindex+m]))  {
#ifdef DEBUG_PRINT_GF_COMM
     ( comm_service::log() << "[GF_ReadGhosts::LocalCopy "
                           << "[" << i << "<-" << m << "]"
                           << *gdbi[lcindex+m]
                           << "]" << endl).flush();
#endif
           gdb[t][l][i]->griddata(ident).copy(gdb[t][l][m]->griddata(ident),
                            gdb[t][l][i]->ghostbox(*gdbi[lcindex+m],ident));
         }
       }
     }
   }
   
   /* Receives */
   register int p;
   for (p=0;p<pnum;p++) {
     if (p == me) continue;
     if (ghost_recv_server[p] && ghost_recv_server[p][idx]
                              && !ghost_recv_server[p][idx]->received()) 
       comm_service::serve(*ghost_recv_server[p][idx]->req());
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
       gdb[t][l][i]->gdbReadGhosts(p,axis,dir,ident,DAGHNull);
   }

   gt->flush(t,dagh.levelnum(level),axis,dir);
   for (p=0;p<pnum;p++) {
     if (p != me && ghost_recv_server[p] && ghost_recv_server[p][idx])
       ghost_recv_server[p][idx]->postrcv();
   }
  }

template <class DAGH_GFType>
void GridFunction(1)<DAGH_GFType>::GF_ReadGhosts(const int time, 
                                                 const int level,
					         const int mgl, 
					         const int axis, 
                                                 const int dir,
                                                 const int ident)
  {
   assert(dir==DAGH_Forward || dir==DAGH_Backward || axis==DAGH_All);
   register int const t = dagh_timeindex(time,level);
   register int const l = level;
   if (!comm(t,l) || t > 2*time_sten_rad || !gdb[t]) return;

   const int levels = dagh.totallevels();
   const int pnum = comm_service::proc_num();
   const int me = comm_service::proc_me();
   const int cnt1 = levels * DAGHMaxAxis * DAGHMaxDirs ;
   const int idx = (l * DAGHMaxAxis * DAGHMaxDirs) +
                    (axis * DAGHMaxDirs) + dir;

   /* Interpolate */
   if (l > 0) GF_InterpGhosts(time,level,mgl,axis,dir,ident);

   /* Local copies */
   const int mindex = dagh.maxindex()+1;
   const int lcindex = DAGHMaxDirs*mindex*axis + mindex*dir;
   if (ghost_recv_info[me] && ghost_recv_info[me][idx] 
                           && ghost_recv_info[me][idx]->cnt > 0) {
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) {
       GDB_Interaction** gdbi = gdb[t][l][i]->gdbReadInfo(me);
       if (gdbi != 0) for (register int m=0; m<mindex; m++) {
         if (m != i && (gdbi[lcindex+m]))  {
#ifdef DEBUG_PRINT_GF_COMM
     ( comm_service::log() << "[GF_ReadGhosts::LocalCopy "
                           << "[" << i << "<-" << m << "]"
                           << *gdbi[lcindex+m]
                           << "]" << endl).flush();
#endif
           gdb[t][l][i]->griddata(ident,mgl).copy(gdb[t][l][m]->griddata(ident,mgl),
                                gdb[t][l][i]->ghostbox(*gdbi[lcindex+m],ident,mgl));
         }
       }
     }
   }
   
   /* Receives */
   register int p;
   for (p=0;p<pnum;p++) {
     if (p == me) continue;
     if (ghost_recv_server[p] && ghost_recv_server[p][idx]
                              && !ghost_recv_server[p][idx]->received()) 
       comm_service::serve(*ghost_recv_server[p][idx]->req());
     for (register int i=0; i<length; i++) if (gdb[t][l][i]) 
       gdb[t][l][i]->gdbReadGhosts(p,axis,dir,ident,mgl);
   }

   gt->flush(t,dagh.levelnum(level),axis,dir);
   for (p=0;p<pnum;p++) {
     if (p != me && ghost_recv_server[p] && ghost_recv_server[p][idx])
       ghost_recv_server[p][idx]->postrcv();
   }
  }

/*****************************************************************************/
/**** Do Space-Time Interpolation ****/
/*****************************************************************************/
template <class DAGH_GFType>
void GridFunction(1)<DAGH_GFType>::GF_InterpGhosts(const int time,
                                                   const int level,
                                                   const int mgl,
                                                   const int ident)
  {
   if (level == 0 || !prolong()) return;

   register int const t = dagh_timeindex(time,level);
   register int const l = level;

   if (t > 0) {
     int tf = dagh.getCurrentTime(l);
     int tc = dagh.getCurrentTime(l-1);
     int sf = dagh.timestep(l);
     int sc = dagh.timestep(l-1);
     int timea, timeb;

     if (time < tc) {
       timea = tc;
       timeb = time-sf;
     }
     else if (time == tc && updatedstep == DAGHNextTime) {
       timea = tc+sc;
       timeb = time-sf;
     }
     else if (time == tc && updatedstep == DAGHCurrentTime) {
       timea = tc;
       timeb = time-sf;
     }
     else {
       timea = tc+sc;
       timeb = time-sf;
     }

     double const frac = 1.0*(time-timeb)/(timea-timeb);
     int ta = dagh_timeindex(timea,l-1);
     int tb = dagh_timeindex(timeb,l);

     register int i;
     for (i=0; i<length; i++) {
       if (gdb[t][l][i] && gdb[tb][l][i] && gdb[ta][l-1][i]) {
         GridData(1)<DAGH_GFType> &pbl = gdb[tb][l][i]->griddata(ident,mgl);
         GridData(1)<DAGH_GFType> &palm = gdb[ta][l-1][i]->griddata(ident,mgl);
         GridData(1)<DAGH_GFType> &pl = gdb[t][l][i]->griddata(ident,mgl);

         if (pfunc) { /* Call the prolongation function */
           int myargc = 0; DAGH_GFType myargs[1];
           for(register int b=0; b<gfrank; b++)  {
             if (gdb[t][l][i]->prolong_ghost(2*b) && 
                 gdb[t][l][i]->has_neighbor(2*b))
               (*pfunc)(FORTRAN_ARGS(palm),FORTRAN_ARGS(pl),
                        BOUNDING_BOX(gdb[t][l][i]->prolong_ghostbox(2*b,ident,mgl)),
                        myargs,&myargc);
             if (gdb[t][l][i]->prolong_ghost(2*b+1) && 
                 gdb[t][l][i]->has_neighbor(2*b+1))
               (*pfunc)(FORTRAN_ARGS(palm),FORTRAN_ARGS(pl),
                        BOUNDING_BOX(gdb[t][l][i]->prolong_ghostbox(2*b+1,ident,mgl)),
                        myargs,&myargc);
           }
         }
         /*$else {$*/ /* Just inject for testing */
           /*$for(register int b=0; b<gfrank; b++)  {
             if (gdb[t][l][i]->prolong_ghost(2*b) && 
                 gdb[t][l][i]->has_neighbor(2*b))
               pl.copy(palm,gdb[t][l][i]->prolong_ghostbox(2*b,ident,mgl));
             if (gdb[t][l][i]->prolong_ghost(2*b+1) && 
                 gdb[t][l][i]->has_neighbor(2*b+1))
               pl.copy(palm,gdb[t][l][i]->prolong_ghostbox(2*b+1,ident,mgl));
           }
         }$*/

         /* data = (old * (1-frac)) + (new * frac) */
         for (register int b=0; b<gfrank; b++)  {
           if (gdb[t][l][i]->prolong_ghost(2*b) && 
               gdb[t][l][i]->has_neighbor(2*b))
             pl.lin_interp(pbl,(1.0-frac),pl,frac,
                           gdb[t][l][i]->prolong_ghostbox(2*b,ident,mgl));
           if (gdb[t][l][i]->prolong_ghost(2*b+1) && 
               gdb[t][l][i]->has_neighbor(2*b+1))
             pl.lin_interp(pbl,(1.0-frac),pl,frac,
                           gdb[t][l][i]->prolong_ghostbox(2*b+1,ident,mgl));
         }
       }
     }
   } /* end t > 0 */
   else { /* if t == 0 */
     register int i;
     for (i=0; i<length; i++) if (gdb[t][l][i]) {
       GridData(1)<DAGH_GFType> &pl = gdb[t][l][i]->griddata(ident,mgl);
       GridData(1)<DAGH_GFType> &plm = gdb[t][l-1][i]->griddata(ident,mgl);

       if (pfunc) { /* Call the prolongation function */
         int myargc = 0; DAGH_GFType myargs[1];
         for(register int b=0; b<gfrank; b++)  {
           if (gdb[t][l][i]->prolong_ghost(2*b) &&
               gdb[t][l][i]->has_neighbor(2*b)) 
             (*pfunc)(FORTRAN_ARGS(plm),FORTRAN_ARGS(pl),
                      BOUNDING_BOX(gdb[t][l][i]->prolong_ghostbox(2*b,ident,mgl)),
                      myargs,&myargc);
           if (gdb[t][l][i]->prolong_ghost(2*b+1) &&
               gdb[t][l][i]->has_neighbor(2*b+1)) 
             (*pfunc)(FORTRAN_ARGS(plm),FORTRAN_ARGS(pl),
                      BOUNDING_BOX(gdb[t][l][i]->prolong_ghostbox(2*b+1,ident,mgl)),
                      myargs,&myargc);
         }
       }
       /*$else {$*/ /* Just inject for testing */
         /*$for(register int b=0; b<gfrank; b++)  {
           if (gdb[t][l][i]->prolong_ghost(2*b) &&
               gdb[t][l][i]->has_neighbor(2*b))
             pl.copy(plm,gdb[t][l][i]->prolong_ghostbox(2*b,ident,mgl));
           if (gdb[t][l][i]->prolong_ghost(2*b+1) &&
               gdb[t][l][i]->has_neighbor(2*b+1))
             pl.copy(plm,gdb[t][l][i]->prolong_ghostbox(2*b+1,ident,mgl));
         }
       }$*/
     }
   } /* end t == 0 */
  }

template <class DAGH_GFType>
void GridFunction(1)<DAGH_GFType>::GF_InterpGhosts(const int time,
                                                   const int level,
                                                   const int mgl,
                                                   const int axis,
                                                   const int dir,
                                                   const int ident)
  {
   if (level == 0 || !prolong()) return;

   register int const t = dagh_timeindex(time,level);
   register int const l = level;

   if (t > 0) {
     int tf = dagh.getCurrentTime(l);
     int tc = dagh.getCurrentTime(l-1);
     int sf = dagh.timestep(l);
     int sc = dagh.timestep(l-1);
     int timea, timeb;

     if (time < tc) {
       timea = tc;
       timeb = time-sf;
     }
     else if (time == tc && updatedstep == DAGHNextTime) {
       timea = tc+sc;
       timeb = time-sf;
     }
     else if (time == tc && updatedstep == DAGHCurrentTime) {
       timea = tc;
       timeb = time-sf;
     }
     else {
       timea = tc+sc;
       timeb = time-sf;
     }

     double const frac = 1.0*(time-timeb)/(timea-timeb);
     int ta = dagh_timeindex(timea,l-1);
     int tb = dagh_timeindex(timeb,l);

     register int i;
     for (i=0; i<length; i++) {
       if (gdb[t][l][i] && gdb[tb][l][i] && gdb[ta][l-1][i]) {

         GridData(1)<DAGH_GFType> &pbl = gdb[tb][l][i]->griddata(ident,mgl);
         GridData(1)<DAGH_GFType> &palm = gdb[ta][l-1][i]->griddata(ident,mgl);
         GridData(1)<DAGH_GFType> &pl = gdb[t][l][i]->griddata(ident,mgl);

         if (pfunc) { /* Call the prolongation function */
           int myargc = 0; DAGH_GFType myargs[1];
           for(register int b=0; b<gfrank; b++)  {
             if (b != axis && axis != DAGH_All) continue;
             if ((dir == DAGH_Backward || dir == DAGH_Both) &&
                 gdb[t][l][i]->prolong_ghost(2*b) && 
                 gdb[t][l][i]->has_neighbor(2*b))
               (*pfunc)(FORTRAN_ARGS(palm),FORTRAN_ARGS(pl),
                        BOUNDING_BOX(gdb[t][l][i]->prolong_ghostbox(2*b,ident,mgl)),
                        myargs,&myargc);
             if ((dir == DAGH_Forward || dir == DAGH_Both) &&
                 gdb[t][l][i]->prolong_ghost(2*b+1) && 
                 gdb[t][l][i]->has_neighbor(2*b+1))
               (*pfunc)(FORTRAN_ARGS(palm),FORTRAN_ARGS(pl),
                        BOUNDING_BOX(gdb[t][l][i]->prolong_ghostbox(2*b+1,ident,mgl)),
                        myargs,&myargc);
           }
         }
         /*$else {$*/ /* Just inject for testing */
           /*$for(register int b=0; b<gfrank; b++)  {
             if (b != axis && axis != DAGH_All) continue;
             if ((dir == DAGH_Backward || dir == DAGH_Both) &&
                 gdb[t][l][i]->prolong_ghost(2*b) && 
                 gdb[t][l][i]->has_neighbor(2*b))
               pl.copy(palm,gdb[t][l][i]->prolong_ghostbox(2*b,ident,mgl));
             if ((dir == DAGH_Forward || dir == DAGH_Both) &&
                 gdb[t][l][i]->prolong_ghost(2*b+1) && 
                 gdb[t][l][i]->has_neighbor(2*b+1))
               pl.copy(palm,gdb[t][l][i]->prolong_ghostbox(2*b+1,ident,mgl));
           }
         }$*/

         /* data = (old * (1-frac)) + (new * frac) */
         for (register int b=0; b<gfrank; b++)  {
           if (b != axis && axis != DAGH_All) continue;
           if ((dir == DAGH_Backward || dir == DAGH_Both) &&
               gdb[t][l][i]->prolong_ghost(2*b) && 
               gdb[t][l][i]->has_neighbor(2*b))
             pl.lin_interp(pbl,(1.0-frac),pl,frac,
                           gdb[t][l][i]->prolong_ghostbox(2*b,ident,mgl));
           if ((dir == DAGH_Forward || dir == DAGH_Both) &&
               gdb[t][l][i]->prolong_ghost(2*b+1) && 
               gdb[t][l][i]->has_neighbor(2*b+1))
             pl.lin_interp(pbl,(1.0-frac),pl,frac,
                           gdb[t][l][i]->prolong_ghostbox(2*b+1,ident,mgl));
         }
       }
     }
   } /* end t > 0 */
   else { /* if t == 0 */
     register int i;
     for (i=0; i<length; i++) if (gdb[t][l][i]) {
       GridData(1)<DAGH_GFType> &pl = gdb[t][l][i]->griddata(ident,mgl);
       GridData(1)<DAGH_GFType> &plm = gdb[t][l-1][i]->griddata(ident,mgl);

       if (pfunc) { /* Call the prolongation function */
         int myargc = 0; DAGH_GFType myargs[1];
         for(register int b=0; b<gfrank; b++)  {
           if (b != axis && axis != DAGH_All) continue;
           if ((dir == DAGH_Backward || dir == DAGH_Both) &&
               gdb[t][l][i]->prolong_ghost(2*b) &&
               gdb[t][l][i]->has_neighbor(2*b)) 
             (*pfunc)(FORTRAN_ARGS(plm),FORTRAN_ARGS(pl),
                      BOUNDING_BOX(gdb[t][l][i]->prolong_ghostbox(2*b,ident,mgl)),
                      myargs,&myargc);
           if ((dir == DAGH_Forward || dir == DAGH_Both) &&
               gdb[t][l][i]->prolong_ghost(2*b+1) &&
               gdb[t][l][i]->has_neighbor(2*b+1)) 
             (*pfunc)(FORTRAN_ARGS(plm),FORTRAN_ARGS(pl),
                      BOUNDING_BOX(gdb[t][l][i]->prolong_ghostbox(2*b+1,ident,mgl)),
                      myargs,&myargc);
         }
       }
       /*$else {$*/ /* Just inject for testing */
         /*$for(register int b=0; b<gfrank; b++)  {
           if (b != axis && axis != DAGH_All) continue;
           if ((dir == DAGH_Backward || dir == DAGH_Both) &&
               gdb[t][l][i]->prolong_ghost(2*b) &&
               gdb[t][l][i]->has_neighbor(2*b))
             pl.copy(plm,gdb[t][l][i]->prolong_ghostbox(2*b,ident,mgl));
           if ((dir == DAGH_Forward || dir == DAGH_Both) &&
               gdb[t][l][i]->prolong_ghost(2*b+1) &&
               gdb[t][l][i]->has_neighbor(2*b+1))
             pl.copy(plm,gdb[t][l][i]->prolong_ghostbox(2*b+1,ident,mgl));
         }
       }$*/
     }
   } /* end t == 0 */
  }
/*****************************************************************************/

#endif
