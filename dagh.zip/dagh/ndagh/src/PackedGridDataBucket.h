#ifndef _included_PackedGridDataBucket_h
#define _included_PackedGridDataBucket_h

/*
*************************************************************************
* PackedGridDataBucket.h                           			*
*                              						*
*************************************************************************
*/

#include "DAGHParams.h"

#include "Coords.h"
#include "BBox.h"

#include "PackedDataBucketVoid.h"
#include "ObjectCounter.h"

/* Bucket/Message Types */
#define DAGHSingle	(1)
#define DAGHPacked	(2)

#ifndef DAGHBktGFNameWidth
#define DAGHBktGFNameWidth	(8)
#endif

struct gdhdr
  {
   friend ostream&  operator << (ostream& os, const struct gdhdr& hdr);

   short int type;			// Bucket type - DAGHSingle or DAGHPacked
   short int owner;			// Who owns the associated Grid function
   short unsigned gfid;			// Grid function id
   short gfdatatype;			// Grid function data type
   short gfstaggertype;			// Grid function staggering (DAGHCellCentered.. etc)
   char gfname[DAGHBktGFNameWidth];	// Grid function name
   BBox bbox;				// Region
   short int time;			// Time
   short int level;			// Level
   short int index;			// Storage index
   short int ident;			// DAGH_Main or DAGH_Shadow
   dMapIndex baseindex;			// SFC index

   inline gdhdr() {};
   gdhdr(struct gdhdr& other);

   gdhdr(const BBox& bb, 
         const unsigned gf, const int gft, const int gfs, const char* gfn,
         const int t, const int l, const int index,
         const int who, const dMapIndex& bindex, 
	 const int which, const int type);

   static unsigned gdbsize(const unsigned dsize);
  };

#define GridDataBucketVoidNULL  ((GridDataBucketVoid *)NULL)

class GridDataBucketVoid : public DataBucketVoid, public ObjectCounter
  {
   int bkttype;

private:
   GridDataBucketVoid(const GridDataBucketVoid&);	
   void operator = (const GridDataBucketVoid&);

public:
   inline GridDataBucketVoid* alias()
        { return((GridDataBucketVoid *) ObjectCounter::alias()); }

   GridDataBucketVoid(const BBox& bb, const unsigned gf,
           const int time, const int level, const int index,
           const int who, const dMapIndex& bindex, 
           const unsigned datasize, const int ident,
           const int type);

   GridDataBucketVoid(const BBox& bb, const unsigned gf, const int gfdtype, const int gfstype,
           const char* gfname, const int time, const int level, const int index,
           const int who, const dMapIndex& bindex, 
           const unsigned datasize, const int ident,
           const int type);

   inline GridDataBucketVoid(const int n, unsigned* dsizes, const int type)
        :bkttype(type), DataBucketVoid(sizeof(struct gdhdr), dsizes, n) {}

   void add(const BBox& bb, const unsigned gf, const int time, const int level, 
       const int index, const int who, const dMapIndex& bindex, 
       const int ident, const int n);

   void add(const BBox& bb, const unsigned gf, const int gfdtype, const int gfstype,
            const char* gfname, 
       const int time, const int level, const int index, const int who, 
       const dMapIndex& bindex, const int ident, const int n);

   inline GridDataBucketVoid(const void* package)
         :DataBucketVoid((const union drecord *) package) 
   { bkttype = ((struct gdhdr *) DataBucketVoid::head())->type; }

   inline GridDataBucketVoid(void* package)
        :DataBucketVoid((union drecord *) package) 
   { bkttype = ((struct gdhdr *) DataBucketVoid::head())->type; }

   inline GridDataBucketVoid(const void* package, const int n)
         :DataBucketVoid((const union drecord *) package, n) 
   { bkttype = ((struct gdhdr *) DataBucketVoid::head())->type = DAGHSingle; }

   GridDataBucketVoid(const struct gdhdr& other, const unsigned datasize);

   inline int const type() const { return (bkttype); }

   inline struct gdhdr *head()
	{ return ( (struct gdhdr *) DataBucketVoid::head() ); }
   inline struct gdhdr *head(const int i)
	{ return ( (struct gdhdr *) DataBucketVoid::head(i) ); }

   inline BBox const &bbox() const
	{ return (((struct gdhdr *) DataBucketVoid::head())->bbox); }
   inline BBox const &bbox(const int i) const
	{ return (((struct gdhdr *) DataBucketVoid::head(i))->bbox); }

   inline short int owner() const
	{ return (((struct gdhdr *) DataBucketVoid::head())->owner); }
   inline short int owner(const int i) const
	{ return (((struct gdhdr *) DataBucketVoid::head(i))->owner); }

   inline short int time() const
	{ return ( ((struct gdhdr *) DataBucketVoid::head())->time); }
   inline short int time(const int i) const
	{ return ( ((struct gdhdr *) DataBucketVoid::head(i))->time); }

   inline short int level() const
	{ return ( ((struct gdhdr *) DataBucketVoid::head())->level); }
   inline short int level(const int i) const
	{ return ( ((struct gdhdr *) DataBucketVoid::head(i))->level); }

   inline short int index() const
	{ return ( ((struct gdhdr *) DataBucketVoid::head())->index); }
   inline short int index(const int i) const
	{ return ( ((struct gdhdr *) DataBucketVoid::head(i))->index); }

   inline short int ident() const
	{ return ( ((struct gdhdr *) DataBucketVoid::head())->ident); }
   inline short int ident(const int i) const
	{ return ( ((struct gdhdr *) DataBucketVoid::head(i))->ident); }

   inline short unsigned gfid() const
	{ return ( ((struct gdhdr *) DataBucketVoid::head())->gfid); }
   inline short unsigned gfid(const int i) const
	{ return ( ((struct gdhdr *) DataBucketVoid::head(i))->gfid); }

   inline short gfdatatype() const
	{ return ( ((struct gdhdr *) DataBucketVoid::head())->gfdatatype); }
   inline short gfdatatype(const int i) const
	{ return ( ((struct gdhdr *) DataBucketVoid::head(i))->gfdatatype); }

   inline short gfstaggertype() const
	{ return ( ((struct gdhdr *) DataBucketVoid::head())->gfstaggertype); }
   inline short gfstaggertype(const int i) const
	{ return ( ((struct gdhdr *) DataBucketVoid::head(i))->gfstaggertype); }

   inline char *gfname() const
	{ return ( ((struct gdhdr *) DataBucketVoid::head())->gfname); }
   inline char *gfname(const int i) const
	{ return ( ((struct gdhdr *) DataBucketVoid::head(i))->gfname); }

   inline void setgfname(const char *name) const
   { strncpy(((struct gdhdr *)DataBucketVoid::head())->gfname,
     name,DAGHBktGFNameWidth-1); }
   inline void setgfname(const char *name, const int i) const
   { strncpy(((struct gdhdr *)DataBucketVoid::head(i))->gfname,
     name,DAGHBktGFNameWidth-1); }

   inline dMapIndex const &baseindex() const
	{ return ( ((struct gdhdr *) DataBucketVoid::head())->baseindex); }
   inline dMapIndex const &baseindex(const int i) const
	{ return ( ((struct gdhdr *) DataBucketVoid::head(i))->baseindex); }
  };

template <class Type>
class GridDataBucket: public GridDataBucketVoid
  {
private:
   GridDataBucket(const GridDataBucket<Type>&);	
   void operator = (const GridDataBucket<Type>&);

public:
   inline GridDataBucket(const BBox& bb, const unsigned gf,
          const int time, const int level, const int index, const int who, 
          const dMapIndex& bindex, const int ident=DAGH_Main, 
          const int type=DAGHSingle)
	: GridDataBucketVoid(bb, gf, time, level, index, who, bindex, 
                             sizeof(Type), ident, type) {}

   inline GridDataBucket(const BBox& bb, const unsigned gf, 
          const int gfdtype, const int gfstype, const char* gfname,
          const int time, const int level, const int index, const int who, 
          const dMapIndex& bindex, const int ident=DAGH_Main, 
          const int type=DAGHSingle)
	: GridDataBucketVoid(bb, gf, gfdtype, gfstype, gfname, time, level, index, 
                             who, bindex, sizeof(Type), ident, type) {}

   inline GridDataBucket(const void* package) 
        : GridDataBucketVoid(package) {}

   inline GridDataBucket(void* package) 
        : GridDataBucketVoid(package) {}

   inline GridDataBucket(const void* package, const int n) 
	: GridDataBucketVoid(package, n) {}

   inline GridDataBucket(const int n, unsigned* dsizes, 
                         const int type=DAGHSingle)
        : GridDataBucketVoid(n, dsizes, type) {}

   inline Type const *data() const
	{ return ( (Type *) DataBucketVoid::data() ); }
   inline Type *data(void)
	{ return ( (Type *) DataBucketVoid::data() ); }

   inline Type const *data(const int i) const
	{ return ( (Type *) DataBucketVoid::data(i) ); }
   inline Type *data(const int i)
	{ return ( (Type *) DataBucketVoid::data(i) ); }
  };

#endif
