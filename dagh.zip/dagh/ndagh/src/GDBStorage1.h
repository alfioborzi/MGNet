#ifndef _included_GDBStorage1_h
#define _included_GDBStorage1_h

/*
*************************************************************************
*                                                                       *
* GDBStorage1.h								*
*                                                                       *
* One unit of GDB storage						*
*                                                                       *
*************************************************************************
*/

#ifndef GridDataBlockStorage
#define GridDataBlockStorage(dim)	name2(GridDataBlockStorage,dim)
#endif

template <class Type> class GridDataBlock(1);
template <class Type> class GridFunction(1);

template <class Type>
class GridDataBlockStorage(1)
  {
   friend ostream& operator<<(ostream&, const GridDataBlockStorage(1)<Type>&);
   friend class GridDataBlock(1)<Type>;
   friend class GridFunction(1)<Type>;

   BBox bbox;
   BBox ibbox;
   BBox bndrybbox[2*1];
   GridData(1)<Type> data;

   inline GridDataBlockStorage(1)() {}
   inline void allocate() { data.allocate(bbox); }
  };

template <class Type>
ostream& operator<<(ostream& os, const GridDataBlockStorage(1)<Type>& gdbs);

#endif
