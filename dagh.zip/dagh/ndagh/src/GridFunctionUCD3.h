#ifndef _included_GridFunctionUCD3_h
#define _included_GridFunctionUCD3_h

/*
*************************************************************************
*                                                                                                                            *
* GridFunctionUCD3.h                                                                                        *
*                                                                                                                            *      
* Author:  Manish Parashar <parashar@cs.utexas.edu>                                *
*                                                                                                                            *
*************************************************************************
*/

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_GetUCDData(const DAGHUCD(3)& daghucd, 
						 const int t,
						 DAGH_GFType*& ucddata,
						 const int ucdserver)
{
  const int me = comm_service::proc_me();

  assert (!ucddata);
  if (me == ucdserver) 
    ucddata = new DAGH_GFType[daghucd.totalnodes];
  
  for (register int idx=0; idx<daghucd.numblks; idx++) {
    const GridData(3)<int>& ucdgd = daghucd.blks[idx];
    const BBox& b = ucdgd.bbox();
    const Coords& s = ucdgd.stepsize();
    assert (s(0) == s(1) && s(0) == s(2));
    const int l = dagh.step2level(s(0));
    GridData(3)<DAGH_GFType> tmpgd;
    GF_gather_one(t,l,b,b,tmpgd,ucdserver,daghucd.ident_flag);

    if (me == ucdserver) {
      for_3(i,j,k,b,s) {
	ucddata[ucdgd(i,j,k)] = tmpgd(i,j,k);
      } end_for
    }
  }
}

#endif
