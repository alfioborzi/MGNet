#ifndef _included_DAGHParam_h
#define _included_DAGHParam_h

/*@@
  @file     DAGHParams.h
  @author   Manish Parashar
  @desc
      <pre>
 DAGHParam.h                                                           
                                                                       
      </pre>
  @enddesc
  @comment
      <code>
      $Id: DAGHParams.h,v 1.7 1997/04/25 21:54:34 parashar Exp $
      </code>
  @endcomment
@@*/

/* Default includes */
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <assert.h>
#include <generic.h>
#include <string.h>
#include <iostream.h>
#include <fstream.h>

/* DAGH True/False */
#define DAGHTrue        	(1)
#define DAGHFalse       	(0)

/* DAGH Nulls */
#define DAGHNull        	(-1)
#define DAGHNoBody      	(DAGHNull)
#define DAGHNullLevel   	(DAGHNull)

#define DAGHAll         	(9999)
#define DAGHSmall         	(-999999)
#define DAGHLarge         	( 999999)

/* Level Information */
#define DAGHAllLevels		(DAGHAll)

/* Time Information */
#define DAGHAllTimes		(DAGHAll)
#define DAGHCurrentTime		(0)
#define DAGHNextTime		(1)
#define DAGHPreviousTime	(2)

/* Distribution Types */
#define DAGHCompositeDistribution	(1)
#define DAGHBlockXDistribution		(2)
#define DAGHBlockYDistribution		(3)
#define DAGHBlockZDistribution		(4)
#define DAGHBlockXYDistribution		(5)
#define DAGHBlockYZDistribution		(6)
#define DAGHBlockXZDistribution		(7)
#define DAGHBlockAllDistribution	(8)
#define DAGHUserDefDistribution	        (9)

/* Interaction Types */
#define DAGHNoInteraction         	(DAGHNull)
#define DAGHGhostInteraction      	(1)

/* GridFunction Flags */
#define DAGHInitGFOnCreation		(DAGHFalse)

/* Axis Information */
#define DAGHMaxRank     (3)

#define DAGH_X		(0)
#define DAGH_Y		(1)
#define DAGH_Z		(2)
#define DAGH_All	(3)
#define DAGHMaxAxis	(4)	/* 3 + 1 */
#define DAGH_XY		(5)
#define DAGH_XZ		(6)
#define DAGH_YZ		(7)

/* Direction Information */
#define DAGH_Backward	(0)
#define DAGH_Forward	(1)
#define DAGH_Both	(2)
#define DAGHMaxDirs	(3)	/* 2 + 1 */
#define DAGHHisDir(d)	(((d) == DAGH_Both) ? (d) : (1 - (d)))
#define DAGH_Inside	(4)

/* Hierarchy Information */
#define DAGH_BothGH		(-20)
#define DAGH_Main 		(-21)
#define DAGH_Shadow		(-22)

/* DAGH Types */
#define DAGHCellCentered	(1)
#define DAGHNonCellCentered	(2)
#define DAGHVertexCentered	(2)
#define DAGHFaceCentered_X	(3)
#define DAGHFaceCentered_Y	(4)
#define DAGHFaceCentered_Z	(5)

/* GF Comm Flag */
#define DAGHNoComm		(DAGHNull)
#define DAGHComm		(1)
#define DAGHCommNoFace		(2)
#define DAGHCommFaceOnly	(3)
#define DAGHCommNoCorner	(4)
#define DAGHCommNoEdge		(5)
#define DAGHCommCurrentTimeOnly	(6)
#define DAGHTemplateComm        (20)

/* GF Shadow Flag */
#define DAGHNoShadow		(DAGHNull)
#define DAGHHasShadow		(DAGHTrue)

/* GF External Ghost Flag */
#define DAGHNoExternalGhost	(DAGHNull)
#define DAGHHasExternalGhost	(DAGHTrue)

/* GF Checkpoint Flag */
#define DAGHNoCheckpoint	(DAGHNull)
#define DAGHCheckpoint  	(DAGHTrue)

/* Return Types */
#define DAGH_OK         	(0)
#define DAGH_ERROR      	(-1)
#define DAGH_WARN       	(-2)
#define DAGH_FATAL      	(-3)

/* Coordinate Types */
#define DAGHWorldCoords         (1)
#define DAGHLocalCoords         (2)

/* DAGHViz Types */
#define DAGHViz_NONE		(DAGHNull)
#define DAGHViz_XGRAPH		(1)
#define DAGHViz_FILE		(2)

/* Message Classes */
#define DAGHGhost           0
#define DAGHData            1
#define DAGHIO              2
#define DAGHService         3

/* Message Tag Shifts */
#define DAGHTypeShift	    (12)
#define DAGHTimeShift	    (10)
#define DAGHLevelShift	    (4)
#define DAGHDirShift	    (0)

/* Message Tags */
#define DAGHGhostTag        (DAGHGhost << DAGHTypeShift)
#define DAGHDataTag         (DAGHData << DAGHTypeShift)
#define DAGHIOTag           (DAGHIO << DAGHTypeShift)
#define DAGHServiceTag      (DAGHService << DAGHTypeShift)

/* DAGH Boundary Which */
#define DAGH_ExternalBoundary		(1)
#define DAGH_AdaptiveBoundary		(2)
#define DAGH_InternalBoundary		(3)

/* DAGH External Boundary Types */
#define DAGHNoBoundary			(0)
#define DAGHBoundaryConst		(1)
#define DAGHBoundaryRegular		(1)
#define DAGHBoundaryShift		(2)
#define DAGHBoundaryPeriodic		(3)
#define DAGHBoundaryUserDef             (4)

/* DAGH AdaptiveBoundary Types */
#define DAGHNoAdaptBoundary		(0)
#define DAGHAdaptBoundaryInterp         (1)
#define DAGHAdaptBoundaryUserDef        (2)
#define DAGHAdaptBoundaryBoth           (3)

/* Choose the type of d-mapping to be used */
#include "PeanoHilbert.h"
typedef class PeanoHilbert dMapIndex;
#define dMapIndexNULL 	((dMapIndex *)NULL)

/* Emulating fortran types */
#if (defined(CRAYC90) || defined(CRAYT3D) || defined(CRAYT3E))
typedef int INTEGER;
typedef double REAL;
typedef long double DOUBLE;
typedef char CHARACTER;
#else
typedef int INTEGER;
typedef float REAL;
typedef double DOUBLE;
typedef char CHARACTER;
#endif

/* Emulating fortran types */
#ifndef MAXLIM
#define MAXLIM(T) ((T)(((unsigned long)(-1))))
// # define MAXLIM(T) ((T)((~(unsigned long)0 >> 1)))
// # define MAXLIM(T) ((T)((unsigned) 1 << (8*sizeof(T))))
#endif

/* GridData, GridDataBlock & GridFunction naming macros */
#ifndef GridFunctionName
#define GridFunction(dim)      name2(GridFunction,dim)
#define GridFunctionName
#endif

#ifndef GridDataBlockName
#define GridDataBlock(dim)      name2(GridDataBlock,dim)
#define GridDataBlockName
#endif

#ifndef GridDataName
#define GridData(dim)      name2(GridData,dim)
#define GridDataName
#endif

#ifndef Array
#define Array      GridData
#endif

#ifndef DAGHUCDName
#define DAGHUCD(dim)	name2(DAGHUCD,dim)
#define DAGHUCDName
#endif

/* Fortran interface generation macros */
#include "DAGHFortranInterfaces.h"

inline unsigned int max(const unsigned int a, const unsigned int b)
       { return((a > b) ? a : b); }
inline unsigned int min(const unsigned int a, const unsigned int b)
       { return((a < b) ? a : b); }

// ---------------------------------------------------------------------
// For efficiency, some methods may be inlined.  To avoid inline methods,
// sometimes necessary for debugging purposes, simply comment out the
// '#define __ENABLE_INLINE__' statement.

#ifdef __ENABLE_INLINE__
#define __INLINE__      inline
#else
#define __INLINE__      /* */
#endif

// ---------------------------------------------------------------------

#include "DAGHParamsOld.h"
#include "DAGHDefaults.h"

#endif
