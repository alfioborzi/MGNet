/***********************************************************************
*
* Subroutine KLMG    Multigrid correction algorithm
*
* Key: n  integer     i  input        1  vector
*      r  real        o  output       2  matrix
*      d  real*8      s  scratch
*      c  character
*
*      Argument  Description
*      --------  -----------
* no   flag      error flag
*                   0  no error
*                  -1  illegal matrix type
*                  -2  illegal opt
*                  -3  no restriction/prolongation matrix
*                  -4  illegal method for klsmds
*                  -5  out of real space in smoothing routines
*                  -6  out of integer space in direct solver
*                  -7  incorrect matrix type for matrix-vector multiply
*                  n+i zero pivot in row i
* ns1  iscr      scratch vector for integers
* nio  levinf    level information, structure
* ni1  madinf    multilevel-aggregation-disaggregation information,
*                size 20
* ro1  res       residuals
* rs1  scr       scratch vector for reals
* ro1  u         factored matrices stored in sparse form with n rows
*
* Algorithm MG(j, maxlev, x, b, m, p, r)
* ---------
*   (1) If j == maxlev, then solve directly
*   (2) If j != maxlev, then
*       (a) Smooth m times on x
*       (b) Do r times
*           (i)   compute a rhs c and an initial guess e = 0 for a
*                 residual correction problem on level j+1
*           (ii)  mg(j+1, maxlev, e, c, m, p, p)
*           (iii) x = x + e
*           (iv)  smooth m times on x
*
* Multiplies/Divides
* ------------------
* Variable: this depends on the choice of parameters and the smoothing
* method.
*
* Reference
* ---------
* Randolph E. Bank and Craig C. Douglas, Sharp estimates for multigrid
*   rates of convergence with general smoothing and acceleration, SIAM
*   Journal on Numerical Analysis, 22 (1985), pp. 617-633.
*
***********************************************************************/

#include "defnc.pre"
#include "defnc.v2"

klmg(madinf, levinf, u, res, iscr, scr, flag)

        INT     *flag, *iscr, *madinf;
        REAL    *res, *scr, *u;
        struct  stlevinf **levinf;
  {
  /*********************************************************************
  *****local variables */
  INT     *iter, lev, levm1, one, rt, uused, zero;
  /********************************************************************/

  /* initialization */
  one = 1;
  zero = 0;

  *flag = 0;
  iter = (INT *)malloc((LEVCOR + 1) * sizeof(INT));
  lev = LEVFINE;
  levm1 = lev - 1;
  iter[lev] = ITRFINE;

  /* main loop of computation */
  while (1) {

    /* smooth or solve problem directly */
    klsmds(&SMMETH(levm1), &ITRSM, &NACOLS(levm1), PTRA(levm1),
           PTRIJA(levm1),  &JUSHFT(levm1), u,
           PTRX(levm1), PTRB(levm1),
           res, iscr, scr, &LENU, &LENISCR, &LENSCR,
           &uused, &ATYPE(levm1), flag);
    if (*flag != 0) break;
    if (SMMETH(lev) == 1) SMMETH(lev) = 3;
    iter[lev]--;

    /* transfer to a coarse level */
    if (iter[lev] >= 0 && lev < LEVCOR) {
      if (lev < LEVCOR) {
        if (PTRR(levm1) != NULL)
          klax(&zero, &NRROWS(levm1), &NRCOLS(levm1),
               PTRIJR(levm1), PTRR(levm1),
               res, PTRB(lev), &RTYPE(levm1),
               flag);
        else if (PTRP(levm1) != NULL) {
          rt = - PTYPE(levm1);
          klax(&zero, &NPROWS(levm1), &NPCOLS(levm1),
               PTRIJP(levm1), PTRP(levm1),
               res, PTRB(lev), &rt,
               flag);
          }
        else {
          *flag = -3;
          break;
          }

        lev++;
        levm1++;
        klzero(&NACOLS(levm1), PTRX(levm1));
        iter[lev] = ITRCOR;
        }
      }

    /* transfer to a finer level */
    else {
      lev--;
      levm1--;
      if (lev >= LEVFINE)
        if (PTRP(lev) != NULL)
          klax(&one, &NPROWS(levm1), &NPCOLS(levm1),
               PTRIJP(levm1), PTRP(levm1),
               PTRX(lev), PTRX(levm1), &PTYPE(levm1),
               flag);
        else if (PTRR(levm1) != NULL) {
          rt = - RTYPE(levm1);
          klax(&one, &NRROWS(levm1), &NRCOLS(levm1),
               PTRIJR(levm1), PTRR(levm1),
               PTRX(lev), PTRX(levm1), &rt, flag);
          }
        else
          *flag = -3;
      }

    if (lev < LEVFINE || *flag != 0) break;
    }

  free(iter);
  }  
