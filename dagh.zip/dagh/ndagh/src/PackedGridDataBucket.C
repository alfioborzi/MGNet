/*
*************************************************************************
* PackedGridDataBucket.C                           			*
*                              						*
*************************************************************************
*/

#include "PackedGridDataBucket.h"

/*************************************************************************/
gdhdr::gdhdr(struct gdhdr& other)
        : type(other.type), owner(other.owner), 
          gfid(other.gfid), gfdatatype(other.gfdatatype), 
          gfstaggertype(other.gfstaggertype),
          bbox(other.bbox), 
          time(other.time), level(other.level), index(other.index),
          ident(other.ident), baseindex(other.baseindex) 
  {
   strncpy(gfname,other.gfname,DAGHBktGFNameWidth-1);
   gfname[DAGHBktGFNameWidth-1] = '\0';
  }

gdhdr::gdhdr(const BBox& bb, 
             const unsigned gf, const int gft, const int gfs, const char* gfn, 
             const int t, const int l, const int idx,
             const int who, const dMapIndex& bindex,
             const int which, const int bkttype)
        : type(bkttype), owner(who), 
          gfid(gf), gfdatatype(gft), gfstaggertype(gfs),
          bbox(bb), 
          time(t), level(l), index(idx),
          ident(which), baseindex(bindex) 
  {
   strncpy(gfname,gfn,DAGHBktGFNameWidth-1);
   gfname[DAGHBktGFNameWidth-1] = '\0';
  }

unsigned gdhdr::gdbsize(const unsigned dsize)
  {
   unsigned hsize = sizeof(struct gdhdr) + sizeof(struct dbkthdr);
   unsigned int align = ((hsize > 8) ? 16 : ((hsize > 4) ? 8 : 4));
   unsigned headsize = (hsize+align-1) & (~(align-1));

   align = ((dsize > 8) ? 16 : ((dsize > 4) ? 8 : 4));
   unsigned datasize = (dsize+align-1) & (~(align-1));

   return (headsize+datasize);
 }
/*************************************************************************/

GridDataBucketVoid::GridDataBucketVoid(const BBox& bb, 
        const unsigned gf,
	const int time, const int level, const int index, 
        const int who, const dMapIndex& bindex, 
        const unsigned datasize, const int ident, const int type)
        :bkttype(type), DataBucketVoid(sizeof(struct gdhdr),datasize*bb.size())
  {
   struct gdhdr *gdh = (struct gdhdr *) DataBucketVoid::head();
   gdh->type = bkttype;
   gdh->owner = (short) who;
   gdh->gfid = (short) gf;
   gdh->gfdatatype = DAGHNull;
   gdh->gfstaggertype = DAGHNull;
   gdh->gfname[0] = '\0';
   gdh->bbox = bb;
   gdh->time = time;
   gdh->level = level;
   gdh->index = index;
   gdh->ident = ident;
   gdh->baseindex = bindex;
  }

GridDataBucketVoid::GridDataBucketVoid(const BBox& bb, 
        const unsigned gf, const int gfdtype, const int gfstype, const char* gfname,
	const int time, const int level, const int index, 
        const int who, const dMapIndex& bindex, 
        const unsigned datasize, const int ident, const int type)
        :bkttype(type), DataBucketVoid(sizeof(struct gdhdr),datasize*bb.size())
  {
   struct gdhdr *gdh = (struct gdhdr *) DataBucketVoid::head();
   gdh->type = bkttype;
   gdh->owner = (short) who;
   gdh->gfid = (short) gf;
   gdh->gfdatatype = gfdtype;
   gdh->gfstaggertype = gfstype;
   strncpy(gdh->gfname,gfname,DAGHBktGFNameWidth-1);
   gdh->gfname[DAGHBktGFNameWidth-1] = '\0';
   gdh->bbox = bb;
   gdh->time = time;
   gdh->level = level;
   gdh->index = index;
   gdh->ident = ident;
   gdh->baseindex = bindex;
  }

GridDataBucketVoid::GridDataBucketVoid(const struct gdhdr& other, 
				       const unsigned datasize)
        :bkttype(other.type),DataBucketVoid(sizeof(struct gdhdr),
         datasize*other.bbox.size())
  {
   struct gdhdr *gdh = (struct gdhdr *) DataBucketVoid::head();
   gdh->type = other.type;
   gdh->owner = other.owner;
   gdh->gfid = other.gfid;
   gdh->gfdatatype = other.gfdatatype;
   gdh->gfstaggertype = other.gfstaggertype;
   strncpy(gdh->gfname,other.gfname,DAGHBktGFNameWidth-1);
   gdh->gfname[DAGHBktGFNameWidth-1] = '\0';
   gdh->bbox = other.bbox;
   gdh->time = other.time;
   gdh->level = other.level;
   gdh->index = other.index;
   gdh->ident = other.ident;
   gdh->baseindex = other.baseindex;
  }

void GridDataBucketVoid::add(const BBox& bb, const unsigned gf,
	const int time, const int level, const int index, const int who, 
        const dMapIndex& bindex, const int ident, const int n)
  {
   struct gdhdr *gdh = (struct gdhdr *) DataBucketVoid::head(n);
   gdh->type = bkttype;
   gdh->owner = (short) who;
   gdh->gfid = (short) gf;
   gdh->gfdatatype = DAGHNull;
   gdh->gfstaggertype = DAGHNull;
   gdh->gfname[0] = '\0';
   gdh->bbox = bb;
   gdh->time = time;
   gdh->level = level;
   gdh->index = index;
   gdh->ident = ident;
   gdh->baseindex = bindex;
  }

void GridDataBucketVoid::add(const BBox& bb, const unsigned gf, 
        const int gfdtype, const int gfstype, const char* gfname, 
	const int time, const int level, const int index, const int who, 
        const dMapIndex& bindex, const int ident, const int n)
  {
   struct gdhdr *gdh = (struct gdhdr *) DataBucketVoid::head(n);
   gdh->type = bkttype;
   gdh->owner = (short) who;
   gdh->gfid = (short) gf;
   gdh->gfdatatype = gfdtype;
   gdh->gfstaggertype = gfstype;
   strncpy(gdh->gfname,gfname,DAGHBktGFNameWidth-1);
   gdh->gfname[DAGHBktGFNameWidth-1] = '\0';
   gdh->bbox = bb;
   gdh->time = time;
   gdh->level = level;
   gdh->index = index;
   gdh->ident = ident;
   gdh->baseindex = bindex;
  }

ostream&  operator << (ostream& os, const struct gdhdr& hdr)
  {

   if (&hdr == (struct gdhdr *)NULL) return os;

   os << "[Type:" << hdr.type << "]";
   os << "[Owner:" << hdr.owner << "]";
   os << "[GFid:" << hdr.gfid << "]";
   os << "[" << hdr.gfdatatype << "]";
   os << "[" << hdr.gfstaggertype << "]";
   os << "[" << hdr.gfname << "]";
   os << "[Time:" << hdr.time << "]";
   os << "[Lev:" << hdr.level << "]";
   os << "[Index:" << hdr.index << "]";
   os << "[Ident:" << hdr.ident << "]";
   
   os << "[BBox:" << hdr.bbox << "]";
   os << "[BaseIndex:" << hdr.baseindex << "]";

   return os;
  }
