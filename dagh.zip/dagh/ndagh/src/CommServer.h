#ifndef _included_CommServer_h
#define _included_CommServer_h

/*
*************************************************************************
* CommServer.h                                                          *
*                                                                       *
* Adapted from:								*
* ---------------------------------------------------------------------	*
* Carter Edwards							*
* Communication services for application controlled event handling.	*
* ---------------------------------------------------------------------	*
*************************************************************************
*/

#include <iostream.h>
#include <strstream.h>
#include <fstream.h>
#include <iomanip.h>
#include <assert.h>

#ifdef DAGH_NO_MPI

typedef unsigned MPI_Request;
typedef unsigned MPI_Group;
typedef unsigned MPI_Comm;

typedef struct {
    int count;
    int MPI_SOURCE;
    int MPI_TAG;
} MPI_Status;

#define MPI_PROC_NULL   (-1)
#define MPI_ANY_SOURCE  (-2)
#define MPI_ANY_TAG     (-1)
#define MPI_SUCCESS     (0)
#define MPI_ERR_COMM    (28)
#define MPI_COMM_WORLD  (301053)

inline static void MPI_Finalize() {};
#else

extern "C" {
#include <mpi.h> 
}

#endif

// ---------------------------------------------------------------------
// ---------------------------------------------------------------------

#define comm_service_comp 	((unsigned) 0)
#define comm_service_io 	((unsigned) 1)
#define comm_service_world 	((unsigned) 2)

#define comm_service_tag 	(((unsigned) 3)<<14)
#define comm_service_comp_tag 	((comm_service_comp)<<12)
#define comm_service_io_tag 	((comm_service_io)<<12)
#define comm_service_world_tag 	((comm_service_world)<<12)

#define comm_service_null_id 	(-1)

class comm_barrier ;

class comm_service {
private: // ------------------------------------------------------------
  // Static parameters

  static int             init_flag ;
  static int             dce_flag ;

  static int             PMe ;

  static int             NList ;
  static MPI_Request   * RList ;
  static comm_service ** SList ;
  static comm_barrier ** Barrier ;
  static comm_barrier ** BarrierWorld ;
  static ofstream        oflog ;

  // Compute Group
  static int             PNum ;
  static MPI_Comm        Comm ;
  static MPI_Group       Grp  ;

  // I/O Server
  static int             io_flag ;
  static int             PIO ;
  static MPI_Comm        CommIO ;

  // Entire Proc Group
  static MPI_Comm        CommWorld ;
  static int             PWorld ;
  static MPI_Group	 GrpWorld ;

  // Communication Array
  static int		NumCommArray ;
  static MPI_Comm     * CommArray ;

  // Idle timer 
  static double Idle_Time ; // Time 'idling'
  static double Srvc_Time ; // Time 'serving'

  MPI_Request * Req ;

  static int findTag( const int , const int , const int ); // By tag
  static int findService( comm_service * const );  // By comm_service
  static int findRequest( const MPI_Request );     // By request

protected: // ----------------------------------------------------------

  const int Id ;
  const int Tag ;
  const int Src ;

  comm_service( const int I , const int T , const int S=MPI_ANY_SOURCE );

  virtual ~comm_service();

  virtual void callrecv( const MPI_Status & ); // Callback for recv
  virtual const char * name( void ) const ;    // Derived class name

  void setreq(const int, const int, const int);

public: // -------------------------------------------------------------

  // Initialize & kill the communication server

  static int  init( MPI_Comm c = 0 );
  static void clean();
  static void kill();

  // Perform services

  static int serve( MPI_Request ); // Serve until request is satisfied
  static int serve( void );        // Serve all stockpiled requests

  static void barrier( int const type = comm_service_comp );

  // General info

  MPI_Request * req(void) const { return Req ; }
  int const tag(void) const { return Tag ; }

  static ofstream & log(void)   { return oflog ; }
  static int dce(void)      	{ return dce_flag ; }
  static int proc_me(void)      { return PMe ; }

  static int proc_num(void)     { return PNum ; }
  static MPI_Comm comm(void)    { return Comm ; }
  static MPI_Group grp(void)    { return Grp ; }

  static int num_services(void) { return NList ;}

  static int comminit(void)     { return (init_flag == 1); }
  static void set_comminit(void)     { init_flag = 1; }
  static void reset_comminit(void)     { init_flag = 0; }

  static int io_enabled(void)     { return (io_flag == 1); }
  static void set_io_enable(void)     { io_flag = 1; }
  static void reset_io_enable(void)     { io_flag = 0; }
  static int proc_io(void)     { return PIO ; }
  static MPI_Comm comm_io(void)    { return CommIO ; }

  static MPI_Comm comm_world(void)    { return CommWorld ; }
  static int proc_world(void)    { return PWorld; }
  static MPI_Group grp_world(void)    { return GrpWorld ; }

  static MPI_Comm comm(int const id)    { return CommArray[id] ; }
  static int num_comm(void)    { return NumCommArray ; }

  static void add_comm(int const id);
  static void delete_comm(int const id);
  static void reset_comm(int const id);

  static void inc_commarray(int const inc);

  static double idle_time(void) { return Idle_Time ; }
  static double srvc_time(void) { return Srvc_Time ; }

  // Error handling
  static void error_msg( const char who[] , const char what[] , int R );
  static void error_die( const char who[] , const char what[] , int R );
};

#endif
