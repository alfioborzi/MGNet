#ifndef _included_GridFunctionUCD2_h
#define _included_GridFunctionUCD2_h

/*
*************************************************************************
*                                                                                                                            *
* GridFunctionUCD2.h                                                                                        *
*                                                                                                                            *      
* Author:  Manish Parashar <parashar@cs.utexas.edu>                                *
*                                                                                                                            *
*************************************************************************
*/

template <class DAGH_GFType>
void GridFunction(2)<DAGH_GFType>::GF_GetUCDData(const DAGHUCD(2)& daghucd, 
						 const int t,
						 DAGH_GFType*& ucddata,
						 const int ucdserver)
{
  const int me = comm_service::proc_me();

  assert (!ucddata);
  if (me == ucdserver) 
    ucddata = new DAGH_GFType[daghucd.totalnodes];
  
  for (register int idx=0; idx<daghucd.numblks; idx++) {
    const GridData(2)<int>& ucdgd = daghucd.blks[idx];
    const BBox& b = ucdgd.bbox();
    const Coords& s = ucdgd.stepsize();
    assert (s(0) == s(1));
    const int l = dagh.step2level(s(0));
    GridData(2)<DAGH_GFType> tmpgd;
    GF_gather_one(t,l,b,b,tmpgd,ucdserver,daghucd.ident_flag);

    if (me == ucdserver) {
      for_2(i,j,b,s) {
	ucddata[ucdgd(i,j)] = tmpgd(i,j);
      } end_for
    }
  }
}

#endif
