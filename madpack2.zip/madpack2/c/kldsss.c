/***********************************************************************
*
* Subroutine KLDSSS  Numeric solution for sparse Gaussian elimination
*
* Key: n  integer     i  input        1  vector
*      r  real        o  output       2  matrix
*      d  real*8      s  scratch
*      c  character
*
*      Argument  Description
*      --------  -----------
* ri1  a         matrix stored in sparse form, length na
* ni   atype     type of matrix
*                   0  symmetric
*                   1  nonsymmetric
*                  -1  nonsymmetric, solve with a transpose
* ri1  b         right hand side, size n (may use same space as x)
* no   flag      information flag
*                   0  no error
*                  -1  illegal matrix type
*                  -2  illegal opt
* ni   genjum    whether or not to generate ju and m vectors
*                   0  m and ju are user input and list is zeroed
*                   1  generate ju and m
*                   2  m and ju are user input, but list needs zeroing
* ni1  ija       pointers to columns of matrix followed by row indices
*                of matrix
* nio1 ju        pointers to columns of factored matrix, size n+1
* ni   jushft    ju shift parameter returned by kldsnf
* ns1  list      scratch vector for links in list, size n
* nio1 m         m(i) = the row number in column i of U of the first
*                nonzero in the factored matrix, size n
* ni   n         number of columns in matrix
* ni   opt       computation option
*                   1  compute m and ju only
*                   3  forward solve (LDx = b)
*                   4  backsolve (Ux = b)
* ro1  u         factored matrix stored in sparse form, size nju
* ro1  x         solution, size n (may use same space as b)
*
***********************************************************************/

#include "defnc.pre"

kldsss(n, a, ija, jushft, ju, u, m, list, x, b, atype, opt,
                   genjum, flag)

        INT     *atype, *flag, *genjum, *ija, *ju, *jushft, *list, *m,
                *n, *opt;
        REAL    *a, *b, *u, *x;
  {
  /*********************************************************************
  *****local variables */
  INT     i, ii, inc, j, j1, j2, k, ksave, len, lshift, tail, ushift;
  static  INT     iniinc[4] = { 1, 1, 1, -1 };
  REAL    sum, xi;
  /********************************************************************/

  /* initialization */
  *flag = -1;
  if (*atype < -1 || *atype > 1) return;
  *flag = -2;
  if (*opt < 1 || *opt == 2 || *opt > 4) return;
  *flag = 0;

  /* initialize m and ju as well as list */
  if (*genjum == 1) {
    for (i = 0; i < *n; i++) {
      m[i] = -1;
      list[i] = -1;
      }
    *ju = *n + 2;
    ju[*n] = 0;
    }

  /* initialize list only */
  else if (*genjum == 2)
    for (i = 0; i < *n; i++)
      list[i] = -1;
  inc = iniinc[*opt-1];
  i = -1;
  if (*opt == 4) i = *n;

  /* determine matrix index shifts */
  lshift = 0;
  ushift = 0;
  if (*opt > 1) {
    if (*atype == 1)  lshift = *jushft;
    if (*atype == -1) ushift = *jushft;
    }

  /* main loop of computation */
  for (ii = 0; ii < *n; ii++) {
    len = 0;
    i = i + inc;
    tail = i;
    list[i] = i;
    j1 = ija[i] - 1;
    j2 = ija[i+1] - 1;

    /* first, compute unordered fillin list for this column */
    for (j = j1; j < j2; j++) {
      k = ija[j] - 1;
      while (list[k] == -1) {
        len++;
        list[tail] = k;
        tail = k;
        if (m[k] == -1) m[k] = i;
        k = m[k];
        }
      list[tail] = i;
      }
    if (*genjum == 1) ju[i+1] = ju[i] + len;

    /* then clean up while doing computation requested */
    k = i;

    switch (*opt) {

      /* compute m and ju vectors only */
      case 1:
        for (j = 0; j < len; j++) {
          ksave = k;
          k = list[k];
          list[ksave] = -1;
          }
        break;

     /* forward solve */
     case 3:
        sum = 0.;
        j1 = ju[i] - 1;
        j2 = ju[i+1] - 1;
        for (j = j1; j < j2; j++) {
          ksave = k;
          k = list[k];
          list[ksave] = -1;
          sum += (u[j+lshift] * x[k]);
          }
        x[i] = b[i] - sum;
        break;

      /* backsolve */
      case 4:
        xi = x[i];
        j1 = ju[i] - 1;
        j2 = ju[i+1] - 1;
        for (j = j1; j < j2; j++) {
          ksave = k;
          k = list[k];
          list[ksave] = -1;
          x[k] -= (u[j+ushift] * xi);
          }
        break;
      }

    /* end of main loop */
    list[k] = -1;
    }

  /* loop to complete forward solve */
  if (*opt == 3)
    for (i = 0; i < *n; i++)
      x[i] *= u[i];

  }
