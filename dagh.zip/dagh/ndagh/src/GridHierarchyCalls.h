#ifndef _included_GridHierarchyCalls_h
#define _included_GridHierarchyCalls_h

/*
*************************************************************************
*                                                                       *
* GridHierarchyCalls.h                                                  *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/*************************************************************************/
/* Setup DAGH */
/*************************************************************************/
inline void SetBaseGrid(GridHierarchy &GH, double const *bbox, int const *shape)
  { GH.DAGH_SetBaseGrid(bbox, shape); }
inline void SetTimeSpecs(GridHierarchy &GH, double const starttime, 
			double const stoptime, int const numtsteps)
  { GH.DAGH_SetTimeSpecs(starttime,stoptime,numtsteps); }

inline void SetBoundaryType(GridHierarchy &GH, int const type)
  { GH.DAGH_SetBoundaryType(type); }
inline void SetAdaptBoundaryType(GridHierarchy &GH, int const type)
  { GH.DAGH_SetAdaptBoundaryType(type); }
inline void SetBoundaryWidth(GridHierarchy &GH, int const width)
  { GH.DAGH_SetBoundaryWidth(width); }

inline void SetExternalGhostWidth(GridHierarchy &GH, int const width)
  { GH.DAGH_SetExternalGhostWidth(width); }

inline void SetRefineFactor(GridHierarchy &GH, int const rfactor)
  { GH.DAGH_SetRefineFactor(rfactor); }

inline void SetDistributionType(GridHierarchy &GH, int const type)
   { GH.DAGH_SetDistributionType(type); }

inline void SetDistributionType(GridHierarchy &GH, int const type, BBoxList& bbl)
   { GH.DAGH_SetDistributionType(type,bbl); }

inline void SetWorkFunction(GridHierarchy &GH, void *wf)
   { GH.DAGH_SetWorkFunction(wf); }

inline void ComposeHierarchy(GridHierarchy &GH)
  { GH.DAGH_ComposeHierarchy(); }

inline void ComposeGridFunctions(GridHierarchy &GH)
  { GH.DAGH_ComposeGridFunctions(); }

inline int GridFunctionTemplate(GridHierarchy& GH, GridFunctionVoid& GFV)
  { return (GH.DAGH_GridFunctionTemplate(GFV)); }

/*************************************************************************/
/* Queries */
/*************************************************************************/
inline void SetCurrentTime(GridHierarchy &GH, int const ctime, int const lev, 
                           int const ident=DAGH_Main)
  { GH.setCurrentTime(ctime, lev, ident); }
inline int CurrentTime(GridHierarchy &GH, int const lev, int const ident=DAGH_Main)
  { return (GH.getCurrentTime(lev, ident)); }
inline void IncrCurrentTime(GridHierarchy &GH, int const lev, 
                            int const ident=DAGH_Main)
  { GH.incrCurrentTime(lev, ident); }

inline int StepSize(GridHierarchy &GH, int const lev, int const ident=DAGH_Main)
  { return(GH.stepsize(lev,ident)); }

inline int TimeStep(GridHierarchy &GH, int const lev, int const ident=DAGH_Main)
  { return(GH.timestep(lev,ident)); }

inline int AbsStepsTaken(GridHierarchy &GH, int const lev, int const ident=DAGH_Main)
  { return (GH.stepstaken(GH.getCurrentTime(lev,ident),lev,ident)); }

inline int StepsTaken(GridHierarchy &GH, int const lev, int const ident=DAGH_Main)
  { return (GH.stepstaken(GH.getCurrentTime(lev,ident)-
            GH.getRefineTime(lev,ident),lev,ident)); }

inline int RefineFactor(GridHierarchy &GH)
  { return (GH.refinefactor()); }
inline int RefineLevel(GridHierarchy &GH)
  { return (GH.refinelevel()); }
inline int RefinedBy(GridHierarchy &GH, int const lev)
  { return (GH.refinedby(lev)); }

inline int TotalLevels(GridHierarchy &GH)
  { return (GH.totallevels()); }
inline int MaxLevel(GridHierarchy &GH)
  { return (GH.maxlevelindex()); }
inline int CoarseLevel(GridHierarchy &GH)
  { return (GH.coarselevelindex()); }
inline int FineLevel(GridHierarchy &GH)
  { return (GH.finelevelindex()); }

inline double DeltaT(GridHierarchy &GH, int const level, int const ident=DAGH_Main)
  { return (GH.delta_t(level,ident)); }
inline double DeltaX(GridHierarchy &GH, int const dim, int const level, 
                     int const ident=DAGH_Main)
  { return (GH.delta_x(dim,level,ident)); }

/*************************************************************************/
/* Set/Query Updated Timestep Info */
/*************************************************************************/
inline int UpdatedValueAt(GridHierarchy &GH) { return GH.updatedvaluestep(); }
inline void SetUpdatedValueStep(GridHierarchy &GH, const int ustep) 
  { GH.setupdatedvaluestep(ustep); }

/*************************************************************************/
/* Refine & Recompose */
/*************************************************************************/
inline void Refine(GridHierarchy &GH, BBoxList &bblist, int const lev)
  { GH.DAGH_Refine(bblist, lev); }

inline void RecomposeHierarchy(GridHierarchy &GH)
  { GH.DAGH_RecomposeHierarchy(); }


/*************************************************************************/
/* Redistribution */
/*************************************************************************/
inline void RedistributeHierarchy(GridHierarchy &GH, const int type)
        { GH.DAGH_RedistributeHierarchy(type); }
inline void RedistributeHierarchy(GridHierarchy &GH, const int type, BBoxList& bbl)
        { GH.DAGH_RedistributeHierarchy(type, bbl); }

/*************************************************************************/
/* Checkpoint */
/*************************************************************************/
inline void Checkpoint(GridHierarchy &GH, const char* name)
  { GH.DAGH_Checkpoint(name); }

inline void ComposeHierarchy(GridHierarchy &GH, 
			     const char* name)
  { GH.DAGH_ComposeHierarchy(name); }

inline void RecomposeHierarchy(GridHierarchy &GH, 
			       const char* name)
  { GH.DAGH_RecomposeHierarchy(name); }

/*************************************************************************/
/* Ghost communications */
/*************************************************************************/
inline void Sync(GridHierarchy &GH, int const t, int const l, 
                 int const ident=DAGH_Main)
  { GH.DAGH_SyncGhostRegions(t, l, ident); }
inline void Sync(GridHierarchy &GH, int const t, int const l, 
                 int const mgl, int const ident)
  { GH.DAGH_SyncGhostRegions(t, l, mgl, ident); }
inline void Sync(GridHierarchy &GH, int const t, int const l,
                 int const axis, int const dir,
                 int const ident)
  { GH.DAGH_SyncGhostRegions(t, l, axis, dir, ident); }
inline void Sync(GridHierarchy &GH, int const t, int const l,
                 int const mgl, int const axis, int const dir,
                 int const ident)
  { GH.DAGH_SyncGhostRegions(t, l, mgl, axis, dir, ident); }
/*************************************************************************/
/* Multigrid operators */
/*************************************************************************/
inline int MultiGridLevels(GridHierarchy &GH, int const level) 
  { return (GH.DAGH_MultiGridLevels(level)); }
inline int MultiGridLevels(GridHierarchy &GH, int const level, int const ident) 
  { return (GH.DAGH_MultiGridLevels(level,ident)); }

/*************************************************************************/
/* DAGH IO support */
/*************************************************************************/
inline void DAGHIOType(GridHierarchy &GH, int const type)
  { GH.DAGH_IOType(type); }
inline void DAGHIOEnd(GridHierarchy &GH)
  { GH.DAGH_IOEnd(); }

#endif
