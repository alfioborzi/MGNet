#ifndef _included_GridFunctionOpsRed3_h
#define _included_GridFunctionOpsRed3_h

/*
*************************************************************************
*                                                                       *
* GridFunctionOpsRed3.h                                                 *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/*************************************************************************/
/* Maxval */
/*************************************************************************/
template <class Type>
Type GridFunction(3)<Type>::GF_maxval(int const time, int const level, int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type maxval = (Type) DAGHSmall, tmax = (Type) DAGHSmall;
   register int i;
   short flag = DAGHTrue;
   for (i=0; i<length; i++) if (gdb[t][l][i]) {
     tmax = (gdb[t][l][i]->griddata(ident)).maxval(gdb[t][l][i]->interiorbox(ident));
     if (flag == DAGHTrue) { maxval = tmax; flag = DAGHFalse; }
     else if (maxval < tmax) maxval = tmax;
     tmax = (Type) DAGHSmall;
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 

     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&maxval, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_maxval", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_maxval" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     maxval = (Type) DAGHSmall;
     flag = DAGHTrue;
     for (i=0;i<num;i++) {
       tmax = *((Type *)values + i);
       if (flag == DAGHTrue) { maxval = tmax; flag = DAGHFalse; }
       else if (maxval < tmax) maxval = tmax;
     }
     if (values) delete [] values;
   }
#endif
   
   return (maxval);
  }

template <class Type>
Type GridFunction(3)<Type>::GF_maxval(int const time, int const level, 
                                      BBox const &where,
                                      int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type maxval = (Type) DAGHSmall, tmax = (Type) DAGHSmall;
   register int i;
   short flag = DAGHTrue;
   for (i=0; i<length; i++) if (gdb[t][l][i]) {
     tmax = (gdb[t][l][i]->griddata(ident)).maxval(
                           alignedwhere*gdb[t][l][i]->interiorbox(ident));
     if (flag == DAGHTrue) { maxval = tmax; flag = DAGHFalse; }
     else if (maxval < tmax) maxval = tmax;
     tmax = (Type) DAGHSmall;
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 

     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&maxval, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_maxval", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_maxval" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     maxval = (Type) DAGHSmall;
     flag = DAGHTrue;
     for (i=0;i<num;i++) {
       tmax = *((Type *)values + i);
       if (flag == DAGHTrue) { maxval = tmax; flag = DAGHFalse; }
       else if (maxval < tmax) maxval = tmax;
     }
     if (values) delete [] values;
   }
#endif

   return (maxval);
  }

template <class Type>
Type GridFunction(3)<Type>::GF_maxval(int const time, int const level, 
                                      int const mgl, int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type maxval = (Type) DAGHSmall, tmax = (Type) DAGHSmall;
   register int i;
   short flag= DAGHTrue;
   for (i=0; i<length; i++) if (gdb[t][l][i]) { 
     tmax = (gdb[t][l][i]->griddata(ident,mgl)).maxval(gdb[t][l][i]->interiorbox(ident,mgl));
     if (flag == DAGHTrue) { maxval = tmax; flag = DAGHFalse; }
     else if (maxval < tmax) maxval = tmax;
     tmax = (Type) DAGHSmall;
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 

     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&maxval, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_maxval", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_maxval" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     maxval = (Type) DAGHSmall;
     flag = DAGHTrue;
     for (i=0;i<num;i++) {
       tmax = *((Type *)values + i);
       if (flag == DAGHTrue) { maxval = tmax; flag = DAGHFalse; }
       else if (maxval < tmax) maxval = tmax;
     }
     if (values) delete [] values;
   }
#endif
   
   return (maxval);
  }

template <class Type>
Type GridFunction(3)<Type>::GF_maxval(int const time, int const level, int const mgl,
                                      BBox const &where,
                                      int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type maxval = (Type) DAGHSmall, tmax = (Type) DAGHSmall;
   register int i;
   short flag = DAGHTrue;
   for (i=0; i<length; i++) if (gdb[t][l][i]) { 
     tmax = (gdb[t][l][i]->griddata(ident,mgl)).maxval(
                           alignedwhere*gdb[t][l][i]->interiorbox(ident,mgl));
     if (flag == DAGHTrue) { maxval = tmax; flag = DAGHFalse; }
     else if (maxval < tmax) maxval = tmax;
     tmax = (Type) DAGHSmall;
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 

     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&maxval, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_maxval", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_maxval" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     maxval = (Type) DAGHSmall;
     flag = DAGHTrue;
     for (i=0;i<num;i++) {
       tmax = *((Type *)values + i);
       if (flag == DAGHTrue) { maxval = tmax; flag = DAGHFalse; }
       else if (maxval < tmax) maxval = tmax;
     }
     if (values) delete [] values;
   }
#endif

   return (maxval);
  }

/*************************************************************************/
/* Minval */
/*************************************************************************/
template <class Type>
Type GridFunction(3)<Type>::GF_minval(int const time, int const level,
                                      int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type minval = MAXLIM(Type), tmin = MAXLIM(Type);
   register int i;
   short flag = DAGHTrue;
   for (i=0; i<length; i++) if (gdb[t][l][i]) {  
     tmin = (gdb[t][l][i]->griddata(ident)).minval(gdb[t][l][i]->interiorbox(ident));
     if (flag == DAGHTrue) { minval = tmin; flag = DAGHFalse; }
     else if (minval > tmin) minval = tmin;
     tmin = MAXLIM(Type);
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 

     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&minval, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_minval", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_minval" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     minval = MAXLIM(Type);
     flag = DAGHTrue;
     for (i=0;i<num;i++) {
       tmin = *((Type *)values + i);
       if (flag == DAGHTrue) { minval = tmin; flag = DAGHFalse; }
       else if (minval > tmin) minval = tmin;
     }
     if (values) delete [] values;
   }
#endif

   return (minval);
  }

template <class Type>
Type GridFunction(3)<Type>::GF_minval(int const time, int const level,
				      BBox const &where,
                                      int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type minval = MAXLIM(Type), tmin = MAXLIM(Type);
   register int i;
   short flag = DAGHTrue;
   for (i=0; i<length; i++) if (gdb[t][l][i]) { 
     tmin = (gdb[t][l][i]->griddata(ident)).minval(
                           alignedwhere*gdb[t][l][i]->interiorbox(ident));
     if (flag == DAGHTrue) { minval = tmin; flag = DAGHFalse; }     
     else if (minval > tmin) minval = tmin;
     tmin = MAXLIM(Type);
   }

#ifdef DAGH_NO_MPI
#else

   if (comm_service::dce() && comm_service::proc_num() > 1) { 

     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&minval, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_minval", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_minval" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     minval = MAXLIM(Type);
     flag = DAGHTrue;
     for (i=0;i<num;i++) {
       tmin = *((Type *)values + i);
       if (flag == DAGHTrue) { minval = tmin; flag = DAGHFalse; }
       else if (minval > tmin) minval = tmin;
     }
     if (values) delete [] values;
   }
#endif

   return (minval);
  }

template <class Type>
Type GridFunction(3)<Type>::GF_minval(int const time, int const level,
                                      int const mgl, int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type minval = MAXLIM(Type), tmin = MAXLIM(Type);
   register int i;
   short flag = DAGHTrue;
   for (i=0; i<length; i++) if (gdb[t][l][i]) { 
       tmin = (gdb[t][l][i]->griddata(ident,mgl)).minval(gdb[t][l][i]->interiorbox(ident,mgl));
     if (flag == DAGHTrue) { minval = tmin; flag = DAGHFalse; }
     else if (minval > tmin) minval = tmin;
     tmin = MAXLIM(Type);
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 

     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&minval, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_minval", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_minval" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     minval = MAXLIM(Type);
     flag = DAGHTrue;
     for (i=0;i<num;i++) {
       tmin = *((Type *)values + i);
       if (flag == DAGHTrue) { minval = tmin; flag = DAGHFalse; }
       else if (minval > tmin) minval = tmin;
     }
     if (values) delete [] values;
   }
#endif

   return (minval);
  }

template <class Type>
Type GridFunction(3)<Type>::GF_minval(int const time, int const level, int const mgl,
				      BBox const &where,
                                      int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type minval = MAXLIM(Type), tmin = MAXLIM(Type);
   register int i;
   short flag = DAGHTrue;
   for (i=0; i<length; i++) if (gdb[t][l][i]) { 
     tmin = (gdb[t][l][i]->griddata(ident,mgl)).minval(
                           alignedwhere*gdb[t][l][i]->interiorbox(ident,mgl));
     if (flag == DAGHTrue) { minval = tmin; flag = DAGHFalse; }   
     else if (minval > tmin) minval = tmin;
     tmin = MAXLIM(Type);
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 


     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&minval, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_minval", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_minval" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     minval = MAXLIM(Type);
     flag = DAGHTrue;
     for (i=0;i<num;i++) {
       tmin = *((Type *)values + i);
       if (flag == DAGHTrue) { minval = tmin; flag = DAGHFalse; }
       else if (minval > tmin) minval = tmin;
     }
     if (values) delete [] values;
   }
#endif

   return (minval);
  }

/*************************************************************************/
/* Sum */
/*************************************************************************/
template <class Type>
Type GridFunction(3)<Type>::GF_sum(int const time, int const level,
                                   int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type sum = (Type) 0;
   register int i;
   for (i=0; i<length; i++) if (gdb[t][l][i]) { 
     sum += (gdb[t][l][i]->griddata(ident)).sum(gdb[t][l][i]->interiorbox(ident));
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 


     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&sum, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_sum", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_sum" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     sum = (Type) 0;
     for (i=0;i<num;i++)
       sum += *((Type *)values + i);

     if (values) delete [] values;
   }
#endif

   return (sum);
  }

template <class Type>
Type GridFunction(3)<Type>::GF_sum(int const time, int const level,
				   BBox const &where,
                                   int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type sum = (Type) 0;
   register int i;
   for (i=0; i<length; i++) if (gdb[t][l][i]) {  
     sum += (gdb[t][l][i]->griddata(ident)).sum(
                           alignedwhere*gdb[t][l][i]->interiorbox(ident));
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 


     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&sum, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_sum", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_sum" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     sum = (Type) 0;
     for (i=0;i<num;i++)
       sum += *((Type *)values + i);
   
     if (values) delete [] values;
   }
#endif

   return (sum);
  }

template <class Type>
Type GridFunction(3)<Type>::GF_sum(int const time, int const level,
                                   int const mgl, int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type sum = (Type) 0;
   register int i;
   for (i=0; i<length; i++) if (gdb[t][l][i]) { 
     sum += (gdb[t][l][i]->griddata(ident,mgl)).sum(gdb[t][l][i]->interiorbox(ident,mgl));
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 


     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&sum, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_sum", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_sum" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     sum = (Type) 0;
     for (i=0;i<num;i++)
       sum += *((Type *)values + i);

     if (values) delete [] values;
   }
#endif

   return (sum);
  }

template <class Type>
Type GridFunction(3)<Type>::GF_sum(int const time, int const level, int const mgl,
				   BBox const &where,
                                   int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type sum = (Type) 0;
   register int i;
   for (i=0; i<length; i++) if (gdb[t][l][i]) { 
     sum += (gdb[t][l][i]->griddata(ident,mgl)).sum(
                           alignedwhere*gdb[t][l][i]->interiorbox(ident,mgl));
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 


     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&sum, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_sum", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_sum" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     sum = (Type) 0;
     for (i=0;i<num;i++)
       sum += *((Type *)values + i);
   
     if (values) delete [] values;
   }
#endif

   return (sum);
  }

/*************************************************************************/
/* Product */
/*************************************************************************/
template <class Type>
Type GridFunction(3)<Type>::GF_product(int const time, int const level,
                                       int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type prod = (Type) 1;
   register int i;
   for (i=0; i<length; i++) {
     if (gdb[t][l][i]) 
       prod *= (gdb[t][l][i]->griddata(ident)).product(gdb[t][l][i]->interiorbox(ident));
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 


     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&prod, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_product", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_product" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     prod = (Type) 1;
     for (i=0;i<num;i++)
       prod *= *((Type *)values + i);
   
     if (values) delete [] values;
   }
#endif

   return (prod);
  }

template <class Type>
Type GridFunction(3)<Type>::GF_product(int const time, int const level,
				       BBox const &where,
                                       int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type prod = (Type) 1;
   register int i;
   for (i=0; i<length; i++) {
     if (gdb[t][l][i]) 
       prod *= (gdb[t][l][i]->griddata(ident)).product(
                              alignedwhere*gdb[t][l][i]->interiorbox(ident));
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 


     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&prod, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_product", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_product" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     prod = (Type) 1;
     for (i=0;i<num;i++)
       prod *= *((Type *)values + i);
   
     if (values) delete [] values;
   }
#endif

   return (prod);
  }

template <class Type>
Type GridFunction(3)<Type>::GF_product(int const time, int const level, int const mgl,
                                       int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type prod = (Type) 1;
   register int i;
   for (i=0; i<length; i++) {
     if (gdb[t][l][i]) 
       prod *= (gdb[t][l][i]->griddata(ident,mgl)).product(gdb[t][l][i]->interiorbox(ident,mgl));
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 


     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&prod, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_product", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_product" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     prod = (Type) 1;
     for (i=0;i<num;i++)
       prod *= *((Type *)values + i);
   
     if (values) delete [] values;
   }
#endif

   return (prod);
  }

template <class Type>
Type GridFunction(3)<Type>::GF_product(int const time, int const level, int const mgl,
				       BBox const &where,
                                       int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type prod = (Type) 1;
   register int i;
   for (i=0; i<length; i++) {
     if (gdb[t][l][i]) 
       prod *= (gdb[t][l][i]->griddata(ident,mgl)).product(
                              alignedwhere*gdb[t][l][i]->interiorbox(ident,mgl));
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 


     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = sizeof(Type);
     void *values = (void *) new char[size*num];

     R = MPI_Allgather(&prod, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_product", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_product" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     prod = (Type) 1;
     for (i=0;i<num;i++)
       prod *= *((Type *)values + i);
   
     if (values) delete [] values;
   }
#endif

   return (prod);
  }

/*************************************************************************/
/* Norm2 */
/*************************************************************************/
template <class Type>
Type GridFunction(3)<Type>::GF_norm2(int const time, int const level, int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type sumsqrd = (Type) 0, s = (Type) 0;
   int cnt = 0, c = 0;
   register int i;
   for (i=0; i<length; i++) {
     if (gdb[t][l][i]) {
       (gdb[t][l][i]->griddata(ident)).sumsqrd(gdb[t][l][i]->interiorbox(ident),s,c);
       sumsqrd += s;
       cnt += c;
     }
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 


     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = 2*sizeof(Type);
     void *values = (void *) new char[size*num];

     void *sndbuf = (void *) new char[size];
     *((Type *) sndbuf) = sumsqrd;
     *((int *) ((Type *)sndbuf+1)) = cnt;

     R = MPI_Allgather(sndbuf, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_norm2", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_norm2" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     sumsqrd = (Type) 0;
     cnt = 0;
     for (i=0;i<num;i++) {
       sumsqrd += *((Type *)values + 2*i);
       cnt += *((int *)((Type *)values + 2*i+1));
     }
   
     if (values) delete [] values;
     if (sndbuf) delete [] sndbuf;
   }
#endif

   return ((Type)sqrt((double) (1.0*sumsqrd/cnt)));
  }

template <class Type>
Type GridFunction(3)<Type>::GF_norm2(int const time, int const level,
                                     BBox const &where,
                                     int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type sumsqrd = (Type) 0, s = (Type) 0;
   int cnt = 0, c = 0;
   register int i;
   for (i=0; i<length; i++) {
     if (gdb[t][l][i]) {
       (gdb[t][l][i]->griddata(ident)).sumsqrd(
                      alignedwhere*gdb[t][l][i]->interiorbox(ident),s,c);
       sumsqrd += s;
       cnt += c;
     }
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 


     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = 2*sizeof(Type);
     void *values = (void *) new char[size*num];

     void *sndbuf = (void *) new char[size];
     *((Type *) sndbuf) = sumsqrd;
     *((int *) ((Type *)sndbuf+1)) = cnt;

     R = MPI_Allgather(sndbuf, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_norm2", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_norm2" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     sumsqrd = (Type) 0;
     cnt = 0;
     for (i=0;i<num;i++) {
       sumsqrd += *((Type *)values + 2*i);
       cnt += *((int *)((Type *)values + 2*i+1));
     }
   
     if (values) delete [] values;
     if (sndbuf) delete [] sndbuf;
   }
#endif
   
   return ((Type)sqrt((double) (1.0*sumsqrd/cnt)));
  }

template <class Type>
Type GridFunction(3)<Type>::GF_norm2(int const time, int const level, int const mgl,
                                     int const ident)
  {
   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type sumsqrd = (Type) 0, s = (Type) 0;
   int cnt = 0, c = 0;
   register int i;
   for (i=0; i<length; i++) {
     if (gdb[t][l][i]) {
       (gdb[t][l][i]->griddata(ident,mgl)).sumsqrd(gdb[t][l][i]->interiorbox(ident,mgl),s,c);
       sumsqrd += s;
       cnt += c;
     }
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 


     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = 2*sizeof(Type);
     void *values = (void *) new char[size*num];

     void *sndbuf = (void *) new char[size];
     *((Type *) sndbuf) = sumsqrd;
     *((int *) ((Type *)sndbuf+1)) = cnt;

     R = MPI_Allgather(sndbuf, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_norm2", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_norm2" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     sumsqrd = (Type) 0;
     cnt = 0;
     for (i=0;i<num;i++) {
       sumsqrd += *((Type *)values + 2*i);
       cnt += *((int *)((Type *)values + 2*i+1));
     }
   
     if (values) delete [] values;
     if (sndbuf) delete [] sndbuf;
   }
#endif

   return ((Type)sqrt((double) (1.0*sumsqrd/cnt)));
  }

template <class Type>
Type GridFunction(3)<Type>::GF_norm2(int const time, int const level, int const mgl,
                                     BBox const &where,
                                     int const ident)
  {
   assert (where.rank == dagh.rank);

   BBox alignedwhere = where;
   gdbAlignBBox(gfrank,alignedwhere,alignment);

   register int t = dagh_timeindex(time,level);
   register int l = level;
   Type sumsqrd = (Type) 0, s = (Type) 0;
   int cnt = 0, c = 0;
   register int i;
   for (i=0; i<length; i++) {
     if (gdb[t][l][i]) {
       (gdb[t][l][i]->griddata(ident,mgl)).sumsqrd(
                      alignedwhere*gdb[t][l][i]->interiorbox(ident,mgl),s,c);
       sumsqrd += s;
       cnt += c;
     }
   }

#ifdef DAGH_NO_MPI
#else
   if (comm_service::dce() && comm_service::proc_num() > 1) { 


     int me = comm_service::proc_me();
     int num = comm_service::proc_num();
 
     int R;
     int size = 2*sizeof(Type);
     void *values = (void *) new char[size*num];

     void *sndbuf = (void *) new char[size];
     *((Type *) sndbuf) = sumsqrd;
     *((int *) ((Type *)sndbuf+1)) = cnt;

     R = MPI_Allgather(sndbuf, size, MPI_BYTE, values, size, MPI_BYTE, 
	   	       comm_service::comm(gfid));
     if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridFunction::GF_norm2", "MPI_Allgather", R );

#ifdef DEBUG_PRINT_GF_COMM
   ( comm_service::log() << "GridFunction::GF_norm2" << " " << comm_service::proc_me() << " "
                         << "MPI_Allgather { "
                         << size
                         << " }"
                         << endl ).flush();
#endif

     sumsqrd = (Type) 0;
     cnt = 0;
     for (i=0;i<num;i++) {
       sumsqrd += *((Type *)values + 2*i);
       cnt += *((int *)((Type *)values + 2*i+1));
     }
   
     if (values) delete [] values;
     if (sndbuf) delete [] sndbuf;
   }
#endif

   return ((Type)sqrt((double) (1.0*sumsqrd/cnt)));
  }

#endif

