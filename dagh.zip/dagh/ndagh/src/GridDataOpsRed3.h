#ifndef _included_GridDataOpsRed_3_h
#define _included_GridDataOpsRed_3_h

/*
*************************************************************************
*                                                                       *
* GridDataOpsRed3.h                                                     *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/


/****************************** maxval ***************************************/

template <class Type>
Type GridData(3)<Type>::maxval (BBox const &where)

  {
    Type max_val = (Type) DAGHSmall;
    short flag = DAGHTrue;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(3)<Type> &dst = *this;

       BeginFastIndex3(dst, dst._bbox, dst._data, Type);

       for_3(i, j, k, intersection, max_step)
         if (flag == DAGHTrue)
           { max_val = FastIndex3(dst,i,j,k); flag = DAGHFalse; }
         else if (FastIndex3(dst,i,j,k) > max_val)
            max_val = FastIndex3(dst,i,j,k);
       end_for

       EndFastIndex3(dst);

      }
    return (max_val);
  }

/************************************************************************/

/****************************** minval ***************************************/

template <class Type>
Type GridData(3)<Type>::minval (BBox const &where)

  {
    Type min_val = MAXLIM(Type);
    short flag = DAGHTrue;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(3)<Type> &dst = *this;

       BeginFastIndex3(dst, dst._bbox, dst._data, Type);

       for_3(i, j, k, intersection, max_step)
         if (flag == DAGHTrue)
           { min_val = FastIndex3(dst,i,j,k); flag = DAGHFalse; }
         else if (FastIndex3(dst,i,j,k) < min_val) 
	   min_val = FastIndex3(dst,i,j,k);
       end_for

       EndFastIndex3(dst);

      }
    return (min_val);
  }

/************************************************************************/

/****************************** sum ***************************************/

template <class Type>
Type GridData(3)<Type>::sum (BBox const &where)

  {
    Type sum_val = (Type) 0;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(3)<Type> &dst = *this;

       BeginFastIndex3(dst, dst._bbox, dst._data, Type);

       for_3(i, j, k, intersection, max_step)
         sum_val += FastIndex3(dst,i,j,k);
       end_for

       EndFastIndex3(dst);

      }
    return (sum_val);
  }

/************************************************************************/

/****************************** product ***************************************/

template <class Type>
Type GridData(3)<Type>::product (BBox const &where)

  {
    Type prod_val = (Type) 1;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(3)<Type> &dst = *this;

       BeginFastIndex3(dst, dst._bbox, dst._data, Type);

       for_3(i, j, k, intersection, max_step)
         prod_val *= FastIndex3(dst,i,j,k);
       end_for

       EndFastIndex3(dst);

      }
    return (prod_val);
  }

/************************************************************************/

/****************************** moment1 ***************************************/
template <class Type>
Type GridData(3)<Type>::moment1 (int const axis, BBox const &where)

  {
    Type m1 = (Type) 0;

    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(3)<Type> &dst = *this;

       BeginFastIndex3(dst, dst._bbox, dst._data, Type);

       if (axis == DAGH_X) {
         for_3(i, j, k, intersection, max_step)
           m1 += FastIndex3(dst,i,j,k) * i;
         end_for
       }
       else if (axis == DAGH_Y) {
         for_3(i, j, k, intersection, max_step)
           m1 += FastIndex3(dst,i,j,k) * j;
         end_for
       }
       else if (axis == DAGH_Z) {
         for_3(i, j, k, intersection, max_step)
           m1 += FastIndex3(dst,i,j,k) * k;
         end_for
       }

       EndFastIndex3(dst);
      }
    return (m1);
  }
/************************************************************************/

/****************************** sumsqrd ***************************************/

template <class Type>
void GridData(3)<Type>::sumsqrd (BBox const &where, Type &s, int &c)

  {
    s = (Type) 0;
    c = 0;
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       intersection.setstepsize(_step);

       GridData(3)<Type> &dst = *this;

       BeginFastIndex3(dst, dst._bbox, dst._data, Type);

       for_3(i, j, k, intersection, max_step)
         s += FastIndex3(dst,i,j,k) * FastIndex3(dst,i,j,k);
	 c++;
       end_for

       EndFastIndex3(dst);

      }
  }

/************************************************************************/

#endif
