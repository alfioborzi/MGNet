/*
*************************************************************************
*                                                                       *
* "GridHierarchyPing.C"							*
*                                                                       *
*************************************************************************
*/

#include "GridHierarchy.h"

void DAGHIO_ComplistPingFunction(GridHierarchy &GH)
  {
   int me = comm_service::proc_me();
   int num = comm_service::proc_num();

   GridUnitList *oldcomplist = GH.complist; GH.complist = 0;

   int sndsize=0, rcvsize=0;
   void *sndbuf = 0;
   void *rcvbuf = 0;
   GH.DAGH_GlbConcat(sndbuf, sndsize, rcvbuf, rcvsize);
   GH.complist = new GridUnitList(rcvbuf, rcvsize, num, me);
   if (rcvbuf) delete [] rcvbuf;

   GH.finelev = GH.complist->finest();

#ifdef DEBUG_PRINT_RG
     ( comm_service::log() << "\n************* New Composite List *************\n"
                           << *GH.complist
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

     /* Repartition the composite list & get local information */
     GH.distribution.partition(GH.complist,GH.locallist,num,me,
                               DAGHDefaultPartMinGUWidth,GH.daghoverlap());

     assert(GH.locallist->isempty()); /* a sanity check */

     if (oldcomplist) delete oldcomplist;
  }

void DAGHIO_EndIOPingFunction(GridHierarchy &GH)
  {
   /*$static int end_iocnt = 0;
   if (++end_iocnt == comm_service::proc_num()) {
     end_iocnt = DAGHNull;
#ifdef DEBUG_PRINT_COMM_IO
   ( comm_service::log() << "DAGHIO_EndIOPingFunction"
                         << comm_service::proc_me() << " "
                         << " Finishing Up IO"
                         << endl ).flush();
#endif     
     comm_service::barrier(comm_service_world);
     comm_service::reset_io_enable();
     comm_service::reset_comminit();
   }
   else if (end_iocnt != DAGHNull) {
#ifdef DAGH_NO_MPI
#else

#ifdef DEBUG_PRINT_COMM_IO
     ( comm_service::log() << "DAGHIO_EndIOPingFunction(" << end_iocnt << ") "
                         << comm_service::proc_me() << " "
                         << " MPI_Irecv: "
                         << "Tag: " << GH.io_end_server->tag() << " "
                         << "Size: " << 0 << " "
                         << endl ).flush();
#endif

	int flag = DAGHTrue;
    int R = MPI_Irecv(&flag,1,MPI_INT,MPI_ANY_SOURCE,GH.io_end_server->tag(),
                      comm_service::comm_io(),GH.io_end_server->req());
    if ( MPI_SUCCESS != R )
        comm_service::error_die( "DAGHIO_EndIOPingFunction" , "MPI_Irecv" , R );

#endif
     GH.DAGH_IOServe();
   }$*/
  }
