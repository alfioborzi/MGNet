/*
*************************************************************************
*                                                                       *
* class GridTable							*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "GridTable.h"

/*************************************************************************/
/* Reads */
/*************************************************************************/
const GridDataBucketVoid* GridTable::read_only(GridTableEntry& gte,
                                               const int t, const int l,
                                               const int a, int const d,
                                               const int m, int& off)
   {
    const int me = comm_service::proc_me();

#ifdef DEBUG_PRINT_COMM
    ( comm_service::log() << "GridTable::read_only" << "(" << me << ")"
                          << "Reading { " 
			  << "(" << gfid << ")"
			  << "(" << gte.myowner() << ")"
			  << "(" << t << "," << l << ")"
			  << "(" << a << "," << d << "," << m << ")"
		 	  << " }"
                         << endl ).flush();
#endif

    GridDataBucketVoid *gdbkt = gte(t,l,a,d,m,off);
    if (gdbkt != GridDataBucketVoidNULL)
      return(gdbkt->alias());
    else if (comm_service::dce()) {
      comm_service::serve();
      if (gdbkt != GridDataBucketVoidNULL) return (gdbkt->alias());
      else return GridDataBucketVoidNULL;
    }
    else
      return GridDataBucketVoidNULL;
   }

const GridDataBucketVoid* GridTable::read_only(const dMapIndex& index,
                                               const int t, const int l,
                                               const int a, int const d,
                                               const int m, int& off)
   {
    const int me = comm_service::proc_me();

    GridTableEntry &tmpgte = *(table.find(index));
    if (&tmpgte == GridTableEntryNULL) return GridDataBucketVoidNULL;

#ifdef DEBUG_PRINT_COMM
    ( comm_service::log() << "GridTable::read_only" << "(" << me << ")"
                          << "Reading { "
                          << "(" << gfid << ")"
                          << "(" << tmpgte.myowner() << ")"
			  << "(" << t << "," << l << ")"
			  << "(" << a << "," << d << "," << m << ")"
                          << " }"
                         << endl ).flush();
#endif

    GridDataBucketVoid *gdbkt = tmpgte(t,l,a,d,m,off);
    if (gdbkt != GridDataBucketVoidNULL)
      return(gdbkt->alias());
    else if (comm_service::dce()) {
      comm_service::serve();
      if (gdbkt != GridDataBucketVoidNULL) return (gdbkt->alias());
      else return GridDataBucketVoidNULL;
    }
    else
      return GridDataBucketVoidNULL;
   }

const GridDataBucketVoid* GridTable::read_destroy(GridTableEntry& gte,
                                                  const int t, const int l,
                                                  const int a, int const d,
                                                  const int m, int& off)
   {
    const int me = comm_service::proc_me();

#ifdef DEBUG_PRINT_COMM
    ( comm_service::log() << "GridTable::read_only" << "(" << me << ")"
                          << "Reading { "
                          << "(" << gfid << ")"
                          << "(" << gte.myowner() << ")"
			  << "(" << t << "," << l << ")"
			  << "(" << a << "," << d << "," << m << ")"
                          << " }"
                         << endl ).flush();
#endif

    GridDataBucketVoid *&gdbkt = gte(t,l,a,d,m,off);
    if (gdbkt != GridDataBucketVoidNULL) {
      GridDataBucketVoid *tmpbkt = gdbkt;
      gdbkt = GridDataBucketVoidNULL;
      return(tmpbkt);
    }
    else if (comm_service::dce()) {
      comm_service::serve();
      GridDataBucketVoid *tmpbkt = gdbkt;
      gdbkt = GridDataBucketVoidNULL;
      return(tmpbkt);
    }
    else
      return GridDataBucketVoidNULL;
   }

const GridDataBucketVoid* GridTable::read_destroy(const dMapIndex& index,
                                                  const int t, const int l,
                                                  const int a, int const d,
                                                  const int m, int& off)
   {
    GridTableEntry &tmpgte = *(table.find(index));
    if (&tmpgte == GridTableEntryNULL) return GridDataBucketVoidNULL;

    const int me = comm_service::proc_me();

#ifdef DEBUG_PRINT_COMM
    ( comm_service::log() << "GridTable::read_only" << "(" << me << ")"
                          << "Reading { "
                          << "(" << gfid << ")"
                          << "(" << tmpgte.myowner() << ")"
			  << "(" << t << "," << l << ")"
			  << "(" << a << "," << d << "," << m << ")"
                          << " }"
                         << endl ).flush();
#endif

    GridDataBucketVoid *&gdbkt = tmpgte(t,l,a,d,m,off);
    if (gdbkt != GridDataBucketVoidNULL) {
      GridDataBucketVoid *tmpbkt = gdbkt;
      gdbkt = GridDataBucketVoidNULL;
      return(tmpbkt);
    }
    else if (comm_service::dce()) {
      comm_service::serve();
      GridDataBucketVoid *tmpbkt = gdbkt;
      gdbkt = GridDataBucketVoidNULL;
      return(tmpbkt);
    }
    else
      return GridDataBucketVoidNULL;
   }

/**************************************************************************/
/* Writes */
/**************************************************************************/
int GridTable::write(GridTableEntry& gte, const int dest, GridDataBucketVoid* gdbkt,
                     const int t, const int l, const int a, const int d, const int m,
                     const unsigned tag)
  {

    const int me = comm_service::proc_me();
    const int ln = gte.levelnum(l);

    if (dest == me || !comm_service::dce()) {

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTable::write" << "(" << me << ")"
                         << "Writing { " 
			 << "(" << gfid << ")"
			 << *((GridDataBucketVoid *) gdbkt)->head() 
		 	 << " }"
                         << endl ).flush();
#endif
      GridDataBucketVoid *&tmpbkt = gte(t,l,a,d,m);
      if (tmpbkt != GridDataBucketVoidNULL) tmpbkt->free();
      tmpbkt = gdbkt;
      gdbkt = 0;
      return DAGH_OK;
    }

    else {
#ifdef DAGH_NO_MPI
#else

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTable::write (" << me << ")"
                         << "Sending { " 
			 << "(" << gfid << ")"
			 << *((GridDataBucketVoid *) gdbkt)->head() 
		 	 << " }"
                         << endl ).flush();
#endif

      void *package = 0; unsigned size;
      gdbkt->pack(package,size);

      unsigned T = (tag | t<<DAGHTimeShift | ln<<DAGHLevelShift | d<<DAGHDirShift);

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTable::write (" << me << ")"
                         << "MPI_Isend { " 
			 << "(Tag:" << T << ")" 
			 << "(Size:" << size << ")" 
		 	 << "(Dest:" << dest << ")"
		 	 << "(" << t << "," << l <<")"
		 	 << "(" << a << "," << d << "," << m <<")"
		 	 << " }"
                         << endl ).flush();
#endif

      MPI_Request req ;
      int R = MPI_Isend( package, size, MPI_BYTE , dest,
                         T, comm_service::comm(gfid) , &req );
      if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridTable::write" , "MPI_Isend" , R );

      R = comm_service::serve( req );
      if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridTable::write" , "comm_service::serve" , R );

      gdbkt->free();
      gdbkt = 0;

#endif
      return DAGH_OK;
     }
  }

int GridTable::write(GridTableEntry& gte, GridDataBucketVoid* gdbkt,
                     const int t, const int l, const int a, const int d, const int m,
                     const unsigned tag)
  {
    const int me = comm_service::proc_me();
    const int dest = gte.owner;
    const int ln = gte.levelnum(l);

    if (dest == me || !comm_service::dce()) {

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTable::write" << "(" << me << ")"
                         << "Writing { "
                         << "(" << gfid << ")"
                         << *((GridDataBucketVoid *) gdbkt)->head()
                         << " }"
                         << endl ).flush();
#endif

      GridDataBucketVoid *&tmpbkt = gte(t,l,a,d,m);
      if (tmpbkt != GridDataBucketVoidNULL) tmpbkt->free();
      tmpbkt = gdbkt;
      gdbkt = 0;
      return DAGH_OK;
    }
    else {
#ifdef DAGH_NO_MPI
#else

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTable::write: (" << me << ")"
                         << "Sending { "
                         << "(" << gfid << ")"
                         << *((GridDataBucketVoid *) gdbkt)->head()
                         << " }"
                         << endl ).flush();
#endif

      void *package = 0; unsigned size;
      gdbkt->pack(package,size);

      unsigned T = (tag | t<<DAGHTimeShift | ln<<DAGHLevelShift | d<<DAGHDirShift);

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTable::write: (" << me << ")"
                         << "MPI_Isend { "
                         << "(Tag:" << T << ")"
                         << "(Size:" << size << ")"
                         << "(Dest:" << dest << ")"
                         << "(" << t << "," << l <<")"
                         << "(" << a << "," << d << "," << m <<")"
                         << " }"
                         << endl ).flush();
#endif

      MPI_Request req ;
      int R = MPI_Isend( package, size, MPI_BYTE , dest,
                         T, comm_service::comm(gfid) , &req );
      if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridTable::write" , "MPI_Isend" , R );

      R = comm_service::serve( req );
      if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridTable::write" , "comm_service::serve" , R );

      gdbkt->free();
      gdbkt = 0;

#endif
      return DAGH_OK;
     }
  }

int GridTable::write(const dMapIndex& index, GridDataBucketVoid* gdbkt,
                     const int t, const int l, const int a, const int d, const int m,
                     const unsigned tag)
  {
    GridTableEntry &tmpgte = *(table.find(index));
    if (&tmpgte == GridTableEntryNULL) return DAGH_ERROR;

    const int me = comm_service::proc_me();
    const int dest = tmpgte.owner;
    const int ln = tmpgte.levelnum(l);

    if (dest == me || !comm_service::dce()) {

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTable::write: (" << me << ")"
                         << "Writing { "
                         << "(" << gfid << ")"
                         << *((GridDataBucketVoid *) gdbkt)->head()
                         << " }"
                         << endl ).flush();
#endif

      GridDataBucketVoid *&tmpbkt = tmpgte(t,l,a,d,m);
      if (tmpbkt != GridDataBucketVoidNULL) tmpbkt->free();
      tmpbkt = gdbkt;
      gdbkt = 0;
      return DAGH_OK;
    }
    else {
#ifdef DAGH_NO_MPI
#else

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTable::write (" << me << ")"
                         << "Sending { "
                         << "(" << gfid << ")"
                         << *((GridDataBucketVoid *) gdbkt)->head()
                         << " }"
                         << endl ).flush();
#endif

      void *package = 0; unsigned size;
      gdbkt->pack(package,size);

      unsigned T = (tag | t<<DAGHTimeShift | ln<<DAGHLevelShift | d<<DAGHDirShift);

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTable::write" << "(" << me << ")"
                         << "MPI_Isend { "
                         << "(Tag:" << T << ")"
                         << "(Size:" << size << ")"
                         << "(Dest:" << dest << ")"
                         << "(" << t << "," << l <<")"
                         << "(" << a << "," << d << "," << m <<")"
                         << " }"
                         << endl ).flush();
#endif

      MPI_Request req ;
      int R = MPI_Isend( package, size, MPI_BYTE , dest,
                         T, comm_service::comm(gfid) , &req );
      if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridTable::write" , "MPI_Isend" , R );

      R = comm_service::serve( req );
      if ( MPI_SUCCESS != R ) 
	comm_service::error_die( "GridTable::write" , "comm_service::serve" , R );

      gdbkt->free();
      gdbkt = 0;

#endif
      return DAGH_OK;
    }
  }

/**************************************************************************/
/* Sends */
/**************************************************************************/
int GridTable::send(const unsigned tag, GridDataBucketVoid* gdbkt, const int dest)
  {
#ifdef DAGH_NO_MPI
#else
   const int me = comm_service::proc_me();

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTable::write: (" << me << ")"
                         << "Sending { " 
			 << "(" << gfid << ")"
			 << *((GridDataBucketVoid *) gdbkt)->head() 
			 << "(" << dest << ")"
		 	 << " }"
                         << endl ).flush();
#endif

   void *package = 0; unsigned size;
   gdbkt->pack(package,size);

#ifdef DEBUG_PRINT_COMM
   ( comm_service::log() << "GridTable::write: (" << me << ")"
                         << "MPI_Isend { " 
			 << "(Tag:" << tag << ")" 
			 << "(Size:" << size << ")" 
		 	 << "(Dest:" << dest << ")"
		 	 << " }"
                         << endl ).flush();
#endif

   MPI_Request req ;
   int R = MPI_Isend( package, size, MPI_BYTE , dest,
                      tag, comm_service::comm(gfid) , &req );
   if ( MPI_SUCCESS != R ) 
     comm_service::error_die( "GridTable::write" , "MPI_Isend" , R );

   R = comm_service::serve( req );
   if ( MPI_SUCCESS != R ) 
     comm_service::error_die( "GridTable::write" , "comm_service::serve" , R );

   gdbkt->free();
   gdbkt = 0;
#endif
   return DAGH_OK;
  }
