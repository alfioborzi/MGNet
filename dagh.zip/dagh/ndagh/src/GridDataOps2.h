#ifndef _included_GridDataOps_2_h
#define _included_GridDataOps_2_h

/*
*************************************************************************
*                                                                       *
* GridDataOps2.h                                                        *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

template <class Type>
void GridData(2)<Type>::lin_interp (GridData(2)<Type> const &gd1, double const frac1,
                   GridData(2)<Type> const &gd2, double const frac2,
                   BBox const &where)
  {
   BBox intersection = _bbox * gd1._bbox * gd2._bbox * where;
   if (!intersection.empty())
    {
     //int max_step = (_step > gd1._step) ? _step : 
     //		(gd1._step > gd2._step) ? gd1._step : gd2._step;

     Coords max_step = max(_step, gd1._step);
     max_step.max(gd2._step);

     GridData(2)<Type> &dst = *this;

     BeginFastIndex2(src1, gd1._bbox, gd1._data, const Type);
     BeginFastIndex2(src2, gd2._bbox, gd2._data, const Type);
     BeginFastIndex2(dst, dst._bbox, dst._data, Type);

     for_2(i, j, intersection, max_step)
       FastIndex2(dst,i,j) = (Type) ((FastIndex2(src1,i,j) * frac1)
			   + (FastIndex2(src2,i,j) * frac2));
     end_for

     EndFastIndex2(dst);
     EndFastIndex2(src1);
     EndFastIndex2(src2);
   }
  }

/**************************************************************************/

template <class Type>
void GridData(2)<Type>::equals (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(equal)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(2)<Type>::equals (GridData(2)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(equal)(gd, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(2)<Type>::plus (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(plus)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(2)<Type>::plus (GridData(2)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(plus)(gd, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(2)<Type>::minus (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(minus)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(2)<Type>::minus (GridData(2)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(minus)(gd, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(2)<Type>::multiply (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(mult)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(2)<Type>::multiply (GridData(2)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(mult)(gd, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(2)<Type>::divide (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(div)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(2)<Type>::divide (GridData(2)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(div)(gd, newto, newfrom, max_step);
     }
  }

/****************************** = ***************************************/

template <class Type>
void GridData(2)<Type>::gd_OperateRegion(equal) (Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(2)<Type> &dst = *this;

   BeginFastIndex2(dst, dst._bbox, dst._data, Type);

   for_2(i, j, to, step)
      FastIndex2(dst,i,j) = val;
   end_for

   EndFastIndex2(dst);
  }

template <class Type>
void GridData(2)<Type>::gd_OperateRegion(equal) (GridData(2)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(2)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);

   BeginFastIndex2(src, src._bbox, src._data, const Type);
   BeginFastIndex2(dst, dst._bbox, dst._data, Type);

   for_2(i, j, to, step)
      FastIndex2(dst,i,j) = FastIndex2(src,i+di,j+dj);
   end_for

   EndFastIndex2(dst);
   EndFastIndex2(src);
  }

/************************************************************************/

/****************************** + ***************************************/

template <class Type>
void GridData(2)<Type>::gd_OperateRegion(plus)(Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(2)<Type> &dst = *this;

   BeginFastIndex2(dst, dst._bbox, dst._data, Type);

   for_2(i, j, to, step)
      FastIndex2(dst,i,j) += val;
   end_for

   EndFastIndex2(dst);
  }

template <class Type>
void GridData(2)<Type>::gd_OperateRegion(plus)(GridData(2)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(2)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);

   BeginFastIndex2(src, src._bbox, src._data, const Type);
   BeginFastIndex2(dst, dst._bbox, dst._data, Type);

   for_2(i, j, to, step)
      FastIndex2(dst,i,j) += FastIndex2(src,i+di,j+dj);
   end_for

   EndFastIndex2(dst);
   EndFastIndex2(src);
  }

/************************************************************************/

/****************************** - ***************************************/

template <class Type>
void GridData(2)<Type>::gd_OperateRegion(minus)(Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(2)<Type> &dst = *this;

   BeginFastIndex2(dst, dst._bbox, dst._data, Type);

   for_2(i, j, to, step)
      FastIndex2(dst,i,j) -= val;
   end_for

   EndFastIndex2(dst);
  }

template <class Type>
void GridData(2)<Type>::gd_OperateRegion(minus)(GridData(2)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(2)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);

   BeginFastIndex2(src, src._bbox, src._data, const Type);
   BeginFastIndex2(dst, dst._bbox, dst._data, Type);

   for_2(i, j, to, step)
      FastIndex2(dst,i,j) -= FastIndex2(src,i+di,j+dj);
   end_for

   EndFastIndex2(dst);
   EndFastIndex2(src);
  }

/************************************************************************/

/****************************** * ***************************************/

template <class Type>
void GridData(2)<Type>::gd_OperateRegion(mult)(Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(2)<Type> &dst = *this;

   BeginFastIndex2(dst, dst._bbox, dst._data, Type);

   for_2(i, j, to, step)
      FastIndex2(dst,i,j) *= val;
   end_for

   EndFastIndex2(dst);
  }

template <class Type>
void GridData(2)<Type>::gd_OperateRegion(mult)(GridData(2)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(2)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);

   BeginFastIndex2(src, src._bbox, src._data, const Type);
   BeginFastIndex2(dst, dst._bbox, dst._data, Type);

   for_2(i, j, to, step)
      FastIndex2(dst,i,j) *= FastIndex2(src,i+di,j+dj);
   end_for

   EndFastIndex2(dst);
   EndFastIndex2(src);
  }

/************************************************************************/

/****************************** / ***************************************/

template <class Type>
void GridData(2)<Type>::gd_OperateRegion(div)(Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   assert (val != (Type)0);
   GridData(2)<Type> &dst = *this;

   BeginFastIndex2(dst, dst._bbox, dst._data, Type);

   for_2(i, j, to, step)
      FastIndex2(dst,i,j) /= val;
   end_for

   EndFastIndex2(dst);
  }

template <class Type>
void GridData(2)<Type>::gd_OperateRegion(div)(GridData(2)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(2)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);

   BeginFastIndex2(src, src._bbox, src._data, const Type);
   BeginFastIndex2(dst, dst._bbox, dst._data, Type);

   for_2(i, j, to, step)
      FastIndex2(dst,i,j) /= FastIndex2(src,i+di,j+dj);
   end_for

   EndFastIndex2(dst);
   EndFastIndex2(src);
  }
/************************************************************************/

#endif
