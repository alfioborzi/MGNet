#ifndef _included_DAGHCluster_c
#define _included_DAGHCluster_c

/*
*************************************************************************
*                                                                       *
* DAGHCluster.c                                                         *
*                                                                       *
* Manish Parashar <parashar@cs.utexas.edu>                              *
*                                                                       *
*************************************************************************
*/

/*************************************************************************/
/* 3-D Clustering */
/*************************************************************************/
template <class Type>
void DAGHCluster3d(GridFunction(3)<Type>& gf, const int time, const int level, 
                   const int blk_width, const int buf_width, 
                   double const min_eff, Type const thresh, 
                   BBoxList& bbl, const int IDENT)
 {
  BBox bb;
  Coords s;
  forall(gf,time,level,c)
    bb += bbox(gf(time,level,c,IDENT));
    s = stepsize(gf(time,level,c,IDENT));
  end_forall 
   
  bb.stepsize() = s;

  if (bb.empty()) {
    bbl.empty();
    return;
  }

  Array(3)<short> flag_array(bb);
  flag_array = 0;
  
#ifdef DEBUG_PRINT_RG_CLUST
  ( comm_service::log() << "\n************* Clustering: Flag Array Size *************\n"
                        << bb
                        << "\n************* ***************** *************\n"
                        ).flush();
#endif

  forall(gf,time,level,c)
     const GridData(3)<Type>& gd = gf(time,level,c,IDENT);
     const BBox& b = gf.mergedbbox(time,level,c,IDENT);
     const Coords& s = b.stepsize();
     for_3(i,j,k,b,s)
       if (gd(i,j,k) > thresh) flag_array(i,j,k) = 1;
     end_for
  end_forall 

  bbl.empty();

  Cluster3(flag_array,
           min_eff,
           blk_width,
           buf_width,bbl);

#ifdef DEBUG_PRINT_RG_CLUST
     ( comm_service::log() << "\n************* Clustering: Output BBoxList  *************\n"
                           << bbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif
 }

template <class Type>
void DAGHCluster3d(GridFunction(3)<Type>& gf, const int time, const int level, 
                   const int blk_width, const int buf_width, 
                   double const min_eff, Type const thresh, 
                   BBoxList& nest_bbl, BBoxList& bbl, const int IDENT)
 {

#ifdef DEBUG_PRINT_RG_CLUST
     ( comm_service::log() << "\n************* Clustering: Nest BBoxList  *************\n"
                           << nest_bbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

  BBox bb;
  Coords s;

  forall(gf,time,level,c)
    bb += bbox(gf(time,level,c,IDENT));
    s = stepsize(gf(time,level,c,IDENT));
  end_forall 
   
  bb.stepsize() = s;

  if (bb.empty()) {
    bbl.empty();
    return;
  }

  Array(3)<short> flag_array(bb);
  flag_array = 0;
  
#ifdef DEBUG_PRINT_RG_CLUST
     ( comm_service::log() << "\n************* Clustering: Flag Array Size *************\n"
                           << bb
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

  BBox *_b = nest_bbl.first();
  for (;_b;_b=nest_bbl.next()) {
    flag_array.equals(1,*_b);
  }

  forall(gf,time,level,c)
     const GridData(3)<Type>& gd = gf(time,level,c,IDENT);
     const BBox& b = gf.mergedbbox(time,level,c,IDENT);
     const Coords& s = b.stepsize();
     for_3(i,j,k,b,s)
       if (gd(i,j,k) > thresh) flag_array(i,j,k) = 1;
     end_for
  end_forall 

  bbl.empty();

  Cluster3(flag_array,
           min_eff,
           blk_width,
           buf_width,bbl);

#ifdef DEBUG_PRINT_RG_CLUST
     ( comm_service::log() << "\n************* Clustering: Output BBoxList  *************\n"
                           << bbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif
 }

/*************************************************************************/
/* 2-D Clustering */
/*************************************************************************/
template <class Type>
void DAGHCluster2d(GridFunction(2)<Type>& gf, const int time, const int level, 
                   const int blk_width, const int buf_width, 
                   double const min_eff, Type const thresh, 
                   BBoxList& bbl, const int IDENT)
 {
  BBox bb;
  Coords s;
  forall(gf,time,level,c)
    bb += bbox(gf(time,level,c,IDENT));
    s = stepsize(gf(time,level,c,IDENT));
  end_forall 
   
  bb.stepsize() = s;

  if (bb.empty()) {
    bbl.empty();
    return;
  }

  Array(2)<short> flag_array(bb);
  flag_array = 0;
  
#ifdef DEBUG_PRINT_RG_CLUST
  ( comm_service::log() << "\n************* Clustering: Flag Array Size *************\n"
                        << bb
                        << "\n************* ***************** *************\n"
                        ).flush();
#endif

  forall(gf,time,level,c)
     const GridData(2)<Type>& gd = gf(time,level,c,IDENT);
     const BBox& b = gf.mergedbbox(time,level,c,IDENT);
     const Coords& s = b.stepsize();
     for_2(i,j,b,s)
       if (gd(i,j) > thresh) flag_array(i,j) = 1;
     end_for
  end_forall 

  bbl.empty();

  Cluster2(flag_array,
           min_eff,
           blk_width,
           buf_width,bbl);

#ifdef DEBUG_PRINT_RG_CLUST
     ( comm_service::log() << "\n************* Clustering: Output BBoxList  *************\n"
                           << bbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif
 }

template <class Type>
void DAGHCluster2d(GridFunction(2)<Type>& gf, const int time, const int level, 
                   const int blk_width, const int buf_width, 
                   double const min_eff, Type const thresh, 
                   BBoxList& nest_bbl, BBoxList& bbl, const int IDENT)
 {

#ifdef DEBUG_PRINT_RG_CLUST
     ( comm_service::log() << "\n************* Clustering: Nest BBoxList  *************\n"
                           << nest_bbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

  BBox bb;
  Coords s;

  forall(gf,time,level,c)
    bb += bbox(gf(time,level,c,IDENT));
    s = stepsize(gf(time,level,c,IDENT));
  end_forall 
   
  bb.stepsize() = s;

  if (bb.empty()) {
    bbl.empty();
    return;
  }

  Array(2)<short> flag_array(bb);
  flag_array = 0;
  
#ifdef DEBUG_PRINT_RG_CLUST
     ( comm_service::log() << "\n************* Clustering: Flag Array Size *************\n"
                           << bb
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

  BBox *_b = nest_bbl.first();
  for (;_b;_b=nest_bbl.next()) {
    flag_array.equals(1,*_b);
  }

  forall(gf,time,level,c)
     const GridData(2)<Type>& gd = gf(time,level,c,IDENT);
     const BBox& b = gf.mergedbbox(time,level,c,IDENT);
     const Coords& s = b.stepsize();
     for_2(i,j,b,s)
       if (gd(i,j) > thresh) flag_array(i,j) = 1;
     end_for
  end_forall 

  bbl.empty();

  Cluster2(flag_array,
           min_eff,
           blk_width,
           buf_width,bbl);

#ifdef DEBUG_PRINT_RG_CLUST
     ( comm_service::log() << "\n************* Clustering: Output BBoxList  *************\n"
                           << bbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif
 }

/*************************************************************************/
/* 1-D Clustering */
/*************************************************************************/
template <class Type>
void DAGHCluster1d(GridFunction(1)<Type>& gf, const int time, const int level, 
                   const int blk_width, const int buf_width, 
                   double const min_eff, Type const thresh, 
                   BBoxList& bbl, const int IDENT)
 {
  BBox bb;
  Coords s;
  forall(gf,time,level,c)
    bb += bbox(gf(time,level,c,IDENT));
    s = stepsize(gf(time,level,c,IDENT));
  end_forall 
   
  bb.stepsize() = s;

  if (bb.empty()) {
    bbl.empty();
    return;
  }

  Array(1)<short> flag_array(bb);
  flag_array = 0;
  
#ifdef DEBUG_PRINT_RG_CLUST
  ( comm_service::log() << "\n************* Clustering: Flag Array Size *************\n"
                        << bb
                        << "\n************* ***************** *************\n"
                        ).flush();
#endif

  forall(gf,time,level,c)
     const GridData(1)<Type>& gd = gf(time,level,c,IDENT);
     const BBox& b = gf.mergedbbox(time,level,c,IDENT);
     const Coords& s = b.stepsize();
     for_1(i,b,s)
       if (gd(i) > thresh) flag_array(i) = 1;
     end_for
  end_forall 

  bbl.empty();

  Cluster1(flag_array,
           min_eff,
           blk_width,
           buf_width,bbl);

#ifdef DEBUG_PRINT_RG_CLUST
     ( comm_service::log() << "\n************* Clustering: Output BBoxList  *************\n"
                           << bbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif
 }

template <class Type>
void DAGHCluster1d(GridFunction(1)<Type>& gf, const int time, const int level, 
		   const int blk_width, const int buf_width, 
		   double const min_eff, Type const thresh, 
		   BBoxList& nest_bbl, BBoxList& bbl, const int IDENT)
 {

#ifdef DEBUG_PRINT_RG_CLUST
     ( comm_service::log() << "\n************* Clustering: Nest BBoxList  *************\n"
                           << nest_bbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

  BBox bb;
  Coords s;

  forall(gf,time,level,c)
    bb += bbox(gf(time,level,c,IDENT));
    s = stepsize(gf(time,level,c,IDENT));
  end_forall 
   
  bb.stepsize() = s;

  if (bb.empty()) {
    bbl.empty();
    return;
  }

  Array(1)<short> flag_array(bb);
  flag_array = 0;
  
#ifdef DEBUG_PRINT_RG_CLUST
     ( comm_service::log() << "\n************* Clustering: Flag Array Size *************\n"
                           << bb
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif

  BBox *_b = nest_bbl.first();
  for (;_b;_b=nest_bbl.next()) {
    flag_array.equals(1,*_b);
  }

  forall(gf,time,level,c)
     const GridData(1)<Type>& gd = gf(time,level,c,IDENT);
     const BBox& b = gf.mergedbbox(time,level,c,IDENT);
     const Coords& s = b.stepsize();
     for_1(i,b,s)
       if (gd(i) > thresh) flag_array(i) = 1;
     end_for
  end_forall 

  bbl.empty();

  Cluster1(flag_array,
           min_eff,
           blk_width,
           buf_width,bbl);

#ifdef DEBUG_PRINT_RG_CLUST
     ( comm_service::log() << "\n************* Clustering: Output BBoxList  *************\n"
                           << bbl
                           << "\n************* ***************** *************\n"
                           ).flush();
#endif
 }

#endif
