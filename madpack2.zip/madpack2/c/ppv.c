#include "defnc.pre"
#include "defnc.v2"

piv(s, n, x) char *s; int n; INT *x; {

  int i;

  printf("\n%s %d\n", s, n);
  for (i = 0; i < n; i++)
    printf("%10d\n", *x++);
  putchar('\n');
  }

ppv(s, n, x) char *s; int n; REAL *x; {

  int i;

  printf("\n%s %d\n", s, n);
  for (i = 0; i < n; i++)
    printf("%14.5e\n", *x++);
  putchar('\n');
  }
