#ifndef GDIterator_h
#define GDIterator_h

#define GDIterator(N) name2(GDIterator_,N)
#define declareGDIterator(N) \
template<class Type> class GridFunction(N); \
template<class Type> \
class GDIterator(N) { \
	friend GridFunction(N)<Type>; \
	int gf_CU; \
	int t,l,c; \
	GridFunction(N)<Type> *gfp; \
	void adv() { \
		assert(gfp); \
		while(!gfp->exists(t,l,c)) \
			c++; \
	} \
public: \
	GDIterator(N)(int ti,int li) { \
		t = ti; \
		l = li; \
		gfp = 0; \
	} \
	void operator=(GridFunction(N)<Type>& gf) { \
		gf_CU = gf.len(); \
		c = 0; \
		gfp = &gf; \
		adv(); \
	} \
	void operator++() { \
		c++; \
		adv(); \
	} \
	void operator++(int) { operator++(); } \
	operator int() { return c < gf_CU; } \
	int component() { return c; } \
	int time() { return t; } \
	int level() {return l; } \
};
declareGDIterator(1)
declareGDIterator(2)
declareGDIterator(3)
#endif
