/* Copyright (c) 1993 by P. Klosowski at NIST.  All Rights Reserved */

/***
   NAME
     lgnuplot
   PURPOSE
     fortran-> gnuplot interface
   NOTES
     
   HISTORY
     przemek - Mar 2, 1993: Created.

---
May 1994.  Changes made by William F. Mitchell, Applied and
Computational Mathematics Division, NIST:

1) changed names gnuplot_open, gnuplot and gnuplot_close to
gpopen, gnuplt and gpclos, respectively, to conform with
FORTRAN 77 standard of 6 characters for identifiers.

2) removed procedure "pause", since I'm not using it and one
of the compilers I tried balked at something in it.

3) replaced procedure names with upper case version without
trailing underscore, as expected by Cray.

4) replaced string conversion by the Cray way of doing it,
using #include <fortran.h>, _fcd and _fcdtocp.

The original version is from the user contributed software
for gnuplot.  It is in the file gpcontrb.zip which is
available with gnuplot release 3.5.

Bill
---

***/
#include <stdio.h>
#include <fortran.h>
long
GPOPEN(void)
{
  FILE * fp = popen("gnuplot","w"); 
  if (fp == NULL) {
    printf("Can't run gnuplot\n");
  }
  return (long) fp;
}
void
GNUPLT(FILE ** fpp, _fcd command)
{
  char buf[200];
  int size;

  size = _fcdlen(command);
  strncpy(buf,_fcdtocp(command),size);  buf[size] = '\0';
  if(buf[size-1] != '\n')
    strcat(buf,"\n");
  fprintf(*fpp,buf);
  fflush(*fpp);
}
void
GPCLOS(FILE ** fpp)
{
  if (pclose(*fpp) == -1) 
    printf("Problem closing communications to gnuplot\n");
}
