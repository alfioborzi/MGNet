#ifndef _included_GridFunctionBndry3_c
#define _included_GridFunctionBndry3_c

/*
*************************************************************************
*                                                                       *
* GridFunctionBndry3.c                                                  *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/*****************************************************************************/
/**** Boundary Update ****/
/*****************************************************************************/

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_BndryUpdate(const int time, 
                                                  const int level,
                                                  const int ident)
{
   if (bwidth == 0) return;

   register int const t = dagh_timeindex(time,level);
   register int const l = level;

   /* Do Adaptive Boundaries if  I am a fine grid */
   if (l > 0 && adaptiveboundary() && adaptbndry_update()) {

     const int tf = dagh.getCurrentTime(l);
     const int tc = dagh.getCurrentTime(l-1);
     const int sf = dagh.timestep(l);
     const int sc = dagh.timestep(l-1);
       
     if (t > 0) {
       int timea, timeb, timec;
       
       if (time < tc) {
	 timea = tc;
	 timeb = time-sf;
	 timec = tc-sc;
       }
       else if (time == tc && updatedstep == DAGHNextTime) {
	 timea = tc+sc;
	 timeb = time-sf;
	 timec = tc;
       }
       else if (time == tc && updatedstep == DAGHCurrentTime) {
	 timea = tc;
	 timeb = time-sf;
	 timec = tc-sc;
       }
       else {
	 timea = tc+sc;
	 timeb = time-sf;
	 timec = tc;
       }
       
       const double frac = 1.0*(time-timeb)/(timea-timeb);
       const double Cfrac = 1.0*(time-timec)/(sc);
       const double OneMinusCfrac = 1.0 - Cfrac;
       const int talm = dagh_timeindex(timea,l-1);
       const int tb = dagh_timeindex(timeb,l);
       const int tlm = dagh_timeindex(timec,l-1);
       
       register int i;
       for (i=0; i<length; i++) {
	 if (gdb[t][l][i] && gdb[tb][l][i] && 
	     gdb[tlm][l-1][i] && gdb[talm][l-1][i] ) {
	   
	   GridData(3)<DAGH_GFType> &pbl = gdb[tb][l][i]->griddata(ident);
	   GridData(3)<DAGH_GFType> &pl = gdb[t][l][i]->griddata(ident);
	   GridData(3)<DAGH_GFType> &palm = gdb[talm][l-1][i]->griddata(ident);
	   GridData(3)<DAGH_GFType> &plm = gdb[tlm][l-1][i]->griddata(ident);
	   
	   /* Do  DAGH Space-Time Interpolation */
	   if (prolong() && /* I can't do Space-Time Interp if I can't prolong ! */
	       (adaptiveboundary_type() ==  DAGHAdaptBoundaryInterp ||
		adaptiveboundary_type() ==  DAGHAdaptBoundaryBoth)) {
	     if (pfunc) { /* Call the prolongation function */
	       int myargc = 0; DAGH_GFType myargs[1];
	       for(register int b=0; b<gfrank; b++)  {
		 if (gdb[t][l][i]->has_adaptiveboundary(2*b)) 
		   (*pfunc)(FORTRAN_ARGS(palm),FORTRAN_ARGS(pl),
			    BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b,ident)),
			    myargs,&myargc);
		 if (gdb[t][l][i]->has_adaptiveboundary(2*b+1))
		   (*pfunc)(FORTRAN_ARGS(palm),FORTRAN_ARGS(pl),
			    BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b+1,ident)),
			    myargs,&myargc);
	       }
	     } 

	     /* data = (old * (1-frac)) + (new * frac) */
	     for (register int b=0; b<gfrank; b++)  {
	       register int itimes2 = 2*b;
	       if (gdb[t][l][i]->has_adaptiveboundary(itimes2)) {
		 pl.lin_interp(pbl,(1.0-frac),pl,frac,
			       gdb[t][l][i]->bndrybox(itimes2,ident));
	       }
	       if (gdb[t][l][i]->has_adaptiveboundary(itimes2+1)) {
		 pl.lin_interp(pbl,(1.0-frac),pl,frac,
			       gdb[t][l][i]->bndrybox(itimes2+1,ident));
	       }
	     }
	   }

	   /* Call User-defined adaptive boundary update function */
	   if (abfunc &&
	       (adaptiveboundary_type() ==  DAGHAdaptBoundaryUserDef ||
		adaptiveboundary_type() ==  DAGHAdaptBoundaryBoth)) {
	     int myargc = 0; DAGH_GFType myargs[1];
	     for(register int b=0; b<gfrank; b++)  {
	       if (gdb[t][l][i]->has_adaptiveboundary(2*b))
		 (*abfunc)(FORTRAN_ARGS(pl),
			   FORTRAN_ARGS(palm),&Cfrac,
			   FORTRAN_ARGS(plm),&OneMinusCfrac,
			   BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b,ident)),
			   myargs,&myargc);
	       if (gdb[t][l][i]->has_adaptiveboundary(2*b+1))
		 (*abfunc)(FORTRAN_ARGS(pl),
			    FORTRAN_ARGS(palm),&Cfrac,
			    FORTRAN_ARGS(plm),&OneMinusCfrac,
			    BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b+1,ident)),
			    myargs,&myargc);
	     }
	   }
	 }
       }
     } /* end t > 0 */
     else { /* if t == 0 */
       for (register int i=0; i<length; i++) {
	 if (gdb[t][l][i] && gdb[t][l-1][i]) {
	   
	   GridData(3)<DAGH_GFType> &pl = gdb[t][l][i]->griddata(ident);
	   GridData(3)<DAGH_GFType> &plm = gdb[t][l-1][i]->griddata(ident);

	   /* Do  DAGH Space-Time Interpolation */
	   if (prolong() && /* I can't do Space-Time Interp if I can't prolong ! */
	       (adaptiveboundary_type() ==  DAGHAdaptBoundaryInterp ||
		adaptiveboundary_type() ==  DAGHAdaptBoundaryBoth)) {

	     if (pfunc) { /* Call the prolongation function */
	       int myargc = 0; DAGH_GFType myargs[1];
	       for(register int b=0; b<gfrank; b++)  {
		 if (gdb[t][l][i]->has_adaptiveboundary(2*b))
		   (*pfunc)(FORTRAN_ARGS(plm),FORTRAN_ARGS(pl),
			    BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b,ident)),
			    myargs,&myargc);
		 if (gdb[t][l][i]->has_adaptiveboundary(2*b+1))
		   (*pfunc)(FORTRAN_ARGS(plm),FORTRAN_ARGS(pl),
			    BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b+1,ident)),
			    myargs,&myargc);
	       }
	     }
	   }

	   /* Call User-defined adaptive boundary update function */
	   if (abfunc &&
	       (adaptiveboundary_type() ==  DAGHAdaptBoundaryUserDef ||
		adaptiveboundary_type() ==  DAGHAdaptBoundaryBoth)) {

	     double Cfrac = 0.0;
	     int talm = t;
	     if (time_sten_rad > 0 && gdb[t+1][l-1][i]) {
	       Cfrac = 1.0*(time-dagh_timevalue(t,l-1))/(sc);
	       talm = t+1;
	     }
	     else {  
	       talm = t;
	     }
	     GridData(3)<DAGH_GFType> &palm = gdb[talm][l-1][i]->griddata(ident);
	     const double OneMinusCfrac = 1.0 - Cfrac;

	     int myargc = 0; DAGH_GFType myargs[1];
	     for(register int b=0; b<gfrank; b++)  {
	       if (gdb[t][l][i]->has_adaptiveboundary(2*b))
		 (*abfunc)(FORTRAN_ARGS(pl),
			   FORTRAN_ARGS(palm),&Cfrac,
			   FORTRAN_ARGS(plm),&OneMinusCfrac,
			   BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b,ident)),
			   myargs,&myargc);
	       if (gdb[t][l][i]->has_adaptiveboundary(2*b+1))
		 (*abfunc)(FORTRAN_ARGS(pl),
			    FORTRAN_ARGS(palm),&Cfrac,
			    FORTRAN_ARGS(plm),&OneMinusCfrac,
			    BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b+1,ident)),
			    myargs,&myargc);
	     }
	   }
	 }
       }
     } /* end t == 0 */
   } /* End Adaptive Boundary */ 

   /* Do External Boundaries */
   if (externalboundary() && bndry_update()) {

     /* Use User-defined External boundary function */
     if (boundary_type() == DAGHBoundaryUserDef && bfunc) {
       for (register int i=0; i<length; i++) if (gdb[t][l][i]) {
	 GridData(3)<DAGH_GFType> &u = gdb[t][l][i]->griddata(ident,DAGHNull);
	 for(register int b=0; b<gfrank; b++)  {
	   if (gdb[t][l][i]->has_externalboundary(2*b)) 
	     (*bfunc)(FORTRAN_ARGS(u),
		      BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b,ident,DAGHNull)),
		      0,0);
	   if (gdb[t][l][i]->has_externalboundary(2*b+1)) 
	     (*bfunc)(FORTRAN_ARGS(u),
		      BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b+1,ident,DAGHNull)),
		      0,0);
	 }
       }
     }
     
     /* H3e type shift boundaries */
     else if (boundary_type() == DAGHBoundaryShift) {
       for (register int i=0; i<length; i++) if (gdb[t][l][i]) {
	 GridData(3)<DAGH_GFType> &u = gdb[t][l][i]->griddata(ident,DAGHNull);
	 for(register int b=0; b<gfrank; b++)  {
	   if (gdb[t][l][i]->has_externalboundary(2*b)) 
	     u.equals(u,gdb[t][l][i]->bndrybox(2*b,ident,DAGHNull),
		      shift(gdb[t][l][i]->bndrybox(2*b,ident,DAGHNull),b,1));
	   if (gdb[t][l][i]->has_externalboundary(2*b+1))
	     u.equals(u,gdb[t][l][i]->bndrybox(2*b+1,ident,DAGHNull),
		      shift(gdb[t][l][i]->bndrybox(2*b+1,ident,DAGHNull),b,-1));
	 }
       }
     }
     
     /* Set the boundary to user defined constant */
     else if (boundary_type() == DAGHBoundaryRegular) {
       for (register int i=0; i<length; i++) if (gdb[t][l][i]) {
	 GridData(3)<DAGH_GFType> &u = gdb[t][l][i]->griddata(ident,DAGHNull);
	 for(register int b=0; b<gfrank; b++)  {
	   if (gdb[t][l][i]->has_externalboundary(2*b)) 
	     u.equals(bvalue,gdb[t][l][i]->bndrybox(2*b,ident,DAGHNull));
	   if (gdb[t][l][i]->has_externalboundary(2*b+1))
	     u.equals(bvalue,gdb[t][l][i]->bndrybox(2*b+1,ident,DAGHNull));
	 }
       }
     }

     /* Periodic boundaries (no defiend as yet...) */
     else if (boundary_type() == DAGHBoundaryPeriodic) {
       assert (0);
     } 
     
     /* Default is an error */
     else {
       assert (0);
     }

   }
}

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_BndryUpdate(const int time, 
                                                  const int level,
                                                  const int mgl,
                                                  const int ident)
{
   if (bwidth == 0) return;

   register int const t = dagh_timeindex(time,level);
   register int const l = level;

   /* Do Adaptive Boundaries if  I am a fine grid */
   if (l > 0 && adaptiveboundary() && adaptbndry_update()) {

     const int tf = dagh.getCurrentTime(l);
     const int tc = dagh.getCurrentTime(l-1);
     const int sf = dagh.timestep(l);
     const int sc = dagh.timestep(l-1);
 
     if (t > 0) {
       int timea, timeb, timec;
       
       if (time < tc) {
	 timea = tc;
	 timeb = time-sf;
	 timec = tc-sc;
       }
       else if (time == tc && updatedstep == DAGHNextTime) {
	 timea = tc+sc;
	 timeb = time-sf;
	 timec = tc;
       }
       else if (time == tc && updatedstep == DAGHCurrentTime) {
	 timea = tc;
	 timeb = time-sf;
	 timec = tc-sc;
       }
       else {
	 timea = tc+sc;
	 timeb = time-sf;
	 timec = tc;
       }
       
       const double frac = 1.0*(time-timeb)/(timea-timeb);
       const double Cfrac = 1.0*(time-timec)/(sc);
       const double OneMinusCfrac = 1.0 - Cfrac;
       const int talm = dagh_timeindex(timea,l-1);
       const int tb = dagh_timeindex(timeb,l);
       const int tlm = dagh_timeindex(timec,l-1);
       
       register int i;
       for (i=0; i<length; i++) {
	 if (gdb[t][l][i] && gdb[tb][l][i] && 
	     gdb[tlm][l-1][i] && gdb[talm][l-1][i] ) {
	   
	   GridData(3)<DAGH_GFType> &pbl = gdb[tb][l][i]->griddata(ident,mgl);
	   GridData(3)<DAGH_GFType> &pl = gdb[t][l][i]->griddata(ident,mgl);
	   GridData(3)<DAGH_GFType> &palm = gdb[talm][l-1][i]->griddata(ident,mgl);
	   GridData(3)<DAGH_GFType> &plm = gdb[tlm][l-1][i]->griddata(ident,mgl);

	   /* Do  DAGH Space-Time Interpolation */
	   if (prolong() && /* I can't do Space-Time Interp if I can't prolong ! */
	       (adaptiveboundary_type() ==  DAGHAdaptBoundaryInterp ||
		adaptiveboundary_type() ==  DAGHAdaptBoundaryBoth)) {
	     if (pfunc) { /* Call the prolongation function */
	       int myargc = 0; DAGH_GFType myargs[1];
	       for(register int b=0; b<gfrank; b++)  {
		 if (gdb[t][l][i]->has_adaptiveboundary(2*b)) 
		   (*pfunc)(FORTRAN_ARGS(palm),FORTRAN_ARGS(pl),
			    BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b,ident,mgl)),
			    myargs,&myargc);
		 if (gdb[t][l][i]->has_adaptiveboundary(2*b+1))
		   (*pfunc)(FORTRAN_ARGS(palm),FORTRAN_ARGS(pl),
			    BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b+1,ident,mgl)),
			    myargs,&myargc);
	       }
	     } 

	     /* data = (old * (1-frac)) + (new * frac) */
	     for (register int b=0; b<gfrank; b++)  {
	       register int itimes2 = 2*b;
	       if (gdb[t][l][i]->has_adaptiveboundary(itimes2)) {
		 pl.lin_interp(pbl,(1.0-frac),pl,frac,
			       gdb[t][l][i]->bndrybox(itimes2,ident,mgl));
	       }
	       if (gdb[t][l][i]->has_adaptiveboundary(itimes2+1)) {
		 pl.lin_interp(pbl,(1.0-frac),pl,frac,
			       gdb[t][l][i]->bndrybox(itimes2+1,ident,mgl));
	       }
	     }
	   }

	   /* Call User-defined adaptive boundary update function */
	   if (abfunc &&
	       (adaptiveboundary_type() ==  DAGHAdaptBoundaryUserDef ||
		adaptiveboundary_type() ==  DAGHAdaptBoundaryBoth)) {
	     int myargc = 0; DAGH_GFType myargs[1];
	     for(register int b=0; b<gfrank; b++)  {
	       if (gdb[t][l][i]->has_adaptiveboundary(2*b))
		 (*abfunc)(FORTRAN_ARGS(pl),
			   FORTRAN_ARGS(palm),&Cfrac,
			   FORTRAN_ARGS(plm),&OneMinusCfrac,
			   BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b,ident,mgl)),
			   myargs,&myargc);
	       if (gdb[t][l][i]->has_adaptiveboundary(2*b+1))
		 (*abfunc)(FORTRAN_ARGS(pl),
			    FORTRAN_ARGS(palm),&Cfrac,
			    FORTRAN_ARGS(plm),&OneMinusCfrac,
			    BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b+1,ident,mgl)),
			    myargs,&myargc);
	     }
	   }
	 }
       }
     } /* end t > 0 */
     else { /* if t == 0 */
       for (register int i=0; i<length; i++) {
	 if (gdb[t][l][i] && gdb[t][l-1][i]) {
	   
	   GridData(3)<DAGH_GFType> &pl = gdb[t][l][i]->griddata(ident,mgl);
	   GridData(3)<DAGH_GFType> &plm = gdb[t][l-1][i]->griddata(ident,mgl);

	   /* Do  DAGH Space-Time Interpolation */
	   if (prolong() && /* I can't do Space-Time Interp if I can't prolong ! */
	       (adaptiveboundary_type() ==  DAGHAdaptBoundaryInterp ||
		adaptiveboundary_type() ==  DAGHAdaptBoundaryBoth)) {

	     if (pfunc) { /* Call the prolongation function */
	       int myargc = 0; DAGH_GFType myargs[1];
	       for(register int b=0; b<gfrank; b++)  {
		 if (gdb[t][l][i]->has_adaptiveboundary(2*b))
		   (*pfunc)(FORTRAN_ARGS(plm),FORTRAN_ARGS(pl),
			    BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b,ident,mgl)),
			    myargs,&myargc);
		 if (gdb[t][l][i]->has_adaptiveboundary(2*b+1))
		   (*pfunc)(FORTRAN_ARGS(plm),FORTRAN_ARGS(pl),
			    BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b+1,ident,mgl)),
			    myargs,&myargc);
	       }
	     }
	   }

	   /* Call User-defined adaptive boundary update function */
	   if (abfunc &&
	       (adaptiveboundary_type() ==  DAGHAdaptBoundaryUserDef ||
		adaptiveboundary_type() ==  DAGHAdaptBoundaryBoth)) {

	     double Cfrac = 0.0;
	     int talm = t;
	     if (time_sten_rad > 0 && gdb[t+1][l-1][i]) {
	       Cfrac = 1.0*(time-dagh_timevalue(t,l-1))/(sc);
	       talm = t+1;
	     }
	     else {  
	       talm = t;
	     }
	     GridData(3)<DAGH_GFType> &palm = gdb[talm][l-1][i]->griddata(ident,mgl);
	     const double OneMinusCfrac = 1.0 - Cfrac;

	     int myargc = 0; DAGH_GFType myargs[1];
	     for(register int b=0; b<gfrank; b++)  {
	       if (gdb[t][l][i]->has_adaptiveboundary(2*b))
		 (*abfunc)(FORTRAN_ARGS(pl),
			   FORTRAN_ARGS(palm),&Cfrac,
			   FORTRAN_ARGS(plm),&OneMinusCfrac,
			   BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b,ident,mgl)),
			   myargs,&myargc);
	       if (gdb[t][l][i]->has_adaptiveboundary(2*b+1))
		 (*abfunc)(FORTRAN_ARGS(pl),
			    FORTRAN_ARGS(palm),&Cfrac,
			    FORTRAN_ARGS(plm),&OneMinusCfrac,
			    BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b+1,ident,mgl)),
			    myargs,&myargc);
	     }
	   }
	 }
       }
     } /* end t == 0 */
   } /* End Adaptive Boundary */ 

   /* Do External Boundaries */
   if (externalboundary() && bndry_update()) {

     /* Use User-defined External boundary function */
     if (boundary_type() == DAGHBoundaryUserDef && bfunc) {
       for (register int i=0; i<length; i++) if (gdb[t][l][i]) {
	 GridData(3)<DAGH_GFType> &u = gdb[t][l][i]->griddata(ident,mgl);
	 for(register int b=0; b<gfrank; b++)  {
	   if (gdb[t][l][i]->has_externalboundary(2*b)) 
	     (*bfunc)(FORTRAN_ARGS(u),
		      BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b,ident,mgl)),
		      0,0);
	   if (gdb[t][l][i]->has_externalboundary(2*b+1)) 
	     (*bfunc)(FORTRAN_ARGS(u),
		      BOUNDING_BOX(gdb[t][l][i]->bndrybox(2*b+1,ident,mgl)),
		      0,0);
	 }
       }
     }

     /* H3e type shift boundaries */
     else if (boundary_type() == DAGHBoundaryShift) {
       for (register int i=0; i<length; i++) if (gdb[t][l][i]) {
	 GridData(3)<DAGH_GFType> &u = gdb[t][l][i]->griddata(ident,mgl);
	 for(register int b=0; b<gfrank; b++)  {
	   if (gdb[t][l][i]->has_externalboundary(2*b)) 
	     u.equals(u,gdb[t][l][i]->bndrybox(2*b,ident,mgl),
		      shift(gdb[t][l][i]->bndrybox(2*b,ident,mgl),b,1));
	   if (gdb[t][l][i]->has_externalboundary(2*b+1))
	     u.equals(u,gdb[t][l][i]->bndrybox(2*b+1,ident,mgl),
		      shift(gdb[t][l][i]->bndrybox(2*b+1,ident,mgl),b,-1));
	 }
       }
     }
     
     /* Set the boundary to user defined constant */
     else if (boundary_type() == DAGHBoundaryRegular) {
       for (register int i=0; i<length; i++) if (gdb[t][l][i]) {
	 GridData(3)<DAGH_GFType> &u = gdb[t][l][i]->griddata(ident,mgl);
	 for(register int b=0; b<gfrank; b++)  {
	   if (gdb[t][l][i]->has_externalboundary(2*b)) 
	     u.equals(bvalue,gdb[t][l][i]->bndrybox(2*b,ident,mgl));
	   if (gdb[t][l][i]->has_externalboundary(2*b+1))
	     u.equals(bvalue,gdb[t][l][i]->bndrybox(2*b+1,ident,mgl));
	 }
       }
     }

     /* Periodic boundaries (no defiend as yet...) */
     else if (boundary_type() == DAGHBoundaryPeriodic) {
       assert (0);
     } 
     
     /* Default is an error */
     else {
       assert (0);
     }

   }
}

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_DoAdaptBndryUpdate(
                                   GridDataBlock(3)<DAGH_GFType> &gdb_pbl,
                                   GridDataBlock(3)<DAGH_GFType> &gdb_palm,
                                   GridDataBlock(3)<DAGH_GFType> &gdb_pl,
                                   const double frac,
                                   const int ident)
  {
   if (bwidth == 0 || !adaptbndry_update() || !prolong()) return;

    GridData(3)<DAGH_GFType> &pbl = gdb_pbl.griddata(ident,DAGHNull);
    GridData(3)<DAGH_GFType> &palm = gdb_palm.griddata(ident,DAGHNull);
    GridData(3)<DAGH_GFType> &pl = gdb_pl.griddata(ident,DAGHNull);

    if (pfunc) { /* Call the prolongation function */
      int myargc = 0; DAGH_GFType myargs[1];
      for(register int b=0; b<gfrank; b++)  {
        if (gdb_pl.has_adaptiveboundary(2*b)) 
          (*pfunc)(FORTRAN_ARGS(palm),FORTRAN_ARGS(pl),
                   BOUNDING_BOX(gdb_pl.bndrybox(2*b,ident,DAGHNull)),
                   myargs,&myargc);
        if (gdb_pl.has_adaptiveboundary(2*b+1))
          (*pfunc)(FORTRAN_ARGS(palm),FORTRAN_ARGS(pl),
                   BOUNDING_BOX(gdb_pl.bndrybox(2*b+1,ident,DAGHNull)),
                   myargs,&myargc);
     }
   }
 
   /* data = (old * (1-frac)) + (new * frac) */
   for (register int b=0; b<gfrank; b++)  {
     register int itimes2 = 2*b;
     if (gdb_pl.has_adaptiveboundary(itimes2)) {
       pl.lin_interp(pbl,(1.0-frac),pl,frac,
                     gdb_pl.bndrybox(itimes2,ident,DAGHNull));
     }
     if (gdb_pl.has_adaptiveboundary(itimes2+1)) {
       pl.lin_interp(pbl,(1.0-frac),pl,frac,
                     gdb_pl.bndrybox(itimes2+1,ident,DAGHNull));
     }
   }
  }

template <class DAGH_GFType>
void GridFunction(3)<DAGH_GFType>::GF_DoAdaptBndryUpdate(
                                   GridDataBlock(3)<DAGH_GFType> &gdb_pbl,
                                   GridDataBlock(3)<DAGH_GFType> &gdb_palm,
                                   GridDataBlock(3)<DAGH_GFType> &gdb_pl,
                                   const double frac,
                                   const int mgl,
                                   const int ident)
  {
   if (bwidth == 0 || !adaptbndry_update() || !prolong()) return;

    GridData(3)<DAGH_GFType> &pbl = gdb_pbl.griddata(ident,mgl);
    GridData(3)<DAGH_GFType> &palm = gdb_palm.griddata(ident,mgl);
    GridData(3)<DAGH_GFType> &pl = gdb_pl.griddata(ident,mgl);

    if (pfunc) { /* Call the prolongation function */
      int myargc = 0; DAGH_GFType myargs[1];
      for(register int b=0; b<gfrank; b++)  {
        if (gdb_pl.has_adaptiveboundary(2*b)) 
          (*pfunc)(FORTRAN_ARGS(palm),FORTRAN_ARGS(pl),
                   BOUNDING_BOX(gdb_pl.bndrybox(2*b,ident,mgl)),
                   myargs,&myargc);
        if (gdb_pl.has_adaptiveboundary(2*b+1))
          (*pfunc)(FORTRAN_ARGS(palm),FORTRAN_ARGS(pl),
                   BOUNDING_BOX(gdb_pl.bndrybox(2*b+1,ident,mgl)),
                   myargs,&myargc);
     }
   }
 
   /* data = (old * (1-frac)) + (new * frac) */
   for (register int b=0; b<gfrank; b++)  {
     register int itimes2 = 2*b;
     if (gdb_pl.has_adaptiveboundary(itimes2)) {
       pl.lin_interp(pbl,(1.0-frac),pl,frac,
                     gdb_pl.bndrybox(itimes2,ident,mgl));
     }
     if (gdb_pl.has_adaptiveboundary(itimes2+1)) {
       pl.lin_interp(pbl,(1.0-frac),pl,frac,
                     gdb_pl.bndrybox(itimes2+1,ident,mgl));
     }
   }
  }

#endif
