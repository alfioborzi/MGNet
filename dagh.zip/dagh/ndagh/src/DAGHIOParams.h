#ifndef _included_DAGHIOParam_h
#define _included_DAGHIOParam_h

/*
*************************************************************************
* DAGHIOParam.h                                                         *
*                                                                       *
*************************************************************************
*/

/* DAGH IO Msg Types */

#define DAGHIOTypeShift		(8)
#define DAGHIOInitReqTag	(1 << DAGHIOTypeShift)
#define DAGHIOEndReqTag		(2 << DAGHIOTypeShift)
#define DAGHIOComplistReqTag	(4 << DAGHIOTypeShift)
#define DAGHIOComplistTag	(5 << DAGHIOTypeShift)
#define DAGHIOWriteReqTag	(6 << DAGHIOTypeShift)
#define DAGHIOWriteDataTag 	(7 << DAGHIOTypeShift)
#define DAGHIOReadReqTag   	(8 << DAGHIOTypeShift)
#define DAGHIOReadDataTag  	(9 << DAGHIOTypeShift)

/* DAGH IO Data Types */
#define DAGH_Integer		(1)
#define DAGH_Real		(2)
#define DAGH_Double		(3)
#define DAGH_Character		(4)
#define DAGH_Byte		(5)

inline static unsigned DAGHIO_DataSize(int const type)	
   { return ( (type == DAGH_Integer) ? sizeof(INTEGER) :
              (type == DAGH_Real) ? sizeof(REAL) : 
              (type == DAGH_Double) ? sizeof(DOUBLE) : 
              (type == DAGH_Character) ? sizeof(CHARACTER) : 
              (type == DAGH_Byte) ? 1 : 1 ); }

/* DAGH IO Functions */
struct gdhdr;
class GridHierarchy;

typedef void (*DAGHIO_WriteFunc) (class GridHierarchy & , struct gdhdr *, void *);
typedef void (*DAGHIO_ReadFunc) (class GridHierarchy & , struct gdhdr *, void *);
typedef void (*DAGHIO_PingFunc) (class GridHierarchy &);

extern DAGHIO_WriteFunc DAGHIO_Write[];
extern DAGHIO_ReadFunc DAGHIO_Read[];

#endif
