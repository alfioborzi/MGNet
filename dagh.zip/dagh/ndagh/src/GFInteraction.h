#ifndef _included_GFInteraction_h
#define _included_GFInteraction_h

/*
*************************************************************************
*                                                                       *
* GFInteraction.h							*
*                                                                       *
*************************************************************************
*/

struct GF_Interaction { 
   friend ostream& operator<<(ostream&, const GF_Interaction&);
   int cnt; 
   unsigned *size; 
   unsigned tsize; 

   inline GF_Interaction() : cnt(0), size(0), tsize(0) {}
   inline ~GF_Interaction() 
    { if (size) delete [] size; }
};

ostream& operator<<(ostream& os, const GF_Interaction&);

#endif
