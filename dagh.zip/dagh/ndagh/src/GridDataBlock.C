/*
*************************************************************************
*                                                                       *
* GridDataBlock.C                                                       *
*                                                                       *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "GridDataBlock.h"

void gdbSetRanks(const int rank, const int align, short* ranks)
  {
   if (align == DAGH_All || align == DAGHNull) return;
   assert(rank < 3);
   if (rank == 1) {
     switch(align) {
       case DAGH_X:
         ranks[0] = DAGH_X;
         break;
       case DAGH_Y:
         ranks[0] = DAGH_Y;
         break;
       case DAGH_Z:
         ranks[0] = DAGH_Z;
         break;
       default:
         assert(0);
     }
   }
   if (rank == 2) {
     switch(align) {
       case DAGH_XY:
         ranks[0] = DAGH_X;
         ranks[1] = DAGH_Y;
         break;
       case DAGH_XZ:
         ranks[0] = DAGH_X;
         ranks[1] = DAGH_Z;
         break;
       case DAGH_YZ:
         ranks[0] = DAGH_Y;
         ranks[1] = DAGH_Z;
         break;
       default:
         assert(0);
     }
   }
  }

void gdbAlignBBox(const int rank, BBox& bb, const int align)
  {
   if (align == DAGH_All || align == DAGHNull) return;
   assert(rank < 3);
   BBox b;
   if (rank == 1) {
     b.rank = 1;
     (b.lower()).rank = 1;
     (b.upper()).rank = 1;
     switch(align) {
       case DAGH_X:
         b.lower(0) = bb.lower(0);
         b.upper(0) = bb.upper(0);
         b.stepsize(0) = bb.stepsize(0);
         break;
       case DAGH_Y:
         b.lower(0) = bb.lower(1);
         b.upper(0) = bb.upper(1);
         b.stepsize(0) = bb.stepsize(1);
         break;
       case DAGH_Z:
         b.lower(0) = bb.lower(2);
         b.upper(0) = bb.upper(2);
         b.stepsize(0) = bb.stepsize(2);
         break;
       default:
         assert(0);
     }
   }
   if (rank == 2) {
     b.rank = 2;
     (b.lower()).rank = 2;
     (b.upper()).rank = 2;
     switch(align) {
       case DAGH_XY:
         b.lower(0) = bb.lower(0);
         b.upper(0) = bb.upper(0);
         b.stepsize(0) = bb.stepsize(0);
         b.lower(1) = bb.lower(1);
         b.upper(1) = bb.upper(1);
         b.stepsize(1) = bb.stepsize(1);
         break;
       case DAGH_XZ:
         b.lower(0) = bb.lower(0);
         b.upper(0) = bb.upper(0);
         b.stepsize(0) = bb.stepsize(0);
         b.lower(1) = bb.lower(2);
         b.upper(1) = bb.upper(2);
         b.stepsize(1) = bb.stepsize(2);
         break;
       case DAGH_YZ:
         b.lower(0) = bb.lower(1);
         b.upper(0) = bb.upper(1);
         b.stepsize(0) = bb.stepsize(1);
         b.lower(1) = bb.lower(2);
         b.upper(1) = bb.upper(2);
         b.stepsize(1) = bb.stepsize(2);
         break;
       default:
         assert(0);
     }
   }
   bb = b;
  }

ostream& operator<<(ostream& os, const GDB_Interaction& gdbi)
  {
    if (&gdbi == (GDB_Interaction *) NULL) return os;

    os << "GDB_Interaction[";

    os << " DAGH_Main:" << gdbi.mbbox;
    if (!gdbi.shbbox.empty()) os << " DAGH_Shadow:" << gdbi.shbbox;

    if (gdbi.gte) os << *gdbi.gte;

    os << "]";
    return os;
  }
