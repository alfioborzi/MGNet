#ifndef _included_GridUnit_h
#define _included_GridUnit_h

/*
*************************************************************************
*                                                                       *
* GridUnit.h                                                        	*
*                                                                       *
* Class GridUnit implements a uniform block of the computational Grid.	*
* The unit is identified by is position (baseindex) and it's size (ext-	*
* ent) at a particular level. A GridUnit can be refine or coarsened	*
* or can be decomposed into GridUnits of smaller extent.		* 
* For a given base, and extent at a level, the size of the GridUnit at 	*
* the level is (base)^(dim*extent). Thus the size of the GridUnit is 	*
* limited to powers of the base. 				*
* Note that, a uniform block of a single level of the Grid can also 	*
* be represented (as a special case) by GridUnit.			*
* GridUnit class provides a member function to query the baseindices of	*
* neighboring GridUnits at different levels.				*
* 							*
* The entire computational Grid is maintainted as a combination of	*
* GridUnits.						*
*                                                                          *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                               *
*                                                                                                                           *         
*************************************************************************
*/

#include "DAGHParams.h"

#include "BBox.h"
#include "Coords.h"
#include "DCoords.h"

#define GridUnitNULL ((GridUnit *) NULL)

class GridUnit 
  {
   friend ostream& operator<<(ostream&, const GridUnit&);
   friend ofstream& operator<<(ofstream&, const GridUnit&);
   friend ifstream& operator>>(ifstream&, GridUnit&);
   friend class GridUnitList;

   short int owner;		/* My Owner */
   short int index;		/* My Index */
   short int dim;		/* Grid dimension */
   short int baselev; 		/* Max level within which this grid unit 
				   is completely contained */
   short int crslev; 		/* Level of the coarsest grid */
   short int finelev; 		/* Level of the finest grid */
   //short int numlev;		/* Number of levels of refinement */
   				/* Finest level = crslev+numlev-1 */
   short int maxlev;		/* Max possible level of refinement */ 
   short int minlev;		/* Min possible level of refinement */ 
   short int levstep;		/* Refinement Factor - power of two - default is 1 */

   short int extent;		/* Extent of the finest level */
				/* i.e. level crslev+numlev-1 */

   //int num;			/* Total number of elements from */
				/*  level crslev to crslev+numlev-1 */

   dMapIndex baseindex; 	/* Index corresponding to the smallest 
				   sfcIndex in the GridUnit. */
   dMapIndex lowindex;    	/* Index corresponding to the lowest
				   sfcIndex in the merged GridUnit set. */

   BBox fbb;                    /* BBox at finest level */
   BBox mbb;                    /* Merged BBox at finest level */

public:
   /* Constructors, Destructor */
   inline GridUnit(void)
        : owner(DAGHNoBody), index(DAGHNull), dim(0), 
          baselev(0), crslev(0), finelev(0), 
          maxlev(0), minlev(0), levstep(0),
          extent(0) { }

   GridUnit(const int ndim, const int clev, unsigned const *bcoords,
	    const int ext, const int mlev, const int lstep, const int reflev);

   GridUnit(const int ndim, const int clev, unsigned const bindex, 
	    const int ext, const int mlev, const int lstep, const int reflev);

   inline GridUnit(GridUnit const &other)
        : owner(other.owner), index(other.index),
          dim(other.dim), baselev(other.baselev),
          crslev(other.crslev), finelev(other.finelev),
          maxlev(other.maxlev), minlev(other.minlev), levstep(other.levstep),
          extent(other.extent), baseindex(other.baseindex),
          fbb(other.fbb), mbb(other.mbb) { }

   inline ~GridUnit(void) {}

   GridUnit const &operator= (GridUnit const &other);

   /* Simple Query funtions */
   inline const int guOwner(void) const { return (owner); }
   inline const int guIndex(void) const { return (index); }
   inline const int guDim(void) const { return (dim); }
   inline const int guBaseLev(void) const { return (baselev); }
   inline const int guFineLev(void) const { return (finelev); }
   inline const int guCrsLev(void) const { return (crslev); }
   inline const int guNumLev(void) const { return ((finelev-crslev)/levstep+1); }
   inline const int guMaxLev(void) const { return (maxlev); }
   inline const int guMinLev(void) const { return (minlev); }
   inline const int guLevStep(void) const { return (levstep); }
   inline const int guLevels(void) const { return ((maxlev-minlev)/levstep+1); }

   inline const int guExtent(const int lev) const
   { return ((lev<=finelev && lev>=crslev && extent>=(finelev-lev)) 
            ? extent-(finelev-lev) : 0); }
   inline const int guExtentAbs(const int lev) const
   { return ((extent>=(finelev-lev)) ? extent-(finelev-lev) : 0); }

   unsigned long const guNum(const int overlap) const;
   unsigned long const guWork(const int overlap) const;
   unsigned long const guNum(const int lev, const int overlap) const;
   unsigned long const guWork(const int lev, const int overlap) const;

   unsigned long const guNum(const short* overlap) const;
   unsigned long const guWork(const short* overlap) const;
   unsigned long const guNum(const int lev, const short* overlap) const;
   unsigned long const guWork(const int lev, const short* overlap) const;

   inline const int guContains(const int lev) const
        { return (lev<=finelev && lev>=crslev); }
   inline const int guContains(const int minlev, const int maxlev) const
        { return (minlev<=finelev && maxlev>=crslev); }

   inline const int guLevIndex(const int lev) const
        { return ((lev-minlev)/levstep); }

   inline void guSetIndex(const int idx) { index = idx; }
   inline void guSetOwner(const int p) { owner = p; }

   inline const dMapIndex& guBaseIndex(void) const { return (baseindex); }
   inline const dMapIndex& guLowIndex(void) const { return (lowindex); }

   inline void guSetLowIndex(const dMapIndex& li) { lowindex = li; }

   dMapIndex guTopIndex(const int lev) const;
   dMapIndex guMaxIndex(const int lev) const;

   void guLCoords(unsigned *c, const int lev) const;
   Coords guLCoords(const int lev) const;

   void guUCoords(unsigned *c, const int lev) const;
   Coords guUCoords(const int lev) const;

   void guSetBBox(); 
   inline void guSetMergedBBox(const BBox& bb) { mbb = bb; }

public:
   BBox guBBox(const int lev, const int olap=0, const int extgh=0) const;
   BBox guBBoxAbs(const int lev, const int olap=0, const int extgh=0) const;
   BBox guMergedBBox(const int lev, const int olap=0, const int extgh=0) const;

   BBox guBBox(const int lev, const short* olap, const int extgh=0) const;
   BBox guBBoxAbs(const int lev, const short* olap, const int extgh=0) const;
   BBox guMergedBBox(const int lev, const short* olap, const int extgh=0) const;

   BBox guBBox(const int minl, const int maxl,
	       const short* olap, const int extgh=0) const;
   BBox guMergedBBox(const int minl, const int maxl,
		     const short* olap, const int extgh=0) const;

   int guInside(const BBox& bbox, const int lev) const;

   /* GridUnit domain calculus  */
   int operator== (GridUnit const &other) const;
   int operator>= (GridUnit const &other) const;
   int operator<= (GridUnit const &other) const;

   /* Operations on a GridUnit */
   void guRefine(const int levs = 1);
   void guRefine(GridUnit &gu, const int levs = 1);

   void guCoarsen(const int levs = 1);
   void guCoarsen(GridUnit &gu, const int levs = 1);

   void guDecompose(GridUnit**& gu, int& cnt, const int levs = 1) const;
   void guDecomposeReplicate(GridUnit**& gu, int& cnt, const int minext, 
					const int levs = 1) const;
   // An operator I would like to have
   //void guRecompose(GridUnit**& gu, const int cnt) const;

   void guGetLevels(GridUnit** &gu) const;
   void guGetLevels(GridUnit &gu, const int lev) const;

   /* 
   // Returns an array of neighbors with the assumption
   // that the neighbors are at the same level and "this"
   */

   inline const int guFaces(void) const
      { return ( dim*2 ) ; }
   inline const int guCorners(void) const
      { return ( (dim == 3) ? 8 : (dim == 2) ? 4 : 0 ); }
   inline const int guEdges(void) const
      { return ( (dim == 3) ? 12 : (dim == 2) ? 0 : 0 ); }

   void guGetNeighbors(dMapIndex** &neighbors, const int lev) const;
   void guGetNeighbors(dMapIndex** &neighbors, int &cnt, const int lev,
                       const int dir, const int next) const;
   void guGetNeighbors(dMapIndex** &neighbors, int &cnt, const int lev, const int dir, 
		   dMapIndex const &hisindex, const int hisext, const int next) const;

   void guGetCorners(dMapIndex** &corners, const int lev) const;
   void guGetCorners(dMapIndex** &corners, int &cnt, const int lev,
                     const int dir, const int next) const;
   void guGetCorners(dMapIndex** &corners, int &cnt, const int lev, const int dir, 
		   dMapIndex const &hisindex, const int hisext, const int next) const;
  
   void guGetEdges(dMapIndex** &edges, const int lev) const;
   void guGetEdges(dMapIndex** &edges, int &cnt, const int lev,
                   const int dir, const int next) const;
   void guGetEdges(dMapIndex** &edges, int &cnt, const int lev, const int dir, 
		   dMapIndex const &hisindex, const int hisext, const int next) const;
  };

#ifdef __ENABLE_INLINE__
#include "GridUnit.inline"
#endif

ostream&  operator << (ostream& os, const GridUnit& gu);
ofstream& operator << (ofstream& ofs, const GridUnit& gu);
ifstream& operator >> (ifstream& ifs, GridUnit& gu);

#endif
