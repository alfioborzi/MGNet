/*
*************************************************************************
*                                                                       *
* class GridTable							*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

/*
*************************************************************************
*                                                                       *
* GridTable.C                                                        	*
*                                                                       *
*************************************************************************
*/


#include "GridTable.h"

/***************************************************************************/
/* struct TableEntry */
/***************************************************************************/
ostream& operator<<(ostream& os, const struct TableEntry& te)
  {
   if (&te == TableEntryNULL) return os;

   if (!te.am_decomp) os << *te.entry;
   else os << *te.array;
   os << "\n";

   return os;
  }

/***************************************************************************/
/* class GridTableEntry */
/***************************************************************************/
GridDataBucketVoid* GridTableEntry::_nulldata = GridDataBucketVoidNULL;

GridTableEntry::GridTableEntry(const GridUnit& gu, 
                               const int maxi, const int ntsteps)
	: index(gu.guIndex()), owner(gu.guOwner()), 
          crslev(gu.guCrsLev()), crsext(gu.guExtent(gu.guCrsLev())), 
	  levstep(gu.guLevStep()), numlev(gu.guNumLev()), 
          numtsteps(ntsteps), maxindex(maxi), offset(0), data(0) 
  {
   register int const num = (numtsteps) * (numlev) ;
   data = new GridDataBucketVoid** [num];
   offset = new short* [num];
   for (register int i=0;i<num;i++) {
     data[i] = (GridDataBucketVoid **) NULL;
     offset[i] = (short *) NULL;
   }
  }

GridTableEntry::~GridTableEntry()
  {
   if (!data) return;
   const int num = (numtsteps) * (numlev) ;
   const int inters = (DAGHMaxAxis * DAGHMaxDirs * maxindex) + 1;
   for (register int i=0;i<num;i++) if (data[i]) {
     for (register int j=0;j<inters;j++) if (data[i][j]) {
       data[i][j]->free();
       data[i][j] = GridDataBucketVoidNULL;
     }
     delete [] data[i];
     delete [] offset[i];
   }
   delete [] data;
   delete [] offset;
  }

void GridTableEntry::allocate(const int id)
  {
   const int inters = (DAGHMaxAxis * DAGHMaxDirs * maxindex) + 1;
   assert (!data[id]);
   data[id] = new GridDataBucketVoid* [inters];
   offset[id] = new short [inters];
   for (register int j=0;j<inters;j++) {
     data[id][j] = GridDataBucketVoidNULL;
     offset[id][j] = DAGHNull;
   }
  }

void GridTableEntry::flush()
  {
   if (!data) return;
   const int num = (numtsteps) * (numlev) ;
   const int inters = (DAGHMaxAxis * DAGHMaxDirs * maxindex) + 1;

   for (register int i=0;i<num;i++) if (data[i]) {
     for (register int j=0;j<inters;j++) if (data[i][j]) {
       data[i][j]->free();
       data[i][j] = GridDataBucketVoidNULL;
       offset[i][j] = DAGHNull;
     }
   }
  }

void GridTableEntry::flush(const int t, const int l)
  {
   if (!data || !haslevel(l) || !hastime(t)) return;
   const int i1 = t*numlev + (l-crslev)/levstep;
   const int inters = (DAGHMaxAxis * DAGHMaxDirs * maxindex) + 1;
   for (register int j=0;j<inters;j++) if (data[i1] && data[i1][j]) {
     data[i1][j]->free();
     data[i1][j] = GridDataBucketVoidNULL;
     offset[i1][j] = DAGHNull;
   }
  }

void GridTableEntry::flush(const int t, const int l, const int id)
  {
   if (!data || !haslevel(l) || !hastime(t)) return;
   const int i1 = t*numlev + (l-crslev)/levstep;
   if (data[i1] && data[i1][id]) {
     data[i1][id]->free();
     data[i1][id] = GridDataBucketVoidNULL;
     offset[i1][id] = DAGHNull;
   }
  }

void GridTableEntry::flush(const int t, const int l, 
                           const int a, const int d)
  {
   if (!data || !haslevel(l) || !hastime(t)) return;
   const int i1 = t*numlev + (l-crslev)/levstep;
   const int i2 = a*(DAGHMaxDirs*maxindex) + d*(maxindex);

   for (register int m=0;m<maxindex;m++) if (data[i1] && data[i1][i2+m]) {
     data[i1][i2+m]->free();
     data[i1][i2+m] = GridDataBucketVoidNULL;
     offset[i1][i2+m] = DAGHNull;
   }
  }

GridDataBucketVoid*& GridTableEntry::operator () 
                     (const int t, const int l, 
                      const int id)
  {
   if (!haslevel(l) || !hastime(t)) return (_nulldata);
   const int i1 = t*numlev + (l-crslev)/levstep;
   if (!data[i1]) allocate(i1);
   GridDataBucketVoid*& gdb = data[i1][id];
   return (gdb);
  }

GridDataBucketVoid*& GridTableEntry::operator () 
                     (const int t, const int l, 
                      const int id, int& off)
  {
   if (!haslevel(l) || !hastime(t)) return (_nulldata);
   const int i1 = t*numlev + (l-crslev)/levstep;
   if (!data[i1]) allocate(i1);
   GridDataBucketVoid*& gdb = data[i1][id];
   off = offset[i1][id];
   return (gdb);
  }

GridDataBucketVoid*& GridTableEntry::operator () 
                     (const int t, const int l, 
                      const int a, const int d,
                      const int m)
  {
   if (!haslevel(l) || !hastime(t)) return (_nulldata);
   const int i1 = t*numlev + (l-crslev)/levstep;
   const int i2 = a*(DAGHMaxDirs*maxindex) + d*(maxindex) + m;
   if (!data[i1]) allocate(i1);
   GridDataBucketVoid*& gdb = data[i1][i2];
   return (gdb);
  }

GridDataBucketVoid*& GridTableEntry::operator () 
                     (const int t, const int l, 
                      const int a, const int d,
                      const int m, int& off)
  {
   if (!haslevel(l) || !hastime(t)) return (_nulldata);
   const int i1 = t*numlev + (l-crslev)/levstep;
   const int i2 = a*(DAGHMaxDirs*maxindex) + d*(maxindex) + m;
   if (!data[i1]) allocate(i1);
   GridDataBucketVoid*& gdb = data[i1][i2];
   off = offset[i1][i2];
   return (gdb);
  }

ostream& operator<<(ostream& os, const GridTableEntry& gte)
  {
   if (&gte == GridTableEntryNULL) return os;

   os << "[ GTE: ";
   os << "Idx:" << gte.index << " ";
   os << "Owner:" << gte.owner << " ";
   os << "CLev:" << gte.crslev << " ";
   os << "CExt:" << gte.crsext << " ";
   os << "Nlev:" << gte.numlev << " ";
   os << "LStep:" << gte.levstep << " ";
   os << "NTStep:" << gte.numtsteps << " ";
   os << "MaxIdx:" << gte.maxindex << " ";
   os << "]";

   return os;
  }

/***************************************************************************/
/* class GridTableArray */
/***************************************************************************/
GridTableArray::GridTableArray(const unsigned k, const unsigned short blev, 
                               const unsigned short ext, const int num)
	: key(k), baselev(blev), extent(ext), number(num), contents(0)
  {
   contents = new struct TableEntry[number];
   for (register int i=0;i<number;i++) {
     contents[i].am_decomp = 0;
     contents[i].entry = GridTableEntryNULL;
   }
  }
   
GridTableArray::~GridTableArray()
  {
   for (register int i=0;i<number;i++) {
     if(contents[i].am_decomp > 0) {
       if(contents[i].array) delete contents[i].array;
     }
     else {
       if(contents[i].entry) delete contents[i].entry;
     }
   }
   if (contents) delete [] contents;
  }

void GridTableArray::flush()
  {
   for (register int n=0;n<number;n++) {
     if(contents[n].am_decomp > 0) {
       if(contents[n].array) contents[n].array->flush();
     }
     else {
       if(contents[n].entry) contents[n].entry->flush();
     }
   }
  }

void GridTableArray::flush(const int t, const int l)
  {
   for (register int n=0;n<number;n++) {
     if(contents[n].am_decomp > 0) {
       if(contents[n].array) contents[n].array->flush(t,l);
     }
     else {
       if(contents[n].entry) contents[n].entry->flush(t,l);
     }
   }
  }

void GridTableArray::flush(const int t, const int l, const int i)
  {
   for (register int n=0;n<number;n++) {
     if(contents[n].am_decomp > 0) {
       if(contents[n].array) contents[n].array->flush(t,l,i);
     }
     else {
       if(contents[n].entry) contents[n].entry->flush(t,l,i);
     }
   }
  }

void GridTableArray::flush(const int t, const int l, 
                           const int a, const int d)
  {
   for (register int n=0;n<number;n++) {
     if(contents[n].am_decomp > 0) {
       if(contents[n].array) contents[n].array->flush(t,l,a,d);
     }
     else {
       if(contents[n].entry) contents[n].entry->flush(t,l,a,d);
     }
   }
  }

void GridTableArray::add(const GridUnit& gu, const int maxi, const int ntsteps)
  {
   const dMapIndex& gubindex = gu.guBaseIndex(); 
   const short gublev = gu.guBaseLev();

   if (number == 0) {
     baselev = gublev;
     extent = gublev;
     number = gubindex.GetCardinality(gublev);
     contents = new  TableEntry[number];
     for (register int i=0;i<number;i++) {
       contents[i].am_decomp = 0;
       contents[i].entry = GridTableEntryNULL;
     }
   }

   short blevdiff = gublev - baselev;

   if (blevdiff ==  0) {
     unsigned index = (baselev == 0 || extent == 0) ?
		0 : gubindex.sfcGetIndex(baselev,extent); 

     if (contents[index].am_decomp > 0 && contents[index].array)  {
       delete contents[index].array;
       contents[index].array = GridTableArrayNULL;
     }
     else if (contents[index].entry)  {
       delete contents[index].entry;
       contents[index].entry = GridTableEntryNULL;
     }
     contents[index].am_decomp = 0;
     contents[index].entry = new GridTableEntry(gu,maxi,ntsteps);
   }
   else if (blevdiff > 0) {
     unsigned index = (baselev == 0 || extent == 0) ?
		0 : gubindex.sfcGetIndex(baselev,extent); 

     if (contents[index].am_decomp > 0) {
       contents[index].array->add(gu,maxi,ntsteps);
     }
     else {
       if (contents[index].entry) {
         delete contents[index].entry;
         contents[index].entry = GridTableEntryNULL;
       }
       int const num = gubindex.GetCardinality(blevdiff);
       contents[index].am_decomp = blevdiff;
       contents[index].array = new GridTableArray(index,gublev,blevdiff,num);
       contents[index].array->add(gu,maxi,ntsteps);
     }
   }
   else if (blevdiff < 0) {
     TableEntry *oldcontents = contents;
     contents = 0;
     blevdiff = baselev - gublev;
     short newblev = gublev;
     short newext = extent - blevdiff;
     unsigned index = (newblev == 0 || newext == 0) ?
		0 : gubindex.sfcGetIndex(newblev,newext); 
     int const num = gubindex.GetCardinality(newext);
     int const numchild = gubindex.GetCardinality(blevdiff);
     contents = new TableEntry[num];
     for (register int i=0;i<num;i++) {
       if (i == index) {
         for (register int j=0;j<numchild;j++) {
           if (oldcontents[i*numchild+j].am_decomp > 0 && 
               oldcontents[i*numchild+j].array) {
             delete oldcontents[i*numchild+j].array;
             oldcontents[i*numchild+j].array = GridTableArrayNULL;
           }
           else if (oldcontents[i*numchild+j].entry) {
             delete oldcontents[i*numchild+j].entry;
             oldcontents[i*numchild+j].entry = GridTableEntryNULL;
           }
         }
         contents[i].am_decomp = 0;
         contents[i].entry = new GridTableEntry(gu,maxi,ntsteps);
       }
       else {
         contents[i].am_decomp = blevdiff;
         contents[i].array = new GridTableArray(i,baselev,blevdiff,numchild);
         for (register int j=0;j<numchild;j++) {
           contents[i].array->contents[j].am_decomp 
                                              = oldcontents[i*numchild+j].am_decomp;
	   if (contents[i].array->contents[j].am_decomp > 0) {
             contents[i].array->contents[j].array = oldcontents[i*numchild+j].array;
             oldcontents[i*numchild+j].array = GridTableArrayNULL;
           }
           else  {
             contents[i].array->contents[j].entry = oldcontents[i*numchild+j].entry;
             oldcontents[i*numchild+j].entry = GridTableEntryNULL;
           }
         }
       }
     }
     if (oldcontents) delete [] oldcontents;
     baselev = gublev;
     extent = newext;
     number = num;
   }
  }

int GridTableArray::find_baselev(dMapIndex const &bindex)
  {
   if (number == 0) return 0;

   const unsigned index = (baselev == 0 || extent == 0) ?
			0 : bindex.sfcGetIndex(baselev,extent); 

   if (contents[index].am_decomp > 0) 
       return (contents[index].array->find_baselev(bindex));
   else 
       return (baselev);
  }

GridTableEntry* GridTableArray::find(const dMapIndex& bindex)
  {
   if (number == 0) return GridTableEntryNULL;

   const unsigned index = (baselev == 0 || extent == 0) ?
			0 : bindex.sfcGetIndex(baselev,extent); 

   if (contents[index].am_decomp > 0) 
       return (contents[index].array->find(bindex));
   else 
       return (contents[index].entry);
  }

ostream& operator<<(ostream& os, const GridTableArray& gta)
  {
   if (&gta == GridTableArrayNULL) return os;

   os << "GridTableArray: ";
   os << "Key: " << gta.key << " ";
   os << "BLev: " << gta.baselev << " ";
   os << "Ext: " << gta.extent << " ";
   os << "Num: " << gta.number << " ";
   os << "[ \n";
   for (register int i=0; i<gta.number; i++)
    {
   	os << gta.contents[i];
    }
   os << "]";

   return os;
  }

/***************************************************************************/
/* clas GridTable */
/***************************************************************************/
List<GridDataBucketVoid*>* GridTable::_nulldata = (List<GridDataBucketVoid*>*) NULL;

GridTable::GridTable(const int gf, GridUnitList& complist, 
                     const int maxi, const int ntsteps)
 	: gfid(gf), gtinside(DAGHMaxAxis*DAGHMaxDirs*maxi),
          numtsteps(ntsteps), data(0)

  {
    register GridUnit* gu = complist.first();
    for(;gu!=GridUnitNULL;gu=complist.next()) 
      table.add(*gu,maxi,numtsteps);
  
    data = new List<GridDataBucketVoid*>[numtsteps];
  }

void GridTable::construct(GridUnitList& complist, 
                          const int maxi, 
                          const int ntsteps)
  {
    gtinside = DAGHMaxAxis*DAGHMaxDirs*maxi;
    numtsteps = ntsteps;
    register GridUnit *gu = complist.first();
    for(;gu!=GridUnitNULL;gu=complist.next()) 
      table.add(*gu,maxi,numtsteps);

    data = new List<GridDataBucketVoid*>[numtsteps];
  }

void GridTable::flushdata()
  {
    for (register int t=0;t<numtsteps;t++) {
      GridDataBucketVoid** gdbv;
      DAGHListLoop(data[t],gdbv,GridDataBucketVoid*)
        if (*gdbv) delete *gdbv;
        *gdbv = 0;
      DAGHEndLoop
      data[t].empty();
    }
  }

void GridTable::flushdata(const int t)
  {
    GridDataBucketVoid** gdbv;
    DAGHListLoop(data[t],gdbv,GridDataBucketVoid*)
      if (*gdbv) delete *gdbv;
      *gdbv = 0;
    DAGHEndLoop
    data[t].empty();
  }

ostream& operator<<(ostream& os, const GridTable& gt)
  {
   if (&gt == GridTableNULL) return os;

   os << "GridTable: " << "(" << gt.gfid << ") ";
   os << "[  \n";
   os << gt.table;
   os << "]";

   return os;
  }
