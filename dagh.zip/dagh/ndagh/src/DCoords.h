#ifndef _included_DCoords_h
#define _included_DCoords_h

/*
*************************************************************************
*									*
* DCoords.h								*
*									*
* This class implements the double precision coordinates of a point in 	*
* the computational domain.            					*
* This class is sort of an adaptation and extension of the from Class   *
* PointX of LPARX developed by  Scott Kohn (skohn-at-cs.ucsd.edu)       *
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)			*
*									*
*************************************************************************
*/

#include "lparx_copyright.h"
#include <iostream.h>
#include <assert.h>

#define DCoordsMaxDim	(3)

#define DCoordsNULL	((DCoords *)NULL)

class DCoords
  {
   friend istream& operator >> (istream& s, DCoords& c);
   friend ostream& operator << (ostream& s, const DCoords& c);

   double c[DCoordsMaxDim];

public:
   int rank;
   static class DCoords _empty_dcoords;

public:
   inline DCoords(void) : rank(0) 
     { c[0] = 0.0; c[1] = 0.0; c[2] = 0.0; }
   inline DCoords(int const r) : rank(r) 
     { c[0] = 0.0; c[1] = 0.0; c[2] = 0.0; }
   inline DCoords(int const r, double const val) : rank(r)
     { c[0] = val; c[1] = val; c[2] = val; }

   inline DCoords(int const r, double const *val) : rank(r)
     { register int i; for (i=0; i<rank; i++) c[i] = val[i]; }

   inline DCoords(DCoords const &other) : rank(other.rank)
     { c[0] = other.c[0]; c[1] = other.c[1]; c[2] = other.c[2]; }

   /* Specific constructors for 2 & 3 D */
   inline DCoords(int const r, double const i, double const j) : rank(r) 
     { assert(r == 2); c[0] = i; c[1] = j; }
   inline DCoords(int const r, double const i, double const j, double const k) : rank(r) 
     { assert(r == 3); c[0] = i; c[1] = j; c[2] = k; }

   inline DCoords &operator = (DCoords const &rhs)
     {
       rank = rhs.rank,
       c[0] = rhs.c[0]; c[1] = rhs.c[1]; c[2] = rhs.c[2];
       return *this;
     }

   inline ~DCoords() {}

   /* Some simple operators on DCoords -- const and non-const ones */
   
   inline double& operator () (int const i) { return(c[i]); }
   inline double operator () (int const i) const { return(c[i]); }

   inline double * operator () (void) { return(c); }
   inline double const *operator () (void) const { return(c); }

   inline operator double * () { return(c); }
   inline operator const double * () const { return(c); }

   /* Define all of the operators between two DCoords */
#define Point_Point_Operator(ope,op)                            \
   DCoords& operator ope (DCoords const &rhs)                   \
     {                                                          \
      c[0] ope rhs.c[0];                                        \
      if (rank>1) c[1] ope rhs.c[1];                            \
      if (rank>2) c[2] ope rhs.c[2];                            \
      return(*this);                                            \
     }                                                          \
   DCoords operator op (DCoords const &rhs) const               \
     {                                                          \
      DCoords coords(*this);                                    \
      coords ope rhs;                                           \
      return(coords);                                           \
     }
   Point_Point_Operator(+=,+)
   Point_Point_Operator(-=,-)
   Point_Point_Operator(*=,*)
   Point_Point_Operator(/=,/)
#undef Point_Point_Operator

   /* Define all of the operators between a DCoords and an integer */
#define Point_Scalar_Operator(ope,op)                           \
   DCoords& operator ope (double const rhs)                     \
     {                                                          \
      c[0] ope rhs;                                             \
      if (rank>1) c[1] ope rhs;                                 \
      if (rank>2) c[2] ope rhs;                                 \
      return(*this);                                            \
     }                                                          \
   DCoords operator op (double const rhs) const                 \
     {                                                          \
      DCoords coords(*this);                                    \
      coords ope rhs;                                           \
      return(coords);                                           \
     }
   Point_Scalar_Operator(+=,+)
   Point_Scalar_Operator(-=,-)
   Point_Scalar_Operator(*=,*)
   Point_Scalar_Operator(/=,/)
#undef Point_Scalar_Operator

   /* Define the negation operator for a DCoords */
   inline DCoords operator - () const
     {
       DCoords coords(rank);
       coords.c[0] = -c[0]; coords.c[1] = -c[1]; coords.c[2] = -c[2];
       return(coords);
     }

   /* Define the equality and inequality operators for DCoords */
   inline int operator != (DCoords const &rhs) const
     {
      return ( ((rank > 0) && (c[0] != rhs.c[0])) ||
               ((rank > 1) && (c[1] != rhs.c[1])) ||
               ((rank > 2) && (c[2] != rhs.c[2]))
             ) ;
     }
   inline int operator == (DCoords const &rhs) const
     { return(!(*this != rhs)); }

   /* Define the greater-than & less-than operators for DCoords */
   inline int operator > (DCoords const &rhs) const
     {
      return (!(((rank > 0) && (c[0] <= rhs.c[0])) ||
               ((rank > 1) && (c[1] <= rhs.c[1])) ||
               ((rank > 2) && (c[2] <= rhs.c[2])))
             ) ;
     }
   inline int operator < (DCoords const &rhs) const
     {
      return (!(((rank > 0) && (c[0] >= rhs.c[0])) ||
               ((rank > 1) && (c[1] >= rhs.c[1])) ||
               ((rank > 2) && (c[2] >= rhs.c[2])))
             ) ;
     }

   inline void setval(double const val)
     { c[0] = val; c[1] = val; c[2] = val; }
   inline void setval(DCoords const &rhs)
     { c[0] = rhs.c[0]; c[1] = rhs.c[1]; c[2] = rhs.c[2]; }

   /* Define elementwise minimum and maximum functions for DCoords */
   inline void min(DCoords const &rhs)
     {
       c[0] = (rhs.c[0] < c[0]) ? rhs.c[0] : c[0];
       c[1] = (rank > 1 && rhs.c[1] < c[1]) ? rhs.c[1] : c[1];
       c[2] = (rank > 2 && rhs.c[2] < c[2]) ? rhs.c[2] : c[2];
     }

   inline void max(DCoords const &rhs)
     {
       c[0] = (rhs.c[0] > c[0]) ? rhs.c[0] : c[0];
       c[1] = (rank > 1 && rhs.c[1] > c[1]) ? rhs.c[1] : c[1];
       c[2] = (rank > 2 && rhs.c[2] > c[2]) ? rhs.c[2] : c[2];
     }

   inline DCoords getmin(DCoords const &rhs) const
     { DCoords other(*this); other.min(rhs); return other; }
   inline DCoords getmax(DCoords const &rhs) const
     { DCoords other(*this); other.max(rhs); return other; }
  };

inline DCoords max(const DCoords& a, const DCoords &b)
       { return(a.getmax(b)); }
inline DCoords min(const DCoords& a, const DCoords &b)
       { return(a.getmin(b)); }

#ifdef __ENABLE_INLINE__
#include "DCoords.inline"
#endif

ostream& operator << (ostream& s, const DCoords& c);
istream& operator >> (istream& s, DCoords& c);

#endif
