/*
*************************************************************************
*									*
* DCoords.C								*
*									*
* Author: Manish Parashar  <parashar@cs.utexas.edu>			*
*									*
*************************************************************************
*/

#include "DCoords.h"

#ifndef __ENABLE_INLINE__
#include "DCoords.inline"
#endif

#define MATCH(s, c) while ((s).get() != (c))

/*************************************************************************/
/* Static empty coords */
/*************************************************************************/
class DCoords DCoords::_empty_dcoords;
/*************************************************************************/

/*
*************************************************************************
*									*
* istream& operator >> (istream& s, DCoords& c)				*
*									*
* Operator >> reads in DCoords information in the form:			*
*									*
*			 (c(0),c(1), ... ,c(N)).			*
*									*
*************************************************************************
*/

istream& operator >> (istream& s, DCoords& c)
  {
   MATCH(s, '('); s >> c(0);
   register int i; for (i=1;i<c.rank;i++) MATCH(s, ','); s >> c(i);
   MATCH(s, ')');
   return(s); 
  }

/*
*************************************************************************
*                                                                       *
* ostream& operator << (ostream& s, const DCoords& c)                    *
*                                                                       *
* Operator << writes the point information in p in the form:            *
*                                                                       *
*                        (c(0),c(1), ..., c(N)).                        *
*                                                                       *
*************************************************************************
*/

ostream& operator << (ostream& s, const DCoords& c)
  {
   s << '(' << c(0);
   for (register int i=1;i<c.rank;i++) s << ',' << c(i);
   s << ')';
   return(s);
  }
