#ifndef _included_ObjectCounter_h
#define _included_ObjectCounter_h

/*
*************************************************************************
*									*
* ObjectCounter.h							*
*									*
* Class ObjectCounter provides a reference counting base class.  The	*
* class counts the number of references to itself and destroys itself	*
* when the count goes to zero.  Subclasses should be manipulated as	*
* follows:								*
*									*
*	class CountedClass : public ObjectCounter { ... }		*
*									*
*	CountedClass *x = new CountedClass(...);			*
*	CountedClass *y = (CountedClass *) x->alias();			*
*	x->free();							*
*	y->free();							*
*									*
* To aviod forcing the case on alias(), define an alias() in the	*
* subclass which does the cast for you.					*
*									*
* Author:  Scott Kohn (skohn@cs.ucsd.edu)				*
*									*
*************************************************************************
*/

class ObjectCounter
  {
   int references;
public:
   inline ObjectCounter() : references(1) { }
   inline ObjectCounter *alias() { references++; return(this); }
   inline void free() { if (--references == 0) delete this; }
   // Make sure all the derived classes have their destructors;
   inline virtual ~ObjectCounter() { }
  };

#endif
