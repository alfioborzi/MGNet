#ifndef _included_GridDataOps_3_h
#define _included_GridDataOps_3_h

/*
*************************************************************************
*                                                                       *
* GridDataOps3.h                                                        *
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

template <class Type>
void GridData(3)<Type>::lin_interp (GridData(3)<Type> const &gd1, double const frac1,
                   GridData(3)<Type> const &gd2, double const frac2,
                   BBox const &where)
  {
   BBox intersection = _bbox * gd1._bbox * gd2._bbox * where;
   if (!intersection.empty())
    {
     //int max_step = (_step > gd1._step) ? _step : 
     //		(gd1._step > gd2._step) ? gd1._step : gd2._step;

     Coords max_step = max(_step, gd1._step);
     max_step.max(gd2._step);

     GridData(3)<Type> &dst = *this;

     BeginFastIndex3(src1, gd1._bbox, gd1._data, const Type);
     BeginFastIndex3(src2, gd2._bbox, gd2._data, const Type);
     BeginFastIndex3(dst, dst._bbox, dst._data, Type);

     for_3(i, j, k, intersection, max_step)
       FastIndex3(dst,i,j,k) = (Type)  ((FastIndex3(src1,i,j,k) * frac1)
			       + (FastIndex3(src2,i,j,k) * frac2));
     end_for

     EndFastIndex3(dst);
     EndFastIndex3(src1);
     EndFastIndex3(src2);
   }
  }

/**************************************************************************/

template <class Type>
void GridData(3)<Type>::equals (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(equal)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(3)<Type>::equals (GridData(3)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(equal)(gd, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(3)<Type>::plus (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(plus)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(3)<Type>::plus (GridData(3)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(plus)(gd, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(3)<Type>::minus (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(minus)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(3)<Type>::minus (GridData(3)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(minus)(gd, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(3)<Type>::multiply (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(mult)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(3)<Type>::multiply (GridData(3)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(mult)(gd, newto, newfrom, max_step);
     }
  }

template <class Type>
void GridData(3)<Type>::divide (Type const &val, BBox const &where)
  {
    BBox intersection = _bbox * where;
    if (!intersection.empty())
      {
       Coords max_step = max(_step, where.stepsize());
       BBox to(intersection); to.setstepsize(_step);
       BBox from(intersection); from.setstepsize(where.stepsize());
       gd_OperateRegion(div)(val, to, from, max_step);
      }
  }

template <class Type>
void GridData(3)<Type>::divide (GridData(3)<Type> const &gd, BBox const &to,
						BBox const &from)
  {
   const Coords  toshift = from.lower() - to.lower();
   BBox newfrom = gd._bbox * from * shiftabs(_bbox * to, toshift);
   if (!newfrom.empty())
     {
      BBox newto = shiftabs(newfrom, -toshift);
      Coords max_step = max(_step, gd._step);
      newto.setstepsize(_step);
      newfrom.setstepsize(gd._step);
      gd_OperateRegion(div)(gd, newto, newfrom, max_step);
     }
  }

/****************************** = ***************************************/

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(equal) (Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(3)<Type> &dst = *this;

   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      FastIndex3(dst,i,j,k) = val;
   end_for

   EndFastIndex3(dst);
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(equal) (GridData(3)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(3)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);
   const int dk = from.lower(2)-to.lower(2);

   BeginFastIndex3(src, src._bbox, src._data, const Type);
   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      FastIndex3(dst,i,j,k) = FastIndex3(src,i+di,j+dj,k+dk);
   end_for

   EndFastIndex3(dst);
   EndFastIndex3(src);
  }

/************************************************************************/

/****************************** + ***************************************/

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(plus)(Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(3)<Type> &dst = *this;

   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      FastIndex3(dst,i,j,k) += val;
   end_for

   EndFastIndex3(dst);
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(plus)(GridData(3)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(3)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);
   const int dk = from.lower(2)-to.lower(2);

   BeginFastIndex3(src, src._bbox, src._data, const Type);
   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      FastIndex3(dst,i,j,k) += FastIndex3(src,i+di,j+dj,k+dk);
   end_for

   EndFastIndex3(dst);
   EndFastIndex3(src);
  }

/************************************************************************/

/****************************** - ***************************************/

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(minus)(Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(3)<Type> &dst = *this;

   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      FastIndex3(dst,i,j,k) -= val;
   end_for

   EndFastIndex3(dst);
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(minus)(GridData(3)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(3)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);
   const int dk = from.lower(2)-to.lower(2);

   BeginFastIndex3(src, src._bbox, src._data, const Type);
   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      FastIndex3(dst,i,j,k) -= FastIndex3(src,i+di,j+dj,k+dk);
   end_for

   EndFastIndex3(dst);
   EndFastIndex3(src);
  }

/************************************************************************/

/****************************** * ***************************************/

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(mult)(Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(3)<Type> &dst = *this;

   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      FastIndex3(dst,i,j,k) *= val;
   end_for

   EndFastIndex3(dst);
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(mult)(GridData(3)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(3)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);
   const int dk = from.lower(2)-to.lower(2);

   BeginFastIndex3(src, src._bbox, src._data, const Type);
   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      FastIndex3(dst,i,j,k) *= FastIndex3(src,i+di,j+dj,k+dk);
   end_for

   EndFastIndex3(dst);
   EndFastIndex3(src);
  }

/************************************************************************/

/****************************** / ***************************************/

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(div)(Type const &val, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   assert (val != (Type)0);
   GridData(3)<Type> &dst = *this;

   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      FastIndex3(dst,i,j,k) /= val;
   end_for

   EndFastIndex3(dst);
  }

template <class Type>
void GridData(3)<Type>::gd_OperateRegion(div)(GridData(3)<Type> const &src, 
			BBox const &to, BBox const &from, Coords const &step)
  {
   GridData(3)<Type> &dst = *this;
   const int di = from.lower(0)-to.lower(0);
   const int dj = from.lower(1)-to.lower(1);
   const int dk = from.lower(2)-to.lower(2);

   BeginFastIndex3(src, src._bbox, src._data, const Type);
   BeginFastIndex3(dst, dst._bbox, dst._data, Type);

   for_3(i, j, k, to, step)
      FastIndex3(dst,i,j,k) /= FastIndex3(src,i+di,j+dj,k+dk);
   end_for

   EndFastIndex3(dst);
   EndFastIndex3(src);
  }
/************************************************************************/

#endif
