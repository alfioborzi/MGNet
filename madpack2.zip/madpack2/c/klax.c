/***********************************************************************
*
* Subroutine KLAX    Compute y = Ax or y = y + Ax
*
* Key: n  integer     i  input        1  vector
*      r  real        o  output       2  matrix
*      d  real*8      s  scratch
*      c  character
*
* Type  Argument  Description
* ----  --------  -----------
* ri1   a         matrix stored in sparse form with nr rows, nc columns
* ni    addopt    addition option
*                    0  y = Ax
*                    1  y = y + Ax
* ni    atype     type of matrix
*                    0  symmetric
*                    1  nonsymmetric
*                    2  nonsymmetric (nonsymmetric zero structure)
*                    3  simple stencil
*                    4  complex stencil
*                 to compute with a-transpose, negate atype
* no    flag      return code
*                    0  no error
*                   -7  incorrect matrix type for matrix-vector multiply
* ni1   ija       pointers to rows of matrix followed by column indices
*                 of matrix
* ni    nc        number of columns in matrix
* ni    nr        number of rows in matrix
* ri1   x         input vector
* ro1   y         matrix-vector product
*
***********************************************************************/

#include "defnc.pre"

klax(addopt, nr, nc, ija, a, x, y, atype, flag)

        INT     *addopt, *atype, *flag, *ija, *nc, *nr;
        REAL    *a, *x, *y;
  {
  /*********************************************************************
  *----local variables */
  INT     i, iia, j, j1, j2, jj, k, lshift, ushift;
  REAL    aj1, *pa, *px, *py, s, s1, xi;
  /********************************************************************/

  *flag = 0;
  py = y;
  pa = a;
  px = x;

  switch (*atype) {

    /* square matrices with the new format */
    case 0:
    case 1:
    case -1:
      /* determine matrix index shifts */
      ushift = 0;
      lshift = 0;
      if (*atype == 1)  lshift = ija[*nc] - *ija;
      if (*atype == -1) ushift = ija[*nc] - *ija;

      /* initialize product vector */
      if (*addopt)
        for (i = 0; i < *nc; i++)
          *py++ += (*pa++ * *px++);
      else
        for (i = 0; i < *nc; i++)
          *py++ = *pa++ * *px++;

      /* main loop */
      py = y;
      px = x;
      for (i = 0; i < *nc; i++) {
        xi = *px++;
        j2 = ija[i+1] - 1;
        s = 0.;
        for (jj = ija[i] - 1; jj < j2; jj++) {
          j = ija[jj] - 1;
          s += (a[jj+lshift] * x[j]);

          /* outer product update */
          y[j] += (a[jj+ushift] * xi);
          }

        /* inner product update */
        *py++ += s;
        }
      break;

    /* use a (old sparse format) */
    case 2:
      for (i = 0; i < *nr; i++) {
        if (*addopt)
          s = *py + *pa++ * *px++;
        else
          s = *pa++ * *px++;
        j2 = ija[i+1] - 1;
        for (j = ija[i] - 1; j < j2; j++)
          s += (a[j] * x[ija[j]-1]);
        *py++ = s;
        }
      break;

    /* use a transpose (old sparse format) */
    case -2:
      if (*addopt)
        for (i = 0; i < *nr; i++)
          *py++ += (*pa++ * *px++);
      else {
        for (i = 0; i < *nr; i++)
          *py++ = *pa++ * *px++;
        for (i = *nr; i < *nc; i++)
          *py++ = 0.;
        }
      px = x;
      for (i = 0; i < *nr; i++) {
        xi = *px++;
        j2 = ija[i+1] - 1;
        for (jj = ija[i] - 1; jj < j2; jj++) {
          j = ija[jj] - 1;
          y[j] += (a[jj] * xi);
          }
        }
      break;

    /* simple stencil format */
    case 3:
      iia = *ija;
      j = 0;
      for (i = 0; i < *nr; i++) {
        if (*addopt)
          s = *py;
        else
          s = 0.;
        j1 = ija[iia+i];
        j2 = j1 + ija[j1-1];
        for (jj = j1; jj < j2; jj++)
          s += (a[jj] * x[j+ija[jj]]);
        *py++ = s;
        j += ija[j2];
        }
      break;

    /* use a transpose (simple stencil format) */
    case -3:
      iia = *ija;
      if (*addopt == 0)
        for (i = 0; i < *nc; i++)
          *py++ = 0.;
      j = 0;
      for (i = 0; i < *nr; i++) {
        xi = *px++;
        j1 = ija[iia+i];
        j2 = j1 + ija[j1-1];
        for (jj = j1; jj < j2; jj++) {
          k = j + ija[jj];
          y[k] += (a[jj] * xi);
          }
        j += ija[j2];
        }
      break;

    /* complex stencil format */
    case 4:
      iia = *ija;
      j = 0;
      for (i = 0; i < *nr; i++) {
        if (*addopt)
          s = *py;
        else
          s = 0.;
        j1 = ija[iia+i];
        j2 = j1 + ija[j1-1];
        while (j1 < j2) {
          s1 = 0;
          aj1 = a[j1-1];
          for (jj = j1; jj < j2; jj++) {
            s1 += (aj1 * x[j+ija[jj]]);
            }
          s += s1;
          j1 = j2 + 1;
          j2 = j1 + ija[j2];
          }
        *py++ = s;
        j += ija[j2];
        }
      break;

    /* use a transpose (complex stencil format) */
    case -4:
      iia = *ija;
      if (*addopt == 0)
        for (i = 0; i < *nc; i++)
          *py++ = 0.;
      j = 0;
      for (i = 0; i < *nr; i++) {
        xi = *px++;
        j1 = ija[iia+i];
        j2 = j1 + ija[j1-1];
        while (j1 < j2) {
          s1 = a[j1-1] * xi;
          for (jj = j1; jj < j2; jj++) {
            k = j + ija[jj];
            y[k] += s1;
            }
          j1 = j2 + 1;
          j2 = j1 + ija[j2];
          }
        j += ija[j2];
        }
      break;

    /* illegal matrix type */
    default:
      *flag = -7;
      break;
    }
  }
