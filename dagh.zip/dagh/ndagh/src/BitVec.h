#ifndef _included_BitVec_h
#define _included_BitVec_h

/*
*************************************************************************
*                                                                       *
* This class has been modified to have a fix maxlen of the bitvector    *
* so that it does not need dynamic allocations.                         *
*                                                                       *
*************************************************************************
*/

/*
*************************************************************************
*                                                                       *
* BitVec.h                                                              *
*                                                                       *
* Class BitVec defines a bit-vector as an array of BitVecType.          *
* Bit are numbered from O; i.e. The MSB of BitVec[0] is bit 0 and the   *
* LSB of BitVec[Dim-1] is bit NBit-1 where NBit=Sizeof(BitVecType)*Dim. *
* 									*
* Operations on the bit vector include testing/setting and toggleing a  *
* set of bits corresponding to a digit and isolating the bits.		*
*                                                                       *
* Author:  Manish Parashar (parashar@cs.utexas.edu)                     *
*                                                                       *
*************************************************************************
*/

#include <limits.h>
#include <iostream.h>
#include <assert.h>

#ifndef ByteWidth
#define ByteWidth (8)
#endif

/* typedef unsigned char BitVecType; */
typedef unsigned BitVecType;

#define MaxBitVecSlots (4)

class BitVec
  {

   int length;
   short int slots;
   short int slot_width;
   BitVecType bvec[MaxBitVecSlots];

private:

   inline int GetSlot(const int loc) const
	{return loc/slot_width;}
   inline unsigned MaskBit(const int loc) const
	{return (unsigned)1 << (slot_width-(loc%slot_width)-1);}

public:

   inline BitVec()
	: length(0), slots(0)
	{slot_width = (sizeof(BitVecType)*ByteWidth);}

   BitVec(const int len);
   BitVec(BitVec const &other);

   inline ~BitVec() {}

   BitVec const &operator= (BitVec const &other);

   int operator==(BitVec const &other) const;
   int operator!=(BitVec const &other) const;
   int operator>(BitVec const &other) const;
   int operator<(BitVec const &other) const;
   int operator>=(BitVec const &other) const;
   int operator<=(BitVec const &other) const;

   unsigned TestBit(const int loc) const;

   void SetBit(const int loc);
   void UnsetBit(const int loc);
   void ToggleBit(const int loc);
   void SwapBit(const int loc1, const int loc2);

   unsigned IsolateBit(const int loc, const int num=1) const;

   void ResetVec(void);
   void SetVec(void);

   inline int GetLength(void) const
	{return length;}
   inline int GetSlotWidth(void) const
	{return slot_width;}
   inline int GetSlots(void) const
	{return slots;}

  };

#ifdef __ENABLE_INLINE__
#include "BitVec.inline"
#endif

#endif
