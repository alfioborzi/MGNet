/***********************************************************************
*
* Subroutine KLDSNF  Numeric factorization for sparse Gaussian
*                    elimination
*
* Key: n  integer     i  input        1  vector
*      r  real        o  output       2  matrix
*      d  real*8      s  scratch
*      c  character
*
*      Argument  Description
*      --------  -----------
* ri1  a         matrix stored in sparse form, length na
* ni   atype     type of matrix
*                   0  symmetric
*                   1  nonsymmetric
*                  -1  nonsymmetric, solve with a transpose
* no   flag      information flag
*                   0  no error
*                  -1  illegal matrix type
*                  n+i zero pivot in row i
* ni   genjum    whether or not to generate ju and m vectors
*                   0  m and ju are user input and list is zeroed
*                   1  generate ju and m
* ni1  ija       pointers to columns of matrix followed by row indices
*                of matrix
* ns1  index     scratch vector for locations in u, size n
* nio1 ju        pointers to columns of factored matrix, size n+1
* no   jushft    matrix index shift parameter required by kldsss for
*                forward and backward solves
* no   lenu      amount of u vector used
* ns1  list      scratch vector for links in list, size n
* nio1 m         m(i) = the row number in column i of U of the first
*                nonzero in the factored matrix, size n
* ni   n         number of columns in matrix
* ns1  order     scratch vector for links in list, size n
* ro1  u         factored matrix stored in sparse form, size nju
*
***********************************************************************/

#include "defnc.pre"

kldsnf(n, a, ija, jushft, ju, u, m, order, list, index,
        atype, genjum, lenu, flag)

        INT     *atype, *flag, *genjum, *ija, *index, *ju, *jushft,
                *lenu, *list, *m, *n, *order;
        REAL    *a, *u;
  {
  /*********************************************************************
  *----local variables */
  INT     gjum, i, ij, iptr, j, j1, j2, jj, jj1, jj2, jk, jshift,
          k, kj, kk, ksave, l1, l2, len, ll, lshift, tail;
  REAL    sum, suml, usv;
  /********************************************************************/

  /* initialization */
  *flag = -1;
  *jushft = 0;
  if (*atype < -1 || *atype > 1) return;
  gjum = *genjum;

  /* generate ju and m for nonsymmetric matrices so we can get one of */
  /* the matrix index shifts correct                                  */
  if (abs(*atype) == 1 && *genjum == 1) {
    i = 1;
    kldsss(n, a, ija, jushft, ju, u, m, list, &sum, &sum, atype, &i,
           genjum, flag);
    if (*flag != 0) return;
    gjum = 2;
    }
  *flag = 0;

  /* initialize m and ju as well as order, list, and index */
  if (gjum == 1) {
    for (i = 0; i < *n; i++) {
      m[i] = -1;
      order[i] = -1;
      list[i] = -1;
      index[i] = -1;
      }
    *ju = *n + 2;
    ju[*n] = 0;
    }

  /* initialize order, list, and index only */
  else if (gjum == 2)
    for (i = 0; i < *n; i++) {
      order[i] = -1;
      list[i] = -1;
      index[i] = -1;
      }

  /* determine matrix index shifts */
  jshift = 0;
  lshift = 0;
  if (*atype != 0) jshift = ju[*n] - *ju;
  if (*atype == 1) lshift = ija[*n] - *ija;

  /* start initializing u for numeric factorization */
  for (i = 0; i < *n; i++)
    u[i] = a[i];

  /* main loop of computation (also long) */
  for (i = 0; i < *n; i++) {
    len = 0;
    order[i] = i;
    j1 = ija[i] - 1;
    j2 = ija[i+1] - 1;

    /* add edges to fillin list */
    iptr = ju[i] - 1;
    for (j = j1; j < j2; j++) {
      k = ija[j] - 1;
      kj = i;
      while (order[k] == -1) {
        while (1) {
          ksave = kj;
          kj = order[kj];
          if (k <= kj || kj == i) break;
          }
        order[k] = kj;
        order[ksave] = k;
        index[k] = iptr++;
        len++;
        if (m[k] == -1) m[k] = i;
        kj = ksave;
        k = m[k];
        }
      }
    if (gjum == 1) ju[i+1] = ju[i] + len;

    /* now clean up after each iteration */
    k = i;
    if (len == 0) goto L21;

    /* initialize column of u */
    jj1 = ju[i] - 1;
    jj2 = ju[i+1] - 1;
    for (jj = jj1; jj < jj2; jj++)
      u[jj] = 0.;
    for (jj = j1; jj < j2; jj++) {
      j = ija[jj] - 1;
      j = index[j];
      u[j+jshift] = a[jj+lshift];
      u[j] = a[jj];
      }
    for (jj = 0; jj < len; jj++) {
      k = order[k];
      if (k < i) {
        tail = k;
        list[k] = k;
        j1 = ija[k] - 1;
        j2 = ija[k+1] - 1;
        l1 = ju[k] - 1;
        l2 = l1 - 1;

        /* add edges to fillin list */
        for (j = j1; j < j2; j++) {
          kk = ija[j] - 1;
          while (list[kk] == -1) {
            list[tail] = kk;
            l2++;
            tail = kk;
            kk = m[kk];
            }
          list[tail] = k;
          }

        /* now use list to factor L and U-transpose */
        if (l2 >= l1) {
          sum = 0.;
          jk = list[k];

          /* symmetric matrix */
          if (*atype == 0) {
            for (ll = l1; ll <= l2; ll++) {
              ij = index[jk];
              if (ij >= 0) sum += (u[ll] * u[ij]);
              jk = m[jk];
              }
            ij = index[k];
            }

          /* nonsymmetric matrix */
          else {
            suml = 0.;
            for (ll = l1; ll <= l2; ll++) {
              ij = index[jk];
              if (ij >= 0) {
                sum += (u[ll+jshift] * u[ij]);
                suml += (u[ll] * u[ij+jshift]);
                }
              jk = m[jk];
              }
            ij = index[k];
            u[ij+jshift] -= suml;
            }
          u[ij] -= sum;
          }

        /* clean up list */
        kk = k;
        while (list[kk] != k) {
          ksave = kk;
          kk = list[kk];
          list[ksave] = -1;
          }
        list[kk] = -1;
        }
      }
    /* factor diagonal and then zero out order and index */
    k = i;
    sum = 0.;
    for (j = 0; j < len; j++) {
      ksave = k;
      k = order[k];
      kk = index[k];
      usv = u[kk+jshift];
      u[kk] *= u[k];
      u[kk+jshift] = usv * u[k];
      sum += (u[kk] * usv);
      order[ksave] = -1;
      index[ksave] = -1;
      }
    index[k] = -1;
    u[i] -= sum;
        
L21:if (u[i] != 0)
      u[i] = 1. / u[i];
    else {
      *flag = *n + i;
      return;
      }
    order[k] = -1;
    }

  /* calculate matrix shift index amount for kldsss and length of u */
  *jushft = ju[*n] - *ju;
  *lenu = *n + 1 + *jushft;
  if (abs(*atype) == 1)
    *lenu += *jushft;

  }
