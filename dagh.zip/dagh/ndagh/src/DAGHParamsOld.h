#ifndef _included_DAGHParamOld_h
#define _included_DAGHParamOld_h

/*@@
  @file     DAGHParamsOld.h
  @author   Manish Parashar
  @desc
      <pre>
 DAGHParamOld.h                                                        
                                                                       
      </pre>
  @enddesc
  @comment
      <code>
      $Id: DAGHParamsOld.h,v 1.7 1997/04/25 21:54:35 parashar Exp $
      </code>
  @endcomment
@@*/

/* DAGH Types */
#define CELL_CENTERED		(1)
#define NON_CELL_CENTERED 	(2)

/* GF Comm Flag */
#define NO_COMM			(DAGHNull)
#define COMM			(1)

/* GF Shadow Flag */
#define NO_SHADOW		(DAGHNull)
#define HAS_SHADOW		(1)

/* The Shadow Hierarchy */
#define BOTH_DAGHS		(-20)
#define MAIN 			(-21)
#define SHADOW			(-22)

#endif
