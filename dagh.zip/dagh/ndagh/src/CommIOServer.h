#ifndef _included_CommIOServer_h
#define _included_CommIOServer_h

/*
*************************************************************************
*                                                                       *
* class DAGHIOServerRcv							*
* class DAGHIOServerSnd							*
* class DAGHIOServerPing						*
*                                                                       *
* Author:  Manish Parashar <parashar@cs.utexas.edu>                     *
*                                                                       *
*************************************************************************
*/

#include "DAGHParams.h"
#include "DAGHIOParams.h"

#include "PackedGridDataBucket.h"

#include "CommServer.h"

#define DAGHIOServerRcvNULL 	((DAGHIOServerRcv *) NULL)
#define DAGHIOServerSndNULL 	((DAGHIOServerSnd *) NULL)
#define DAGHIOServerPingNULL 	((DAGHIOServerPing *) NULL)

class DAGHIOServerRcv : public comm_service 
  {
public:
   class GridHierarchy& gh;
   int Size;
   DAGHIO_WriteFunc wf;
   int end_cnt;

   DAGHIOServerRcv(const unsigned tag, GridHierarchy& gridherarchy, 
                   DAGHIO_WriteFunc writefunc);
   void callrecv( const MPI_Status & );
   void rcv_update( void * );
   inline void Set_DAGHIOWriteFunc(DAGHIO_WriteFunc writefunc) { wf = writefunc; }
   const char * name(void) const;
  };

class DAGHIOServerSnd : public comm_service 
  {
public:
   class GridHierarchy& gh;
   DAGHIO_ReadFunc rf;
   struct gdhdr Req;
   int Size;
   int end_cnt;

   DAGHIOServerSnd(const unsigned tag, GridHierarchy& gridherarchy, 
                   DAGHIO_ReadFunc readfunc);
   void callrecv( const MPI_Status & );
   void snd_update( struct gdhdr & );
   inline void Set_DAGHIOReadFunc(DAGHIO_ReadFunc readfunc) { rf = readfunc; }
   const char * name(void) const;
  };

class DAGHIOServerPing : public comm_service 
  {
   class GridHierarchy& gh;
   DAGHIO_PingFunc pf;
   int flag;
   int end_cnt;
public:
   DAGHIOServerPing(const unsigned tag, GridHierarchy& gridherarchy, 
                    DAGHIO_PingFunc pingfunc);
   void callrecv( const MPI_Status & );
   const char * name(void) const;
  };

#endif




























