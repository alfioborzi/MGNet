/* measure execution time in seconds */
/* Bill Mitchell 10/9/92             */
/*                                   */
/* Use unix routine"times"to measure */
/* user execution time between       */
/* calls to second in seconds.       */
/* Callable from FORTRAN and C.      */
/* Returns real                      */
/* in FORTRAN and float in C.        */

/* FORTRAN callable version */
static int holdtime,flagtime=1;
float second_()
{
/* just call C version */
   float second();
   return second();
}

/* C callable version */
float second()
{
#include <sys/types.h>
#include <sys/times.h>
#include <sys/param.h>
   clock_t times();
   clock_t t;
   struct tms t1;

/* call "times" */
   t=times(&t1);
   if (flagtime) {
      flagtime=0;
      holdtime=t;
   }
/* user time in 1/HZ seconds is in tms_utime */
/* HZ is in sys/param.h */
   return ((float)t1.tms_utime)/((float)HZ);
}
