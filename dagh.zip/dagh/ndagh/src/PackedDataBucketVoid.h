#ifndef _included_PackedDataBucketVoid_h
#define _included_PackedDataBucketVoid_h

/*
*************************************************************************
* PackedDataBucketVoid.h                           			*
*                              						*
*************************************************************************
*/

#include <iostream.h>
#include <assert.h>
#include <memory.h>

#ifdef DEBUG_PRINT_DBKT_MEMORY
#include "DAGHMemoryTrace.h"
#endif

struct dbkthdr 
  { unsigned headsize; unsigned datasize; short int cnt; };

struct dbkthdrdata 
  {
   unsigned headsize; unsigned datasize; short int cnt;
   unsigned data[1]; 
  };

union drecord 
  {
   struct dbkthdr head;
   struct dbkthdrdata rec;
  };
   
class DataBucketVoid
  {
   unsigned headsize;
   unsigned datasize;
   short cnt;
   unsigned *hs;
   unsigned *ds;
   union drecord *bkt;

private:
   DataBucketVoid(const DataBucketVoid&);	
   void operator = (const DataBucketVoid&);

public:
   inline DataBucketVoid(void)
	: headsize(0), datasize(0), cnt(0), hs(0), ds(0), bkt(0) {}

   DataBucketVoid(unsigned const hsize, unsigned const dsize);
   DataBucketVoid(unsigned *hsize, unsigned *dsize, int const n);
   DataBucketVoid(unsigned hsize, unsigned *dsize, int const n);
   DataBucketVoid(union drecord const *package);
   DataBucketVoid(union drecord *package);
   DataBucketVoid(union drecord const *package, int const n);

   inline ~DataBucketVoid(void) 
     { 

#ifdef DEBUG_PRINT_DBKT_MEMORY
      DAGHMemoryTrace::free(sizeof(unsigned)*cnt); // hs
      DAGHMemoryTrace::free(sizeof(unsigned)*cnt); // ds
      DAGHMemoryTrace::free(sizeof(char)*(headsize+datasize));
#endif

      if (hs) delete [] hs; 
      if (ds) delete [] ds;
      if (bkt) delete [] ((char *)bkt); 
     }

   inline short const num(void) const
	{ return (cnt); }
   inline short num(void) 
	{ return (cnt); }

   inline void *head(void)
	{ return ((void *) ((union drecord *)((char *)(bkt)+hs[0]))->rec.data); }
   inline void const *head(void) const
	{ return ((void *) ((union drecord *)((char *)(bkt)+hs[0]))->rec.data); }

   inline void *head(int const i)
	{ assert (i<cnt); 
          return ((void *) ((union drecord *)((char *)(bkt)+hs[i]))->rec.data); }
   inline void const *head(int const i) const
	{ assert (i<cnt);
          return ((void *) ((union drecord *)((char *)(bkt)+hs[i]))->rec.data); }

   inline void *data(void)
	{ return ((void *) ((char *)(bkt)+ds[0])); }
   inline void const *data(void) const
	{ return ((void *) ((char *)(bkt)+ds[0])); }

   inline void *data(int const i)
	{ assert (i<cnt);
          return ((void *) ((char *)(bkt)+ds[i])); }
   inline void const *data(int const i) const
	{ assert (i<cnt);
          return ((void *) ((char *)(bkt)+ds[i])); }

   inline void *pack(unsigned& size)
	{ size = headsize+datasize; return((void *) bkt); }
   inline void pack(void *&package, unsigned& size)
	{ size = headsize+datasize; package = (void *) bkt; }
  };

#endif
